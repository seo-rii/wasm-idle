define(["./boot", "./junk-drawer", "require"], (boot, $goodies, require) => {
    const globals = boot.globals,
        exports = {},
        extend = $goodies.extend,
        api = boot.api;

    // API

    exports.popupHelios = () => {
        require(['helios/index'], helios => {
            helios.popup();
        }, err => {
            window.alert(`Error loading helios.\nIf not present, you can install it with 'npm install @ambers/helios --save-dev'.\nThe error follows:\n${err}`);
        });
    };
    Object.defineProperty(exports, "api", {
        value: api,
        enumerable: true, configurable: true, writable: false
    });
    Object.defineProperty(exports, "globals", {
        value: globals,
        enumerable: true, configurable: true, writable: false
    });
    Object.defineProperty(exports, "$nil", {
        value: boot.nilAsReceiver,
        enumerable: true, configurable: true, writable: false
    });
    Object.defineProperty(exports, "nil", {
        value: boot.nilAsValue,
        enumerable: true, configurable: true, writable: false
    });

    function settingsInLocalStorage () {
        let storage;
        try {
            storage = 'localStorage' in globalThis && globalThis.localStorage;
        } catch (ex) {
            console.warn("Access denied to localStorage, " +
                "settings not loaded nor, subsequently, saved.");
            return;
        }

        if (storage) {
            let fromStorage;
            try {
                fromStorage = JSON.parse(storage.getItem('amber.SmalltalkSettings'));
            } catch (ex) {
                // pass
            }
            extend(globals.SmalltalkSettings, fromStorage || {});
            if (typeof window !== "undefined") {
                window.addEventListener('beforeunload', () => {
                    storage.setItem('amber.SmalltalkSettings', JSON.stringify(globals.SmalltalkSettings));
                });
            }
        }
    }

    exports.initialize = options => {
        return new Promise(resolve => {
            globals.SmalltalkSettings['transport.defaultAmdNamespace'] = "amber/core";
            api.amdRequire = require; // TODO better
            settingsInLocalStorage();
            extend(globals.SmalltalkSettings, options || {});
            resolve(api.initialize());
        });
    };

    exports.loadPackages = modules => {
        return new Promise((resolve, reject) => {
            require(modules, resolve, reject);
        }).then(() => globals.Smalltalk._postLoad());
    };

    exports.beClean = () => globals.Smalltalk._beClean();

    // Exports

    return exports;
});
