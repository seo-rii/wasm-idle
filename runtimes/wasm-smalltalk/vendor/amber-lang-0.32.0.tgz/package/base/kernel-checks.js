define(function () {
    "use strict";

    /* The JavaScript engine floor Amber runs on, stated once and probed below.
     Every probe names the edition that introduced what it needs and, for the
     semantic ones, the kernel mechanism that relies on it. All failures are
     collected and reported together, so that one look tells what to upgrade.

     Kept in ES5 syntax on purpose: this file has to run on an engine that is
     too old, in order to say so. */

    var FLOOR = "ES2020";
    var missing = [];

    function need (edition, feature, probe) {
        var ok, failure = "";
        try {
            ok = probe();
        } catch (e) {
            ok = false;
            failure = "; " + e;
        }
        if (!ok) missing.push(feature + " (" + edition + failure + ")");
    }

    /* APIs the kernel calls directly */

    need("ES2020", "globalThis", function () {
        return typeof globalThis === "object" && globalThis.Object === Object;
    });
    need("ES2015", "Promise", function () {
        return typeof Promise === "function" &&
            typeof Promise.resolve === "function" &&
            typeof Promise.reject === "function" &&
            typeof Promise.all === "function" &&
            typeof Promise.race === "function" &&
            typeof new Promise(function () {}).then === "function";
    });
    need("ES2015", "Object.setPrototypeOf", function () {
        var p = {x: 4, y: 5}, q = {x: 6};
        return Object.setPrototypeOf(q, p) === q && q.x === 6 && q.y === 5;
    });
    need("ES2015", "Number.isFinite / Number.isNaN", function () {
        return Number.isFinite(1) && !Number.isFinite("1") &&
            Number.isNaN(NaN) && !Number.isNaN("NaN");
    });
    need("ES2015", "Reflect.construct", function () {
        function Point (x) {
            this.x = x;
        }
        return Reflect.construct(Point, [4]).x === 4;
    });

    /* Semantics the object model is built on */

    // Method dictionaries and selector sets are Object.create(null) maps;
    // a key such as "hasOwnProperty" must not be found by inheritance.
    need("ES5", "prototype-less objects", function () {
        var p = {};
        return !("hasOwnProperty" in Object.create(null)) &&
            Object.getPrototypeOf(Object.create(null)) === null &&
            Object.getPrototypeOf(Object.create(p)) === p;
    });
    // The globals object is Object.create(globalThis) (see boot.js);
    // lookups of host globals must fall through to it.
    need("ES2020", "inheriting from globalThis", function () {
        return Object.create(globalThis).Object === Object;
    });
    // A send to 3 or "foo" reaches the method with `this` being the primitive
    // itself; sloppy-mode boxing would break every Number, String and Boolean
    // receiver.
    need("ES5 strict mode", "unboxed primitive `this`", function () {
        function me () {
            return this;
        }
        return me.apply(void 0) === void 0 && me.apply(null) === null &&
            me.apply(3) === 3 && me.apply("foo") === "foo" && me.apply(true) === true;
    });
    // MethodContext falls back to one shared frozen `locals` object;
    // a write must not leak into it.
    need("ES5", "Object.freeze", function () {
        var o = Object.freeze({});
        try {
            o.foo = "bar";
        } catch (e) {
            // strict mode throws here, which is also fine
        }
        return !("foo" in o);
    });

    if (missing.length) {
        throw new Error("Amber needs an " + FLOOR + "-capable JavaScript engine; " +
            "this one lacks: " + missing.join(", "));
    }
});
