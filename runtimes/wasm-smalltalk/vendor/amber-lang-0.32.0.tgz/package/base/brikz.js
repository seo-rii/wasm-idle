define([], () => {
    return function Brikz(api, apiKey, initKey, backupKey) {
        "use strict";

        let backup = {};
        apiKey = apiKey || 'exports';
        initKey = initKey || '__init__';
        backupKey = backupKey || 'backup';

        function mixin(src, target, what) {
            for (const key of Object.keys(what || src)) {
                if (src == null) {
                    target[key] = undefined;
                } else {
                    const value = src[key];
                    if (typeof value !== "undefined") {
                        target[key] = value;
                    }
                }
            }
            return target;
        }

        return function brikz() {
            Object.keys(backup).forEach(key => {
                mixin(null, api, (backup[key] || 0)[apiKey] || {});
            });
            const oapi = mixin(api, {}),
                order = [],
                chk = {};

            function ensure(key) {
                let b = brikz[key];
                const bak = backup[key];
                while (typeof b === "function") {
                    (b.deps || []).forEach(ensure);
                    b[backupKey] = bak;
                    mixin(null, api, api);
                    b = new b(brikz, api);
                }
                brikz[key] = b;
                if (b && !chk[key]) {
                    chk[key] = true;
                    order.push(b);
                }
                if (b && !b[apiKey]) {
                    b[apiKey] = mixin(api, {});
                }
            }

            Object.keys(brikz).forEach(ensure);
            mixin(oapi, mixin(null, api, api));
            order.forEach(brik => {
                mixin(brik[apiKey] || {}, api);
            });
            order.forEach(brik => {
                if (brik[initKey]) {
                    brik[initKey]();
                    if (brik[initKey].once) {
                        delete brik[initKey];
                    }
                }
            });
            backup = mixin(brikz, {});
        };
    };
});