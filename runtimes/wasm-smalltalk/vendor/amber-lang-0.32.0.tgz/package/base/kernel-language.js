/**
 * @typedef {Behavioral & {
 *     trait: true,
 *     category: string,
 *     traitUsers: Array<Trait | Behavior>,
 *     traitComposition?: TraitTransformation[]
 * }} Trait
 */

/**
 * @typedef {Behavioral & {
 *     fn: Function,
 *     superclass: Behavior,
 *     subclasses: Behavior[],
 *     slots: string[],
 *     a$cls: Behavior,
 *     traitComposition?: TraitTransformation[],
 *     category?: string,
 *     meta?: true,
 *     instanceClass?: Behavior,
 *     detachedRoot?: boolean
 * }} Behavior
 */

/**
 * @typedef {object} TraitTransformation
 * @property {Trait} trait
 * @property {Object<string, string>} [aliases]
 * @property {string[]} [exclusions]
 */

define(['./junk-drawer'], $goodies => {
    "use strict";

    const inherits = $goodies.inherits;
    const declareJsMethod = $goodies.declareJsMethod;
    const addElement = $goodies.addElement;
    const removeElement = $goodies.removeElement;
    const extend = $goodies.extend;
    const deleteKeysFrom = $goodies.deleteKeysFrom;

    MethodCompositionBrik.deps = ["methods"];

    function MethodCompositionBrik (brikz, st) {
        const setLocalMethods = brikz.methods.setLocalMethods;
        const updateMethod = brikz.methods.updateMethod;

        function aliased (selector, method) {
            const result = st.method(method, method.instantiateFn);
            if (method.selector !== selector) {
                result.selector = selector;
                result.source = `"Aliased as ${selector}"\n${method.source}`;
            }
            result.owner = method.owner;
            return result;
        }

        function fillTraitTransformation (traitTransformation, obj) {
            // assert(Object.getOwnProperties(obj).length === 0)
            const traitMethods = traitTransformation.trait.methods;
            Object.keys(traitMethods).forEach(selector => {
                obj[selector] = aliased(selector, traitMethods[selector]);
            });
            const traitAliases = traitTransformation.aliases;
            if (traitAliases) {
                Object.keys(traitAliases).forEach(aliasSelector => {
                    const aliasedMethod = traitMethods[traitAliases[aliasSelector]];
                    if (aliasedMethod) obj[aliasSelector] = aliased(aliasSelector, aliasedMethod);
                    // else delete obj[aliasSelector]; // semantically correct; optimized away
                });
            }
            const traitExclusions = traitTransformation.exclusions;
            if (traitExclusions) {
                deleteKeysFrom(traitExclusions, obj);
            }
            return obj;
        }

        function buildCompositionChain (traitComposition) {
            return traitComposition.reduce((soFar, each) => fillTraitTransformation(each, Object.create(soFar)), null);
        }

        /**
         * @param {TraitTransformation[]} traitComposition
         * @param {Trait | Behavior} traitOrBehavior
         */
        st.setTraitComposition = (traitComposition, traitOrBehavior) => {
            const oldLocalMethods = traitOrBehavior.localMethods,
                newLocalMethodsTemplate = Object.create(buildCompositionChain(traitComposition));
            setLocalMethods(traitOrBehavior, extend(newLocalMethodsTemplate, oldLocalMethods));
            (traitOrBehavior.traitComposition || []).forEach(each => {
                removeElement(each.trait.traitUsers, traitOrBehavior);
            });
            traitOrBehavior.traitComposition = traitComposition && traitComposition.length ? traitComposition : null;
            (traitOrBehavior.traitComposition || []).forEach(each => {
                addElement(each.trait.traitUsers, traitOrBehavior);
            });
        };

        function aliasesOfSelector (selector, traitAliases) {
            if (!traitAliases) return [selector];
            const result = Object.keys(traitAliases).filter(aliasSelector => traitAliases[aliasSelector] === selector);
            if (!traitAliases[selector]) result.push(selector);
            return result;
        }

        function applyTraitMethodAddition (selector, method, traitTransformation, obj) {
            const changes = aliasesOfSelector(selector, traitTransformation.aliases);
            changes.forEach(aliasSelector => {
                obj[aliasSelector] = aliased(aliasSelector, method);
            });
            const traitExclusions = traitTransformation.exclusions;
            if (traitExclusions) {
                deleteKeysFrom(traitExclusions, obj);
            }
            return changes;
        }

        function applyTraitMethodDeletion (selector, traitTransformation, obj) {
            const changes = aliasesOfSelector(selector, traitTransformation.aliases);
            deleteKeysFrom(changes, obj);
            return changes;
        }

        /**
         * @param {string} selector
         * @param {CompiledMethod | null} method
         * @param {Trait} trait
         * @param {Trait | Behavior} traitOrBehavior
         */
        function traitMethodChanged (selector, method, trait, traitOrBehavior) {
            const traitComposition = traitOrBehavior.traitComposition;
            let chain = traitOrBehavior.localMethods;
            const changes = [];
            for (let i = traitComposition.length - 1; i >= 0; --i) {
                chain = Object.getPrototypeOf(chain);
                const traitTransformation = traitComposition[i];
                if (traitTransformation.trait !== trait) continue;
                changes.push(...(method ?
                    applyTraitMethodAddition(selector, method, traitTransformation, chain) :
                    applyTraitMethodDeletion(selector, traitTransformation, chain)));
            }
            // assert(chain === null);
            changes.forEach(each => {
                updateMethod(each, traitOrBehavior);
            });
        }

        this.traitMethodChanged = traitMethodChanged;
    }

    function LanguageFactory (specialConstructors, emit) {
        function declareEvent (name) {
            declareJsMethod(emit, name);
        }

        TraitsBrik.deps = ["behaviorals", "methods", "composition", "root"];

        function TraitsBrik (brikz, st) {
            const SmalltalkObject = brikz.root.Object;
            const setupMethods = brikz.methods.setupMethods;
            const traitMethodChanged = brikz.composition.traitMethodChanged;
            const buildTraitOrClass = brikz.behaviorals.buildTraitOrClass;

            function SmalltalkTrait () {
            }

            specialConstructors.Trait = inherits(SmalltalkTrait, SmalltalkObject);

            SmalltalkTrait.prototype.trait = true;
            declareJsMethod(SmalltalkTrait.prototype, "toString");
            declareJsMethod(SmalltalkTrait.prototype, "added");
            declareJsMethod(SmalltalkTrait.prototype, "removed");
            declareJsMethod(SmalltalkTrait.prototype, "methodAdded");
            declareJsMethod(SmalltalkTrait.prototype, "methodRemoved");

            SmalltalkTrait.prototype.toString = function () {
                return `Smalltalk Trait ${this.name}`;
            };

            SmalltalkTrait.prototype.methodAdded = function (method) {
                propagateMethodChange(this, method.selector, method);
            };

            SmalltalkTrait.prototype.methodRemoved = function (method) {
                propagateMethodChange(this, method.selector, null);
            };

            function propagateMethodChange (trait, selector, method) {
                trait.traitUsers.forEach(each => {
                    traitMethodChanged(selector, method, trait, each);
                });
            }

            function traitBuilder (traitName, category) {
                return {
                    name: traitName,
                    make () {
                        const that = new SmalltalkTrait();
                        that.name = traitName;
                        that.category = category;
                        that.traitUsers = [];
                        setupMethods(that);
                        return that;
                    },
                    updateExisting (trait) {
                    }
                };
            }

            st.addTrait = (className, category) => buildTraitOrClass(traitBuilder(className, category));
        }

        ClassModelBrik.deps = ["root", "nil"];

        function ClassModelBrik (brikz, st) {
            const SmalltalkRoot = brikz.root.Root;
            const SmalltalkObject = brikz.root.Object;
            const nilAsReceiver = brikz.nil.nilAsReceiver;

            function SmalltalkBehavior () {
            }

            function SmalltalkClass () {
            }

            function SmalltalkMetaclass () {
            }

            this.newMetaclass = () => new SmalltalkMetaclass();

            specialConstructors.Behavior = inherits(SmalltalkBehavior, SmalltalkObject);
            specialConstructors.Class = inherits(SmalltalkClass, SmalltalkBehavior);
            specialConstructors.Metaclass = inherits(SmalltalkMetaclass, SmalltalkBehavior);

            SmalltalkMetaclass.prototype.meta = true;
            declareJsMethod(SmalltalkClass.prototype, "toString");
            declareJsMethod(SmalltalkMetaclass.prototype, "toString");
            declareJsMethod(SmalltalkClass.prototype, "added");
            declareJsMethod(SmalltalkClass.prototype, "removed");
            declareJsMethod(SmalltalkBehavior.prototype, "methodAdded");
            declareJsMethod(SmalltalkBehavior.prototype, "methodRemoved");

            SmalltalkClass.prototype.toString = function () {
                return `Smalltalk ${this.name}`;
            };

            SmalltalkMetaclass.prototype.toString = function () {
                return `Smalltalk Metaclass ${this.instanceClass.name}`;
            };

            declareEvent("classCreated");
            SmalltalkClass.prototype.added = function () {
                registerToSuperclass(this);
                emit.classCreated(this);
            };

            SmalltalkClass.prototype.removed = function () {
                unregisterFromSuperclass(this);
            };

            declareEvent("behaviorMethodAdded");
            SmalltalkBehavior.prototype.methodAdded = function (method) {
                emit.behaviorMethodAdded(method, this);
            };

            declareEvent("behaviorMethodRemoved");
            SmalltalkBehavior.prototype.methodRemoved = function (method) {
                emit.behaviorMethodRemoved(method, this);
            };

            // Fake root class of the system.
            // Effective superclass of all classes created with `nil subclass: ...`.
            const nilAsClass = this.nilAsClass = {
                fn: SmalltalkRoot,
                subclasses: [],
                a$cls: {fn: SmalltalkClass, methods: Object.create(null)}
            };

            this.bootstrapHierarchy = realClass => {
                nilAsClass.a$cls = realClass;
                nilAsClass.subclasses.forEach(each => {
                    each.a$cls.superclass = realClass;
                    Object.setPrototypeOf(each.a$cls.methods, realClass.methods);
                    registerToSuperclass(each.a$cls);
                });
            };

            function registerToSuperclass (klass) {
                addElement((klass.superclass || nilAsClass).subclasses, klass);
            }

            function unregisterFromSuperclass (klass) {
                removeElement((klass.superclass || nilAsClass).subclasses, klass);
            }

            /** @param {Behavior} metaclass */
            function metaSubclasses (metaclass) {
                return metaclass.instanceClass.subclasses
                    .filter(each => !each.meta)
                    .map(each => each.a$cls);
            }

            st.metaSubclasses = metaSubclasses;

            /**
             * @param {Behavior} klass
             * @param {(item: Behavior, sentinel: object) => unknown} fn
             */
            st.traverseClassTree = (klass, fn) => {
                const queue = [klass], sentinel = {};
                for (let i = 0; i < queue.length; ++i) {
                    const item = queue[i];
                    if (fn(item, sentinel) === sentinel) continue;
                    const subclasses = item.meta ? metaSubclasses(item) : item.subclasses;
                    queue.push(...subclasses);
                }
            };

            /**
             * This function is used all over the compiled amber code.
             * It takes any value (JavaScript or Smalltalk)
             * and returns a proper Amber Smalltalk receiver.
             *
             * null or undefined -> nilAsReceiver,
             * object having Smalltalk signature -> unchanged,
             * otherwise wrapped foreign (JS) object
             */
            this.asReceiver = o => {
                if (o == null) return nilAsReceiver;
                else if (o.a$cls != null) return o;
                else return st.wrapJavaScript(o);
            };
        }

        ClassConstructionBrik.deps = ["classModel", "behaviorals", "methods"];

        function ClassConstructionBrik (brikz, st) {
            const nilAsClass = brikz.classModel.nilAsClass;
            const newMetaclass = brikz.classModel.newMetaclass;
            const buildTraitOrClass = brikz.behaviorals.buildTraitOrClass;
            const setupMethods = brikz.methods.setupMethods;
            const removeTraitOrClass = brikz.behaviorals.removeTraitOrClass;

            declareEvent("slotsChanged");

            /**
             * @param {Behavior} klass
             * @param {string[]} slots
             */
            function setSlots (klass, slots) {
                slots.forEach(name => {
                    if (!name.match(/^[a-zA-Z][a-zA-Z0-9]*$/))
                        throw new Error(`Wrong identifier name: ${name}`);
                });

                klass.slots = slots;
                emit.slotsChanged(klass);
            }

            st.setSlots = setSlots;

            /* Smalltalk class creation. A class is an instance of an automatically
             created metaclass object. Newly created classes (not their metaclass)
             should be added to the system, see smalltalk.addClass().
             Superclass linking is *not* handled here, see api.initialize()  */

            function classBuilder (className, superclass, category, fn) {
                let logicalSuperclass = superclass;
                if (superclass == null || superclass.a$nil) {
                    superclass = nilAsClass;
                    logicalSuperclass = null;
                }

                function klass () {
                    const that = metaclass().instanceClass;

                    that.superclass = logicalSuperclass;
                    that.fn = fn || inherits(function () {
                    }, superclass.fn);
                    that.slots = [];

                    that.name = className;
                    that.category = category;
                    that.subclasses = [];

                    setupMethods(that);
                    return that;
                }

                function metaclass () {
                    const that = newMetaclass();

                    that.superclass = superclass.a$cls;
                    that.fn = inherits(function () {
                    }, that.superclass.fn);
                    that.slots = [];

                    that.instanceClass = new that.fn();

                    wireKlass(that);
                    setupMethods(that);
                    return that;
                }

                return {
                    name: className,
                    make: klass,
                    updateExisting (klass) {
                        if (logicalSuperclass == null && klass.superclass != null || logicalSuperclass != null && klass.superclass !== logicalSuperclass || fn != null && fn !== klass.fn)
                            throw new Error(`Incompatible change of class: ${klass.name}`);
                    }
                };
            }

            /** @param {Behavior} klass */
            function wireKlass (klass) {
                Object.defineProperty(klass.fn.prototype, "a$cls", {
                    value: klass,
                    enumerable: false, configurable: true, writable: true
                });
            }

            this.wireKlass = wireKlass;

            /* Add a class to the system, creating a new one if needed.
             A Package is lazily created if one with given name does not exist. */

            st.addClass = (className, superclass, category, legacyCategory) => {
                // TODO remove, backward compatibility (note: only deprecated as of this note)
                if (legacyCategory) {
                    const added = st.addClass(className, superclass, legacyCategory);
                    setSlots(added, category);
                    return added;
                }

                // While subclassing nil is allowed, it might be an error, so
                // warn about it.
                if (typeof superclass === 'undefined' || superclass && superclass.a$nil) {
                    console.warn(`Compiling ${className} as a subclass of \`nil\`. A dependency might be missing.`);
                }
                return buildTraitOrClass(classBuilder(className, superclass, category, specialConstructors[className]));
            };

            st.removeClass = removeTraitOrClass;
        }

        /* Making smalltalk that can load */

        function configure (brikz) {
            brikz.traits = TraitsBrik;
            brikz.composition = MethodCompositionBrik;
            brikz.classModel = ClassModelBrik;
            brikz.classConstruction = ClassConstructionBrik;

            brikz();
        }

        return {configure};
    }

    return LanguageFactory;
});
