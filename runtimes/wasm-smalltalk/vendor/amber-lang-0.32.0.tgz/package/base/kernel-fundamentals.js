/**
 * @typedef {object} MethodSpec
 * @property {string} selector
 * @property {string} protocol
 * @property {string[]} [args]
 * @property {string} [source]
 * @property {Array} [pragmas]
 * @property {string[]} [messageSends]
 * @property {string[]} [referencedClasses]
 * @property {Function} [fn]
 */

/**
 * @typedef {MethodSpec & {
 *     args: string[],
 *     messageSends: string[],
 *     referencedClasses: string[],
 *     instantiateFn?: (methodClass: Behavioral) => Function,
 *     owner?: Behavioral,
 *     methodClass?: Behavioral,
 *     jsSelector?: string
 * }} CompiledMethod
 */

/**
 * @typedef {object} Behavioral
 * @property {string} name
 * @property {Behavioral} [superclass]
 * @property {Object<string, CompiledMethod>} localMethods
 * @property {Object<string, CompiledMethod>} methods
 * @property {() => void} added
 * @property {() => void} removed
 * @property {(method: CompiledMethod) => void} methodAdded
 * @property {(method: CompiledMethod) => void} methodRemoved
 */

/**
 * @typedef {object} BehavioralBuilder
 * @property {string} name
 * @property {() => Behavioral} make
 * @property {(existing: Behavioral) => void} updateExisting
 */

define(['./junk-drawer'], $goodies => {
    "use strict";

    const inherits = $goodies.inherits;
    const declareJsMethod = $goodies.declareJsMethod;
    const addElement = $goodies.addElement;
    const removeElement = $goodies.removeElement;

    const hop = Object.prototype.hasOwnProperty;

    function SelectorsBrik (brikz, st) {
        const selectorSet = Object.create(null);
        const selectors = this.selectors = [];

        this.registerSelector = stSelector => {
            if (selectorSet[stSelector]) return false;
            selectors.push(stSelector);
            return selectorSet[stSelector] = true;
        };

        st.allSelectors = () => selectors;
    }

    function PackagesBrik (brikz, st) {
        st.packageDescriptors = {};

        /* Add a package load descriptor to the system */
        st.addPackage = (name, properties) => {
            if (!name) return null;
            return st.packageDescriptors[name] = {properties};
        };
    }

    function FundamentalsFactory (globals, emit) {
        const specialConstructors = Object.create(null);

        function declareEvent (name) {
            declareJsMethod(emit, name);
        }

        function RootBrik (brikz, st) {
            /* Smalltalk foundational objects */

            /* SmalltalkRoot is the hidden root of the normal Amber hierarchy.
             All objects including `ProtoObject` inherit from SmalltalkRoot.
             Detached roots (eg. wrapped JS classes like Number or Date)
             do not directly inherit from SmalltalkRoot, but employ a workaround.*/
            function SmalltalkRoot () {
            }

            function SmalltalkProtoObject () {
            }

            function SmalltalkObject () {
            }

            specialConstructors.ProtoObject = inherits(SmalltalkProtoObject, SmalltalkRoot);
            specialConstructors.Object = inherits(SmalltalkObject, SmalltalkProtoObject);

            this.Root = SmalltalkRoot;
            this.Object = SmalltalkObject;
        }

        BehavioralsBrik.deps = ["root"];

        function BehavioralsBrik (brikz, st) {
            /* Smalltalk classes and traits */

            const traitsOrClasses = [];

            /** @param {BehavioralBuilder} builder */
            this.buildTraitOrClass = builder => {
                const traitOrClass = hop.call(globals, builder.name) && globals[builder.name];
                if (traitOrClass) {
                    builder.updateExisting(traitOrClass);
                    return traitOrClass;
                } else {
                    return addTraitOrClass(builder.make());
                }
            };

            declareEvent("behavioralAdded");

            function addTraitOrClass (traitOrClass) {
                globals[traitOrClass.name] = traitOrClass;
                addElement(traitsOrClasses, traitOrClass);
                traitOrClass.added();
                emit.behavioralAdded(traitOrClass);
                return traitOrClass;
            }

            declareEvent("behavioralRemoved");

            /** @param {Behavioral} traitOrClass */
            function removeTraitOrClass (traitOrClass) {
                emit.behavioralRemoved(traitOrClass);
                traitOrClass.removed();
                removeElement(traitsOrClasses, traitOrClass);
                delete globals[traitOrClass.name];
                return traitOrClass;
            }

            this.removeTraitOrClass = removeTraitOrClass;

            st.traitsOrClasses = this.traitsOrClasses = traitsOrClasses;
        }

        MethodsBrik.deps = ["selectors", "root"];

        function MethodsBrik (brikz, st) {
            const registerSelector = brikz.selectors.registerSelector;
            const SmalltalkObject = brikz.root.Object;

            function SmalltalkMethod () {
            }

            specialConstructors.CompiledMethod = inherits(SmalltalkMethod, SmalltalkObject);

            /* Smalltalk method object. To add a method to a class,
             use api.addMethod() */

            /** @param {MethodSpec} spec */
            st.method = (spec, factory) => {
                const that = new SmalltalkMethod();
                that.selector = spec.selector;
                that.args = spec.args || [];
                that.protocol = spec.protocol;
                that.source = spec.source;
                that.pragmas = spec.pragmas;
                that.messageSends = spec.messageSends || [];
                // TODO remove .referencedClasses, have .referencedGlobals
                that.referencedClasses = spec.referencedClasses || [];
                that.fn = spec.fn;
                if (factory) that.instantiateFn = factory;
                return that;
            };

            /* Add/remove a method to/from a class */

            /**
             * @param {CompiledMethod} method
             * @param {Behavioral} traitOrBehavior
             */
            st.addMethod = (method, traitOrBehavior) => {
                if (method.owner != null) {
                    throw new Error(`addMethod: Method ${method.selector} already bound to ${method.owner}`);
                }
                method.owner = traitOrBehavior;
                registerNewSelectors(method);
                traitOrBehavior.localMethods[method.selector] = method;
                updateMethod(method.selector, traitOrBehavior);
            };

            declareEvent("selectorsAdded");

            function registerNewSelectors (method) {
                const newSelectors = [];

                function selectorInUse (stSelector) {
                    if (registerSelector(stSelector)) {
                        newSelectors.push(stSelector);
                    }
                }

                selectorInUse(method.selector);
                method.messageSends.forEach(selectorInUse);
                emit.selectorsAdded(newSelectors);
            }

            /**
             * @param {CompiledMethod} method
             * @param {Behavioral} traitOrBehavior
             */
            st.removeMethod = (method, traitOrBehavior) => {
                if (traitOrBehavior.localMethods[method.selector] !== method) return;

                delete traitOrBehavior.localMethods[method.selector];
                updateMethod(method.selector, traitOrBehavior);
            };

            /** @param {Behavioral} traitOrBehavior */
            this.setupMethods = traitOrBehavior => {
                traitOrBehavior.localMethods = Object.create(null);
                const superclass = traitOrBehavior.superclass;
                traitOrBehavior.methods = Object.create(superclass ? superclass.methods : null);
            };

            /**
             * @param {Behavioral} traitOrBehavior
             * @param {Object<string, CompiledMethod>} newLocalMethods
             */
            function setLocalMethods (traitOrBehavior, newLocalMethods) {
                const oldLocalMethods = traitOrBehavior.localMethods;
                traitOrBehavior.localMethods = newLocalMethods;
                let selector;
                for (selector in newLocalMethods) {
                    updateMethod(selector, traitOrBehavior);
                }
                for (selector in oldLocalMethods) {
                    updateMethod(selector, traitOrBehavior);
                }
            }

            this.setLocalMethods = setLocalMethods;

            declareEvent("methodReplaced");

            /**
             * @param {string} selector
             * @param {Behavioral} traitOrBehavior
             */
            function updateMethod (selector, traitOrBehavior) {
                let oldMethod;
                const newMethod = traitOrBehavior.localMethods[selector];
                const methods = traitOrBehavior.methods;
                if (hop.call(methods, selector)) {
                    oldMethod = methods[selector];
                    if (newMethod === oldMethod) return;
                } else {
                    if (newMethod == null) {
                        console.warn(`Removal of nonexistent method ${traitOrBehavior} >> ${selector}`);
                        return;
                    }
                    oldMethod = null;
                }
                if (newMethod != null) {
                    if (newMethod.methodClass && newMethod.methodClass !== traitOrBehavior) {
                        console.warn(`Resetting methodClass of ${newMethod.methodClass.name} >> ${selector} to ${traitOrBehavior.name}`);
                    }
                    newMethod.methodClass = traitOrBehavior;
                    methods[selector] = newMethod;
                    traitOrBehavior.methodAdded(newMethod);
                } else {
                    delete methods[selector];
                    traitOrBehavior.methodRemoved(oldMethod);
                }
                emit.methodReplaced(newMethod, oldMethod, traitOrBehavior);
            }

            this.updateMethod = updateMethod;
        }

        NilBrik.deps = ["root"];

        function NilBrik (brikz, st) {
            const SmalltalkObject = brikz.root.Object;

            function SmalltalkNil () {
            }

            specialConstructors.UndefinedObject = inherits(SmalltalkNil, SmalltalkObject);

            this.nilAsReceiver = new SmalltalkNil();
            this.nilAsValue = this.nilAsReceiver; // TODO null

            // Adds an `a$nil` property to the `nil` object.  When sending
            // nil objects from one environment to another, doing
            // `anObject == nil` (in JavaScript) does not always answer
            // true as the referenced nil object might come from the other
            // environment.
            Object.defineProperty(this.nilAsReceiver, 'a$nil', {
                value: true,
                enumerable: false, configurable: false, writable: false
            });
        }

        /* Making smalltalk that has basic building blocks */
        function configure (brikz) {
            brikz.root = RootBrik;
            brikz.nil = NilBrik;
            brikz.selectors = SelectorsBrik;
            brikz.packages = PackagesBrik;
            brikz.behaviorals = BehavioralsBrik;
            brikz.methods = MethodsBrik;

            brikz();
        }

        return {configure, specialConstructors};
    }

    return FundamentalsFactory;
});
