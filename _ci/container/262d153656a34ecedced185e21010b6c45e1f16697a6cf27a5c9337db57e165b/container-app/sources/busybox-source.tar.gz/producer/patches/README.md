# Selected BusyBox WASI patch boundary

Apply patches in filename order to the pinned BusyBox 1.37.0 source. They preserve
upstream applet operations and multicall dispatch, with explicit B1 capability
rejections. The first seven patches preserve the original B0 behavior.
`BB_WASI_B0` and `BB_WASI_B1` are set only for `ARCH=wasm32`. The native reference build compiles the
original helpers and paths.

| Patch | Cause and scope |
| --- | --- |
| `0001-wasi-b0-declarations.patch` | Exclude unused network, account, signal, process-clock, mmap, setjmp and terminal declarations from this restricted profile. No fabricated types or successful calls replace them. |
| `0002-wasi-b0-libbb-exclusions.patch` | Exclude unused mmap, identity-changing, pipe/dup, network, terminal and process helper definitions in the shared allocation/stdio file. Suppress glibc malloc tuning. Allocation, read/write, open and diagnostics used by B0 remain upstream code. |
| `0003-wasi-b0-build-closure.patch` | Build only `coreutils` and the explicit B0 `libbb` closure. Minimal Kconfig still compiles unrelated archive/account libraries. Declare a hard 64 MiB Wasm memory maximum and retain the real entry from the archive instead of libc's trapping weak entry. |
| `0004-wasm-partial-link.patch` | Omit the GNU linker compatibility flag `-nostdlib` from raw `wasm-ld -r` invocations. |
| `0005-wasi-b0-help-output.patch` | Write help/list bytes directly to stdout in WASI batch mode, instead of duplicating fd 1 onto fd 2. Use 80-column help layout because batch mode has no terminal. |
| `0006-wasm-final-link.patch` | Omit GNU archive group and informational options unsupported by wasm-ld. wasm-ld resolves archive dependencies without the GNU group flags. |
| `0007-process-initial-cwd.patch` | A priority-101 constructor obtains the initial cwd from the versioned host import, validates its NUL-terminated result, and calls libc `chdir` before the real multicall entry. Invalid or inaccessible cwd exits 125. Environment entries are unchanged. |
| `0008-b1-build-closure.patch` | Add upstream grep, file utilities, `coreutils/libcoreutils` and their actual common helper closure; retain the B0 helpers and process ABI. |
| `0009-b1-directory-mode-profile.patch` | WASI Preview 1 has no chmod/umask contract. Reject `mkdir -m` before mutation and use actual mkdir/stat path traversal with host-owned creation modes. Native behavior is retained. |
| `0010-b1-file-mutation-profile.patch` | Reject recursive/preserving/link copy modes before mutation, reject special files, and retain actual regular/symlink copy code. Use actual rename for mv; reject its cross-mount fallback before copy/unlink because metadata preservation is unavailable. Native code retains the upstream fallback. |
| `0011-b1-text-grep-profile.patch` | The small upstream grep accepts but ignores -a/-I and truncates NUL chunks. Reject these modes/input explicitly. WASI libc lacks the GNU regex API required by EXTRA_COMPAT; no replacement regex engine is introduced. Native reference behavior remains upstream. |
| `0012-b2-command-profile.patch` | Add the real directory/path/text helper closure, UTF-8 display, checked dot entries for WASI `ls -a`, and direct FILE handles for sort/uniq instead of POSIX dup2. Explicitly reject tail follow, tee signal, and pre-extension long/block metadata modes. |
| `0013-b3-development-commands.patch` | Real sed/find/diff/hash/binary helpers; content-only recursive copy and symbolic links; direct FILE/fmemopen paths avoid POSIX dup/fork/mkstemp. Explicitly reject unsupported mutation/process modes. |
| `0014-virtual-metadata-profile.patch` | Enable touch/stat/long ls with real WASI timestamps and versioned mode imports. Enrich libc stat with stored permission bits, retain file types, and report unavailable account/block/device fields explicitly. |
| `0015-archive-content-profile.patch` | Link real archive codecs, CRC32 and content extraction; use owned descriptors instead of dup2/fork, real metadata times, exclusive output creation and explicit unsupported-mode failures. |
| `0016-buffered-output-errors.patch` | Preserve prior stdio write errors in sort/uniq file and stdout output even when a later close/flush succeeds. |
| `0017-tar-directory-errors.patch` | Propagate directory creation errors and reject non-directory conflicts before metadata restoration. |
| `0018-tar-directory-times.patch` | Restore directory times after child/deferred-link extraction with last-header precedence and explicit errors. |
| `0019-zip-stored-crc.patch` | Validate stored ZIP payloads with the actual upstream CRC32 helper and report checksum failures. |

No shell parser, fake process success, network implementation or filesystem stub
is introduced. Unsupported applets remain disabled. Extending this closure needs
real syscall support or explicit feature exclusion, then native/WASI/browser tests.

`CONFIG_LFS=y` matches WASI libc's 64-bit `off_t`. A 4 KiB copy buffer selects
upstream `read`/`write` copying without optional mmap/sendfile. These configuration
choices do not change `cat` byte semantics.
