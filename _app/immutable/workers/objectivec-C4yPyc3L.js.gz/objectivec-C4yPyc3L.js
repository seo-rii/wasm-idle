const e=e=>typeof globalThis.SharedArrayBuffer==`function`&&e instanceof SharedArrayBuffer,t=t=>e(t?.buffer),n=Int32Array.BYTES_PER_ELEMENT*2;new TextEncoder;const r=new TextDecoder,i=e=>e instanceof Int32Array?e:new Int32Array(e),a=e=>new Uint8Array(e.buffer,e.byteOffset+n,e.byteLength-n),o=e=>{let t=i(e),n=Atomics.load(t,1);if(n===-1)return null;let o=a(t);return r.decode(o.slice(0,n))},s=(e,n)=>{if(!e||!t(e))return null;let r=Atomics.load(e,0);for(n();;)if(Atomics.wait(e,0,r,100)===`not-equal`)return o(e)},c=e=>e.reason??new DOMException(`Runtime asset load aborted`,`AbortError`),l=(e,t)=>{try{Promise.resolve(e.cancel(t)).catch(()=>void 0)}catch{}};async function u(e,{asset:t,maxAssetBytes:n,total:r,signal:i,onProgress:a}){let o=()=>/* @__PURE__ */ Error(`Runtime asset ${t} exceeds the ${n} byte limit`);try{if(!Number.isSafeInteger(n)||n<=0)throw TypeError(`Runtime asset maxAssetBytes must be a positive safe integer`);if(r!==void 0&&(!Number.isSafeInteger(r)||r<0))throw TypeError(`Runtime asset total must be a non-negative safe integer`);if(r!==void 0&&r>n)throw o();if(i?.aborted)throw c(i)}catch(t){throw e.body&&l(e.body,t),t}let s=e.headers.get(`content-type`),u={status:200,headers:s?{"Content-Type":s}:void 0};if(!e.body){let t,s=i?new Promise((e,n)=>{t=()=>n(c(i)),i.addEventListener(`abort`,t,{once:!0})}):void 0;try{let t=e.arrayBuffer(),l=s?await Promise.race([t,s]):await t;if(i?.aborted)throw c(i);if(l.byteLength>n)throw o();if(a?.(l.byteLength,r??l.byteLength),i?.aborted)throw c(i);return new Response(l,u)}finally{t&&i?.removeEventListener(`abort`,t)}}let d=e.body.getReader(),f=!1,p=!1,m=0,h,g=()=>{p||(p=!0,d.releaseLock())},_=()=>i?.removeEventListener(`abort`,b),v=e=>{if(!f){f=!0,_(),l(d,e);try{g()}catch{}}},y=e=>{f||(v(e),h.error(e))},b=()=>{i&&y(c(i))},x=new ReadableStream({start(e){h=e,i?.addEventListener(`abort`,b,{once:!0}),i?.aborted&&b()},async pull(e){if(!f)try{let{done:t,value:s}=await d.read();if(f)return;if(i?.aborted)throw c(i);if(t){if(g(),a?.(m,r??m),f)return;f=!0,_(),e.close();return}if(!s)return;let l=m+s.byteLength;if(!Number.isSafeInteger(l)||l>n)throw o();m=l,a?.(m,r),f||e.enqueue(s)}catch(e){y(i?.aborted?c(i):e)}},cancel(e){v(e)}},{highWaterMark:0});return new Response(x,u)}const d=new TextDecoder,f=globalThis.fetch.bind(globalThis),p=globalThis.XMLHttpRequest;let m=null,h=null,g=/* @__PURE__ */ new Map,_=!1,v=0;const y=/* @__PURE__ */ new Map,b=/* @__PURE__ */ new Map,x=(e,t)=>{try{Promise.resolve(e.body?.cancel(t)).catch(()=>void 0)}catch{}},S=()=>{if(!m)return null;let e=globalThis.location?.origin,t=globalThis.location?.href,n=e&&e!==`null`?`${e}/`:t?.startsWith(`blob:`)?t.slice(5):t||`http://localhost/`,r;try{r=new URL(m.baseUrl,n)}catch{throw Error(`Runtime asset base URL is invalid: ${m.baseUrl}`)}if(r.protocol!==`http:`&&r.protocol!==`https:`)throw Error(`Runtime asset base URL must use HTTP(S): ${m.baseUrl}`);if(r.username||r.password||r.hash||r.search)throw Error(`Runtime asset base URL must not include credentials, a query, or a fragment: ${m.baseUrl}`);return r.pathname.endsWith(`/`)||(r.pathname+=`/`),r},C=e=>{let t=e.buffer;return e.byteOffset===0&&e.byteLength===t.byteLength?t:t.slice(e.byteOffset,e.byteOffset+e.byteLength)},w=e=>{let t=S();if(!t)return null;try{return typeof e==`string`?new URL(e,t).href:e instanceof URL?e.href:e.url}catch{return null}},T=e=>{if(!h)return!1;let t;try{t=new URL(e)}catch{return!1}return t.protocol===h.protocol&&t.origin===h.origin&&t.pathname.startsWith(h.pathname)},E=e=>{let t=S();if(!t)return null;let n;try{n=new URL(e,t)}catch{return null}return n.protocol!==`http:`&&n.protocol!==`https:`||n.username||n.password||n.hash||/%2f|%5c/iu.test(n.pathname)?null:g.get(n.href)||(T(n.href)||n.origin!==t.origin||!n.pathname.startsWith(t.pathname)?null:`${n.pathname.slice(t.pathname.length)}${n.search}`)},D=e=>E(e)!==null,O=async e=>{let t=++v;return await new Promise((n,r)=>{y.set(t,{resolve:n,reject:r}),self.postMessage({assetRequest:{id:t,asset:e}})})},k=async(e,t,n,r)=>{let i=w(e);if(!i||E(i)!==t||!m)throw Error(`Untracked runtime asset request`);let a=m.maxAssetBytes??134217728;r?.throwIfAborted();let o=await f(i,{credentials:`omit`,redirect:`error`,referrerPolicy:`no-referrer`,...n?{integrity:n}:{},...r?{signal:r}:{}});if(r?.aborted&&(x(o,r.reason),r.throwIfAborted()),o.url){let e;try{e=new URL(o.url)}catch{let e=/* @__PURE__ */ Error(`Runtime asset response URL is invalid: ${o.url}`);throw x(o,e),e}if(e.href!==i){let t=/* @__PURE__ */ Error(`Runtime asset response URL mismatch: expected ${i}, received ${e.href}`);throw x(o,t),t}}if(!o.ok){let e=/* @__PURE__ */ Error(`Failed to load ${t}: ${o.status}`);throw x(o,e),e}let s=o.headers.get(`content-length`),c;if(s!==null){let e=Number(s);if(!/^\d+$/u.test(s.trim())||!Number.isSafeInteger(e)){let e=/* @__PURE__ */ Error(`Runtime asset ${t} has an invalid Content-Length`);throw x(o,e),e}c=e||void 0}if(c!==void 0&&c>a){let e=/* @__PURE__ */ Error(`Runtime asset ${t} exceeds the ${a} byte limit`);throw x(o,e),e}let l=o.headers.get(`content-type`)||void 0;return{response:o,maxAssetBytes:a,total:c,mimeType:l}},A=async(e,t,n)=>{let{response:r,maxAssetBytes:i,total:a,mimeType:o}=await k(e,t,n);if(!r.body){let e=new Uint8Array(await r.arrayBuffer());if(e.byteLength>i)throw Error(`Runtime asset ${t} exceeds the ${i} byte limit`);return self.postMessage({assetProgress:{asset:t,loaded:e.byteLength,total:a??e.byteLength}}),{bytes:e,mimeType:o}}let s=r.body.getReader(),c=!1,l=e=>{if(!c){c=!0;try{Promise.resolve(s.cancel(e)).catch(()=>void 0)}catch{}}},u=0,d,f;try{for(d=new Uint8Array(a||Math.min(65536,i));;){let{done:e,value:n}=await s.read();if(e)break;if(!n)continue;let r=u+n.byteLength;if(r>i){let e=/* @__PURE__ */ Error(`Runtime asset ${t} exceeds the ${i} byte limit`);throw l(e),e}if(r>d.byteLength){let e=Math.min(i,Math.max(r,d.byteLength*2)),t=new Uint8Array(e);t.set(d.subarray(0,u)),d=t}d.set(n,u),u=r,self.postMessage({assetProgress:{asset:t,loaded:u,total:a}})}}catch(e){throw l(e),e}finally{try{s.releaseLock()}catch(e){f={error:e}}}if(f)throw f.error;return u!==d.byteLength&&(d=d.slice(0,u)),self.postMessage({assetProgress:{asset:t,loaded:u,total:a??u}}),{bytes:d,mimeType:o}};async function j(e,t){let n=E(e);if(!n||!m)throw Error(`Untracked runtime asset request`);return m.useAssetBridge?await O(n):await A(e,n,t)}function ee(e){return new Response(C(e.bytes),{status:200,headers:e.mimeType?{"Content-Type":e.mimeType}:void 0})}function te(){if(p===void 0)return;class e{responseType=``;response=null;responseText=``;readyState=0;status=0;statusText=``;timeout=0;withCredentials=!1;onload=null;onerror=null;onprogress=null;onreadystatechange=null;native=null;url=``;open(e,t){let n=w(t);if(!n||!D(n)){if(n&&T(n))throw Error(`Untracked runtime asset request`);let r=n||(t instanceof URL?t.href:String(t));this.native=new p,this.native.responseType=this.responseType,this.native.timeout=this.timeout,this.native.withCredentials=this.withCredentials,this.native.onload=e=>{this.response=this.native?.response,this.responseText=this.native?.responseText||``,this.readyState=this.native?.readyState||0,this.status=this.native?.status||0,this.statusText=this.native?.statusText||``,this.onreadystatechange?.call(this,e),this.onload?.call(this,e)},this.native.onerror=e=>{this.readyState=this.native?.readyState||4,this.status=this.native?.status||0,this.statusText=this.native?.statusText||``,this.onreadystatechange?.call(this,e),this.onerror?.call(this,e)},this.native.onprogress=e=>{this.onprogress?.call(this,e)},this.native.onreadystatechange=e=>{this.readyState=this.native?.readyState||0,this.onreadystatechange?.call(this,e)},this.native.open(e,r);return}this.url=n,this.readyState=1,this.onreadystatechange?.call(this,new ProgressEvent(`readystatechange`))}setRequestHeader(e,t){this.native?.setRequestHeader(e,t)}async send(e){if(this.native){this.native.send(e);return}try{let e=await j(this.url),t=C(e.bytes);if(this.status=200,this.statusText=`OK`,this.readyState=4,this.responseType===`arraybuffer`)this.response=t;else if(this.responseType===`blob`)this.response=new Blob([t],{type:e.mimeType||`application/octet-stream`});else{let t=d.decode(e.bytes);this.responseText=t,this.response=t}let n=new ProgressEvent(`progress`,{lengthComputable:!0,loaded:e.bytes.byteLength,total:e.bytes.byteLength});this.onprogress?.call(this,n),this.onreadystatechange?.call(this,new ProgressEvent(`readystatechange`)),this.onload?.call(this,new ProgressEvent(`load`))}catch(e){this.readyState=4,this.status=0,this.statusText=e instanceof Error?e.message:String(e),this.onreadystatechange?.call(this,new ProgressEvent(`readystatechange`)),this.onerror?.call(this,new ProgressEvent(`error`))}}abort(){this.native?.abort()}getAllResponseHeaders(){return this.native?.getAllResponseHeaders()||``}getResponseHeader(e){return this.native?.getResponseHeader(e)||null}}globalThis.XMLHttpRequest=e}function ne(){_||(_=!0,globalThis.fetch=(async(e,t)=>{let n=w(e);if(!n||!D(n)){if(n&&T(n))throw Error(`Untracked runtime asset request`);return f(e,t)}let r=typeof Request<`u`&&e instanceof Request?e:void 0,i=t?.integrity??r?.integrity,a=typeof i==`string`?i:void 0,o=(t?.method??r?.method??`GET`).toUpperCase();if(m?.useAssetBridge===!1&&o===`GET`&&new URL(n).pathname.endsWith(`.wasm`)){let e=E(n),i=(t?.signal===void 0?r?.signal:t.signal)??void 0,{response:o,maxAssetBytes:s,total:c}=await k(n,e,a,i);return u(o,{asset:e,maxAssetBytes:s,total:c,signal:i,onProgress:(t,n)=>self.postMessage({assetProgress:{asset:e,loaded:t,total:n}})})}return ee(await j(n,a))}),te())}function re(e){if(e?.maxAssetBytes!==void 0&&(!Number.isSafeInteger(e.maxAssetBytes)||e.maxAssetBytes<=0))throw TypeError(`Runtime asset maxAssetBytes must be a positive safe integer`);for(let e of b.values())e.reject(/* @__PURE__ */ Error(`Runtime module configuration changed`));b.clear(),h=null,g=/* @__PURE__ */ new Map,m=e,ne()}function ie(e){let t=e?.assetResponse;if(!t)return!1;let n=b.get(t.id);if(n)return b.delete(t.id),t.ok?t.module instanceof WebAssembly.Module?n.resolve(t.module):n.reject(/* @__PURE__ */ Error(`Runtime module response is invalid`)):n.reject(Error(t.error||`Runtime module request failed`)),!0;let r=y.get(t.id);return!r||(y.delete(t.id),t.ok?(r.resolve({bytes:new Uint8Array(t.bytes),mimeType:t.mimeType||void 0}),!0):(r.reject(Error(t.error||`Runtime asset request failed`)),!0))}const ae=`wasm32-wasi`,oe=[`-fobjc-runtime=gnustep-2.0`,`-fblocks`];function se(e){return(e||``).trim().toUpperCase().replaceAll(/\s+/g,``)}function ce(e){switch(se(e)){case`03`:case`CPP03`:case`C++03`:case`GNU++03`:case`GNUC++03`:return`-std=gnu++03`;case`11`:case`CPP11`:case`C++11`:case`GNU++11`:case`GNUC++11`:return`-std=gnu++11`;case`14`:case`CPP14`:case`C++14`:case`GNU++14`:case`GNUC++14`:return`-std=gnu++14`;case`17`:case`CPP17`:case`C++17`:case`GNU++17`:case`GNUC++17`:return`-std=gnu++17`;case`20`:case`CPP20`:case`C++20`:case`GNU++20`:case`GNUC++20`:return`-std=gnu++20`;case`23`:case`CPP23`:case`C++23`:case`GNU++23`:case`GNUC++23`:return`-std=gnu++23`;case`26`:case`CPP26`:case`C++26`:case`GNU++26`:case`GNUC++26`:return`-std=gnu++26`;default:return`-std=gnu++20`}}function le(e){switch(se(e)){case`99`:case`C99`:case`GNU99`:case`GNUC99`:return`-std=gnu99`;case`11`:case`C11`:case`GNU11`:case`GNUC11`:return`-std=gnu11`;case`17`:case`18`:case`C17`:case`C18`:case`GNU17`:case`GNU18`:case`GNUC17`:case`GNUC18`:return`-std=gnu17`;default:return`-std=gnu11`}}function ue(e,t){return e===`C`?{languageArg:`c`,standardArg:le(t.cVersion)}:e===`OBJC`?{languageArg:`objective-c`,standardArg:le(t.cVersion)}:{languageArg:`c++`,standardArg:ce(t.cppVersion)}}function de(e,t=``,n){return[...[`CPP`,`OBJCXX`].includes(e)?[`${t}/include/c++/v1`,`${t}/include/wasm32-wasi/c++/v1`]:[],...n?[`${n.replace(/\/+$/,``)}/include`]:[],`${t}/include/wasm32-wasi`,`${t}/include`]}var fe=class extends Error{code;phase;runtimeId;profileId;recoverable;constructor(e,t){super(e,{cause:t.cause}),this.name=`WasmIdleError`,this.code=t.code,this.phase=t.phase,this.runtimeId=t.runtimeId,this.profileId=t.profileId,this.recoverable=t.recoverable??!1}},M=class extends fe{constructor(e,t={}){super(e,{...t,code:`asset-integrity`,phase:t.phase??`asset`,recoverable:t.recoverable??!1}),this.name=`AssetIntegrityError`}};const pe=/* @__PURE__ */ new Set([`application/javascript`,`text/javascript`]);async function me(e){let t=e.stage??`compressed`,n={runtimeId:e.runtimeId,profileId:e.profileId};if(!e.asset||e.asset.includes(`\0`))throw new M(`Runtime asset identity must be a non-empty safe string`,n);if(!ArrayBuffer.isView(e.bytes)||Object.prototype.toString.call(e.bytes)!==`[object Uint8Array]`)throw new M(`Runtime asset ${e.asset} did not provide byte data`,n);let r,i,a;if(typeof e.expected==`string`){if(t===`uncompressed`)throw new M(`Runtime asset ${e.asset} is missing uncompressed integrity metadata`,n);r=e.expected}else if(e.expected&&typeof e.expected==`object`){if(t===`compressed`)r=e.expected.sha256,i=e.expected.bytes,e.expected.uncompressedSha256===void 0&&e.expected.uncompressedBytes===void 0&&(a=e.expected.mediaType);else{if(e.expected.uncompressedSha256===void 0||e.expected.uncompressedBytes===void 0)throw new M(`Runtime asset ${e.asset} is missing uncompressed integrity metadata`,n);r=e.expected.uncompressedSha256,i=e.expected.uncompressedBytes,a=e.expected.mediaType}}else throw new M(`Runtime asset ${e.asset} has invalid integrity metadata`,n);if(!/^[a-f0-9]{64}$/u.test(r))throw new M(`Runtime asset ${e.asset} has an invalid expected ${t} SHA-256 digest`,n);if(i!==void 0&&(!Number.isSafeInteger(i)||i<0))throw new M(`Runtime asset ${e.asset} has an invalid expected ${t} byte size`,n);if(i!==void 0&&e.bytes.byteLength!==i)throw new M(`Runtime asset ${e.asset} ${t} size mismatch: expected ${i} bytes, received ${e.bytes.byteLength}`,n);if(a!==void 0){if(!a.includes(`/`))throw new M(`Runtime asset ${e.asset} has an invalid expected MIME type`,n);let t=e.mimeType?.split(`;`,1)[0]?.trim().toLowerCase()||`missing`,r=a.trim().toLowerCase();if(t!==r&&!(pe.has(t)&&pe.has(r)))throw new M(`Runtime asset ${e.asset} MIME type mismatch: expected ${r}, received ${t}`,n)}if(!globalThis.crypto?.subtle)throw new M(`Web Crypto SHA-256 is unavailable`,n);let o=e.bytes.byteOffset===0&&e.bytes.byteLength===e.bytes.buffer.byteLength&&e.bytes.buffer instanceof ArrayBuffer?e.bytes.buffer:Uint8Array.from(e.bytes).buffer,s=new Uint8Array(await globalThis.crypto.subtle.digest(`SHA-256`,o)),c=Array.from(s,e=>e.toString(16).padStart(2,`0`)).join(``);if(c!==r)throw new M(`Runtime asset ${e.asset} ${t} SHA-256 mismatch: expected ${r}, received ${c}`,n);return Object.freeze({asset:e.asset,stage:t,sha256:c,bytes:e.bytes.byteLength,mediaType:a?e.mimeType?.split(`;`,1)[0]?.trim().toLowerCase():void 0})}const he={schemaVersion:1,version:`1.0.11`,assets:{"clang/bin/c-sysroot.tar.gz":{sha256:`fb3e1cdacac3eceddcfe2e57cbbf78e593ec2a298f01acb61c06e4b9d24fbbee`,bytes:1216797,encoding:`gzip`,mediaType:`application/octet-stream`,uncompressedSha256:`720c620e459025e918747768b9f5f1aef7b48c6df1b34c1a31fb2e5b1b7a213e`,uncompressedBytes:3736064},"clang/bin/clang.wasm":{sha256:`d92ef06cdd3fea88acf384db15a6f2a344790c05bcba8e9f13f5b75b36ad4a99`,bytes:35658969,mediaType:`application/wasm`,deliveryPath:`clang/bin/clang.wasm.gz`},"clang/bin/clang.wasm.gz":{sha256:`8dc032057fbeb41e4a9986dfc54b2336c17532033dee172eb0095eba9c5fbe75`,bytes:13121917,encoding:`gzip`,mediaType:`application/wasm`,uncompressedSha256:`d92ef06cdd3fea88acf384db15a6f2a344790c05bcba8e9f13f5b75b36ad4a99`,uncompressedBytes:35658969},"clang/bin/cpp-addon.tar.gz":{sha256:`47e9946c5aaeb3b35a1d42d6a80eae8987c596f4f858b207e492c00d8680af9e`,bytes:3840608,encoding:`gzip`,mediaType:`application/octet-stream`,uncompressedSha256:`7d61b724d377dc4e5670725055fb2884ebc8153d697e05093992004d5859310d`,uncompressedBytes:15572992},"clang/bin/lld.wasm":{sha256:`34d39bc410c098e7e09933b61cc8e28699447af9a28abf4544d71b6e9cad1f9d`,bytes:16171013,mediaType:`application/wasm`,deliveryPath:`clang/bin/lld.wasm.gz`},"clang/bin/lld.wasm.gz":{sha256:`495813efde8f354c38483749cdface7a7d9e23c8411da45a6f5f80030159eb11`,bytes:6417339,encoding:`gzip`,mediaType:`application/wasm`,uncompressedSha256:`34d39bc410c098e7e09933b61cc8e28699447af9a28abf4544d71b6e9cad1f9d`,uncompressedBytes:16171013},"clang/bin/memfs.wasm":{sha256:`5b741e03dd3502bcfd80e4e5055232b5d633604e1461752efed0189f93407dc3`,bytes:38071,mediaType:`application/wasm`,deliveryPath:`clang/bin/memfs.wasm.gz`},"clang/bin/memfs.wasm.gz":{sha256:`a3e43451bc15ae69a7f113009e2ee82ab4db711625c1782cd45d0d3c4d38175a`,bytes:16111,encoding:`gzip`,mediaType:`application/wasm`,uncompressedSha256:`5b741e03dd3502bcfd80e4e5055232b5d633604e1461752efed0189f93407dc3`,uncompressedBytes:38071},"clang/bin/sysroot.tar.gz":{sha256:`c0ef46e903492383a3c7069bfd4aed0e764e8df988f92bb81eb96bea50bf2c00`,bytes:5059493,encoding:`gzip`,mediaType:`application/octet-stream`,uncompressedSha256:`e122f1acec0642d62d8976101c542aaa5346460df6eae5a3f8efb594ff32f5ae`,uncompressedBytes:19312640},"clang/language-sysroots.v1.json":{sha256:`d69acbdb636009dc5b2243f13f1580264f64a34362f0af67c9cd661388b565d0`,bytes:175348,mediaType:`application/json`},"clang/libc-printscan-long-double.a":{sha256:`33e04007d3547095068391b42189d1ac5398dd04e9da3118dfa644ffea7f4148`,bytes:111062,mediaType:`application/octet-stream`,deliveryPath:`clang/libc-printscan-long-double.a.gz`},"clang/libc-printscan-long-double.a.gz":{sha256:`b3f11e17e40fb13371a97244fdde00d5bd951ad8e20dfdf88a069167d6be628b`,bytes:52723,encoding:`gzip`,mediaType:`application/octet-stream`,uncompressedSha256:`33e04007d3547095068391b42189d1ac5398dd04e9da3118dfa644ffea7f4148`,uncompressedBytes:111062},"clang/long-double-library.v1.json":{sha256:`21fae445632a54b1687176afd0611442999132f29a68c3023ecc94b9ff48535d`,bytes:3115,mediaType:`application/json`},"clang/runtime-build.json":{sha256:`572ab389bdd15237d2026b3c512a5fe41b522b7c8b3163fabd776d7174b9569d`,bytes:12899,mediaType:`application/json`},"clang/runtime-manifest.v1.json":{sha256:`0b854bc6b41924420cfcc840509ecbe03af3c63ca3edd4940897917e32c8d8ad`,bytes:967,mediaType:`application/json`},"clangd/clangd.js":{sha256:`92dce989f2623a6e8930369dd205301c2815d70cf81312c64de1c47a16302b27`,bytes:97002,mediaType:`text/javascript`},"clangd/clangd.wasm":{sha256:`f2bef5c4b4aa8691f0b996286231c5778a17119c41537ae4108c7ff2795f7fc3`,bytes:78993623,mediaType:`application/wasm`,deliveryPath:`clangd/clangd.wasm.gz`},"clangd/clangd.wasm.gz":{sha256:`284e7117da923ca99ea9d64e4d9a80a739cdce4cc1c81dd099b040ab0a8a926f`,bytes:16723115,encoding:`gzip`,mediaType:`application/wasm`,uncompressedSha256:`f2bef5c4b4aa8691f0b996286231c5778a17119c41537ae4108c7ff2795f7fc3`,uncompressedBytes:78993623},"compressed-runtime-assets.v1.json":{sha256:`2106defe1cc4dde9251831334d7203a92de062239624c0c6a8143d9a0c08b620`,bytes:23765,mediaType:`application/json`},"jungol-robot/jungol_robot.zip":{sha256:`af1ff295840219a4b7c4b2640df40d5b91a48c326774e1660fefa9e6cb0371fa`,bytes:16230,mediaType:`application/zip`},"layered-runtime-assets.v1.json":{sha256:`0ef13d0c1e8772411b113c19d199ce9c09fe2945d146241c0c877223d5e7f714`,bytes:75642,mediaType:`application/json`},"lsp/typescript-libs.json.gz":{sha256:`8d4acc17ee1c3c09610b207da58b98cd63c1042f3b6a1751e38521f861c5b655`,bytes:555649,encoding:`gzip`,mediaType:`application/json`,uncompressedSha256:`4b026ba0cfa40aa481545d27fe0ee6594706020c783ef70aa015dbfd661c6d6d`,uncompressedBytes:3869629},"pyodide/ffi.d.ts":{sha256:`1f55e2a59cee5306dd19788368823d2863098aa4eb3e6cf8d7f460482d1e266e`,bytes:45021,mediaType:`application/octet-stream`},"pyodide/jedi-0.19.2-py2.py3-none-any.whl":{sha256:`14346bd3f7aabb699b9e1223afdfae706f9a391212659d2cbf74c66c715095b4`,bytes:1563101,mediaType:`application/zip`},"pyodide/numpy-2.4.6-cp314-cp314-pyemscripten_2026_0_wasm32.whl":{sha256:`a292c1f5d7d8a2208cd5e94fc467604c131cabcd2fc14fed6eefde121e7fabdf`,bytes:2960568,mediaType:`application/zip`},"pyodide/package.json":{sha256:`40ca48e43ce4ddc68412d5b7a7ca9e2477cd4f0e672277ae468ac2245717079b`,bytes:2999,mediaType:`application/json`},"pyodide/parso-0.8.6-py2.py3-none-any.whl":{sha256:`6a4e296bc54f0e3489ce61ff9f30e9538dc382bdae10fa6413b34000883385d8`,bytes:106894,mediaType:`application/zip`},"pyodide/pyodide-lock.json":{sha256:`5dc2fc119108bc148c7457dc86e7675b5c87e1cafd420b9c34c1eaef7b36c010`,bytes:119077,mediaType:`application/json`},"pyodide/pyodide.asm.mjs":{sha256:`f7cdc8ece80678ceb712f8e65ebe6d3a83203a180c399865f49612a051693635`,bytes:1250344,mediaType:`text/javascript`,deliveryPath:`pyodide/pyodide.asm.mjs.gz`},"pyodide/pyodide.asm.mjs.gz":{sha256:`dbd7b4869182e66aa3f7ee778a1a2bc66cacc05e8033cc419c12b53bcd947a0c`,bytes:261220,encoding:`gzip`,mediaType:`text/javascript`,uncompressedSha256:`f7cdc8ece80678ceb712f8e65ebe6d3a83203a180c399865f49612a051693635`,uncompressedBytes:1250344},"pyodide/pyodide.asm.wasm":{sha256:`cc36e3cab04fdfc9a63ff13eb52eae2b911bf46c025cc7b281f394bd3de1d5e6`,bytes:9598218,mediaType:`application/wasm`,deliveryPath:`pyodide/pyodide.asm.wasm.gz`},"pyodide/pyodide.asm.wasm.gz":{sha256:`8d00a5287267213cd5e4ff5a33c238e0a65da646da89c7757979523835f83c9c`,bytes:3593065,encoding:`gzip`,mediaType:`application/wasm`,uncompressedSha256:`cc36e3cab04fdfc9a63ff13eb52eae2b911bf46c025cc7b281f394bd3de1d5e6`,uncompressedBytes:9598218},"pyodide/pyodide.d.ts":{sha256:`7c3ca5a978f3c5dd5229758b91849a62a5866b23869615a95e2e00082d402ff1`,bytes:81966,mediaType:`application/octet-stream`},"pyodide/pyodide.js":{sha256:`3141b814715a72e59b51b1b18b9ceae5bf19f7c852417e431bb0a34feadf825c`,bytes:18912,mediaType:`text/javascript`},"pyodide/pyodide.mjs":{sha256:`6f1d60f7bf529beb300f0f47983c921d3982363640ba20af0e38efdddbc66109`,bytes:17931,mediaType:`text/javascript`},"pyodide/python_stdlib.zip":{sha256:`fa1957e5777068fc4f7437f96d860ae2fbe9c19732ba06c84e004ec16dd7dd7a`,bytes:2545637,mediaType:`application/zip`},"robot-jungol/robot_jungol.zip":{sha256:`a7bc1bd63a0eb6cabfc55e61a99a4a760d9b92ac177308821505553f0f4fefa1`,bytes:16230,mediaType:`application/zip`},"shared/emscripten-lld/lld.data.gz":{sha256:`369220e5714722229163d3ef9ecc39b3da29f9897cf596a39ce2818eb938a4df`,bytes:2673035,encoding:`gzip`,mediaType:`application/octet-stream`,uncompressedSha256:`8c58f81883c4f3f0980743dfb75b4241b69447f67b5731341f72ed98571a05c7`,uncompressedBytes:9489178},"shared/emscripten-lld/lld.js":{sha256:`991179802d1951f237b248c68ef8fc17993e89bbf5906c3795c2de52beaede88`,bytes:91648,mediaType:`text/javascript`},"shared/emscripten-lld/lld.wasm.gz":{sha256:`a1402830fd7756a8d122a773cb2ac2eba07245cc97891759ed4cf5b10cc73608`,bytes:21649502,encoding:`gzip`,mediaType:`application/wasm`,uncompressedSha256:`28f079e4997a4e2eebe02b8209a663d56eeba0815b010ff74b3ead2549d0ff9b`,uncompressedBytes:83133801},"teavm/compile-classlib-teavm.bin":{sha256:`71746dc82ddad5ad8be829f461c235a747bdaf121d1b7abd16dbbbbe6a17f53d`,bytes:200621,mediaType:`application/octet-stream`},"teavm/compiler.wasm":{sha256:`9eb047426613c3ed3006838daae49e29929ad0d560ec6b1f8b50e15e2c3865d6`,bytes:4299273,mediaType:`application/wasm`,deliveryPath:`teavm/compiler.wasm.gz`},"teavm/compiler.wasm-runtime.js":{sha256:`bd103f277be99fd2f3ffc0248b3558e6c2c85a44902bfeef042c6bedcf0b2c63`,bytes:13936,mediaType:`text/javascript`},"teavm/compiler.wasm.gz":{sha256:`5f46653e00fb5832e0bb2daba4fe49bf3e7bce369a3d16fcb30025fb7ed96bf2`,bytes:1678507,encoding:`gzip`,mediaType:`application/wasm`,uncompressedSha256:`9eb047426613c3ed3006838daae49e29929ad0d560ec6b1f8b50e15e2c3865d6`,uncompressedBytes:4299273},"teavm/runtime-classlib-teavm.bin":{sha256:`f0c9c8c0426e310d08751e57cc88fdfd63ea2f428e4d6cb1b7e59a3dc20844ad`,bytes:2394175,mediaType:`application/octet-stream`,deliveryPath:`teavm/runtime-classlib-teavm.bin.gz`},"teavm/runtime-classlib-teavm.bin.gz":{sha256:`bf0d0ba86f2e35c4360e54151a171b2e2729a2c5e6cb9cfbdc7ecefae8ced4c4`,bytes:2358693,encoding:`gzip`,mediaType:`application/octet-stream`,uncompressedSha256:`f0c9c8c0426e310d08751e57cc88fdfd63ea2f428e4d6cb1b7e59a3dc20844ad`,uncompressedBytes:2394175},"teavm/runtime-manifest.v2.json":{sha256:`13d782567e888ff65515f68b117e06a10ed85eaa299b8915710e07213b17ce19`,bytes:10208,mediaType:`application/json`},"wasm-aheui/aheui-1.2.5-py3-none-any.whl":{sha256:`118d21234ba7e8252542286c825d01ea078b3b9468b56afdd1fae28238f869a3`,bytes:24259,mediaType:`application/zip`},"wasm-aheui/runtime-build.json":{sha256:`fccd232d67e6dadc05dc1cc8d46119c3168c52674270b8a59ec224cd73b78c43`,bytes:1220,mediaType:`application/json`},"wasm-apecode/UPSTREAM-LICENSE-NOTICE.txt":{sha256:`a8712f9407baa9a6db8b8bce91475c42b0e975080782719522e2d83abe840669`,bytes:469,mediaType:`application/octet-stream`},"wasm-apecode/apecode-0.1.0-py3-none-any.whl":{sha256:`30aecb8eeff9a40cd55bb5fe5c18104f6c8308bdba9e71ac0b95d077badae30c`,bytes:7484,mediaType:`application/zip`},"wasm-apecode/runtime-build.json":{sha256:`25d4767f16a7ead4287de41219e7a1846eb4098957bca6667f39165610dd51d0`,bytes:1307,mediaType:`application/json`},"wasm-assemblyscript/chunks/__vite-browser-external-Bl4KRA5l.mjs":{sha256:`5354aac59231bbfa4999138ebdedcb8010be5fa66ef2dc8a8883337488b2d9d4`,bytes:113,mediaType:`text/javascript`},"wasm-assemblyscript/chunks/asc-BRewbG4u.mjs":{sha256:`3afaa09defaf791f327a732c8ed69b3ed3b1a663ccb6795c7a15b606b593246c`,bytes:13567562,mediaType:`text/javascript`,deliveryPath:`wasm-assemblyscript/chunks/asc-BRewbG4u.mjs.gz`},"wasm-assemblyscript/chunks/asc-BRewbG4u.mjs.gz":{sha256:`9acfd79060691673f04b0894e5a57ba0b04ef42e1cac4033eb956ab574815767`,bytes:2863936,encoding:`gzip`,mediaType:`text/javascript`,uncompressedSha256:`3afaa09defaf791f327a732c8ed69b3ed3b1a663ccb6795c7a15b606b593246c`,uncompressedBytes:13567562},"wasm-assemblyscript/chunks/preload-helper-CGPSMADP.mjs":{sha256:`619e20fe75396cf1771978ff186d0753bca8f42ec931be5128516c33046a0a09`,bytes:1573,mediaType:`text/javascript`},"wasm-assemblyscript/chunks/rolldown-runtime-CXHxssQy.mjs":{sha256:`5cc960457405f4677d7f7e3eee166ceabd1608df13bc972f15a76135eccb1e28`,bytes:717,mediaType:`text/javascript`},"wasm-assemblyscript/runtime-manifest.v1.json":{sha256:`32f537970d617ee0025754c899114154ad30138e27d8310f1254a9cc232f6345`,bytes:1141,mediaType:`application/json`},"wasm-assemblyscript/runtime.mjs":{sha256:`199cb826876abbf8ed6a5ba46bb0810a25a0e6febb290cf31328c77da77fd47e`,bytes:6e3,mediaType:`text/javascript`},"wasm-awk/goawk.wasm":{sha256:`04ea6a3b3024ce6c4fd779a620eb5569a23879fb8fe2afaac87103ea7dd4b7a6`,bytes:4697052,mediaType:`application/wasm`,deliveryPath:`wasm-awk/goawk.wasm.gz`},"wasm-awk/goawk.wasm.gz":{sha256:`1e152f3ecfc0e5f66820c8e08987ab9a05d594968ac6af500e93a8a556a2d86e`,bytes:1289352,encoding:`gzip`,mediaType:`application/wasm`,uncompressedSha256:`04ea6a3b3024ce6c4fd779a620eb5569a23879fb8fe2afaac87103ea7dd4b7a6`,uncompressedBytes:4697052},"wasm-awk/goawk.wasm.gz.bin":{sha256:`1e152f3ecfc0e5f66820c8e08987ab9a05d594968ac6af500e93a8a556a2d86e`,bytes:1289352,encoding:`gzip`,mediaType:`application/wasm`,uncompressedSha256:`04ea6a3b3024ce6c4fd779a620eb5569a23879fb8fe2afaac87103ea7dd4b7a6`,uncompressedBytes:4697052},"wasm-awk/runner-worker.js":{sha256:`cb8a0beda1ca4483bfc7dc6e6b1fc89c3022719c9cfeaddc35a534f48e8e4b0b`,bytes:5138,mediaType:`text/javascript`},"wasm-awk/runner-worker.v2.js":{sha256:`4a199657d6d56f8626b4c67cbed3219e7852db8152743758968693553ef8c75e`,bytes:14124,mediaType:`text/javascript`},"wasm-awk/runtime-build.json":{sha256:`31694157ff763cdef5fb31075338a7f77e5406ea1709d9e83789163a6ec76dd4`,bytes:59,mediaType:`application/json`},"wasm-awk/runtime-manifest.v1.json":{sha256:`92175886ab17d484117a1e3d97a2e201eba1e3624033c96cb28651a8b9795ecf`,bytes:243,mediaType:`application/json`},"wasm-awk/runtime-manifest.v2.json":{sha256:`82b7da83f543cbf22eead6920b09901e61b98f7afa26f9004b937e6ab42843e6`,bytes:887,mediaType:`application/json`},"wasm-awk/wasm_exec.js":{sha256:`0c949f4996f9a89698e4b5c586de32249c3b69b7baadb64d220073cc04acba14`,bytes:16992,mediaType:`text/javascript`},"wasm-bash/bash.webc":{sha256:`73e34672254faf20f54fa0e7f8ffa8a6117017e8779aaa75c80682c00e6d8468`,bytes:1808682,mediaType:`application/octet-stream`,deliveryPath:`wasm-bash/bash.webc.gz`},"wasm-bash/bash.webc.gz":{sha256:`6f5be27b3c2e685e3ee823a6ff7380c5143e9c7e353975e39e4dbf297a3ea577`,bytes:648807,encoding:`gzip`,mediaType:`application/octet-stream`,uncompressedSha256:`73e34672254faf20f54fa0e7f8ffa8a6117017e8779aaa75c80682c00e6d8468`,uncompressedBytes:1808682},"wasm-bash/bash.webc.gz.bin":{sha256:`6f5be27b3c2e685e3ee823a6ff7380c5143e9c7e353975e39e4dbf297a3ea577`,bytes:648807,encoding:`gzip`,mediaType:`application/octet-stream`,uncompressedSha256:`73e34672254faf20f54fa0e7f8ffa8a6117017e8779aaa75c80682c00e6d8468`,uncompressedBytes:1808682},"wasm-bash/runtime-build.json":{sha256:`ac1a2f4d1286744d19c8b19fa4cdb23729727daf1701551b03796b2ea832c9ac`,bytes:2055,mediaType:`application/json`},"wasm-bash/runtime-manifest.v1.json":{sha256:`faeddc5ae9a14c110d8011379df5f2e6b009def644f3d860e49b67cdc0477604`,bytes:311,mediaType:`application/json`},"wasm-bash/runtime-manifest.v2.json":{sha256:`2e1a5b7e6d8c85ff605252a64ea2a9fba2d0dd2d42be1d0247732fcd57c9f8cd`,bytes:4800,mediaType:`application/json`},"wasm-bash/sdk/index.mjs":{sha256:`d5e0424d9de8173c0c7bc6a6b704aecde620d3f424050e0e6a079d863a44d58b`,bytes:48694,mediaType:`text/javascript`},"wasm-bash/sdk/index.mjs.bin":{sha256:`d5e0424d9de8173c0c7bc6a6b704aecde620d3f424050e0e6a079d863a44d58b`,bytes:48694,mediaType:`application/octet-stream`},"wasm-bash/sdk/runtime-manifest.v1.json":{sha256:`2fd6e88656f5d5acd789957015c24ff6c5fedd205092fbd2fe61a796dddc36af`,bytes:713,mediaType:`application/json`},"wasm-bash/sdk/wasmer_js_bg.wasm":{sha256:`49a6646209f5ab5e7c737eac33407d87d9a9959ac83e5ecaaab9261b2323589e`,bytes:6598804,mediaType:`application/wasm`,deliveryPath:`wasm-bash/sdk/wasmer_js_bg.wasm.gz`},"wasm-bash/sdk/wasmer_js_bg.wasm.gz":{sha256:`f592295111f5140a0afd5c5905e31e3ef1c9126df182d1249c86e7d6d4d260da`,bytes:2383903,encoding:`gzip`,mediaType:`application/wasm`,uncompressedSha256:`49a6646209f5ab5e7c737eac33407d87d9a9959ac83e5ecaaab9261b2323589e`,uncompressedBytes:6598804},"wasm-bash/sdk/wasmer_js_bg.wasm.gz.bin":{sha256:`f592295111f5140a0afd5c5905e31e3ef1c9126df182d1249c86e7d6d4d260da`,bytes:2383903,encoding:`gzip`,mediaType:`application/wasm`,uncompressedSha256:`49a6646209f5ab5e7c737eac33407d87d9a9959ac83e5ecaaab9261b2323589e`,uncompressedBytes:6598804},"wasm-bash/sdk/worker.mjs":{sha256:`4c8a2c405f689e6aac28b6cc31a10407215680517b04efbaa036ee58c261fd1d`,bytes:709,mediaType:`text/javascript`},"wasm-befunge93/befunge93.wasm":{sha256:`0b28bdff5085e98bcec4d30a4a3475f693f0ad6c0194ea083c7d1832d994df81`,bytes:47871,mediaType:`application/wasm`},"wasm-befunge93/runtime-build.json":{sha256:`23f0d54aa08531c012d1a10ba3a27afba93067746fc4c383c407503a6e0f4139`,bytes:2075,mediaType:`application/json`},"wasm-bqn/BQN.js":{sha256:`0a5474e6944cc3ce8a8b21874f82341dd1680d7bac056d619adfd49e98123570`,bytes:212190,mediaType:`text/javascript`},"wasm-bqn/BQN.wasm":{sha256:`a57bd7e67537b0eb977f921dd75898878d4c51865df9c4e35d7a156f7db33632`,bytes:1175370,mediaType:`application/wasm`,deliveryPath:`wasm-bqn/BQN.wasm.gz`},"wasm-bqn/BQN.wasm.gz":{sha256:`e1789da62cd8a269d167bedf8eb0b6b3eef190f6b4f5e6cd5c7afaf28ecd81e9`,bytes:324306,encoding:`gzip`,mediaType:`application/wasm`,uncompressedSha256:`a57bd7e67537b0eb977f921dd75898878d4c51865df9c4e35d7a156f7db33632`,uncompressedBytes:1175370},"wasm-bqn/BQN.wasm.gz.bin":{sha256:`e1789da62cd8a269d167bedf8eb0b6b3eef190f6b4f5e6cd5c7afaf28ecd81e9`,bytes:324306,encoding:`gzip`,mediaType:`application/wasm`,uncompressedSha256:`a57bd7e67537b0eb977f921dd75898878d4c51865df9c4e35d7a156f7db33632`,uncompressedBytes:1175370},"wasm-bqn/LICENSE-GPLv3.txt":{sha256:`8b1ba204bb69a0ade2bfcf65ef294a920f6bb361b317dba43c7ef29d96332b9b`,bytes:35148,mediaType:`application/octet-stream`},"wasm-bqn/runner-worker.js":{sha256:`4ac73f01a459a641e392abdd5cfe5e5407f75656e1e7f77fda3ec1fddc9fe660`,bytes:14928,mediaType:`text/javascript`},"wasm-bqn/runtime-manifest.v1.json":{sha256:`7c942ff646c39eeed1645b913fede6a5fdd09261cba97a31b55739eb4eed17f1`,bytes:354,mediaType:`application/json`},"wasm-bqn/runtime-manifest.v2.json":{sha256:`699364acfc57f52f9674dbc430a1f641d9d05e377d2e720644313872985116cc`,bytes:1577,mediaType:`application/json`},"wasm-brainfuck/brainfuck.wasm":{sha256:`62c813c99c700d65e05974ec0ad07333c8ca40460330f1f835f28a8cb39657a5`,bytes:34467,mediaType:`application/wasm`},"wasm-brainfuck/runtime-build.json":{sha256:`17aa8eb6c0bfc680bdff38566c3603a05d90251cc8cbe42c6418de4b09da8b76`,bytes:2225,mediaType:`application/json`},"wasm-c3/c3c.mjs":{sha256:`2174a9b00c8b412c1162683a232d20af3640336b9abfad5a61af872f7d792e45`,bytes:101743,mediaType:`text/javascript`},"wasm-c3/c3c.wasm":{sha256:`f84c768a8dcd679bf092b7cd7bb9ec5786bc70bedc9d8929cfbb2d79291d8c0e`,bytes:39058650,mediaType:`application/wasm`,deliveryPath:`wasm-c3/c3c.wasm.gz`},"wasm-c3/c3c.wasm.gz":{sha256:`ec1e5babdf7d20a180d3dfd262c0374d3dd72737e50a27c551c582d41c8e9da4`,bytes:13195546,encoding:`gzip`,mediaType:`application/wasm`,uncompressedSha256:`f84c768a8dcd679bf092b7cd7bb9ec5786bc70bedc9d8929cfbb2d79291d8c0e`,uncompressedBytes:39058650},"wasm-c3/producer-receipt.json":{sha256:`3fec378b171e717bf08f5096291740fa313649e14280d156d0cf7cdcf50082f8`,bytes:13996,mediaType:`application/json`},"wasm-c3/runner-worker.js":{sha256:`358ee8aabac7e05c9eff87fcf3335410cc189e50b7fe9fc70bd318d9a90b1d56`,bytes:14151,mediaType:`text/javascript`},"wasm-clojurescript/compiler.js":{sha256:`ec1d3f02f8ee2ff7d8007acb565ec454c8a0625bd305260db3e974bbf5d3b162`,bytes:6588008,mediaType:`text/javascript`,deliveryPath:`wasm-clojurescript/compiler.js.gz`},"wasm-clojurescript/compiler.js.gz":{sha256:`76bb9862946f341609a28fb14eb079432dfc239350c2515efc7fccc6d3051676`,bytes:614160,encoding:`gzip`,mediaType:`text/javascript`,uncompressedSha256:`ec1d3f02f8ee2ff7d8007acb565ec454c8a0625bd305260db3e974bbf5d3b162`,uncompressedBytes:6588008},"wasm-clojurescript/compiler.js.gz.bin":{sha256:`76bb9862946f341609a28fb14eb079432dfc239350c2515efc7fccc6d3051676`,bytes:614160,encoding:`gzip`,mediaType:`text/javascript`,uncompressedSha256:`ec1d3f02f8ee2ff7d8007acb565ec454c8a0625bd305260db3e974bbf5d3b162`,uncompressedBytes:6588008},"wasm-clojurescript/runner-worker.js":{sha256:`c535913a7ce1972ceb2c620d1b1bba746e9fda62562ef2ac9032e18ad70940d5`,bytes:17270,mediaType:`text/javascript`},"wasm-clojurescript/runtime-build.json":{sha256:`0551fe28ffcab0520b438a46881eb851e7abfae10f7f63f6201e7d145a712052`,bytes:545,mediaType:`application/json`},"wasm-clojurescript/runtime-manifest.v1.json":{sha256:`19e0eee4b516a622bb11eb6d24c05dcb6e2056204e31610e8916124dfbf29335`,bytes:352,mediaType:`application/json`},"wasm-clojurescript/runtime-manifest.v2.json":{sha256:`b3fdb915bf79db5c970fafc9e34ad1ba7f958acebf251d28f307e82d7e72811f`,bytes:1664,mediaType:`application/json`},"wasm-cobol/c-sysroot.tar.gz":{sha256:`0bba0b9290add72f2ee5fafed18cd464ddb126dc8eb1729b97f708b80ffb868e`,bytes:1216964,encoding:`gzip`,mediaType:`application/octet-stream`,uncompressedSha256:`39719bb29de91a1a30630b93d56e5bfebcb8e1108c42f5a6ea89513480abc6ce`,uncompressedBytes:3747840},"wasm-cobol/cobc.wasm":{sha256:`d23bba63b301fc2f117a725e9b21aeaf1679aadbbaa6aff10834e7001869cd75`,bytes:1713037,mediaType:`application/wasm`,deliveryPath:`wasm-cobol/cobc.wasm.gz`},"wasm-cobol/cobc.wasm.gz":{sha256:`92bfb399d5e5a7add7a11f4e1eca786312f4cd1010c06001f85f11d5f2bca12b`,bytes:600296,encoding:`gzip`,mediaType:`application/wasm`,uncompressedSha256:`d23bba63b301fc2f117a725e9b21aeaf1679aadbbaa6aff10834e7001869cd75`,uncompressedBytes:1713037},"wasm-cobol/rootfs.tar.gz":{sha256:`13bdf0fa99247694405352576ea9b3251640ff51a92a44de84623756e8983578`,bytes:530360,encoding:`gzip`,mediaType:`application/octet-stream`,uncompressedSha256:`102e9eecff70d34519b42e8686a44218a98b791c454cc59eb7d3c9eddd3964c6`,uncompressedBytes:1658880},"wasm-cobol/runtime-build.json":{sha256:`1c8381dd5ae143b59f6c867a4cf67a7698f454ab922842373fb7cf896099a579`,bytes:1834,mediaType:`application/json`},"wasm-cobol/runtime-manifest.v1.json":{sha256:`83dd3ba5d09b9d8fdb7b0200793f664e7b7dc5d62aa18d38730fa82a341c7c67`,bytes:573,mediaType:`application/json`},"wasm-commonlisp/THIRD_PARTY_NOTICES.txt":{sha256:`7ba01a2b46315ba8684c290abfd812d1ec14634789a235dabc030952c6cbeedc`,bytes:43801,mediaType:`application/octet-stream`},"wasm-commonlisp/ecl.mjs":{sha256:`c9a2df8f418f637a2f5dc4a52842463a5a9df1a2dc5d24038ad01adb93969fa7`,bytes:77142,mediaType:`text/javascript`},"wasm-commonlisp/ecl.wasm.gz.bin":{sha256:`2d8d273a602db2e9677dd185351cf3019f3c31be0e0d6b4c14f7356f8f353a16`,bytes:1535867,encoding:`gzip`,mediaType:`application/wasm`,uncompressedSha256:`9aa43374a0fd991d841628eb209fbfd78e938636732692662f719383e52184c4`,uncompressedBytes:4560196},"wasm-commonlisp/producer-receipt.json":{sha256:`56f1eb7cf6470619cb3393e99d5c8ad1841a001ab758f388c006ca1d801ba071`,bytes:6154,mediaType:`application/json`},"wasm-commonlisp/runner-worker.js":{sha256:`46b24c0fbde93dfaa71ddbce697d717c772ad8fd03f8486ad2102c41145606c6`,bytes:11814,mediaType:`text/javascript`},"wasm-d/index.js":{sha256:`bdf2ef4a3f5697f07ac2c32d68d452373b8a7162300b9cec0e8a87ccd35bf27a`,bytes:50012,mediaType:`text/javascript`},"wasm-d/runtime/bin/ldc2.wasm":{sha256:`e0e0c2766ae3aff308c6d587439143c4a88e68f11c6e8084ce5f134ee87d2091`,bytes:23577090,mediaType:`application/wasm`,deliveryPath:`wasm-d/runtime/bin/ldc2.wasm.gz`},"wasm-d/runtime/bin/ldc2.wasm.gz":{sha256:`69ce5776b5edcb48d167d1004986a0f0dd0131cd3c9c871d52b8077ee997c5f3`,bytes:8058355,encoding:`gzip`,mediaType:`application/wasm`,uncompressedSha256:`e0e0c2766ae3aff308c6d587439143c4a88e68f11c6e8084ce5f134ee87d2091`,uncompressedBytes:23577090},"wasm-d/runtime/runtime-build.json":{sha256:`6c826f1e8f521c55f1f0a90aafd557007182edd68ac9d033578ebd39040cdc98`,bytes:2170,mediaType:`application/json`},"wasm-d/runtime/runtime-manifest.v1.json":{sha256:`1df7310e813913397f3e1ee49ee77665603745651b678767a82fa2057ffa2690`,bytes:2303,mediaType:`application/json`},"wasm-d/runtime/toolchain/toolchain.tar":{sha256:`6b67d88388eabe93e440047940ef6fe529f4c3b15f71574c6df548a0677828d6`,bytes:36239360,mediaType:`application/octet-stream`,deliveryPath:`wasm-d/runtime/toolchain/toolchain.tar.gz`},"wasm-d/runtime/toolchain/toolchain.tar.gz":{sha256:`d9a7eff7eeff239ef2b838ed799ce6641e3cd5d5dc4bc4519e43b018740dee2b`,bytes:8063553,encoding:`gzip`,mediaType:`application/octet-stream`,uncompressedSha256:`6b67d88388eabe93e440047940ef6fe529f4c3b15f71574c6df548a0677828d6`,uncompressedBytes:36239360},"wasm-debug/debug/lldb-web-dap.js":{sha256:`c6ecfaf08d60af11b003df60435c77a5ed24fc46887d2aa43e19436d5a5eb59d`,bytes:162488,mediaType:`text/javascript`},"wasm-debug/debug/lldb-web-dap.pthread.mjs":{sha256:`d40975277aa0c98c6570f9a35d52ab9be475ded4e7a4796fc6d0f8f314c9652d`,bytes:1364,mediaType:`text/javascript`},"wasm-debug/debug/lldb-web-dap.wasm":{sha256:`e7146642a865ffb41cca6635c72f97bfe923be1ce7f0d930e2e59713a3ee5222`,bytes:42718479,mediaType:`application/wasm`,deliveryPath:`wasm-debug/debug/lldb-web-dap.wasm.gz`},"wasm-debug/debug/lldb-web-dap.wasm.gz":{sha256:`1f16dfccbe8cd441e0f09f660a8bd2c6f482b05829ecae83038c3c9b4cf22e26`,bytes:14930210,encoding:`gzip`,mediaType:`application/wasm`,uncompressedSha256:`e7146642a865ffb41cca6635c72f97bfe923be1ce7f0d930e2e59713a3ee5222`,uncompressedBytes:42718479},"wasm-debug/debug/wamr-debug.js":{sha256:`ee0d1d3cbb1379a7f4389a445c5b3846461ebaa8e0b320fb1e3c1062eb9a838a`,bytes:111124,mediaType:`text/javascript`},"wasm-debug/debug/wamr-debug.wasm":{sha256:`35e53c222ec5cde0935d48bdd5fd1897de91622619f78e9b939170e67792b95b`,bytes:278958,mediaType:`application/wasm`,deliveryPath:`wasm-debug/debug/wamr-debug.wasm.gz`},"wasm-debug/debug/wamr-debug.wasm.gz":{sha256:`06ab0bbdab5f5672fba1b0ff10bdef04b2ea866bf894352f358f87e2412dee42`,bytes:100560,encoding:`gzip`,mediaType:`application/wasm`,uncompressedSha256:`35e53c222ec5cde0935d48bdd5fd1897de91622619f78e9b939170e67792b95b`,uncompressedBytes:278958},"wasm-debug/debug/wamr-debug.worker.mjs":{sha256:`6cdfdba3fba1d9f0226f2ac748d9be1ee567049a086727072b82a9451f6eb609`,bytes:111117,mediaType:`text/javascript`},"wasm-debug/runtime-manifest.v2.json":{sha256:`97ea95e89667e97a5cb4f50dc0600ccdc58865eedaeaf42945f54cc1a3dfcddd`,bytes:2853,mediaType:`application/json`},"wasm-dotnet/browser-execution.js":{sha256:`d30f817692aae7a4da633c1d2007334b022bdff8e9919fcde6d41fa82e28a891`,bytes:1139,mediaType:`text/javascript`},"wasm-dotnet/compiler.js":{sha256:`709a604d949e8e3847f5f70d2293577662264c04391ad307a99ee8971a60e757`,bytes:9777,mediaType:`text/javascript`},"wasm-dotnet/index.js":{sha256:`ad73fc2559f5ab9a8302d8593ea957e3da8d619ac5ae86144fe32403c6f05045`,bytes:500,mediaType:`text/javascript`},"wasm-dotnet/runtime-loader.js":{sha256:`82cf6bc708bc5840b196bff1751c31da57f452e508cba7793ff1fd044739e336`,bytes:8305,mediaType:`text/javascript`},"wasm-dotnet/runtime/csharp/Microsoft.CodeAnalysis.CSharp.wasm":{sha256:`55bf607d35b2408c3a2c44d880b46a0b76264f4c295fc1ec4f17e2cacaf8e71c`,bytes:5094681,mediaType:`application/wasm`,layer:{path:`wasm-dotnet/runtime/layers/csharp-00.pack.gz`,offset:0,bytes:5094681}},"wasm-dotnet/runtime/csharp/Microsoft.CodeAnalysis.wasm":{sha256:`b0d38624f00988ec700f78254520c5ec6e82342b5102d647f98f23c9713e9cd4`,bytes:1278741,mediaType:`application/wasm`,layer:{path:`wasm-dotnet/runtime/layers/csharp-00.pack.gz`,offset:5094681,bytes:1278741}},"wasm-dotnet/runtime/csharp/System.Collections.Concurrent.wasm":{sha256:`265cfe15d53c7d3416c9256a53769763307978c64c748d4a4c4d4ed2a5e4ef58`,bytes:25365,mediaType:`application/wasm`,layer:{path:`wasm-dotnet/runtime/layers/csharp-00.pack.gz`,offset:6373422,bytes:25365}},"wasm-dotnet/runtime/csharp/System.Collections.Immutable.wasm":{sha256:`8a1dd39db9b8d275a5e10c081520baf8e31cdf61ecb337f6faf5cc97919f5078`,bytes:80149,mediaType:`application/wasm`,layer:{path:`wasm-dotnet/runtime/layers/csharp-00.pack.gz`,offset:6398787,bytes:80149}},"wasm-dotnet/runtime/csharp/System.Collections.NonGeneric.wasm":{sha256:`871743255f218b596618fd990e5c52cc4005418a0b9800d85af77547e318afa4`,bytes:7445,mediaType:`application/wasm`,layer:{path:`wasm-dotnet/runtime/layers/csharp-00.pack.gz`,offset:6478936,bytes:7445}},"wasm-dotnet/runtime/csharp/System.Collections.Specialized.wasm":{sha256:`8540a381292cbf1637a05e94e033208834b7c81e99be8aa91db5a70eb81d3271`,bytes:9493,mediaType:`application/wasm`,layer:{path:`wasm-dotnet/runtime/layers/csharp-00.pack.gz`,offset:6486381,bytes:9493}},"wasm-dotnet/runtime/csharp/System.Collections.wasm":{sha256:`78194413b59e46caee01741b09069df95341ce37b26d24aedf7ba43a60a6e2f8`,bytes:31509,mediaType:`application/wasm`,layer:{path:`wasm-dotnet/runtime/layers/csharp-00.pack.gz`,offset:6495874,bytes:31509}},"wasm-dotnet/runtime/csharp/System.ComponentModel.Primitives.wasm":{sha256:`952b98a68dcb0d8479bfbada3ce275d4a6e677038db3c0c5168e7864af94b805`,bytes:6933,mediaType:`application/wasm`,layer:{path:`wasm-dotnet/runtime/layers/csharp-00.pack.gz`,offset:6527383,bytes:6933}},"wasm-dotnet/runtime/csharp/System.ComponentModel.TypeConverter.wasm":{sha256:`63a1a0d81c6ee4259b90a741c1771250043efab2e88bec2630a8e95427517025`,bytes:45333,mediaType:`application/wasm`,layer:{path:`wasm-dotnet/runtime/layers/csharp-00.pack.gz`,offset:6534316,bytes:45333}},"wasm-dotnet/runtime/csharp/System.ComponentModel.wasm":{sha256:`455436e971c5bd41f2de5062ea7a2abb6b9a80870b11986750705a6d2164697a`,bytes:4885,mediaType:`application/wasm`,layer:{path:`wasm-dotnet/runtime/layers/csharp-00.pack.gz`,offset:6579649,bytes:4885}},"wasm-dotnet/runtime/csharp/System.Console.wasm":{sha256:`755fe0c9fcf7daea2e9866fa3fa1bb9ea8e3b99ac23e1491133d799e1f9ab453`,bytes:30997,mediaType:`application/wasm`,layer:{path:`wasm-dotnet/runtime/layers/csharp-00.pack.gz`,offset:6584534,bytes:30997}},"wasm-dotnet/runtime/csharp/System.Diagnostics.DiagnosticSource.wasm":{sha256:`5864933f73e3a718f5537646eae8aa70bfb0b4d95c597051e0645afb7aba4cfd`,bytes:18197,mediaType:`application/wasm`,layer:{path:`wasm-dotnet/runtime/layers/csharp-00.pack.gz`,offset:6615531,bytes:18197}},"wasm-dotnet/runtime/csharp/System.Globalization.wasm":{sha256:`8396792b7b1304fc982f8d59a6a3d847926f70f575c771a126b081690d66db5b`,bytes:4373,mediaType:`application/wasm`,layer:{path:`wasm-dotnet/runtime/layers/csharp-00.pack.gz`,offset:6633728,bytes:4373}},"wasm-dotnet/runtime/csharp/System.IO.Compression.wasm":{sha256:`efa5f5dbf2faed48df07c6322e8e4232f269f162437eb6b29dbba4c1dfe6b32b`,bytes:24853,mediaType:`application/wasm`,layer:{path:`wasm-dotnet/runtime/layers/csharp-00.pack.gz`,offset:6638101,bytes:24853}},"wasm-dotnet/runtime/csharp/System.IO.MemoryMappedFiles.wasm":{sha256:`63bf010878d1823836138f6e27243bf28590da6295646c354a9b919dd0f95d3b`,bytes:24341,mediaType:`application/wasm`,layer:{path:`wasm-dotnet/runtime/layers/csharp-00.pack.gz`,offset:6662954,bytes:24341}},"wasm-dotnet/runtime/csharp/System.IO.Pipelines.wasm":{sha256:`6a0070dcee449a4b1a1d0e34a9b058deae4d0a78d9e412c448f3a3ebd1a717c8`,bytes:5909,mediaType:`application/wasm`,layer:{path:`wasm-dotnet/runtime/layers/csharp-00.pack.gz`,offset:6687295,bytes:5909}},"wasm-dotnet/runtime/csharp/System.Linq.Expressions.wasm":{sha256:`b2b645cdab124c8403dcd32db3c45dcfe60a7a147220e50a7fc24821df06709c`,bytes:7445,mediaType:`application/wasm`,layer:{path:`wasm-dotnet/runtime/layers/csharp-00.pack.gz`,offset:6693204,bytes:7445}},"wasm-dotnet/runtime/csharp/System.Linq.wasm":{sha256:`dabee02a1bba49e2e161f94cfa9522d08156eceefdc168fb9265be5316d86494`,bytes:46869,mediaType:`application/wasm`,layer:{path:`wasm-dotnet/runtime/layers/csharp-00.pack.gz`,offset:6700649,bytes:46869}},"wasm-dotnet/runtime/csharp/System.Memory.wasm":{sha256:`25c378e4f8634247fe8dcacfe3efbd0d36f1a0697b7039b4d83c56e82a7628d9`,bytes:14101,mediaType:`application/wasm`,layer:{path:`wasm-dotnet/runtime/layers/csharp-00.pack.gz`,offset:6747518,bytes:14101}},"wasm-dotnet/runtime/csharp/System.Net.Http.wasm":{sha256:`b66dd549ff3d390acedc9b1ab49d5899791adc02967b30f8ae4a693dfe40aedd`,bytes:138517,mediaType:`application/wasm`,layer:{path:`wasm-dotnet/runtime/layers/csharp-00.pack.gz`,offset:6761619,bytes:138517}},"wasm-dotnet/runtime/csharp/System.Net.Primitives.wasm":{sha256:`a54ef248e2ddfcb4991c7b196ee6b33a8c2bd06775309c9f339b1b0f50879777`,bytes:7445,mediaType:`application/wasm`,layer:{path:`wasm-dotnet/runtime/layers/csharp-00.pack.gz`,offset:6900136,bytes:7445}},"wasm-dotnet/runtime/csharp/System.ObjectModel.wasm":{sha256:`68a10e9e56a896b0006e01f4e2df1264bfe034d3913694635a926df94c02e083`,bytes:5909,mediaType:`application/wasm`,layer:{path:`wasm-dotnet/runtime/layers/csharp-00.pack.gz`,offset:6907581,bytes:5909}},"wasm-dotnet/runtime/csharp/System.Private.CoreLib.wasm":{sha256:`7f7e93f3661aee9559525c2cc412be82437a153c382387de501cb46de857860a`,bytes:1633557,mediaType:`application/wasm`,layer:{path:`wasm-dotnet/runtime/layers/csharp-00.pack.gz`,offset:6913490,bytes:1633557}},"wasm-dotnet/runtime/csharp/System.Private.Uri.wasm":{sha256:`2777bf7ba9b26016c5650049f9be6d1e6972438520e764c0c494c1568a70281a`,bytes:64277,mediaType:`application/wasm`,layer:{path:`wasm-dotnet/runtime/layers/csharp-00.pack.gz`,offset:8547047,bytes:64277}},"wasm-dotnet/runtime/csharp/System.Private.Xml.Linq.wasm":{sha256:`bef4b22cb0d5148fcf5a38e2c666c1c7c8a899119ca7bd68e55b8c0ef735940a`,bytes:44309,mediaType:`application/wasm`,layer:{path:`wasm-dotnet/runtime/layers/csharp-00.pack.gz`,offset:8611324,bytes:44309}},"wasm-dotnet/runtime/csharp/System.Private.Xml.wasm":{sha256:`9669db5606beac4759838c743e47a162214040ca15dcbada98f8f80a747cf219`,bytes:530197,mediaType:`application/wasm`,layer:{path:`wasm-dotnet/runtime/layers/csharp-00.pack.gz`,offset:8655633,bytes:530197}},"wasm-dotnet/runtime/csharp/System.Reflection.Metadata.wasm":{sha256:`e860a8ade4071950440859efe363ee0b082fae9bf18cddadc8a113f64e401dce`,bytes:257813,mediaType:`application/wasm`,layer:{path:`wasm-dotnet/runtime/layers/csharp-00.pack.gz`,offset:9185830,bytes:257813}},"wasm-dotnet/runtime/csharp/System.Runtime.InteropServices.JavaScript.wasm":{sha256:`d3a62254869fb628c7b77f5786b16240af89f7e40ecadacdfa7ee12da8eea3b7`,bytes:59157,mediaType:`application/wasm`,layer:{path:`wasm-dotnet/runtime/layers/csharp-00.pack.gz`,offset:9443643,bytes:59157}},"wasm-dotnet/runtime/csharp/System.Runtime.Numerics.wasm":{sha256:`5e5774125365581ff0e0ab8cadb7205ab9adbae6c74c888a88c6763d6d4b09d5`,bytes:80661,mediaType:`application/wasm`,layer:{path:`wasm-dotnet/runtime/layers/csharp-00.pack.gz`,offset:9502800,bytes:80661}},"wasm-dotnet/runtime/csharp/System.Runtime.Serialization.Primitives.wasm":{sha256:`630ffcf185b1d071c51c4e411333a240bf273579568068d5163997961120e576`,bytes:5909,mediaType:`application/wasm`,layer:{path:`wasm-dotnet/runtime/layers/csharp-00.pack.gz`,offset:9583461,bytes:5909}},"wasm-dotnet/runtime/csharp/System.Security.Cryptography.wasm":{sha256:`7522c4ec6d1decd42c54212b68d3cbf4886785c2bffc57c26df8111eddcaac9a`,bytes:23829,mediaType:`application/wasm`,layer:{path:`wasm-dotnet/runtime/layers/csharp-00.pack.gz`,offset:9589370,bytes:23829}},"wasm-dotnet/runtime/csharp/System.Text.Encodings.Web.wasm":{sha256:`8b6954f779e7b0de352805a65c263351bc15e1e864c00e7b9669abbaea81d648`,bytes:29461,mediaType:`application/wasm`,layer:{path:`wasm-dotnet/runtime/layers/csharp-00.pack.gz`,offset:9613199,bytes:29461}},"wasm-dotnet/runtime/csharp/System.Text.Json.wasm":{sha256:`202aa084b4c95f841837e42eaf57facc0b021325a629f44f544842aac5d6975e`,bytes:197909,mediaType:`application/wasm`,layer:{path:`wasm-dotnet/runtime/layers/csharp-00.pack.gz`,offset:9642660,bytes:197909}},"wasm-dotnet/runtime/csharp/System.Text.RegularExpressions.wasm":{sha256:`09b63ab1f89aa6b00784005b27678f77a5121eedbbf62b1a9f6e7e1820cee88c`,bytes:235797,mediaType:`application/wasm`,layer:{path:`wasm-dotnet/runtime/layers/csharp-00.pack.gz`,offset:9840569,bytes:235797}},"wasm-dotnet/runtime/csharp/System.Threading.Channels.wasm":{sha256:`79f1698693c1612b45fd49799142a32c4eadc4ff430389fce5e2d4af2884f596`,bytes:20757,mediaType:`application/wasm`,layer:{path:`wasm-dotnet/runtime/layers/csharp-00.pack.gz`,offset:10076366,bytes:20757}},"wasm-dotnet/runtime/csharp/System.Threading.Tasks.Parallel.wasm":{sha256:`a9edf29a589d922756b61c31e151f792e0189f653b584c41329934b8809b444e`,bytes:15637,mediaType:`application/wasm`,layer:{path:`wasm-dotnet/runtime/layers/csharp-00.pack.gz`,offset:10097123,bytes:15637}},"wasm-dotnet/runtime/csharp/System.Xml.Linq.wasm":{sha256:`937ef5ff8a2252bd5c88167090f6f864fb7f760322a270b21df422f54521180a`,bytes:4373,mediaType:`application/wasm`,layer:{path:`wasm-dotnet/runtime/layers/csharp-00.pack.gz`,offset:10112760,bytes:4373}},"wasm-dotnet/runtime/csharp/System.wasm":{sha256:`8e898ef2158280fd3d14ea113e4a5e8edb71455fe5a288eeec471ba922a434e7`,bytes:4373,mediaType:`application/wasm`,layer:{path:`wasm-dotnet/runtime/layers/csharp-00.pack.gz`,offset:10117133,bytes:4373}},"wasm-dotnet/runtime/csharp/WasmDotnet.Compiler.wasm":{sha256:`a6ed48c03554a23c48922e38c0d54f6f65415a4fa01d60e6e90a067a3647bec2`,bytes:69909,mediaType:`application/wasm`,layer:{path:`wasm-dotnet/runtime/layers/csharp-00.pack.gz`,offset:10121506,bytes:69909}},"wasm-dotnet/runtime/csharp/WasmDotnet.Stdin.wasm":{sha256:`fb1de53e58715855614aa0fa79280bc9e8ec8cf552e17763368a17ad34f52bce`,bytes:3861,mediaType:`application/wasm`,layer:{path:`wasm-dotnet/runtime/layers/csharp-00.pack.gz`,offset:10191415,bytes:3861}},"wasm-dotnet/runtime/csharp/blazor.boot.json":{sha256:`2b7a2d9145ee5a3acbd61f4407294da14b7b7ba25466b9f10c08c08c1399eef6`,bytes:7774,mediaType:`application/json`,layer:{path:`wasm-dotnet/runtime/layers/csharp-00.pack.gz`,offset:10195276,bytes:7774}},"wasm-dotnet/runtime/csharp/cs/Microsoft.CodeAnalysis.CSharp.resources.wasm":{sha256:`a71cd21a941d33fb2598506041ff1031e86390a58ca333c96337cfa96e477957`,bytes:430869,mediaType:`application/wasm`,layer:{path:`wasm-dotnet/runtime/layers/csharp-00.pack.gz`,offset:10203050,bytes:430869}},"wasm-dotnet/runtime/csharp/cs/Microsoft.CodeAnalysis.resources.wasm":{sha256:`9a5c8fbc8cbf693ac3f5c591fa7694ddd2258328b41dde572f216381288d230a`,bytes:37653,mediaType:`application/wasm`,layer:{path:`wasm-dotnet/runtime/layers/csharp-00.pack.gz`,offset:10633919,bytes:37653}},"wasm-dotnet/runtime/csharp/de/Microsoft.CodeAnalysis.CSharp.resources.wasm":{sha256:`4323c73910ce6de7035d24f9c4cb9fecc3a3b3ce8206e188df156223ec68bc5f`,bytes:461077,mediaType:`application/wasm`,layer:{path:`wasm-dotnet/runtime/layers/csharp-00.pack.gz`,offset:10671572,bytes:461077}},"wasm-dotnet/runtime/csharp/de/Microsoft.CodeAnalysis.resources.wasm":{sha256:`5e73b0323639ffe0ecacc753bbab657fe145e496d419fd036427aa0d9ad2f4d9`,bytes:39701,mediaType:`application/wasm`,layer:{path:`wasm-dotnet/runtime/layers/csharp-00.pack.gz`,offset:11132649,bytes:39701}},"wasm-dotnet/runtime/csharp/dotnet.js":{sha256:`f4697f2c0de6d3266d9881d1d3bca86fc24b166379798b2e1905f5db40bd65bb`,bytes:42864,mediaType:`text/javascript`,layer:{path:`wasm-dotnet/runtime/layers/csharp-00.pack.gz`,offset:11172350,bytes:42864}},"wasm-dotnet/runtime/csharp/dotnet.native.js":{sha256:`a5bed755220d252f5bda5abc474c805d009161ceaa34020fc3a681dc6ff98909`,bytes:148537,mediaType:`text/javascript`,layer:{path:`wasm-dotnet/runtime/layers/csharp-00.pack.gz`,offset:11215214,bytes:148537}},"wasm-dotnet/runtime/csharp/dotnet.native.wasm":{sha256:`93b5823f7c4f98cb921be5eb13bd8a25f80ddd7a5f729a5226b587d2dcd5cc12`,bytes:29156655,mediaType:`application/wasm`,deliveryPath:`wasm-dotnet/runtime/csharp/dotnet.native.wasm.gz`},"wasm-dotnet/runtime/csharp/dotnet.native.wasm.gz":{sha256:`6f2615a951056677d591d830dbf4b97ddd76a1c72f0a28b8f18db7880468fb20`,bytes:9400861,encoding:`gzip`,mediaType:`application/wasm`,uncompressedSha256:`93b5823f7c4f98cb921be5eb13bd8a25f80ddd7a5f729a5226b587d2dcd5cc12`,uncompressedBytes:29156655},"wasm-dotnet/runtime/csharp/dotnet.native.worker.mjs":{sha256:`5bca00fcf6664a97e54c58286bb235abfb3faa2de8582aaaf046d4520c1838d5`,bytes:2854,mediaType:`text/javascript`,layer:{path:`wasm-dotnet/runtime/layers/csharp-00.pack.gz`,offset:11363751,bytes:2854}},"wasm-dotnet/runtime/csharp/dotnet.runtime.js":{sha256:`8dea669b9580f3e9e3222cfc0407887b7b8ccda953c2048a54693ad5ede2c40c`,bytes:232671,mediaType:`text/javascript`,layer:{path:`wasm-dotnet/runtime/layers/csharp-00.pack.gz`,offset:11366605,bytes:232671}},"wasm-dotnet/runtime/csharp/es/Microsoft.CodeAnalysis.CSharp.resources.wasm":{sha256:`a106c6257d85cee3a7338d0a6fc6048c841ac7a23ea3516f3d7c93a4c7d57a92`,bytes:450837,mediaType:`application/wasm`,layer:{path:`wasm-dotnet/runtime/layers/csharp-00.pack.gz`,offset:11599276,bytes:450837}},"wasm-dotnet/runtime/csharp/es/Microsoft.CodeAnalysis.resources.wasm":{sha256:`fef6f3876c1289b90b1be87104d74ebe2b61ab45911231d923d5127ea113cddd`,bytes:39189,mediaType:`application/wasm`,layer:{path:`wasm-dotnet/runtime/layers/csharp-00.pack.gz`,offset:12050113,bytes:39189}},"wasm-dotnet/runtime/csharp/fr/Microsoft.CodeAnalysis.CSharp.resources.wasm":{sha256:`963b64c710e9679ec87403868b40638689a702cb00a2360a9251a66fe331b81b`,bytes:463125,mediaType:`application/wasm`,layer:{path:`wasm-dotnet/runtime/layers/csharp-00.pack.gz`,offset:12089302,bytes:463125}},"wasm-dotnet/runtime/csharp/fr/Microsoft.CodeAnalysis.resources.wasm":{sha256:`8e167e434812ab15faa6135c808c19cbda743f3ec475b142ad706bb6c96cd660`,bytes:39701,mediaType:`application/wasm`,layer:{path:`wasm-dotnet/runtime/layers/csharp-00.pack.gz`,offset:12552427,bytes:39701}},"wasm-dotnet/runtime/csharp/it/Microsoft.CodeAnalysis.CSharp.resources.wasm":{sha256:`94dd37278531f31f9ec209744c806c3565f9cb248c544b8eb484d54d729e878c`,bytes:457493,mediaType:`application/wasm`,layer:{path:`wasm-dotnet/runtime/layers/csharp-00.pack.gz`,offset:12592128,bytes:457493}},"wasm-dotnet/runtime/csharp/it/Microsoft.CodeAnalysis.resources.wasm":{sha256:`d0e8e7692c25c1e4e39c3862fa77d94e4a3b9c2325380f9f1a22fa7e6979575d`,bytes:39701,mediaType:`application/wasm`,layer:{path:`wasm-dotnet/runtime/layers/csharp-00.pack.gz`,offset:13049621,bytes:39701}},"wasm-dotnet/runtime/csharp/ja/Microsoft.CodeAnalysis.CSharp.resources.wasm":{sha256:`a984f5f020b40167706df13dd1b07fabf3de5cb9faa63bd28f51dc1df1a99b7e`,bytes:504597,mediaType:`application/wasm`,layer:{path:`wasm-dotnet/runtime/layers/csharp-00.pack.gz`,offset:13089322,bytes:504597}},"wasm-dotnet/runtime/csharp/ja/Microsoft.CodeAnalysis.resources.wasm":{sha256:`0170006336c2590bcfe155a894e041643bcf27f8718c8f29e9b7ec83a56a8a64`,bytes:43285,mediaType:`application/wasm`,layer:{path:`wasm-dotnet/runtime/layers/csharp-00.pack.gz`,offset:13593919,bytes:43285}},"wasm-dotnet/runtime/csharp/ko/Microsoft.CodeAnalysis.CSharp.resources.wasm":{sha256:`3303e33701d8573dd7df1bf1cc3ba9b06eb7eee6c49bae535483db4ba7ef2fde`,bytes:462613,mediaType:`application/wasm`,layer:{path:`wasm-dotnet/runtime/layers/csharp-00.pack.gz`,offset:13637204,bytes:462613}},"wasm-dotnet/runtime/csharp/ko/Microsoft.CodeAnalysis.resources.wasm":{sha256:`c273548046b7d4ff01bddb62e7640fd5f39041cbef56240398cb4c3f69e7975f`,bytes:39701,mediaType:`application/wasm`,layer:{path:`wasm-dotnet/runtime/layers/csharp-00.pack.gz`,offset:14099817,bytes:39701}},"wasm-dotnet/runtime/csharp/pl/Microsoft.CodeAnalysis.CSharp.resources.wasm":{sha256:`98edd553fff66f35ae4a20a8d8bff5f8b990d53ff547d0a9fd38db6454c5cfd5`,bytes:463637,mediaType:`application/wasm`,layer:{path:`wasm-dotnet/runtime/layers/csharp-00.pack.gz`,offset:14139518,bytes:463637}},"wasm-dotnet/runtime/csharp/pl/Microsoft.CodeAnalysis.resources.wasm":{sha256:`7417edd7a418a858074e10277c36cf2f5e068193b8c5ec3716e4f646f489bc31`,bytes:39701,mediaType:`application/wasm`,layer:{path:`wasm-dotnet/runtime/layers/csharp-00.pack.gz`,offset:14603155,bytes:39701}},"wasm-dotnet/runtime/csharp/pt-BR/Microsoft.CodeAnalysis.CSharp.resources.wasm":{sha256:`39ee81c693c861b26a41fcc670ef17fd3fd678550fc50d262d83cf6677a02ce7`,bytes:443157,mediaType:`application/wasm`,layer:{path:`wasm-dotnet/runtime/layers/csharp-00.pack.gz`,offset:14642856,bytes:443157}},"wasm-dotnet/runtime/csharp/pt-BR/Microsoft.CodeAnalysis.resources.wasm":{sha256:`921393dcb10c6c087c0c3b73b493de8a2b8b6033dd2010fa724a8ae56e65446e`,bytes:38677,mediaType:`application/wasm`,layer:{path:`wasm-dotnet/runtime/layers/csharp-00.pack.gz`,offset:15086013,bytes:38677}},"wasm-dotnet/runtime/csharp/ru/Microsoft.CodeAnalysis.CSharp.resources.wasm":{sha256:`ce074440d87f9f9e9da54db562668d4417f40113cee4300bc37246af91cc8d04`,bytes:610581,mediaType:`application/wasm`,layer:{path:`wasm-dotnet/runtime/layers/csharp-00.pack.gz`,offset:15124690,bytes:610581}},"wasm-dotnet/runtime/csharp/ru/Microsoft.CodeAnalysis.resources.wasm":{sha256:`63ee787aea6292dcdbdab9ef2487cef244ebbbbbafee3e1212770399f8ce7b96`,bytes:49941,mediaType:`application/wasm`,layer:{path:`wasm-dotnet/runtime/layers/csharp-00.pack.gz`,offset:15735271,bytes:49941}},"wasm-dotnet/runtime/csharp/supportFiles/0_runtimeconfig.bin":{sha256:`eba865048cf85bf45a627bfda964b22784be8e1616d250d9349e962a186e8d34`,bytes:1551,mediaType:`application/octet-stream`,layer:{path:`wasm-dotnet/runtime/layers/csharp-00.pack.gz`,offset:15785212,bytes:1551}},"wasm-dotnet/runtime/csharp/tr/Microsoft.CodeAnalysis.CSharp.resources.wasm":{sha256:`1764230af7603218a5ec0e5f8006618319a3e30b3803a06a4ebc8609f910ddf2`,bytes:439061,mediaType:`application/wasm`,layer:{path:`wasm-dotnet/runtime/layers/csharp-00.pack.gz`,offset:15786763,bytes:439061}},"wasm-dotnet/runtime/csharp/tr/Microsoft.CodeAnalysis.resources.wasm":{sha256:`1f05bc34b37b713aa565f61ed7a801fdadd00813ba6462a2f35ac0a5045379ce`,bytes:38165,mediaType:`application/wasm`,layer:{path:`wasm-dotnet/runtime/layers/csharp-00.pack.gz`,offset:16225824,bytes:38165}},"wasm-dotnet/runtime/csharp/zh-Hans/Microsoft.CodeAnalysis.CSharp.resources.wasm":{sha256:`2717ddcf72609a89f9c2bad98230c6ebe85302b87956b65e41b953d6d66e78f0`,bytes:390421,mediaType:`application/wasm`,layer:{path:`wasm-dotnet/runtime/layers/csharp-00.pack.gz`,offset:16263989,bytes:390421}},"wasm-dotnet/runtime/csharp/zh-Hans/Microsoft.CodeAnalysis.resources.wasm":{sha256:`85e94866e88998e4b88920ad7bcd3e4de57f91ec9c5b0e3331369ded3102739d`,bytes:34581,mediaType:`application/wasm`,layer:{path:`wasm-dotnet/runtime/layers/csharp-00.pack.gz`,offset:16654410,bytes:34581}},"wasm-dotnet/runtime/csharp/zh-Hant/Microsoft.CodeAnalysis.CSharp.resources.wasm":{sha256:`7924d132a621057d064d73e74a1e1d63486eee7fd73de4529b022b34e7003951`,bytes:389909,mediaType:`application/wasm`,layer:{path:`wasm-dotnet/runtime/layers/csharp-01.pack.gz`,offset:0,bytes:389909}},"wasm-dotnet/runtime/csharp/zh-Hant/Microsoft.CodeAnalysis.resources.wasm":{sha256:`ad5707a586422ee6256c8a9f044d26378c971706424b661b47b4f93f2a1e368d`,bytes:34581,mediaType:`application/wasm`,layer:{path:`wasm-dotnet/runtime/layers/csharp-01.pack.gz`,offset:389909,bytes:34581}},"wasm-dotnet/runtime/fsharp/FSharp.Compiler.Service.wasm":{sha256:`a58645e1b93b62aedee3cb4f9ffa04a165b9c3a7f8509ae4c221a648dde271d6`,bytes:15848729,mediaType:`application/wasm`,layer:{path:`wasm-dotnet/runtime/layers/fsharp-00.pack.gz`,offset:0,bytes:15848729}},"wasm-dotnet/runtime/fsharp/FSharp.Core.wasm":{sha256:`96802397c8f3b6830c93b0b44fb5b7252989bd09176566d131e2ad112f822c38`,bytes:1670933,mediaType:`application/wasm`,layer:{path:`wasm-dotnet/runtime/layers/fsharp-01.pack.gz`,offset:0,bytes:1670933}},"wasm-dotnet/runtime/fsharp/System.Buffers.wasm":{sha256:`0cbb8cc5c5750454a01e5be5e017156db386e64dfff106a06c32a594261cdda5`,bytes:4373,mediaType:`application/wasm`,layer:{path:`wasm-dotnet/runtime/layers/fsharp-01.pack.gz`,offset:1670933,bytes:4373}},"wasm-dotnet/runtime/fsharp/System.Collections.Concurrent.wasm":{sha256:`d90906901de698ecfadab579176024b73584b476aabcce3183d13fe1d55b33d0`,bytes:30997,mediaType:`application/wasm`,layer:{path:`wasm-dotnet/runtime/layers/fsharp-01.pack.gz`,offset:1675306,bytes:30997}},"wasm-dotnet/runtime/fsharp/System.Collections.Immutable.wasm":{sha256:`6c08dd9086f8d9eb365fc413ffdf46d0051c3cb231a821691f84d4e1ef506f51`,bytes:62741,mediaType:`application/wasm`,layer:{path:`wasm-dotnet/runtime/layers/fsharp-01.pack.gz`,offset:1706303,bytes:62741}},"wasm-dotnet/runtime/fsharp/System.Collections.NonGeneric.wasm":{sha256:`8da781ba579360cee3c8e9edc503669f31bab42a7ce451feb7ac00de521c76a8`,bytes:12565,mediaType:`application/wasm`,layer:{path:`wasm-dotnet/runtime/layers/fsharp-01.pack.gz`,offset:1769044,bytes:12565}},"wasm-dotnet/runtime/fsharp/System.Collections.Specialized.wasm":{sha256:`a3dd0598cf002bb4a7532feedb42154940918695febbe295da839ec7a62cb91c`,bytes:10005,mediaType:`application/wasm`,layer:{path:`wasm-dotnet/runtime/layers/fsharp-01.pack.gz`,offset:1781609,bytes:10005}},"wasm-dotnet/runtime/fsharp/System.Collections.wasm":{sha256:`2716e3dc2be5eccd8896b5186e17fa1ddced99f315036263cca39016b59ef958`,bytes:16661,mediaType:`application/wasm`,layer:{path:`wasm-dotnet/runtime/layers/fsharp-01.pack.gz`,offset:1791614,bytes:16661}},"wasm-dotnet/runtime/fsharp/System.ComponentModel.EventBasedAsync.wasm":{sha256:`d6ec0c23bc4cd5ddc78fa51b23ec916bf55802a205d93a99c816f00251c35fda`,bytes:5397,mediaType:`application/wasm`,layer:{path:`wasm-dotnet/runtime/layers/fsharp-01.pack.gz`,offset:1808275,bytes:5397}},"wasm-dotnet/runtime/fsharp/System.ComponentModel.Primitives.wasm":{sha256:`d5586cbcb719b4be216a42b6eef35509758e60ea462a1e93fcbd7c17001dd8c4`,bytes:11029,mediaType:`application/wasm`,layer:{path:`wasm-dotnet/runtime/layers/fsharp-01.pack.gz`,offset:1813672,bytes:11029}},"wasm-dotnet/runtime/fsharp/System.ComponentModel.TypeConverter.wasm":{sha256:`571f3ee9a70bfba8542a735a7f9d616094da68018549ba50ce66e51849e75af0`,bytes:45333,mediaType:`application/wasm`,layer:{path:`wasm-dotnet/runtime/layers/fsharp-01.pack.gz`,offset:1824701,bytes:45333}},"wasm-dotnet/runtime/fsharp/System.ComponentModel.wasm":{sha256:`455436e971c5bd41f2de5062ea7a2abb6b9a80870b11986750705a6d2164697a`,bytes:4885,mediaType:`application/wasm`,layer:{path:`wasm-dotnet/runtime/layers/fsharp-01.pack.gz`,offset:1870034,bytes:4885}},"wasm-dotnet/runtime/fsharp/System.Console.wasm":{sha256:`d050bc4a3e69738ced6b23ec1b7633ef58fe4aa00b07ced8c2ff61a4a3dcd716`,bytes:30997,mediaType:`application/wasm`,layer:{path:`wasm-dotnet/runtime/layers/fsharp-01.pack.gz`,offset:1874919,bytes:30997}},"wasm-dotnet/runtime/fsharp/System.Diagnostics.DiagnosticSource.wasm":{sha256:`0392e10077a0172e02ebe8672486123b5391a4d1ed490b431202428a938645de`,bytes:63765,mediaType:`application/wasm`,layer:{path:`wasm-dotnet/runtime/layers/fsharp-01.pack.gz`,offset:1905916,bytes:63765}},"wasm-dotnet/runtime/fsharp/System.Diagnostics.Process.wasm":{sha256:`05c86e1133898a08cb61e6391496df45e7c300ee1acd5b5834250414fb739801`,bytes:8981,mediaType:`application/wasm`,layer:{path:`wasm-dotnet/runtime/layers/fsharp-01.pack.gz`,offset:1969681,bytes:8981}},"wasm-dotnet/runtime/fsharp/System.Diagnostics.TraceSource.wasm":{sha256:`e7c7206c2e63f5241b266a1834948d0216ad95698b147519b8a6741b678d7d7b`,bytes:17173,mediaType:`application/wasm`,layer:{path:`wasm-dotnet/runtime/layers/fsharp-01.pack.gz`,offset:1978662,bytes:17173}},"wasm-dotnet/runtime/fsharp/System.IO.Compression.wasm":{sha256:`b5b6f0fc3ad7bc71b15b4957c5e7894452187c307da6d0396b392f5d5cf713db`,bytes:29973,mediaType:`application/wasm`,layer:{path:`wasm-dotnet/runtime/layers/fsharp-01.pack.gz`,offset:1995835,bytes:29973}},"wasm-dotnet/runtime/fsharp/System.IO.MemoryMappedFiles.wasm":{sha256:`341d6456d01380886a11e286020726ab73d32bebc29e92654d16f5dd6f55fbd6`,bytes:25877,mediaType:`application/wasm`,layer:{path:`wasm-dotnet/runtime/layers/fsharp-01.pack.gz`,offset:2025808,bytes:25877}},"wasm-dotnet/runtime/fsharp/System.IO.Pipelines.wasm":{sha256:`6a0070dcee449a4b1a1d0e34a9b058deae4d0a78d9e412c448f3a3ebd1a717c8`,bytes:5909,mediaType:`application/wasm`,layer:{path:`wasm-dotnet/runtime/layers/fsharp-01.pack.gz`,offset:2051685,bytes:5909}},"wasm-dotnet/runtime/fsharp/System.IO.Pipes.wasm":{sha256:`044f07f25e283a8fd51eb1a3d8f55e41436cf878b14da5df8eb75022f9a72cb2`,bytes:6933,mediaType:`application/wasm`,layer:{path:`wasm-dotnet/runtime/layers/fsharp-01.pack.gz`,offset:2057594,bytes:6933}},"wasm-dotnet/runtime/fsharp/System.Linq.Expressions.wasm":{sha256:`a781f58019ec08fed5d56a32a20d490cb6c44d5ded812d957643d096ac781b89`,bytes:359189,mediaType:`application/wasm`,layer:{path:`wasm-dotnet/runtime/layers/fsharp-01.pack.gz`,offset:2064527,bytes:359189}},"wasm-dotnet/runtime/fsharp/System.Linq.Queryable.wasm":{sha256:`4036f420dad23f3a93a36f3373629a3613dde646c7fd9703ccbcd6856979af78`,bytes:30997,mediaType:`application/wasm`,layer:{path:`wasm-dotnet/runtime/layers/fsharp-01.pack.gz`,offset:2423716,bytes:30997}},"wasm-dotnet/runtime/fsharp/System.Linq.wasm":{sha256:`16c9a91f37b70995782c600ca6a0483b430b5e1f43e8d0eeef49b9deb73a37aa`,bytes:69397,mediaType:`application/wasm`,layer:{path:`wasm-dotnet/runtime/layers/fsharp-01.pack.gz`,offset:2454713,bytes:69397}},"wasm-dotnet/runtime/fsharp/System.Memory.wasm":{sha256:`aab6b63b6d9067b5ace349f86cb1e0e2c8ffca705ecdf177344aec67c798b1ba`,bytes:14101,mediaType:`application/wasm`,layer:{path:`wasm-dotnet/runtime/layers/fsharp-01.pack.gz`,offset:2524110,bytes:14101}},"wasm-dotnet/runtime/fsharp/System.Net.Http.wasm":{sha256:`63b45f308a7fe398bf9ace5055cb7562342892f1da4a481fbcaa417b16c7b3c8`,bytes:142101,mediaType:`application/wasm`,layer:{path:`wasm-dotnet/runtime/layers/fsharp-01.pack.gz`,offset:2538211,bytes:142101}},"wasm-dotnet/runtime/fsharp/System.Net.Primitives.wasm":{sha256:`a54ef248e2ddfcb4991c7b196ee6b33a8c2bd06775309c9f339b1b0f50879777`,bytes:7445,mediaType:`application/wasm`,layer:{path:`wasm-dotnet/runtime/layers/fsharp-01.pack.gz`,offset:2680312,bytes:7445}},"wasm-dotnet/runtime/fsharp/System.Net.Requests.wasm":{sha256:`5dd08a468c71fafa30c4e3e001113dbf3919e36cfa286c161de2681645d37876`,bytes:6421,mediaType:`application/wasm`,layer:{path:`wasm-dotnet/runtime/layers/fsharp-01.pack.gz`,offset:2687757,bytes:6421}},"wasm-dotnet/runtime/fsharp/System.Net.WebClient.wasm":{sha256:`de6906f49868ee3710fb45f96a14da5940d4a2c1c47f82583632516f00be220d`,bytes:6421,mediaType:`application/wasm`,layer:{path:`wasm-dotnet/runtime/layers/fsharp-01.pack.gz`,offset:2694178,bytes:6421}},"wasm-dotnet/runtime/fsharp/System.ObjectModel.wasm":{sha256:`68a10e9e56a896b0006e01f4e2df1264bfe034d3913694635a926df94c02e083`,bytes:5909,mediaType:`application/wasm`,layer:{path:`wasm-dotnet/runtime/layers/fsharp-01.pack.gz`,offset:2700599,bytes:5909}},"wasm-dotnet/runtime/fsharp/System.Private.CoreLib.wasm":{sha256:`49a0803f5078b2c7b1ef2fc872b54be8d14d1a150cb7b9546da27f5bf758feea`,bytes:1880853,mediaType:`application/wasm`,layer:{path:`wasm-dotnet/runtime/layers/fsharp-01.pack.gz`,offset:2706508,bytes:1880853}},"wasm-dotnet/runtime/fsharp/System.Private.Uri.wasm":{sha256:`2777bf7ba9b26016c5650049f9be6d1e6972438520e764c0c494c1568a70281a`,bytes:64277,mediaType:`application/wasm`,layer:{path:`wasm-dotnet/runtime/layers/fsharp-01.pack.gz`,offset:4587361,bytes:64277}},"wasm-dotnet/runtime/fsharp/System.Private.Xml.Linq.wasm":{sha256:`6c3c98f12900db56e3332542772b006ccba7fb3119da857e16c22291b60d0c13`,bytes:35093,mediaType:`application/wasm`,layer:{path:`wasm-dotnet/runtime/layers/fsharp-01.pack.gz`,offset:4651638,bytes:35093}},"wasm-dotnet/runtime/fsharp/System.Private.Xml.wasm":{sha256:`88b57cbe3f03e3809bd30174d3c8281b0cde83159f1e71d4b53c65e98f8cf1e7`,bytes:688405,mediaType:`application/wasm`,layer:{path:`wasm-dotnet/runtime/layers/fsharp-01.pack.gz`,offset:4686731,bytes:688405}},"wasm-dotnet/runtime/fsharp/System.Reflection.Emit.ILGeneration.wasm":{sha256:`a12370f269ac1320bb365d1f0bdbd79ee0a59a90c189c8acd411a9757e1989f8`,bytes:4885,mediaType:`application/wasm`,layer:{path:`wasm-dotnet/runtime/layers/fsharp-01.pack.gz`,offset:5375136,bytes:4885}},"wasm-dotnet/runtime/fsharp/System.Reflection.Emit.wasm":{sha256:`a2c19aed6366d54d09bc271d9549d60f3ca3de68b919dabd37460c6687e57e8f`,bytes:14613,mediaType:`application/wasm`,layer:{path:`wasm-dotnet/runtime/layers/fsharp-01.pack.gz`,offset:5380021,bytes:14613}},"wasm-dotnet/runtime/fsharp/System.Reflection.Metadata.wasm":{sha256:`a49906d04f47600a0cb56975cd968fc18bf8e2dbed8940fb195d12dae0858212`,bytes:134933,mediaType:`application/wasm`,layer:{path:`wasm-dotnet/runtime/layers/fsharp-01.pack.gz`,offset:5394634,bytes:134933}},"wasm-dotnet/runtime/fsharp/System.Runtime.InteropServices.JavaScript.wasm":{sha256:`51ed66d7cd88952885c7184b2e58ebb9c0ac62f42af5c62e83c497f9abc01d1f`,bytes:59157,mediaType:`application/wasm`,layer:{path:`wasm-dotnet/runtime/layers/fsharp-01.pack.gz`,offset:5529567,bytes:59157}},"wasm-dotnet/runtime/fsharp/System.Runtime.InteropServices.RuntimeInformation.wasm":{sha256:`22db9c8fdbc313476d62daa2d8ec4cfb8fc1b317608dca4f653e5cb21e937848`,bytes:4885,mediaType:`application/wasm`,layer:{path:`wasm-dotnet/runtime/layers/fsharp-01.pack.gz`,offset:5588724,bytes:4885}},"wasm-dotnet/runtime/fsharp/System.Runtime.InteropServices.wasm":{sha256:`5dd236cd9a86d32f841d5f461c54d65c9a239ebd66d31dcbb71b5f8b5d1062e5`,bytes:5909,mediaType:`application/wasm`,layer:{path:`wasm-dotnet/runtime/layers/fsharp-01.pack.gz`,offset:5593609,bytes:5909}},"wasm-dotnet/runtime/fsharp/System.Runtime.Loader.wasm":{sha256:`98f1fc84dc72dec2596614ab144267a9c8e5dea72170f9ac2ebb1b711dc89a46`,bytes:4885,mediaType:`application/wasm`,layer:{path:`wasm-dotnet/runtime/layers/fsharp-01.pack.gz`,offset:5599518,bytes:4885}},"wasm-dotnet/runtime/fsharp/System.Runtime.Numerics.wasm":{sha256:`9fc1957a3142a7af9084a45e59bcd3d3584292befb12f0f971f2c8c2fe3fe722`,bytes:83221,mediaType:`application/wasm`,layer:{path:`wasm-dotnet/runtime/layers/fsharp-01.pack.gz`,offset:5604403,bytes:83221}},"wasm-dotnet/runtime/fsharp/System.Security.Cryptography.wasm":{sha256:`5ea33c0493c50edb5e0186d8581a5f81bff142ff8c60e855c61cefc333f02e0b`,bytes:23829,mediaType:`application/wasm`,layer:{path:`wasm-dotnet/runtime/layers/fsharp-01.pack.gz`,offset:5687624,bytes:23829}},"wasm-dotnet/runtime/fsharp/System.Text.Encodings.Web.wasm":{sha256:`bc7d1eee6c3ff69df77aa689c872205594f58aca23f82115b0cd8890bd902bee`,bytes:29461,mediaType:`application/wasm`,layer:{path:`wasm-dotnet/runtime/layers/fsharp-01.pack.gz`,offset:5711453,bytes:29461}},"wasm-dotnet/runtime/fsharp/System.Text.Json.wasm":{sha256:`a1a90eff03f7614f5a71bda16600dee52354fef4408bff39aa379dbee330981d`,bytes:200469,mediaType:`application/wasm`,layer:{path:`wasm-dotnet/runtime/layers/fsharp-01.pack.gz`,offset:5740914,bytes:200469}},"wasm-dotnet/runtime/fsharp/System.Text.RegularExpressions.wasm":{sha256:`8267556630cfac3192bc93d1138118b9d069f7fed0d9f6c96eb70e57bbe177f2`,bytes:251669,mediaType:`application/wasm`,layer:{path:`wasm-dotnet/runtime/layers/fsharp-01.pack.gz`,offset:5941383,bytes:251669}},"wasm-dotnet/runtime/fsharp/System.Threading.Channels.wasm":{sha256:`8d57e9bf881b183453ebe6b4b7cdf9d290e7ee2bf2e525c6f8f83c777001381c`,bytes:21269,mediaType:`application/wasm`,layer:{path:`wasm-dotnet/runtime/layers/fsharp-01.pack.gz`,offset:6193052,bytes:21269}},"wasm-dotnet/runtime/fsharp/System.Threading.Tasks.Parallel.wasm":{sha256:`8987c1b72c8a7eeefda272244219af8ffb7adb8f5ffe7aa2360cbcc8aa92eea7`,bytes:17173,mediaType:`application/wasm`,layer:{path:`wasm-dotnet/runtime/layers/fsharp-01.pack.gz`,offset:6214321,bytes:17173}},"wasm-dotnet/runtime/fsharp/System.Xml.Linq.wasm":{sha256:`937ef5ff8a2252bd5c88167090f6f864fb7f760322a270b21df422f54521180a`,bytes:4373,mediaType:`application/wasm`,layer:{path:`wasm-dotnet/runtime/layers/fsharp-01.pack.gz`,offset:6231494,bytes:4373}},"wasm-dotnet/runtime/fsharp/System.wasm":{sha256:`8e898ef2158280fd3d14ea113e4a5e8edb71455fe5a288eeec471ba922a434e7`,bytes:4373,mediaType:`application/wasm`,layer:{path:`wasm-dotnet/runtime/layers/fsharp-01.pack.gz`,offset:6235867,bytes:4373}},"wasm-dotnet/runtime/fsharp/WasmDotnet.Compiler.wasm":{sha256:`e3a2f06aaf0fa8c1cf8f0f7c4330322607063119077625e7c2712fa9f2e7c5b5`,bytes:67861,mediaType:`application/wasm`,layer:{path:`wasm-dotnet/runtime/layers/fsharp-01.pack.gz`,offset:6240240,bytes:67861}},"wasm-dotnet/runtime/fsharp/WasmDotnet.Stdin.wasm":{sha256:`fb1de53e58715855614aa0fa79280bc9e8ec8cf552e17763368a17ad34f52bce`,bytes:3861,mediaType:`application/wasm`,layer:{path:`wasm-dotnet/runtime/layers/fsharp-01.pack.gz`,offset:6308101,bytes:3861}},"wasm-dotnet/runtime/fsharp/blazor.boot.json":{sha256:`0037278684da652b9cde6d77c14c89c5ba29c76d8925b8d68868a78eeea7b5c7`,bytes:10123,mediaType:`application/json`,layer:{path:`wasm-dotnet/runtime/layers/fsharp-01.pack.gz`,offset:6311962,bytes:10123}},"wasm-dotnet/runtime/fsharp/cs/FSharp.Compiler.Service.resources.wasm":{sha256:`461b3c6a84e9455f1db9caff8e03ea012b414759763f356ac2c6e878b2934ad9`,bytes:363797,mediaType:`application/wasm`,layer:{path:`wasm-dotnet/runtime/layers/fsharp-01.pack.gz`,offset:6322085,bytes:363797}},"wasm-dotnet/runtime/fsharp/cs/FSharp.Core.resources.wasm":{sha256:`e747e7e32693e3937735f2d876399a31548e0445026606efb7fedcf15406ca6a`,bytes:23829,mediaType:`application/wasm`,layer:{path:`wasm-dotnet/runtime/layers/fsharp-01.pack.gz`,offset:6685882,bytes:23829}},"wasm-dotnet/runtime/fsharp/cs/FSharp.DependencyManager.Nuget.resources.wasm":{sha256:`801a44e49fbb1d18e8a683421b54670a0365a7e51291e735d4381e39440a0646`,bytes:5909,mediaType:`application/wasm`,layer:{path:`wasm-dotnet/runtime/layers/fsharp-01.pack.gz`,offset:6709711,bytes:5909}},"wasm-dotnet/runtime/fsharp/de/FSharp.Compiler.Service.resources.wasm":{sha256:`afc6b5ede05f011f86af03245ae673680d2f55f443cd2f6e7b977f5a13071617`,bytes:386837,mediaType:`application/wasm`,layer:{path:`wasm-dotnet/runtime/layers/fsharp-01.pack.gz`,offset:6715620,bytes:386837}},"wasm-dotnet/runtime/fsharp/de/FSharp.Core.resources.wasm":{sha256:`215d63e50cb10f8b59508262c2a5e077eb59db25203a8e49775b129cde988cbe`,bytes:24853,mediaType:`application/wasm`,layer:{path:`wasm-dotnet/runtime/layers/fsharp-01.pack.gz`,offset:7102457,bytes:24853}},"wasm-dotnet/runtime/fsharp/de/FSharp.DependencyManager.Nuget.resources.wasm":{sha256:`a56d066c7251e2b4f7677923d34fb7ff6ef7685a65d5fb55f20fdf99d393ae34`,bytes:5909,mediaType:`application/wasm`,layer:{path:`wasm-dotnet/runtime/layers/fsharp-01.pack.gz`,offset:7127310,bytes:5909}},"wasm-dotnet/runtime/fsharp/dotnet.js":{sha256:`f4697f2c0de6d3266d9881d1d3bca86fc24b166379798b2e1905f5db40bd65bb`,bytes:42864,mediaType:`text/javascript`,layer:{path:`wasm-dotnet/runtime/layers/fsharp-01.pack.gz`,offset:7133219,bytes:42864}},"wasm-dotnet/runtime/fsharp/dotnet.native.js":{sha256:`12d7d6748d1abc896484faa9b4a0f368b5069ef87079387d2bdba0f1e0e1d100`,bytes:166962,mediaType:`text/javascript`,layer:{path:`wasm-dotnet/runtime/layers/fsharp-01.pack.gz`,offset:7176083,bytes:166962}},"wasm-dotnet/runtime/fsharp/dotnet.native.wasm":{sha256:`0d3c66faf195bcd048f7e787b1e776291b6f7e7e8baa35073a8776bd9db0e3ab`,bytes:47182075,mediaType:`application/wasm`,deliveryPath:`wasm-dotnet/runtime/fsharp/dotnet.native.wasm.gz`},"wasm-dotnet/runtime/fsharp/dotnet.native.wasm.gz":{sha256:`ad9092d0c5f5007a8ffa77cadd76dd901682cff55bb62dc257c6ec15b9fede0f`,bytes:14256680,encoding:`gzip`,mediaType:`application/wasm`,uncompressedSha256:`0d3c66faf195bcd048f7e787b1e776291b6f7e7e8baa35073a8776bd9db0e3ab`,uncompressedBytes:47182075},"wasm-dotnet/runtime/fsharp/dotnet.native.worker.mjs":{sha256:`5bca00fcf6664a97e54c58286bb235abfb3faa2de8582aaaf046d4520c1838d5`,bytes:2854,mediaType:`text/javascript`,layer:{path:`wasm-dotnet/runtime/layers/fsharp-01.pack.gz`,offset:7343045,bytes:2854}},"wasm-dotnet/runtime/fsharp/dotnet.runtime.js":{sha256:`8dea669b9580f3e9e3222cfc0407887b7b8ccda953c2048a54693ad5ede2c40c`,bytes:232671,mediaType:`text/javascript`,layer:{path:`wasm-dotnet/runtime/layers/fsharp-01.pack.gz`,offset:7345899,bytes:232671}},"wasm-dotnet/runtime/fsharp/es/FSharp.Compiler.Service.resources.wasm":{sha256:`e60ddc1b545938f59b6063121df593c2d2218ea4f876bb91c00079576aa22b65`,bytes:378133,mediaType:`application/wasm`,layer:{path:`wasm-dotnet/runtime/layers/fsharp-01.pack.gz`,offset:7578570,bytes:378133}},"wasm-dotnet/runtime/fsharp/es/FSharp.Core.resources.wasm":{sha256:`917bec52bca724c98dd39a2898e6d22113367488362be60282cce88b10ddf1dc`,bytes:23829,mediaType:`application/wasm`,layer:{path:`wasm-dotnet/runtime/layers/fsharp-01.pack.gz`,offset:7956703,bytes:23829}},"wasm-dotnet/runtime/fsharp/es/FSharp.DependencyManager.Nuget.resources.wasm":{sha256:`179a58149ce647890433ca71ea84ab0b3cc5b1f1d9fb479dd5ee5257e7416598`,bytes:5909,mediaType:`application/wasm`,layer:{path:`wasm-dotnet/runtime/layers/fsharp-01.pack.gz`,offset:7980532,bytes:5909}},"wasm-dotnet/runtime/fsharp/fr/FSharp.Compiler.Service.resources.wasm":{sha256:`6c68f2f21ea2aa15e05ad67d2364bfe5088b3b8b1b584f2f9598e46338bd2024`,bytes:385813,mediaType:`application/wasm`,layer:{path:`wasm-dotnet/runtime/layers/fsharp-01.pack.gz`,offset:7986441,bytes:385813}},"wasm-dotnet/runtime/fsharp/fr/FSharp.Core.resources.wasm":{sha256:`bc24b2b50829735cf25cf99ab2da4dfcf0f58c20b680ce08dcbc44798f55f93c`,bytes:24341,mediaType:`application/wasm`,layer:{path:`wasm-dotnet/runtime/layers/fsharp-01.pack.gz`,offset:8372254,bytes:24341}},"wasm-dotnet/runtime/fsharp/fr/FSharp.DependencyManager.Nuget.resources.wasm":{sha256:`c13cba3e0ccf3d8f9ae79265033645c41b3b893877be3767d7623267114c5ad5`,bytes:5909,mediaType:`application/wasm`,layer:{path:`wasm-dotnet/runtime/layers/fsharp-01.pack.gz`,offset:8396595,bytes:5909}},"wasm-dotnet/runtime/fsharp/it/FSharp.Compiler.Service.resources.wasm":{sha256:`7d0725d26d28ffa556336b1976ae390626d3e85c9f83f2bc789686e2cd0f8450`,bytes:379669,mediaType:`application/wasm`,layer:{path:`wasm-dotnet/runtime/layers/fsharp-01.pack.gz`,offset:8402504,bytes:379669}},"wasm-dotnet/runtime/fsharp/it/FSharp.Core.resources.wasm":{sha256:`6e4617de367cb5b9f4aa756f17263406b275a0be01171c97ea1dee1a8e5fd8b5`,bytes:23829,mediaType:`application/wasm`,layer:{path:`wasm-dotnet/runtime/layers/fsharp-01.pack.gz`,offset:8782173,bytes:23829}},"wasm-dotnet/runtime/fsharp/it/FSharp.DependencyManager.Nuget.resources.wasm":{sha256:`52e0de64b9ee8190375d9a26b80351f90fb8ba9140a25f43d9534e20e2b03553`,bytes:5909,mediaType:`application/wasm`,layer:{path:`wasm-dotnet/runtime/layers/fsharp-01.pack.gz`,offset:8806002,bytes:5909}},"wasm-dotnet/runtime/fsharp/ja/FSharp.Compiler.Service.resources.wasm":{sha256:`8b74d91b824c5edb0fba9cf37b1a8c7a75f8fd7e7fcce1b5dbc4af2b012898b2`,bytes:420629,mediaType:`application/wasm`,layer:{path:`wasm-dotnet/runtime/layers/fsharp-01.pack.gz`,offset:8811911,bytes:420629}},"wasm-dotnet/runtime/fsharp/ja/FSharp.Core.resources.wasm":{sha256:`d1bca22721aa10335d44eb134600ef1d048f890e2c9adaeed3b85ca97fc799f6`,bytes:26389,mediaType:`application/wasm`,layer:{path:`wasm-dotnet/runtime/layers/fsharp-01.pack.gz`,offset:9232540,bytes:26389}},"wasm-dotnet/runtime/fsharp/ja/FSharp.DependencyManager.Nuget.resources.wasm":{sha256:`fcbeb3fdbee4ee93e9f39cacedebd5f636bea13105a77687a76ce7ce2d5f7840`,bytes:5909,mediaType:`application/wasm`,layer:{path:`wasm-dotnet/runtime/layers/fsharp-01.pack.gz`,offset:9258929,bytes:5909}},"wasm-dotnet/runtime/fsharp/ko/FSharp.Compiler.Service.resources.wasm":{sha256:`65f30a180590d856e279df9654cf9aa0c439b99404bb1cecc4622c4aeef8b250`,bytes:390933,mediaType:`application/wasm`,layer:{path:`wasm-dotnet/runtime/layers/fsharp-01.pack.gz`,offset:9264838,bytes:390933}},"wasm-dotnet/runtime/fsharp/ko/FSharp.Core.resources.wasm":{sha256:`0bc2548dc5934a7f4ef1870a530d23a01b82f6cbbdab84dc8eeafd5d2d1c05d5`,bytes:25365,mediaType:`application/wasm`,layer:{path:`wasm-dotnet/runtime/layers/fsharp-01.pack.gz`,offset:9655771,bytes:25365}},"wasm-dotnet/runtime/fsharp/ko/FSharp.DependencyManager.Nuget.resources.wasm":{sha256:`e271ec979aad32d9e6fe8ee21f8e16906e0caac18ff70930d6cc93e365455021`,bytes:5909,mediaType:`application/wasm`,layer:{path:`wasm-dotnet/runtime/layers/fsharp-01.pack.gz`,offset:9681136,bytes:5909}},"wasm-dotnet/runtime/fsharp/netstandard.wasm":{sha256:`614fcf154d86e0588e962e9efa4c80ccc33d693520eff65789bbc211f18e273a`,bytes:18709,mediaType:`application/wasm`,layer:{path:`wasm-dotnet/runtime/layers/fsharp-01.pack.gz`,offset:9687045,bytes:18709}},"wasm-dotnet/runtime/fsharp/pl/FSharp.Compiler.Service.resources.wasm":{sha256:`a161f76916944f94d9a16cf36b494056c05c8ffbe392e28cdc875bb671952a51`,bytes:385301,mediaType:`application/wasm`,layer:{path:`wasm-dotnet/runtime/layers/fsharp-01.pack.gz`,offset:9705754,bytes:385301}},"wasm-dotnet/runtime/fsharp/pl/FSharp.Core.resources.wasm":{sha256:`09a5fc696f1ee93c5dd2c19d2557784e31df7626f6651e77e6903cd2c83d7387`,bytes:24853,mediaType:`application/wasm`,layer:{path:`wasm-dotnet/runtime/layers/fsharp-01.pack.gz`,offset:10091055,bytes:24853}},"wasm-dotnet/runtime/fsharp/pl/FSharp.DependencyManager.Nuget.resources.wasm":{sha256:`daea6d8fc6b4e70ece2ce833943324237d51b7ad5caa8070eca6747fd3e267d7`,bytes:5909,mediaType:`application/wasm`,layer:{path:`wasm-dotnet/runtime/layers/fsharp-01.pack.gz`,offset:10115908,bytes:5909}},"wasm-dotnet/runtime/fsharp/pt-BR/FSharp.Compiler.Service.resources.wasm":{sha256:`a8d30094481ed5116968da4904a434b6267b684959e1bea72881d53e2d9f68bc`,bytes:371477,mediaType:`application/wasm`,layer:{path:`wasm-dotnet/runtime/layers/fsharp-01.pack.gz`,offset:10121817,bytes:371477}},"wasm-dotnet/runtime/fsharp/pt-BR/FSharp.Core.resources.wasm":{sha256:`ba4d17da8f039569e0a0aef51ac81ed3da7b3818ed203bbbce494aeeb2b01858`,bytes:23317,mediaType:`application/wasm`,layer:{path:`wasm-dotnet/runtime/layers/fsharp-01.pack.gz`,offset:10493294,bytes:23317}},"wasm-dotnet/runtime/fsharp/pt-BR/FSharp.DependencyManager.Nuget.resources.wasm":{sha256:`f571ff8b45c0912fd47045d65a82b2bd3e345894cee5e4dfdb9327f5d1ed7190`,bytes:5909,mediaType:`application/wasm`,layer:{path:`wasm-dotnet/runtime/layers/fsharp-01.pack.gz`,offset:10516611,bytes:5909}},"wasm-dotnet/runtime/fsharp/ru/FSharp.Compiler.Service.resources.wasm":{sha256:`9cb1c2df961971abd41e43a345605490b869800b9a912241ebb21de4f6576568`,bytes:509205,mediaType:`application/wasm`,layer:{path:`wasm-dotnet/runtime/layers/fsharp-01.pack.gz`,offset:10522520,bytes:509205}},"wasm-dotnet/runtime/fsharp/ru/FSharp.Core.resources.wasm":{sha256:`6518cedddfd335d349ebbdea4c4271abcbe8020034803b4cec54b56912197d85`,bytes:30997,mediaType:`application/wasm`,layer:{path:`wasm-dotnet/runtime/layers/fsharp-01.pack.gz`,offset:11031725,bytes:30997}},"wasm-dotnet/runtime/fsharp/ru/FSharp.DependencyManager.Nuget.resources.wasm":{sha256:`cbf554907f891d2d73a36bd3b9b54498f82630fab9182e1a3c251f06b8040baa`,bytes:6421,mediaType:`application/wasm`,layer:{path:`wasm-dotnet/runtime/layers/fsharp-01.pack.gz`,offset:11062722,bytes:6421}},"wasm-dotnet/runtime/fsharp/supportFiles/0_runtimeconfig.bin":{sha256:`eba865048cf85bf45a627bfda964b22784be8e1616d250d9349e962a186e8d34`,bytes:1551,mediaType:`application/octet-stream`,layer:{path:`wasm-dotnet/runtime/layers/fsharp-01.pack.gz`,offset:11069143,bytes:1551}},"wasm-dotnet/runtime/fsharp/tr/FSharp.Compiler.Service.resources.wasm":{sha256:`c33ccb26c1c690ff521aa92c856e679d014513f0b523005f23dc69fa4e56a159`,bytes:371477,mediaType:`application/wasm`,layer:{path:`wasm-dotnet/runtime/layers/fsharp-01.pack.gz`,offset:11070694,bytes:371477}},"wasm-dotnet/runtime/fsharp/tr/FSharp.Core.resources.wasm":{sha256:`0c3a313baba3a10329b8eb5fa2f336afea5358a760471a4ee5d71c33eb3ad0b4`,bytes:23317,mediaType:`application/wasm`,layer:{path:`wasm-dotnet/runtime/layers/fsharp-01.pack.gz`,offset:11442171,bytes:23317}},"wasm-dotnet/runtime/fsharp/tr/FSharp.DependencyManager.Nuget.resources.wasm":{sha256:`567d36d420343ad1a4148386d9c404c92095e6af1b1946d9cd50677cbc611f08`,bytes:5909,mediaType:`application/wasm`,layer:{path:`wasm-dotnet/runtime/layers/fsharp-01.pack.gz`,offset:11465488,bytes:5909}},"wasm-dotnet/runtime/fsharp/zh-Hans/FSharp.Compiler.Service.resources.wasm":{sha256:`8907b85ad9737f1d09f3008860886446e8e8b104e41b68e2afb461f0976bffca`,bytes:330517,mediaType:`application/wasm`,layer:{path:`wasm-dotnet/runtime/layers/fsharp-01.pack.gz`,offset:11471397,bytes:330517}},"wasm-dotnet/runtime/fsharp/zh-Hans/FSharp.Core.resources.wasm":{sha256:`dc74157527036dfb1b4f2febf1410d64afb72de87964df87b6b07838959ffc89`,bytes:21781,mediaType:`application/wasm`,layer:{path:`wasm-dotnet/runtime/layers/fsharp-01.pack.gz`,offset:11801914,bytes:21781}},"wasm-dotnet/runtime/fsharp/zh-Hans/FSharp.DependencyManager.Nuget.resources.wasm":{sha256:`20af834b3a9ddce4e7d8e8311d7dbc9174a173023b42f06283f2cdc88d2ca7ef`,bytes:5909,mediaType:`application/wasm`,layer:{path:`wasm-dotnet/runtime/layers/fsharp-01.pack.gz`,offset:11823695,bytes:5909}},"wasm-dotnet/runtime/fsharp/zh-Hant/FSharp.Compiler.Service.resources.wasm":{sha256:`5757a8fc6476bfb9a112fa9c3e25e562600d8ecfdb9ee560e2c6a62c86cf6829`,bytes:328981,mediaType:`application/wasm`,layer:{path:`wasm-dotnet/runtime/layers/fsharp-01.pack.gz`,offset:11829604,bytes:328981}},"wasm-dotnet/runtime/fsharp/zh-Hant/FSharp.Core.resources.wasm":{sha256:`bc57f34b177583eedd92870887225dc9a2be07697224c2315486ee8de8d22e95`,bytes:21269,mediaType:`application/wasm`,layer:{path:`wasm-dotnet/runtime/layers/fsharp-01.pack.gz`,offset:12158585,bytes:21269}},"wasm-dotnet/runtime/fsharp/zh-Hant/FSharp.DependencyManager.Nuget.resources.wasm":{sha256:`1e122de1eb4e4e9ad52ee52bc4134ed44c5af16b5bdc016f697ac7b14ac626c0`,bytes:5909,mediaType:`application/wasm`,layer:{path:`wasm-dotnet/runtime/layers/fsharp-01.pack.gz`,offset:12179854,bytes:5909}},"wasm-dotnet/runtime/layers/csharp-00.pack.gz":{sha256:`c23fa949d00cac2eeee72b6a707bceddf2b13ba88445804907135165fb0d3a0c`,bytes:4534899,encoding:`gzip`,mediaType:`application/octet-stream`,uncompressedSha256:`ac2d1813f8714c3e0414187b2ad3e79b0d05498b862c7db7fa173448d8eda55f`,uncompressedBytes:16688991},"wasm-dotnet/runtime/layers/csharp-01.pack.gz":{sha256:`aa90f2ad8d5cacd0b2bfb939012b68fceff2fe8dc87ab781db3d58ea3eeb9811`,bytes:123617,encoding:`gzip`,mediaType:`application/octet-stream`,uncompressedSha256:`03eded2592952d858daeebe75b4c5c56da1c0fef04d2a967406f0422893069b8`,uncompressedBytes:424490},"wasm-dotnet/runtime/layers/fsharp-00.pack.gz":{sha256:`34d46847256a3bef8e754c0cb293c9ad3b1c896ef575c135f351e9cc6889c479`,bytes:4437556,encoding:`gzip`,mediaType:`application/octet-stream`,uncompressedSha256:`a58645e1b93b62aedee3cb4f9ffa04a165b9c3a7f8509ae4c221a648dde271d6`,uncompressedBytes:15848729},"wasm-dotnet/runtime/layers/fsharp-01.pack.gz":{sha256:`d34d96085f3e8d0d739354fd259df0735b4322e765d2a372762b6d3d1d88a8f9`,bytes:3646312,encoding:`gzip`,mediaType:`application/octet-stream`,uncompressedSha256:`ca2b1d47dc436efc1386471fc469e7a069ea9f7eee941888210a7ef762deb80d`,uncompressedBytes:12185763},"wasm-dotnet/runtime/layers/ref-00.pack.gz":{sha256:`67fe1b43c561fa56cb20ef17bb7cec55176f501ed7a28cfce89be47d40824ca0`,bytes:3133651,encoding:`gzip`,mediaType:`application/octet-stream`,uncompressedSha256:`4dde0f170411ecf8962cec97d24cdacdbb6fd2dc094a54015773465470d227a0`,uncompressedBytes:8231119},"wasm-dotnet/runtime/layers/vbnet-00.pack.gz":{sha256:`e8ad7631d15a94a360aeb563de909faa22469d0a80d46adbceb19c338c3ddd09`,bytes:3631176,encoding:`gzip`,mediaType:`application/octet-stream`,uncompressedSha256:`8969cd754097ae201f73199c41f34851dee009012dceb63cfcbab9240e763252`,uncompressedBytes:13073765},"wasm-dotnet/runtime/manifest.json":{sha256:`230d9e0f10dcffa90650b5d346c29bbdb3a67954fdb761787beee1b85cf6e152`,bytes:483,mediaType:`application/json`},"wasm-dotnet/runtime/ref/FSharp.Core.dll":{sha256:`324552b4b90ddd802e3efd62ce1a76531fe675c2cd34f541256a6138fc993ca0`,bytes:2396456,mediaType:`application/octet-stream`,layer:{path:`wasm-dotnet/runtime/layers/ref-00.pack.gz`,offset:0,bytes:2396456}},"wasm-dotnet/runtime/ref/Microsoft.CSharp.dll":{sha256:`52a63b9322ad4f2a63f1561e23bf989e35a6453cdc9e1023c0e520d9e6bfafdd`,bytes:18216,mediaType:`application/octet-stream`,layer:{path:`wasm-dotnet/runtime/layers/ref-00.pack.gz`,offset:2396456,bytes:18216}},"wasm-dotnet/runtime/ref/Microsoft.VisualBasic.Core.dll":{sha256:`0df856c80bd01fe6e9aed714b54e19be34527628d7d5886f987f64692c1d7392`,bytes:59216,mediaType:`application/octet-stream`,layer:{path:`wasm-dotnet/runtime/layers/ref-00.pack.gz`,offset:2414672,bytes:59216}},"wasm-dotnet/runtime/ref/Microsoft.VisualBasic.dll":{sha256:`bea8e0a37e735433442761a599351681975d7a3b0c651e9d980da963ecf32ee9`,bytes:17192,mediaType:`application/octet-stream`,layer:{path:`wasm-dotnet/runtime/layers/ref-00.pack.gz`,offset:2473888,bytes:17192}},"wasm-dotnet/runtime/ref/Microsoft.Win32.Primitives.dll":{sha256:`4c1e155caf24ce60fa5a55040bbc7a3df38e6cc386a3d7db5be2fbae95b24aed`,bytes:16168,mediaType:`application/octet-stream`,layer:{path:`wasm-dotnet/runtime/layers/ref-00.pack.gz`,offset:2491080,bytes:16168}},"wasm-dotnet/runtime/ref/Microsoft.Win32.Registry.dll":{sha256:`d81fbdbbe687c3a70dd4661d27c5df04f7ce99795619194fc83f9d69537a3f73`,bytes:21288,mediaType:`application/octet-stream`,layer:{path:`wasm-dotnet/runtime/layers/ref-00.pack.gz`,offset:2507248,bytes:21288}},"wasm-dotnet/runtime/ref/System.AppContext.dll":{sha256:`7e5f6c8c034b8f1688bec7bdf0bf2c12f8a7b5bbff8f43ef9f814492d4a4afc8`,bytes:15184,mediaType:`application/octet-stream`,layer:{path:`wasm-dotnet/runtime/layers/ref-00.pack.gz`,offset:2528536,bytes:15184}},"wasm-dotnet/runtime/ref/System.Buffers.dll":{sha256:`3236bb485b39e38a33303ccdc59dfc2e30fa7ebe88f55b6835bd965272238643`,bytes:15144,mediaType:`application/octet-stream`,layer:{path:`wasm-dotnet/runtime/layers/ref-00.pack.gz`,offset:2543720,bytes:15144}},"wasm-dotnet/runtime/ref/System.Collections.Concurrent.dll":{sha256:`9cfe9d868b31b53fb64258ca0a94101fdfcdcdf21bbfdf99f67288afb735fc21`,bytes:27432,mediaType:`application/octet-stream`,layer:{path:`wasm-dotnet/runtime/layers/ref-00.pack.gz`,offset:2558864,bytes:27432}},"wasm-dotnet/runtime/ref/System.Collections.Immutable.dll":{sha256:`1999879b0491f5d3eee5a4ea05be2bf7242bcbdecd7c31a28b7f5bc3bfcdc2c2`,bytes:74536,mediaType:`application/octet-stream`,layer:{path:`wasm-dotnet/runtime/layers/ref-00.pack.gz`,offset:2586296,bytes:74536}},"wasm-dotnet/runtime/ref/System.Collections.NonGeneric.dll":{sha256:`d8c17cfded747270c747e64c37903802493672ff242b4c94c42d429301a13817`,bytes:22824,mediaType:`application/octet-stream`,layer:{path:`wasm-dotnet/runtime/layers/ref-00.pack.gz`,offset:2660832,bytes:22824}},"wasm-dotnet/runtime/ref/System.Collections.Specialized.dll":{sha256:`e64dc6b10b6c586f1c8f295bf64607a4bc188de1653eb338f730fda9053e4040`,bytes:25896,mediaType:`application/octet-stream`,layer:{path:`wasm-dotnet/runtime/layers/ref-00.pack.gz`,offset:2683656,bytes:25896}},"wasm-dotnet/runtime/ref/System.Collections.dll":{sha256:`f916e3f653e18d72c058cf065162234379ecf1d031356b19c1e0bdb3ab3d280b`,bytes:56104,mediaType:`application/octet-stream`,layer:{path:`wasm-dotnet/runtime/layers/ref-00.pack.gz`,offset:2709552,bytes:56104}},"wasm-dotnet/runtime/ref/System.ComponentModel.Annotations.dll":{sha256:`79dbbb3fc3e428c9b189886d9e1b09d6f097c7421f8d6dc0d6c89f6dfaa14f0e`,bytes:31528,mediaType:`application/octet-stream`,layer:{path:`wasm-dotnet/runtime/layers/ref-00.pack.gz`,offset:2765656,bytes:31528}},"wasm-dotnet/runtime/ref/System.ComponentModel.DataAnnotations.dll":{sha256:`742fb1cb4d5705bb5f3dba5c277e9566933ed9478326aae47d685b35e10f57c4`,bytes:16720,mediaType:`application/octet-stream`,layer:{path:`wasm-dotnet/runtime/layers/ref-00.pack.gz`,offset:2797184,bytes:16720}},"wasm-dotnet/runtime/ref/System.ComponentModel.EventBasedAsync.dll":{sha256:`bf794e616c925352ca9189c9bf400b59c92c766ba1d8b4e21321aaae4799ca3b`,bytes:19280,mediaType:`application/octet-stream`,layer:{path:`wasm-dotnet/runtime/layers/ref-00.pack.gz`,offset:2813904,bytes:19280}},"wasm-dotnet/runtime/ref/System.ComponentModel.Primitives.dll":{sha256:`5f83142660fa59c06be33877264b779a38eeaaa7d036590777369e942b198c69`,bytes:25936,mediaType:`application/octet-stream`,layer:{path:`wasm-dotnet/runtime/layers/ref-00.pack.gz`,offset:2833184,bytes:25936}},"wasm-dotnet/runtime/ref/System.ComponentModel.TypeConverter.dll":{sha256:`a77534424efa19d178655c6496d86dfe0874a2ee3b5b8451e83f6a2822554afc`,bytes:104744,mediaType:`application/octet-stream`,layer:{path:`wasm-dotnet/runtime/layers/ref-00.pack.gz`,offset:2859120,bytes:104744}},"wasm-dotnet/runtime/ref/System.ComponentModel.dll":{sha256:`c4e53081962d03aab18127f18834e4d98c2a1e9d78f7c4d780ea47567d43f9b7`,bytes:15656,mediaType:`application/octet-stream`,layer:{path:`wasm-dotnet/runtime/layers/ref-00.pack.gz`,offset:2963864,bytes:15656}},"wasm-dotnet/runtime/ref/System.Configuration.dll":{sha256:`ff8a4df72ec15aceb6e4aef33f10f1ab03fc3038ca1fe4809896fca2fab1a885`,bytes:19280,mediaType:`application/octet-stream`,layer:{path:`wasm-dotnet/runtime/layers/ref-00.pack.gz`,offset:2979520,bytes:19280}},"wasm-dotnet/runtime/ref/System.Console.dll":{sha256:`4f6c807862adbc6f278dfc2083313901428cb3d12c1769f517f97a3aeaabb14e`,bytes:26408,mediaType:`application/octet-stream`,layer:{path:`wasm-dotnet/runtime/layers/ref-00.pack.gz`,offset:2998800,bytes:26408}},"wasm-dotnet/runtime/ref/System.Core.dll":{sha256:`2d3998cfa423d728ad6e9a1cf6fc5b8a2142e3032636a75e9faa3cb9408ff6c3`,bytes:23376,mediaType:`application/octet-stream`,layer:{path:`wasm-dotnet/runtime/layers/ref-00.pack.gz`,offset:3025208,bytes:23376}},"wasm-dotnet/runtime/ref/System.Data.Common.dll":{sha256:`b143b289a2f1c2bc77c6974dc624dff35f4d21702e31c14a52b134726bd4ef19`,bytes:153896,mediaType:`application/octet-stream`,layer:{path:`wasm-dotnet/runtime/layers/ref-00.pack.gz`,offset:3048584,bytes:153896}},"wasm-dotnet/runtime/ref/System.Data.DataSetExtensions.dll":{sha256:`bec4f9125b3bb19545cd3b66b65822a818173e1fc3720e78228ef12cc57884f9`,bytes:15656,mediaType:`application/octet-stream`,layer:{path:`wasm-dotnet/runtime/layers/ref-00.pack.gz`,offset:3202480,bytes:15656}},"wasm-dotnet/runtime/ref/System.Data.dll":{sha256:`a83822c5145394f0d70370bc4bb5eaede44dc7b2c80bc8a185e8f2b21bd9ca53`,bytes:23848,mediaType:`application/octet-stream`,layer:{path:`wasm-dotnet/runtime/layers/ref-00.pack.gz`,offset:3218136,bytes:23848}},"wasm-dotnet/runtime/ref/System.Diagnostics.Contracts.dll":{sha256:`53e0a840f1d84c68867032f1fc16e0bddf7d12cbf87092f13ffd83b6def6779d`,bytes:19752,mediaType:`application/octet-stream`,layer:{path:`wasm-dotnet/runtime/layers/ref-00.pack.gz`,offset:3241984,bytes:19752}},"wasm-dotnet/runtime/ref/System.Diagnostics.Debug.dll":{sha256:`0d2db8232e9f56c58a41a0b1c0cc146909793634d4822be20fab27337ef4471c`,bytes:15656,mediaType:`application/octet-stream`,layer:{path:`wasm-dotnet/runtime/layers/ref-00.pack.gz`,offset:3261736,bytes:15656}},"wasm-dotnet/runtime/ref/System.Diagnostics.DiagnosticSource.dll":{sha256:`f91fdb5e3697480dbc5978ba109c5437e58c7106d080af4505aff739db533b47`,bytes:42280,mediaType:`application/octet-stream`,layer:{path:`wasm-dotnet/runtime/layers/ref-00.pack.gz`,offset:3277392,bytes:42280}},"wasm-dotnet/runtime/ref/System.Diagnostics.FileVersionInfo.dll":{sha256:`e8a877ec0dd8f01c3c86f83cb1c724b6809dbd0edb2f76c04ad7088e13e9f5e8`,bytes:16720,mediaType:`application/octet-stream`,layer:{path:`wasm-dotnet/runtime/layers/ref-00.pack.gz`,offset:3319672,bytes:16720}},"wasm-dotnet/runtime/ref/System.Diagnostics.Process.dll":{sha256:`a94c7297bc8b0ab2aa49988a3831506c4878b0f4de66945049d1caebf88c8f67`,bytes:31016,mediaType:`application/octet-stream`,layer:{path:`wasm-dotnet/runtime/layers/ref-00.pack.gz`,offset:3336392,bytes:31016}},"wasm-dotnet/runtime/ref/System.Diagnostics.StackTrace.dll":{sha256:`ed249f9c1975533b4b8fb9962875e72229ecbd6477c4385ff6f90045070cfd10`,bytes:22824,mediaType:`application/octet-stream`,layer:{path:`wasm-dotnet/runtime/layers/ref-00.pack.gz`,offset:3367408,bytes:22824}},"wasm-dotnet/runtime/ref/System.Diagnostics.TextWriterTraceListener.dll":{sha256:`881e3cd52a1ea1211f828f35098eff5232ae4b9be6a33bc45c4e89e4c496e8e9`,bytes:17704,mediaType:`application/octet-stream`,layer:{path:`wasm-dotnet/runtime/layers/ref-00.pack.gz`,offset:3390232,bytes:17704}},"wasm-dotnet/runtime/ref/System.Diagnostics.Tools.dll":{sha256:`5e4d95081d49d6de72819f246a01878270943d1450a8341270d67b2e2d6a53e6`,bytes:15144,mediaType:`application/octet-stream`,layer:{path:`wasm-dotnet/runtime/layers/ref-00.pack.gz`,offset:3407936,bytes:15144}},"wasm-dotnet/runtime/ref/System.Diagnostics.TraceSource.dll":{sha256:`d5f603cd0cb6ffa092aca58f9d08bfd096202184bcbb3f009cb64a62ac1c084a`,bytes:27984,mediaType:`application/octet-stream`,layer:{path:`wasm-dotnet/runtime/layers/ref-00.pack.gz`,offset:3423080,bytes:27984}},"wasm-dotnet/runtime/ref/System.Diagnostics.Tracing.dll":{sha256:`a6c9c063383f4022b03ee19bc199e80446813321e8d30d4eda54656bea3bd8db`,bytes:28968,mediaType:`application/octet-stream`,layer:{path:`wasm-dotnet/runtime/layers/ref-00.pack.gz`,offset:3451064,bytes:28968}},"wasm-dotnet/runtime/ref/System.Drawing.Primitives.dll":{sha256:`71efa7b2f3dfa767573cb982ca703339494a7b75a100d841a9f430df0c544f98`,bytes:35624,mediaType:`application/octet-stream`,layer:{path:`wasm-dotnet/runtime/layers/ref-00.pack.gz`,offset:3480032,bytes:35624}},"wasm-dotnet/runtime/ref/System.Drawing.dll":{sha256:`acac05fc119cfeef8728741a9defc28ca956293b24e35f7898b5b1f1fa770c69`,bytes:20264,mediaType:`application/octet-stream`,layer:{path:`wasm-dotnet/runtime/layers/ref-00.pack.gz`,offset:3515656,bytes:20264}},"wasm-dotnet/runtime/ref/System.Dynamic.Runtime.dll":{sha256:`4c0ff42d3152a98e5b4f22cca450875d4f9208301444acf1b30b0f0306c9e0a4`,bytes:16168,mediaType:`application/octet-stream`,layer:{path:`wasm-dotnet/runtime/layers/ref-00.pack.gz`,offset:3535920,bytes:16168}},"wasm-dotnet/runtime/ref/System.Formats.Asn1.dll":{sha256:`68655c927db4188a61748c4074bc3b26a63c0f19f3bf14d26f345b198d7c64bb`,bytes:25896,mediaType:`application/octet-stream`,layer:{path:`wasm-dotnet/runtime/layers/ref-00.pack.gz`,offset:3552088,bytes:25896}},"wasm-dotnet/runtime/ref/System.Formats.Tar.dll":{sha256:`f413f3d3db25f58c757df0b11b58326a5f02e869da580a8ee6387d64eec9e44c`,bytes:20264,mediaType:`application/octet-stream`,layer:{path:`wasm-dotnet/runtime/layers/ref-00.pack.gz`,offset:3577984,bytes:20264}},"wasm-dotnet/runtime/ref/System.Globalization.Calendars.dll":{sha256:`50bc3367ac369d9a0c386c5eab1f71313e4c180c33498b3245cd44bbcb6f23fe`,bytes:15656,mediaType:`application/octet-stream`,layer:{path:`wasm-dotnet/runtime/layers/ref-00.pack.gz`,offset:3598248,bytes:15656}},"wasm-dotnet/runtime/ref/System.Globalization.Extensions.dll":{sha256:`87046971cb7a68e6844bfe8bce1b947405a5054d5666769b9e2869e56968a664`,bytes:15144,mediaType:`application/octet-stream`,layer:{path:`wasm-dotnet/runtime/layers/ref-00.pack.gz`,offset:3613904,bytes:15144}},"wasm-dotnet/runtime/ref/System.Globalization.dll":{sha256:`521859a8e843841f0d4ce70242c9b646e7b4169ac17ded1c3c39b34dd3e8e837`,bytes:15696,mediaType:`application/octet-stream`,layer:{path:`wasm-dotnet/runtime/layers/ref-00.pack.gz`,offset:3629048,bytes:15696}},"wasm-dotnet/runtime/ref/System.IO.Compression.Brotli.dll":{sha256:`9b35163e9d7b3da69eeeb9282cb55647755024ad518ed2af2ac75313bfbb959c`,bytes:18216,mediaType:`application/octet-stream`,layer:{path:`wasm-dotnet/runtime/layers/ref-00.pack.gz`,offset:3644744,bytes:18216}},"wasm-dotnet/runtime/ref/System.IO.Compression.FileSystem.dll":{sha256:`22b7b7f3e04066ee9d655da521d633c22862dc009c2435c66fefc4f42c9d8d62`,bytes:15184,mediaType:`application/octet-stream`,layer:{path:`wasm-dotnet/runtime/layers/ref-00.pack.gz`,offset:3662960,bytes:15184}},"wasm-dotnet/runtime/ref/System.IO.Compression.ZipFile.dll":{sha256:`64a3c8b1caaecb30c101a8037ddf9a098fc535b720e2d6034aa24b83b628af20`,bytes:16720,mediaType:`application/octet-stream`,layer:{path:`wasm-dotnet/runtime/layers/ref-00.pack.gz`,offset:3678144,bytes:16720}},"wasm-dotnet/runtime/ref/System.IO.Compression.dll":{sha256:`0e34d8f84306a25636f547b2515d0ff457031bad94c9df85cd1f5548441f8bfb`,bytes:21800,mediaType:`application/octet-stream`,layer:{path:`wasm-dotnet/runtime/layers/ref-00.pack.gz`,offset:3694864,bytes:21800}},"wasm-dotnet/runtime/ref/System.IO.FileSystem.AccessControl.dll":{sha256:`8098537adb1574d551c93995ac47b87f988135b6b05f00576ab9ee2930210fc5`,bytes:20264,mediaType:`application/octet-stream`,layer:{path:`wasm-dotnet/runtime/layers/ref-00.pack.gz`,offset:3716664,bytes:20264}},"wasm-dotnet/runtime/ref/System.IO.FileSystem.DriveInfo.dll":{sha256:`4b43f70c9faf92d99eafd283f1ccfc47552990bbd457e7352694b067c172f659`,bytes:17232,mediaType:`application/octet-stream`,layer:{path:`wasm-dotnet/runtime/layers/ref-00.pack.gz`,offset:3736928,bytes:17232}},"wasm-dotnet/runtime/ref/System.IO.FileSystem.Primitives.dll":{sha256:`0c23302e66ea906ace43e45f77b0869afa653e98b9c48b5cedc47a4ed8ffa033`,bytes:15144,mediaType:`application/octet-stream`,layer:{path:`wasm-dotnet/runtime/layers/ref-00.pack.gz`,offset:3754160,bytes:15144}},"wasm-dotnet/runtime/ref/System.IO.FileSystem.Watcher.dll":{sha256:`9a682ae013ed3c038a7f72047708d490ebe6dc945e924771b24b487496363d78`,bytes:20776,mediaType:`application/octet-stream`,layer:{path:`wasm-dotnet/runtime/layers/ref-00.pack.gz`,offset:3769304,bytes:20776}},"wasm-dotnet/runtime/ref/System.IO.FileSystem.dll":{sha256:`21d8fa19f84d35b28e49ca00090bab4100854ff798c369412682fa07dae9c9c5`,bytes:15656,mediaType:`application/octet-stream`,layer:{path:`wasm-dotnet/runtime/layers/ref-00.pack.gz`,offset:3790080,bytes:15656}},"wasm-dotnet/runtime/ref/System.IO.IsolatedStorage.dll":{sha256:`888be007d2097be040a4d21590963da7212f1257be78d575e6b697301574dce9`,bytes:22312,mediaType:`application/octet-stream`,layer:{path:`wasm-dotnet/runtime/layers/ref-00.pack.gz`,offset:3805736,bytes:22312}},"wasm-dotnet/runtime/ref/System.IO.MemoryMappedFiles.dll":{sha256:`52e77e46a4434aba071b7d19af4113b20c33c1e6ae8f1414e0d7f178fa1d166d`,bytes:18256,mediaType:`application/octet-stream`,layer:{path:`wasm-dotnet/runtime/layers/ref-00.pack.gz`,offset:3828048,bytes:18256}},"wasm-dotnet/runtime/ref/System.IO.Pipelines.dll":{sha256:`e0669208fd7ee400ddc1824b0112d0901b0bbe5b269a1bb19c1950f79552e1e4`,bytes:20264,mediaType:`application/octet-stream`,layer:{path:`wasm-dotnet/runtime/layers/ref-00.pack.gz`,offset:3846304,bytes:20264}},"wasm-dotnet/runtime/ref/System.IO.Pipes.AccessControl.dll":{sha256:`9209933f3b14b8da02ce2a180b46205c3e11a066d8cebe560754f32232eeec70`,bytes:17704,mediaType:`application/octet-stream`,layer:{path:`wasm-dotnet/runtime/layers/ref-00.pack.gz`,offset:3866568,bytes:17704}},"wasm-dotnet/runtime/ref/System.IO.Pipes.dll":{sha256:`b2245f1dcf74595078bff6a77a0a6cc6028e384ed04a8b5491d293ee1a4dddf3`,bytes:21800,mediaType:`application/octet-stream`,layer:{path:`wasm-dotnet/runtime/layers/ref-00.pack.gz`,offset:3884272,bytes:21800}},"wasm-dotnet/runtime/ref/System.IO.UnmanagedMemoryStream.dll":{sha256:`0bc8bf10f46e73a521c05bc1b59e7c3a2878c25d23b0437a1959e6afc9471420`,bytes:15144,mediaType:`application/octet-stream`,layer:{path:`wasm-dotnet/runtime/layers/ref-00.pack.gz`,offset:3906072,bytes:15144}},"wasm-dotnet/runtime/ref/System.IO.dll":{sha256:`158b1066faadfdcd3001c24fd0633688c0d7d6a0968118245ad78ff35d472e44`,bytes:15696,mediaType:`application/octet-stream`,layer:{path:`wasm-dotnet/runtime/layers/ref-00.pack.gz`,offset:3921216,bytes:15696}},"wasm-dotnet/runtime/ref/System.Linq.Expressions.dll":{sha256:`b2f70816bab3b1d5ee34c8a5ffa229ecd0ceda90cdae86e8176d7c7481c1ff70`,bytes:63272,mediaType:`application/octet-stream`,layer:{path:`wasm-dotnet/runtime/layers/ref-00.pack.gz`,offset:3936912,bytes:63272}},"wasm-dotnet/runtime/ref/System.Linq.Parallel.dll":{sha256:`9513fc70c4533d27cae67154582a0d51d3ce32493ea679cb84db6079d2e83920`,bytes:31056,mediaType:`application/octet-stream`,layer:{path:`wasm-dotnet/runtime/layers/ref-00.pack.gz`,offset:4000184,bytes:31056}},"wasm-dotnet/runtime/ref/System.Linq.Queryable.dll":{sha256:`ea3ab2f7664465ce608c9fce692749299f7a6f3c2771801062a6edb04d292976`,bytes:31016,mediaType:`application/octet-stream`,layer:{path:`wasm-dotnet/runtime/layers/ref-00.pack.gz`,offset:4031240,bytes:31016}},"wasm-dotnet/runtime/ref/System.Linq.dll":{sha256:`483d5f8d9a960f5e858e3744150dc3f3633a6e05929474f9c3867727f54a894b`,bytes:32592,mediaType:`application/octet-stream`,layer:{path:`wasm-dotnet/runtime/layers/ref-00.pack.gz`,offset:4062256,bytes:32592}},"wasm-dotnet/runtime/ref/System.Memory.dll":{sha256:`19c2c3e299b823d7f8080372c21040c38462dff88a320a6d8672ac375616eb58`,bytes:52048,mediaType:`application/octet-stream`,layer:{path:`wasm-dotnet/runtime/layers/ref-00.pack.gz`,offset:4094848,bytes:52048}},"wasm-dotnet/runtime/ref/System.Net.Http.Json.dll":{sha256:`56f9b15958cec446a8f5ffbc15243d863b75944809a5387912da18316ab4fc1f`,bytes:23336,mediaType:`application/octet-stream`,layer:{path:`wasm-dotnet/runtime/layers/ref-00.pack.gz`,offset:4146896,bytes:23336}},"wasm-dotnet/runtime/ref/System.Net.Http.dll":{sha256:`54f067b7f117ee5dd4de4cf2e8ff1cd3f45f4363fba16a173c97d5fa27e9f25e`,bytes:60200,mediaType:`application/octet-stream`,layer:{path:`wasm-dotnet/runtime/layers/ref-00.pack.gz`,offset:4170232,bytes:60200}},"wasm-dotnet/runtime/ref/System.Net.HttpListener.dll":{sha256:`54cfd12fc5771885bfb73cb76c333586eac727af2d31eb4f2666e52f9bd59fec`,bytes:25384,mediaType:`application/octet-stream`,layer:{path:`wasm-dotnet/runtime/layers/ref-00.pack.gz`,offset:4230432,bytes:25384}},"wasm-dotnet/runtime/ref/System.Net.Mail.dll":{sha256:`03d7714f8ae811e805157949d164e6a900fd03cb9183903eefde2c7cebebee8f`,bytes:32040,mediaType:`application/octet-stream`,layer:{path:`wasm-dotnet/runtime/layers/ref-00.pack.gz`,offset:4255816,bytes:32040}},"wasm-dotnet/runtime/ref/System.Net.NameResolution.dll":{sha256:`8b20f06c7187f7f4e6d7b551923d350482211d15acb4b8aec79d0f8770cfa656`,bytes:17704,mediaType:`application/octet-stream`,layer:{path:`wasm-dotnet/runtime/layers/ref-00.pack.gz`,offset:4287856,bytes:17704}},"wasm-dotnet/runtime/ref/System.Net.NetworkInformation.dll":{sha256:`8cf162537243756da705cdd612aa31bff1cf0a48b62261ded84107d0afc5e0d8`,bytes:33576,mediaType:`application/octet-stream`,layer:{path:`wasm-dotnet/runtime/layers/ref-00.pack.gz`,offset:4305560,bytes:33576}},"wasm-dotnet/runtime/ref/System.Net.Ping.dll":{sha256:`e025d4c30162ab44185aa4d783da48cb711b3a5c1610c2197f02af678a4b178b`,bytes:20264,mediaType:`application/octet-stream`,layer:{path:`wasm-dotnet/runtime/layers/ref-00.pack.gz`,offset:4339136,bytes:20264}},"wasm-dotnet/runtime/ref/System.Net.Primitives.dll":{sha256:`a2d1e79805861d0276933c88d941a44a934c0003882786ba34baf74585346262`,bytes:35664,mediaType:`application/octet-stream`,layer:{path:`wasm-dotnet/runtime/layers/ref-00.pack.gz`,offset:4359400,bytes:35664}},"wasm-dotnet/runtime/ref/System.Net.Quic.dll":{sha256:`9c577570909573c3fe4d2fbb73e000bb1945230097cf2feaea9e69b55a19015d`,bytes:23336,mediaType:`application/octet-stream`,layer:{path:`wasm-dotnet/runtime/layers/ref-00.pack.gz`,offset:4395064,bytes:23336}},"wasm-dotnet/runtime/ref/System.Net.Requests.dll":{sha256:`d33ba46ce97800dc1cd9223d52123a90e48a9b6ca6ceedfce15847fc4342cb4b`,bytes:40784,mediaType:`application/octet-stream`,layer:{path:`wasm-dotnet/runtime/layers/ref-00.pack.gz`,offset:4418400,bytes:40784}},"wasm-dotnet/runtime/ref/System.Net.Security.dll":{sha256:`88761caeb1a9a93db379cd4436bbfa3741325d8a11684451fbd1301c4512b822`,bytes:52520,mediaType:`application/octet-stream`,layer:{path:`wasm-dotnet/runtime/layers/ref-00.pack.gz`,offset:4459184,bytes:52520}},"wasm-dotnet/runtime/ref/System.Net.ServicePoint.dll":{sha256:`b54ce46374e0b5c95c881f9fd8f50d79a7fa0346ab0ed43b6bbfd272fac5ef1f`,bytes:15144,mediaType:`application/octet-stream`,layer:{path:`wasm-dotnet/runtime/layers/ref-00.pack.gz`,offset:4511704,bytes:15144}},"wasm-dotnet/runtime/ref/System.Net.Sockets.dll":{sha256:`3c27a1b3e1dd68997bfa900e496bcc7a7b88958c948f18aa58c38908f15a5809`,bytes:47400,mediaType:`application/octet-stream`,layer:{path:`wasm-dotnet/runtime/layers/ref-00.pack.gz`,offset:4526848,bytes:47400}},"wasm-dotnet/runtime/ref/System.Net.WebClient.dll":{sha256:`36311c97f7d85ed89eea6ad1cdc178fa7d2af4db7eb1bfed3014f55218a83921`,bytes:27432,mediaType:`application/octet-stream`,layer:{path:`wasm-dotnet/runtime/layers/ref-00.pack.gz`,offset:4574248,bytes:27432}},"wasm-dotnet/runtime/ref/System.Net.WebHeaderCollection.dll":{sha256:`9ec06accd2427876f3cb6182c27bad24e133118134660c03059de917994e0cd4`,bytes:19280,mediaType:`application/octet-stream`,layer:{path:`wasm-dotnet/runtime/layers/ref-00.pack.gz`,offset:4601680,bytes:19280}},"wasm-dotnet/runtime/ref/System.Net.WebProxy.dll":{sha256:`0cbb8fa8e33952aff884431f673269d657ef358d2975b00bc63b39c16d663e54`,bytes:17704,mediaType:`application/octet-stream`,layer:{path:`wasm-dotnet/runtime/layers/ref-00.pack.gz`,offset:4620960,bytes:17704}},"wasm-dotnet/runtime/ref/System.Net.WebSockets.Client.dll":{sha256:`07bfc82b926f1c50ab01e5468f7497beb1b377e7c36b1a851d1d7426c8906250`,bytes:19240,mediaType:`application/octet-stream`,layer:{path:`wasm-dotnet/runtime/layers/ref-00.pack.gz`,offset:4638664,bytes:19240}},"wasm-dotnet/runtime/ref/System.Net.WebSockets.dll":{sha256:`fffe12e6146373ca2941f68c8629a77f5fd8031a0f2077b4fba1b9f60cb981e7`,bytes:22312,mediaType:`application/octet-stream`,layer:{path:`wasm-dotnet/runtime/layers/ref-00.pack.gz`,offset:4657904,bytes:22312}},"wasm-dotnet/runtime/ref/System.Net.dll":{sha256:`38947f6e1d47c512a51ec63ca5e2db0cf8fa5171b34cbda3de3be1a467750aa5`,bytes:17232,mediaType:`application/octet-stream`,layer:{path:`wasm-dotnet/runtime/layers/ref-00.pack.gz`,offset:4680216,bytes:17232}},"wasm-dotnet/runtime/ref/System.Numerics.Vectors.dll":{sha256:`cf497746ea59644f36ae2cec194e48999b9dadcba99b3ec71d63d62a39b7d41a`,bytes:47440,mediaType:`application/octet-stream`,layer:{path:`wasm-dotnet/runtime/layers/ref-00.pack.gz`,offset:4697448,bytes:47440}},"wasm-dotnet/runtime/ref/System.Numerics.dll":{sha256:`8051b7f7e45d62e7e0e020f350443e6ba24723ccb99033e148a4fc38f0dee80d`,bytes:15144,mediaType:`application/octet-stream`,layer:{path:`wasm-dotnet/runtime/layers/ref-00.pack.gz`,offset:4744888,bytes:15144}},"wasm-dotnet/runtime/ref/System.ObjectModel.dll":{sha256:`ea8ea6b4504b831e3b4f48e9f0169b7929bf0f5f8b7e0acd05d1349880b9c2a9`,bytes:23336,mediaType:`application/octet-stream`,layer:{path:`wasm-dotnet/runtime/layers/ref-00.pack.gz`,offset:4760032,bytes:23336}},"wasm-dotnet/runtime/ref/System.Reflection.DispatchProxy.dll":{sha256:`8a2a107cc70c147ddc53be7b9a908806f480fa76f2b8a6aef33c0ea5fca8e641`,bytes:15696,mediaType:`application/octet-stream`,layer:{path:`wasm-dotnet/runtime/layers/ref-00.pack.gz`,offset:4783368,bytes:15696}},"wasm-dotnet/runtime/ref/System.Reflection.Emit.ILGeneration.dll":{sha256:`b9f1bf52bedfd55ff92beb11ba9fd7e813ddff93c862c7b16e8edd22d1748ab1`,bytes:20776,mediaType:`application/octet-stream`,layer:{path:`wasm-dotnet/runtime/layers/ref-00.pack.gz`,offset:4799064,bytes:20776}},"wasm-dotnet/runtime/ref/System.Reflection.Emit.Lightweight.dll":{sha256:`d52bdedb1337b9a7143e2ce529627edcffb6396c61c6d0104e2f18246dfb36f8`,bytes:19240,mediaType:`application/octet-stream`,layer:{path:`wasm-dotnet/runtime/layers/ref-00.pack.gz`,offset:4819840,bytes:19240}},"wasm-dotnet/runtime/ref/System.Reflection.Emit.dll":{sha256:`9ba6092f831679ab73d8f6d3fbaaa9af803d3378f8d93c67de4b53028f25d96a`,bytes:43816,mediaType:`application/octet-stream`,layer:{path:`wasm-dotnet/runtime/layers/ref-00.pack.gz`,offset:4839080,bytes:43816}},"wasm-dotnet/runtime/ref/System.Reflection.Extensions.dll":{sha256:`c059314a2c022293b8c7537687221bd23291e7083ee87a3f9ad9776855116099`,bytes:15144,mediaType:`application/octet-stream`,layer:{path:`wasm-dotnet/runtime/layers/ref-00.pack.gz`,offset:4882896,bytes:15144}},"wasm-dotnet/runtime/ref/System.Reflection.Metadata.dll":{sha256:`2684624dd44eda10678dde7e3916dce7370538a9234ff087041b72b07743c221`,bytes:122152,mediaType:`application/octet-stream`,layer:{path:`wasm-dotnet/runtime/layers/ref-00.pack.gz`,offset:4898040,bytes:122152}},"wasm-dotnet/runtime/ref/System.Reflection.Primitives.dll":{sha256:`27081dbdf40b276252d50fc576867951fb0fe53a5430bd840f49f8fc6a378b00`,bytes:21800,mediaType:`application/octet-stream`,layer:{path:`wasm-dotnet/runtime/layers/ref-00.pack.gz`,offset:5020192,bytes:21800}},"wasm-dotnet/runtime/ref/System.Reflection.TypeExtensions.dll":{sha256:`69d31e89a3ae1c2a35f2bf92cd035447d32ba32513ca51f9e0751834bcb7ba4d`,bytes:19280,mediaType:`application/octet-stream`,layer:{path:`wasm-dotnet/runtime/layers/ref-00.pack.gz`,offset:5041992,bytes:19280}},"wasm-dotnet/runtime/ref/System.Reflection.dll":{sha256:`575afc3fd8dca8449745d50070638691aaf38be8a9e00ce0b522d853f15c963b`,bytes:16208,mediaType:`application/octet-stream`,layer:{path:`wasm-dotnet/runtime/layers/ref-00.pack.gz`,offset:5061272,bytes:16208}},"wasm-dotnet/runtime/ref/System.Resources.Reader.dll":{sha256:`e294e4a6ea75fba235fe70e61261e239f0fc575f8d356f71c5cde17e1edd4485`,bytes:15184,mediaType:`application/octet-stream`,layer:{path:`wasm-dotnet/runtime/layers/ref-00.pack.gz`,offset:5077480,bytes:15184}},"wasm-dotnet/runtime/ref/System.Resources.ResourceManager.dll":{sha256:`82775e45a50331c9a511396ae8cd8b052498e75dd0666de32d05458ceb8cf3a4`,bytes:15656,mediaType:`application/octet-stream`,layer:{path:`wasm-dotnet/runtime/layers/ref-00.pack.gz`,offset:5092664,bytes:15656}},"wasm-dotnet/runtime/ref/System.Resources.Writer.dll":{sha256:`54d63bfecfaede050cce2e160ebce83862fff3052faae0be149f1a0bfcc34ca0`,bytes:16168,mediaType:`application/octet-stream`,layer:{path:`wasm-dotnet/runtime/layers/ref-00.pack.gz`,offset:5108320,bytes:16168}},"wasm-dotnet/runtime/ref/System.Runtime.CompilerServices.Unsafe.dll":{sha256:`652682d81c3b6427e2c389d2c6c170783fd7c6e6f8808afc4b66c82e1f918a70`,bytes:15144,mediaType:`application/octet-stream`,layer:{path:`wasm-dotnet/runtime/layers/ref-00.pack.gz`,offset:5124488,bytes:15144}},"wasm-dotnet/runtime/ref/System.Runtime.CompilerServices.VisualC.dll":{sha256:`b6e148ce860dce326e04c1b87eddbcf5730573a522074789b1744ef39303d108`,bytes:17232,mediaType:`application/octet-stream`,layer:{path:`wasm-dotnet/runtime/layers/ref-00.pack.gz`,offset:5139632,bytes:17232}},"wasm-dotnet/runtime/ref/System.Runtime.Extensions.dll":{sha256:`9f77a73f406ec39b616b23ee213222f8f0f67d2436b5a826ff4e10a6b7d903f7`,bytes:17704,mediaType:`application/octet-stream`,layer:{path:`wasm-dotnet/runtime/layers/ref-00.pack.gz`,offset:5156864,bytes:17704}},"wasm-dotnet/runtime/ref/System.Runtime.Handles.dll":{sha256:`d095d0ebff53ac771e1f977951d22000d87fa90aa536b509c47be31131d502a3`,bytes:15184,mediaType:`application/octet-stream`,layer:{path:`wasm-dotnet/runtime/layers/ref-00.pack.gz`,offset:5174568,bytes:15184}},"wasm-dotnet/runtime/ref/System.Runtime.InteropServices.JavaScript.dll":{sha256:`1940c475923ec831be24c7fd7f2a656a6dbe0e0f7a03664c7068628629123c11`,bytes:25896,mediaType:`application/octet-stream`,layer:{path:`wasm-dotnet/runtime/layers/ref-00.pack.gz`,offset:5189752,bytes:25896}},"wasm-dotnet/runtime/ref/System.Runtime.InteropServices.RuntimeInformation.dll":{sha256:`692b6eb89b2abe5a37bf807188ffafb4128edc0ffaf925fb58b1eca45c2ece36`,bytes:15184,mediaType:`application/octet-stream`,layer:{path:`wasm-dotnet/runtime/layers/ref-00.pack.gz`,offset:5215648,bytes:15184}},"wasm-dotnet/runtime/ref/System.Runtime.InteropServices.dll":{sha256:`7f93fd306191bb3dd0159c7f1cd4b3a78e0492bf2be1a84e66a0403bae3d7af2`,bytes:98640,mediaType:`application/octet-stream`,layer:{path:`wasm-dotnet/runtime/layers/ref-00.pack.gz`,offset:5230832,bytes:98640}},"wasm-dotnet/runtime/ref/System.Runtime.Intrinsics.dll":{sha256:`70d8a48ff56192b48beca6d45a032ebc95da4f858e9f443839f2379c8e8f2a1b`,bytes:400168,mediaType:`application/octet-stream`,layer:{path:`wasm-dotnet/runtime/layers/ref-00.pack.gz`,offset:5329472,bytes:400168}},"wasm-dotnet/runtime/ref/System.Runtime.Loader.dll":{sha256:`421a09e079d0865ab1972f02d5c587977ddb5274c42b8d65a39e760d7505a7ef`,bytes:19280,mediaType:`application/octet-stream`,layer:{path:`wasm-dotnet/runtime/layers/ref-00.pack.gz`,offset:5729640,bytes:19280}},"wasm-dotnet/runtime/ref/System.Runtime.Numerics.dll":{sha256:`1716396e47d8794f394e31ac9d97f17d75f1ba0d3a5a2ce9f9718a5d87b77593`,bytes:36176,mediaType:`application/octet-stream`,layer:{path:`wasm-dotnet/runtime/layers/ref-00.pack.gz`,offset:5748920,bytes:36176}},"wasm-dotnet/runtime/ref/System.Runtime.Serialization.Formatters.dll":{sha256:`2cf4557c37f422e79bc2131d2ec559032e8a2253ff61ff04ffc3945ddc2f9cb2`,bytes:23336,mediaType:`application/octet-stream`,layer:{path:`wasm-dotnet/runtime/layers/ref-00.pack.gz`,offset:5785096,bytes:23336}},"wasm-dotnet/runtime/ref/System.Runtime.Serialization.Json.dll":{sha256:`f2a7bf8851727e3f3cb1b8d7ed74c3f9ef092aa2567015a6440f82425e1702a0`,bytes:20816,mediaType:`application/octet-stream`,layer:{path:`wasm-dotnet/runtime/layers/ref-00.pack.gz`,offset:5808432,bytes:20816}},"wasm-dotnet/runtime/ref/System.Runtime.Serialization.Primitives.dll":{sha256:`5363aed62bfd691bf8686c6b981756d74a3d48da5811bea112d299dee823b3c2`,bytes:19752,mediaType:`application/octet-stream`,layer:{path:`wasm-dotnet/runtime/layers/ref-00.pack.gz`,offset:5829248,bytes:19752}},"wasm-dotnet/runtime/ref/System.Runtime.Serialization.Xml.dll":{sha256:`e2737ddd41a855406e77a27d08bdcce62503fd569ffd2c012037b56044a8fbe1`,bytes:39720,mediaType:`application/octet-stream`,layer:{path:`wasm-dotnet/runtime/layers/ref-00.pack.gz`,offset:5849e3,bytes:39720}},"wasm-dotnet/runtime/ref/System.Runtime.Serialization.dll":{sha256:`1db6defe80abf929de6eda7430a8e7d9d5bbe62eec92d4ade1220046d350a807`,bytes:16680,mediaType:`application/octet-stream`,layer:{path:`wasm-dotnet/runtime/layers/ref-00.pack.gz`,offset:5888720,bytes:16680}},"wasm-dotnet/runtime/ref/System.Runtime.dll":{sha256:`de6572c1ba3158501da94fd7204c38d62c9da6212c6b48990bfb920f708e6072`,bytes:847144,mediaType:`application/octet-stream`,layer:{path:`wasm-dotnet/runtime/layers/ref-00.pack.gz`,offset:5905400,bytes:847144}},"wasm-dotnet/runtime/ref/System.Security.AccessControl.dll":{sha256:`bf8036c6f6f200450e35845cd2e254a78b0cb965ea1b0e3a302cd6ca024a87db`,bytes:37200,mediaType:`application/octet-stream`,layer:{path:`wasm-dotnet/runtime/layers/ref-00.pack.gz`,offset:6752544,bytes:37200}},"wasm-dotnet/runtime/ref/System.Security.Claims.dll":{sha256:`ed3730a93d28cf847987035282fe84a51f13c40843ad2a9d00feb818f375ee7c`,bytes:32080,mediaType:`application/octet-stream`,layer:{path:`wasm-dotnet/runtime/layers/ref-00.pack.gz`,offset:6789744,bytes:32080}},"wasm-dotnet/runtime/ref/System.Security.Cryptography.Algorithms.dll":{sha256:`a1d2ad3eb451cd7bb018bc8fa0c649f50eab75e7dbb9a71922c282553a50107c`,bytes:17192,mediaType:`application/octet-stream`,layer:{path:`wasm-dotnet/runtime/layers/ref-00.pack.gz`,offset:6821824,bytes:17192}},"wasm-dotnet/runtime/ref/System.Security.Cryptography.Cng.dll":{sha256:`7a58bc274e38caff27a68c75a630fffb9aa62b6495725db36cafbae50230e331`,bytes:16168,mediaType:`application/octet-stream`,layer:{path:`wasm-dotnet/runtime/layers/ref-00.pack.gz`,offset:6839016,bytes:16168}},"wasm-dotnet/runtime/ref/System.Security.Cryptography.Csp.dll":{sha256:`16a5161e1158889ae4bddacd6afe0b14cfaab14baa9f92f242419022a042246c`,bytes:15696,mediaType:`application/octet-stream`,layer:{path:`wasm-dotnet/runtime/layers/ref-00.pack.gz`,offset:6855184,bytes:15696}},"wasm-dotnet/runtime/ref/System.Security.Cryptography.Encoding.dll":{sha256:`a9095478b226abc51e8108a7bc628009c596ad2b8719c0c57d4501252adb943f`,bytes:15696,mediaType:`application/octet-stream`,layer:{path:`wasm-dotnet/runtime/layers/ref-00.pack.gz`,offset:6870880,bytes:15696}},"wasm-dotnet/runtime/ref/System.Security.Cryptography.OpenSsl.dll":{sha256:`73d365d7320a3d722e0c119ef9cdcedb86d59efde89381b2c23bc5aaa7af6a70`,bytes:15184,mediaType:`application/octet-stream`,layer:{path:`wasm-dotnet/runtime/layers/ref-00.pack.gz`,offset:6886576,bytes:15184}},"wasm-dotnet/runtime/ref/System.Security.Cryptography.Primitives.dll":{sha256:`0da7ba4e059c490553b5a1e1d1c76b9cc1c2c0eff4243831926987aecd15e151`,bytes:15696,mediaType:`application/octet-stream`,layer:{path:`wasm-dotnet/runtime/layers/ref-00.pack.gz`,offset:6901760,bytes:15696}},"wasm-dotnet/runtime/ref/System.Security.Cryptography.X509Certificates.dll":{sha256:`19d5896f934d202dd5027ce97a9b631590914edd86c14c93ec123c0a76df1e3b`,bytes:16680,mediaType:`application/octet-stream`,layer:{path:`wasm-dotnet/runtime/layers/ref-00.pack.gz`,offset:6917456,bytes:16680}},"wasm-dotnet/runtime/ref/System.Security.Cryptography.dll":{sha256:`59d05d4ee0673b5422e4c1f7ec50196a25ff79e59ee49e7ea0194467e649c89d`,bytes:142120,mediaType:`application/octet-stream`,layer:{path:`wasm-dotnet/runtime/layers/ref-00.pack.gz`,offset:6934136,bytes:142120}},"wasm-dotnet/runtime/ref/System.Security.Principal.Windows.dll":{sha256:`d23f9146f1a287c338ce503c03866bb32d279fbe14219df5e437945b3f1f333b`,bytes:26960,mediaType:`application/octet-stream`,layer:{path:`wasm-dotnet/runtime/layers/ref-00.pack.gz`,offset:7076256,bytes:26960}},"wasm-dotnet/runtime/ref/System.Security.Principal.dll":{sha256:`92b87ca7ccd783e0d45aa2cf69882e38ea65436ecfe8183c6cbc1cd5ea76e245`,bytes:15144,mediaType:`application/octet-stream`,layer:{path:`wasm-dotnet/runtime/layers/ref-00.pack.gz`,offset:7103216,bytes:15144}},"wasm-dotnet/runtime/ref/System.Security.SecureString.dll":{sha256:`5bc22e96bbf41beda0768a1c32b3dea11d9c18f18c6f3059ae0ea88452fe8c47`,bytes:15144,mediaType:`application/octet-stream`,layer:{path:`wasm-dotnet/runtime/layers/ref-00.pack.gz`,offset:7118360,bytes:15144}},"wasm-dotnet/runtime/ref/System.Security.dll":{sha256:`b57db13c2944ae290c6143dfb6023340cbc524dda4a67dd9f1cab7520ad1e045`,bytes:18216,mediaType:`application/octet-stream`,layer:{path:`wasm-dotnet/runtime/layers/ref-00.pack.gz`,offset:7133504,bytes:18216}},"wasm-dotnet/runtime/ref/System.ServiceModel.Web.dll":{sha256:`e0cb2764a1f900c81d51feca39a04fd948f4e841b42e9b177d74b0cf50ec8231`,bytes:16680,mediaType:`application/octet-stream`,layer:{path:`wasm-dotnet/runtime/layers/ref-00.pack.gz`,offset:7151720,bytes:16680}},"wasm-dotnet/runtime/ref/System.ServiceProcess.dll":{sha256:`d0a9e507a3f797f89ea845cf0f9baa2a91f2daed463c7d9cc9209194c1cf1db7`,bytes:15656,mediaType:`application/octet-stream`,layer:{path:`wasm-dotnet/runtime/layers/ref-00.pack.gz`,offset:7168400,bytes:15656}},"wasm-dotnet/runtime/ref/System.Text.Encoding.CodePages.dll":{sha256:`68bea62e562e9046777b3760086c9e8ce1f203d6649efd6a3b0ba3466a7919b5`,bytes:15696,mediaType:`application/octet-stream`,layer:{path:`wasm-dotnet/runtime/layers/ref-00.pack.gz`,offset:7184056,bytes:15696}},"wasm-dotnet/runtime/ref/System.Text.Encoding.Extensions.dll":{sha256:`65d97c03d88cde9ec14ea1407635189a3140ffddc82379de1aa849b860b5af95`,bytes:20776,mediaType:`application/octet-stream`,layer:{path:`wasm-dotnet/runtime/layers/ref-00.pack.gz`,offset:7199752,bytes:20776}},"wasm-dotnet/runtime/ref/System.Text.Encoding.dll":{sha256:`8bb03d1ebfb71beb899b8ed1dce6d2ca6ad28fc6c256b1e3a9976884e679c340`,bytes:15696,mediaType:`application/octet-stream`,layer:{path:`wasm-dotnet/runtime/layers/ref-00.pack.gz`,offset:7220528,bytes:15696}},"wasm-dotnet/runtime/ref/System.Text.Encodings.Web.dll":{sha256:`88b7f0c1b6a2a67e37c562103417e5465c7bf13a081d3169648099b906cd5d30`,bytes:25896,mediaType:`application/octet-stream`,layer:{path:`wasm-dotnet/runtime/layers/ref-00.pack.gz`,offset:7236224,bytes:25896}},"wasm-dotnet/runtime/ref/System.Text.Json.dll":{sha256:`acc43d7c81867f1dce6df06847ad39a54e787c2211ad150fddfe7d58cfb3334d`,bytes:80168,mediaType:`application/octet-stream`,layer:{path:`wasm-dotnet/runtime/layers/ref-00.pack.gz`,offset:7262120,bytes:80168}},"wasm-dotnet/runtime/ref/System.Text.RegularExpressions.dll":{sha256:`9ec64ce3dde161cb021a735ca0e8cd6e4b1c65021ef6f961a15b2ab3a5d43ab7`,bytes:36176,mediaType:`application/octet-stream`,layer:{path:`wasm-dotnet/runtime/layers/ref-00.pack.gz`,offset:7342288,bytes:36176}},"wasm-dotnet/runtime/ref/System.Threading.Channels.dll":{sha256:`d94f7595e2e71081c4a8963c22871dc48b3daf9e2cddc4d9013bdc97666554bc`,bytes:19240,mediaType:`application/octet-stream`,layer:{path:`wasm-dotnet/runtime/layers/ref-00.pack.gz`,offset:7378464,bytes:19240}},"wasm-dotnet/runtime/ref/System.Threading.Overlapped.dll":{sha256:`fb9f9fa1edbd6e24dee469761ae4b0c0891871dec02315890f014f037ffa171b`,bytes:18728,mediaType:`application/octet-stream`,layer:{path:`wasm-dotnet/runtime/layers/ref-00.pack.gz`,offset:7397704,bytes:18728}},"wasm-dotnet/runtime/ref/System.Threading.Tasks.Dataflow.dll":{sha256:`cd0433c078b54c6866576e89946358ea59955981e4aad43df51ad08b00008f83`,bytes:31528,mediaType:`application/octet-stream`,layer:{path:`wasm-dotnet/runtime/layers/ref-00.pack.gz`,offset:7416432,bytes:31528}},"wasm-dotnet/runtime/ref/System.Threading.Tasks.Extensions.dll":{sha256:`442a8b7e82a358e6f8a6fa0ab3f72469262fedaa60eaa650deec4b2fd6778ece`,bytes:15696,mediaType:`application/octet-stream`,layer:{path:`wasm-dotnet/runtime/layers/ref-00.pack.gz`,offset:7447960,bytes:15696}},"wasm-dotnet/runtime/ref/System.Threading.Tasks.Parallel.dll":{sha256:`d141e1fb98b8a831aba83c0ef454947adae965c31d7935cab63e9143ac2dee4b`,bytes:19752,mediaType:`application/octet-stream`,layer:{path:`wasm-dotnet/runtime/layers/ref-00.pack.gz`,offset:7463656,bytes:19752}},"wasm-dotnet/runtime/ref/System.Threading.Tasks.dll":{sha256:`39ba3edb7a2c4207a2787e821dd61ec85fd65184ad09e0f01b6e76b9b819a014`,bytes:16680,mediaType:`application/octet-stream`,layer:{path:`wasm-dotnet/runtime/layers/ref-00.pack.gz`,offset:7483408,bytes:16680}},"wasm-dotnet/runtime/ref/System.Threading.Thread.dll":{sha256:`257a28b110f4eec20088c3c01424fa0bf42999ce1c20308df92ffc5eeaa053c1`,bytes:23376,mediaType:`application/octet-stream`,layer:{path:`wasm-dotnet/runtime/layers/ref-00.pack.gz`,offset:7500088,bytes:23376}},"wasm-dotnet/runtime/ref/System.Threading.ThreadPool.dll":{sha256:`9754e5f30ea765c2ae346ea6339d2c674fd6e6f7973fa558aa79f962ae4cd717`,bytes:18216,mediaType:`application/octet-stream`,layer:{path:`wasm-dotnet/runtime/layers/ref-00.pack.gz`,offset:7523464,bytes:18216}},"wasm-dotnet/runtime/ref/System.Threading.Timer.dll":{sha256:`20c94f066d4fc43e984adf7b5091dd955e14c314fbf99be0975276cab0d7e1bf`,bytes:15144,mediaType:`application/octet-stream`,layer:{path:`wasm-dotnet/runtime/layers/ref-00.pack.gz`,offset:7541680,bytes:15144}},"wasm-dotnet/runtime/ref/System.Threading.dll":{sha256:`c45c1a6d777dc94478dd4477be848eff01c71524686d7decb3b75d43a7b0848e`,bytes:32552,mediaType:`application/octet-stream`,layer:{path:`wasm-dotnet/runtime/layers/ref-00.pack.gz`,offset:7556824,bytes:32552}},"wasm-dotnet/runtime/ref/System.Transactions.Local.dll":{sha256:`0b9c574b03b4ace54628dee9867a6febf8eebeab007cd18f6e3d644b6117d093`,bytes:25936,mediaType:`application/octet-stream`,layer:{path:`wasm-dotnet/runtime/layers/ref-00.pack.gz`,offset:7589376,bytes:25936}},"wasm-dotnet/runtime/ref/System.Transactions.dll":{sha256:`f2b89bf5485ec532a0f080ec1c695276dc556ee2272c510f2fe70c47857ceb5b`,bytes:16208,mediaType:`application/octet-stream`,layer:{path:`wasm-dotnet/runtime/layers/ref-00.pack.gz`,offset:7615312,bytes:16208}},"wasm-dotnet/runtime/ref/System.ValueTuple.dll":{sha256:`9dd20fe9679a4cb2b7cd7507a147599e09e049c8bf81bcd34c152be49c2ebe28`,bytes:15144,mediaType:`application/octet-stream`,layer:{path:`wasm-dotnet/runtime/layers/ref-00.pack.gz`,offset:7631520,bytes:15144}},"wasm-dotnet/runtime/ref/System.Web.HttpUtility.dll":{sha256:`f783c0d44819619179745e7e48cf6c0004c757935383b8490fb3a5e32813fc24`,bytes:17232,mediaType:`application/octet-stream`,layer:{path:`wasm-dotnet/runtime/layers/ref-00.pack.gz`,offset:7646664,bytes:17232}},"wasm-dotnet/runtime/ref/System.Web.dll":{sha256:`d5bd60d5be0f1a48b483324e15ae1b8b6bf3652355121b0c2e679c7c04d5206a`,bytes:15144,mediaType:`application/octet-stream`,layer:{path:`wasm-dotnet/runtime/layers/ref-00.pack.gz`,offset:7663896,bytes:15144}},"wasm-dotnet/runtime/ref/System.Windows.dll":{sha256:`1e4891b17a6c47a04707b66c6932cc839734f609fd0e2fe7425a2776104ace89`,bytes:15656,mediaType:`application/octet-stream`,layer:{path:`wasm-dotnet/runtime/layers/ref-00.pack.gz`,offset:7679040,bytes:15656}},"wasm-dotnet/runtime/ref/System.Xml.Linq.dll":{sha256:`ccb95f83b96d824aca346498afa194160039724173d16a0fe589a8cab51df0e0`,bytes:15656,mediaType:`application/octet-stream`,layer:{path:`wasm-dotnet/runtime/layers/ref-00.pack.gz`,offset:7694696,bytes:15656}},"wasm-dotnet/runtime/ref/System.Xml.ReaderWriter.dll":{sha256:`84bd85d822df9ace65d58995abe438a8e1fe5bbf5c3ab636878ff34f653b721f`,bytes:115496,mediaType:`application/octet-stream`,layer:{path:`wasm-dotnet/runtime/layers/ref-00.pack.gz`,offset:7710352,bytes:115496}},"wasm-dotnet/runtime/ref/System.Xml.Serialization.dll":{sha256:`b81e6694fa9717409ed485dab46040c6a96bf31deafff3d221921d061d80653d`,bytes:16168,mediaType:`application/octet-stream`,layer:{path:`wasm-dotnet/runtime/layers/ref-00.pack.gz`,offset:7825848,bytes:16168}},"wasm-dotnet/runtime/ref/System.Xml.XDocument.dll":{sha256:`6ceadf70c2641eb5b52cedddc509e4b04ecc567db7483920ca80b06db4cffc41`,bytes:34088,mediaType:`application/octet-stream`,layer:{path:`wasm-dotnet/runtime/layers/ref-00.pack.gz`,offset:7842016,bytes:34088}},"wasm-dotnet/runtime/ref/System.Xml.XPath.XDocument.dll":{sha256:`b4183cff9ed7d510fd7124280007dfd4a0738d4c95eff16aa8717dba8a1ca83e`,bytes:16168,mediaType:`application/octet-stream`,layer:{path:`wasm-dotnet/runtime/layers/ref-00.pack.gz`,offset:7876104,bytes:16168}},"wasm-dotnet/runtime/ref/System.Xml.XPath.dll":{sha256:`caeeffceaad09e9cf450292906ce113313a5d33ba711d1067470a622fcf337ec`,bytes:16720,mediaType:`application/octet-stream`,layer:{path:`wasm-dotnet/runtime/layers/ref-00.pack.gz`,offset:7892272,bytes:16720}},"wasm-dotnet/runtime/ref/System.Xml.XmlDocument.dll":{sha256:`aed44387180aa01b7ef85f76606415e4f9bfc5d3f61e9f63df37c0e6b238fcc6`,bytes:15696,mediaType:`application/octet-stream`,layer:{path:`wasm-dotnet/runtime/layers/ref-00.pack.gz`,offset:7908992,bytes:15696}},"wasm-dotnet/runtime/ref/System.Xml.XmlSerializer.dll":{sha256:`aa9a0919e44b66809075b2e6a2f867e507a2bf5ce1533987cb98cbf6f06cfef8`,bytes:50472,mediaType:`application/octet-stream`,layer:{path:`wasm-dotnet/runtime/layers/ref-00.pack.gz`,offset:7924688,bytes:50472}},"wasm-dotnet/runtime/ref/System.Xml.dll":{sha256:`9315d84ad4ea92c7e5621ede2bf4903a52b312f7dc759d26b8ead93e5467ff57`,bytes:23376,mediaType:`application/octet-stream`,layer:{path:`wasm-dotnet/runtime/layers/ref-00.pack.gz`,offset:7975160,bytes:23376}},"wasm-dotnet/runtime/ref/System.dll":{sha256:`ee0a44e59e9be91aaa4f1cae93ab67af5b3b38d7a0295f1cc80a1774f93331ee`,bytes:49488,mediaType:`application/octet-stream`,layer:{path:`wasm-dotnet/runtime/layers/ref-00.pack.gz`,offset:7998536,bytes:49488}},"wasm-dotnet/runtime/ref/WasmDotnet.Stdin.dll":{sha256:`ccb2176c696619e2eaed2a1968c61acf38fc7ef5c6e026bb5ed43b1f4fad398a`,bytes:4608,mediaType:`application/octet-stream`,layer:{path:`wasm-dotnet/runtime/layers/ref-00.pack.gz`,offset:8048024,bytes:4608}},"wasm-dotnet/runtime/ref/WindowsBase.dll":{sha256:`793d3d5169cfd81aae273a242806f4826d4350e84701d6c6ace123ca774c9e19`,bytes:16168,mediaType:`application/octet-stream`,layer:{path:`wasm-dotnet/runtime/layers/ref-00.pack.gz`,offset:8052632,bytes:16168}},"wasm-dotnet/runtime/ref/manifest.json":{sha256:`13eba540736cbfef1697109f2546c0c3b6de757f1e9b6af80c3476a8833a9b84`,bytes:6079,mediaType:`application/json`,layer:{path:`wasm-dotnet/runtime/layers/ref-00.pack.gz`,offset:8068800,bytes:6079}},"wasm-dotnet/runtime/ref/mscorlib.dll":{sha256:`0146ace3dea097468a7bec69e4e9c37a2d41e4350aaa3326ae27a8c642c351cc`,bytes:55592,mediaType:`application/octet-stream`,layer:{path:`wasm-dotnet/runtime/layers/ref-00.pack.gz`,offset:8074879,bytes:55592}},"wasm-dotnet/runtime/ref/netstandard.dll":{sha256:`37ff7c4edf8ce36eaf2122d59323c4494a2bc9a7541413de9d345f76a83a2d83`,bytes:100648,mediaType:`application/octet-stream`,layer:{path:`wasm-dotnet/runtime/layers/ref-00.pack.gz`,offset:8130471,bytes:100648}},"wasm-dotnet/runtime/vbnet/Microsoft.CodeAnalysis.VisualBasic.wasm":{sha256:`70258456029dd598040bb48e320de01b7c60bcbe9748c2cb3af8abe3476c9039`,bytes:3296025,mediaType:`application/wasm`,layer:{path:`wasm-dotnet/runtime/layers/vbnet-00.pack.gz`,offset:0,bytes:3296025}},"wasm-dotnet/runtime/vbnet/Microsoft.CodeAnalysis.wasm":{sha256:`eeabd85e3797549f18a7a092ccb2fc6a421ad6c7a516461caa15289378aa9abb`,bytes:1174293,mediaType:`application/wasm`,layer:{path:`wasm-dotnet/runtime/layers/vbnet-00.pack.gz`,offset:3296025,bytes:1174293}},"wasm-dotnet/runtime/vbnet/System.Collections.Concurrent.wasm":{sha256:`e65be2ec815af32021006fe48ab9812d7e8c4e4d77db13812d03d194631599c8`,bytes:23829,mediaType:`application/wasm`,layer:{path:`wasm-dotnet/runtime/layers/vbnet-00.pack.gz`,offset:4470318,bytes:23829}},"wasm-dotnet/runtime/vbnet/System.Collections.Immutable.wasm":{sha256:`d068a8e2bbf2e6216f8a87384aeb61bf27451a9b6d05b4780d4cd4666957727d`,bytes:77077,mediaType:`application/wasm`,layer:{path:`wasm-dotnet/runtime/layers/vbnet-00.pack.gz`,offset:4494147,bytes:77077}},"wasm-dotnet/runtime/vbnet/System.Collections.NonGeneric.wasm":{sha256:`871743255f218b596618fd990e5c52cc4005418a0b9800d85af77547e318afa4`,bytes:7445,mediaType:`application/wasm`,layer:{path:`wasm-dotnet/runtime/layers/vbnet-00.pack.gz`,offset:4571224,bytes:7445}},"wasm-dotnet/runtime/vbnet/System.Collections.Specialized.wasm":{sha256:`76b7f4fb54cb4ff3451a45d87d23af7f1ce335a62210d574f39065001d331f4f`,bytes:9493,mediaType:`application/wasm`,layer:{path:`wasm-dotnet/runtime/layers/vbnet-00.pack.gz`,offset:4578669,bytes:9493}},"wasm-dotnet/runtime/vbnet/System.Collections.wasm":{sha256:`c7e8f4bca53726f1c07fdedbb1ddef701cbd81b1f3c29f48a9c53187d34836fd`,bytes:34581,mediaType:`application/wasm`,layer:{path:`wasm-dotnet/runtime/layers/vbnet-00.pack.gz`,offset:4588162,bytes:34581}},"wasm-dotnet/runtime/vbnet/System.ComponentModel.Primitives.wasm":{sha256:`952b98a68dcb0d8479bfbada3ce275d4a6e677038db3c0c5168e7864af94b805`,bytes:6933,mediaType:`application/wasm`,layer:{path:`wasm-dotnet/runtime/layers/vbnet-00.pack.gz`,offset:4622743,bytes:6933}},"wasm-dotnet/runtime/vbnet/System.ComponentModel.TypeConverter.wasm":{sha256:`f597203f6252b16f0d24656f569688e7dcbf6098c56bd9d2506898bd13462773`,bytes:45333,mediaType:`application/wasm`,layer:{path:`wasm-dotnet/runtime/layers/vbnet-00.pack.gz`,offset:4629676,bytes:45333}},"wasm-dotnet/runtime/vbnet/System.ComponentModel.wasm":{sha256:`455436e971c5bd41f2de5062ea7a2abb6b9a80870b11986750705a6d2164697a`,bytes:4885,mediaType:`application/wasm`,layer:{path:`wasm-dotnet/runtime/layers/vbnet-00.pack.gz`,offset:4675009,bytes:4885}},"wasm-dotnet/runtime/vbnet/System.Console.wasm":{sha256:`6e7f487f39d95aaa12780772edef2b2836805599131258f93b0f36e7257d6742`,bytes:30997,mediaType:`application/wasm`,layer:{path:`wasm-dotnet/runtime/layers/vbnet-00.pack.gz`,offset:4679894,bytes:30997}},"wasm-dotnet/runtime/vbnet/System.Diagnostics.DiagnosticSource.wasm":{sha256:`5864933f73e3a718f5537646eae8aa70bfb0b4d95c597051e0645afb7aba4cfd`,bytes:18197,mediaType:`application/wasm`,layer:{path:`wasm-dotnet/runtime/layers/vbnet-00.pack.gz`,offset:4710891,bytes:18197}},"wasm-dotnet/runtime/vbnet/System.Globalization.wasm":{sha256:`8396792b7b1304fc982f8d59a6a3d847926f70f575c771a126b081690d66db5b`,bytes:4373,mediaType:`application/wasm`,layer:{path:`wasm-dotnet/runtime/layers/vbnet-00.pack.gz`,offset:4729088,bytes:4373}},"wasm-dotnet/runtime/vbnet/System.IO.Compression.wasm":{sha256:`efa5f5dbf2faed48df07c6322e8e4232f269f162437eb6b29dbba4c1dfe6b32b`,bytes:24853,mediaType:`application/wasm`,layer:{path:`wasm-dotnet/runtime/layers/vbnet-00.pack.gz`,offset:4733461,bytes:24853}},"wasm-dotnet/runtime/vbnet/System.IO.MemoryMappedFiles.wasm":{sha256:`63bf010878d1823836138f6e27243bf28590da6295646c354a9b919dd0f95d3b`,bytes:24341,mediaType:`application/wasm`,layer:{path:`wasm-dotnet/runtime/layers/vbnet-00.pack.gz`,offset:4758314,bytes:24341}},"wasm-dotnet/runtime/vbnet/System.IO.Pipelines.wasm":{sha256:`6a0070dcee449a4b1a1d0e34a9b058deae4d0a78d9e412c448f3a3ebd1a717c8`,bytes:5909,mediaType:`application/wasm`,layer:{path:`wasm-dotnet/runtime/layers/vbnet-00.pack.gz`,offset:4782655,bytes:5909}},"wasm-dotnet/runtime/vbnet/System.Linq.wasm":{sha256:`65ed0f2eef0f240b10d122e4911de1ab8f4c54d8a3a81ad1bf6ceccfdd0c8a70`,bytes:44821,mediaType:`application/wasm`,layer:{path:`wasm-dotnet/runtime/layers/vbnet-00.pack.gz`,offset:4788564,bytes:44821}},"wasm-dotnet/runtime/vbnet/System.Memory.wasm":{sha256:`25c378e4f8634247fe8dcacfe3efbd0d36f1a0697b7039b4d83c56e82a7628d9`,bytes:14101,mediaType:`application/wasm`,layer:{path:`wasm-dotnet/runtime/layers/vbnet-00.pack.gz`,offset:4833385,bytes:14101}},"wasm-dotnet/runtime/vbnet/System.Net.Http.wasm":{sha256:`dcdc774e44253f09a2389ce91d6a9e6362b666890e4a16d99dc2b26b02ef4601`,bytes:138005,mediaType:`application/wasm`,layer:{path:`wasm-dotnet/runtime/layers/vbnet-00.pack.gz`,offset:4847486,bytes:138005}},"wasm-dotnet/runtime/vbnet/System.Net.Primitives.wasm":{sha256:`a54ef248e2ddfcb4991c7b196ee6b33a8c2bd06775309c9f339b1b0f50879777`,bytes:7445,mediaType:`application/wasm`,layer:{path:`wasm-dotnet/runtime/layers/vbnet-00.pack.gz`,offset:4985491,bytes:7445}},"wasm-dotnet/runtime/vbnet/System.ObjectModel.wasm":{sha256:`68a10e9e56a896b0006e01f4e2df1264bfe034d3913694635a926df94c02e083`,bytes:5909,mediaType:`application/wasm`,layer:{path:`wasm-dotnet/runtime/layers/vbnet-00.pack.gz`,offset:4992936,bytes:5909}},"wasm-dotnet/runtime/vbnet/System.Private.CoreLib.wasm":{sha256:`4294efdd71bbec177c144089a17251f01a8b841b4ad00c71da6772b935aca5b9`,bytes:1666325,mediaType:`application/wasm`,layer:{path:`wasm-dotnet/runtime/layers/vbnet-00.pack.gz`,offset:4998845,bytes:1666325}},"wasm-dotnet/runtime/vbnet/System.Private.Uri.wasm":{sha256:`2777bf7ba9b26016c5650049f9be6d1e6972438520e764c0c494c1568a70281a`,bytes:64277,mediaType:`application/wasm`,layer:{path:`wasm-dotnet/runtime/layers/vbnet-00.pack.gz`,offset:6665170,bytes:64277}},"wasm-dotnet/runtime/vbnet/System.Private.Xml.Linq.wasm":{sha256:`bef4b22cb0d5148fcf5a38e2c666c1c7c8a899119ca7bd68e55b8c0ef735940a`,bytes:44309,mediaType:`application/wasm`,layer:{path:`wasm-dotnet/runtime/layers/vbnet-00.pack.gz`,offset:6729447,bytes:44309}},"wasm-dotnet/runtime/vbnet/System.Private.Xml.wasm":{sha256:`9669db5606beac4759838c743e47a162214040ca15dcbada98f8f80a747cf219`,bytes:530197,mediaType:`application/wasm`,layer:{path:`wasm-dotnet/runtime/layers/vbnet-00.pack.gz`,offset:6773756,bytes:530197}},"wasm-dotnet/runtime/vbnet/System.Reflection.Metadata.wasm":{sha256:`c70ab649d2549b767319a0baa1946b355d9ac71e2a3bada5451840cd2696a5d3`,bytes:257813,mediaType:`application/wasm`,layer:{path:`wasm-dotnet/runtime/layers/vbnet-00.pack.gz`,offset:7303953,bytes:257813}},"wasm-dotnet/runtime/vbnet/System.Runtime.InteropServices.JavaScript.wasm":{sha256:`d3a62254869fb628c7b77f5786b16240af89f7e40ecadacdfa7ee12da8eea3b7`,bytes:59157,mediaType:`application/wasm`,layer:{path:`wasm-dotnet/runtime/layers/vbnet-00.pack.gz`,offset:7561766,bytes:59157}},"wasm-dotnet/runtime/vbnet/System.Runtime.Numerics.wasm":{sha256:`3048f4112fe313bdaa58eef8c3e8c5ba55641ebf908407d1b863f8b4525b0ac7`,bytes:82197,mediaType:`application/wasm`,layer:{path:`wasm-dotnet/runtime/layers/vbnet-00.pack.gz`,offset:7620923,bytes:82197}},"wasm-dotnet/runtime/vbnet/System.Runtime.Serialization.Primitives.wasm":{sha256:`630ffcf185b1d071c51c4e411333a240bf273579568068d5163997961120e576`,bytes:5909,mediaType:`application/wasm`,layer:{path:`wasm-dotnet/runtime/layers/vbnet-00.pack.gz`,offset:7703120,bytes:5909}},"wasm-dotnet/runtime/vbnet/System.Security.Cryptography.wasm":{sha256:`7522c4ec6d1decd42c54212b68d3cbf4886785c2bffc57c26df8111eddcaac9a`,bytes:23829,mediaType:`application/wasm`,layer:{path:`wasm-dotnet/runtime/layers/vbnet-00.pack.gz`,offset:7709029,bytes:23829}},"wasm-dotnet/runtime/vbnet/System.Text.Encodings.Web.wasm":{sha256:`8b6954f779e7b0de352805a65c263351bc15e1e864c00e7b9669abbaea81d648`,bytes:29461,mediaType:`application/wasm`,layer:{path:`wasm-dotnet/runtime/layers/vbnet-00.pack.gz`,offset:7732858,bytes:29461}},"wasm-dotnet/runtime/vbnet/System.Text.Json.wasm":{sha256:`71d6ae68513863ea5c1ea735744d2092f00112c7fb7ea8f9a52373e92f063e66`,bytes:197909,mediaType:`application/wasm`,layer:{path:`wasm-dotnet/runtime/layers/vbnet-00.pack.gz`,offset:7762319,bytes:197909}},"wasm-dotnet/runtime/vbnet/System.Text.RegularExpressions.wasm":{sha256:`36198b5f5a4d475fca0e643ad058b690aff7e51e5985274975f107e4fea4077a`,bytes:15637,mediaType:`application/wasm`,layer:{path:`wasm-dotnet/runtime/layers/vbnet-00.pack.gz`,offset:7960228,bytes:15637}},"wasm-dotnet/runtime/vbnet/System.Threading.Channels.wasm":{sha256:`79f1698693c1612b45fd49799142a32c4eadc4ff430389fce5e2d4af2884f596`,bytes:20757,mediaType:`application/wasm`,layer:{path:`wasm-dotnet/runtime/layers/vbnet-00.pack.gz`,offset:7975865,bytes:20757}},"wasm-dotnet/runtime/vbnet/System.Threading.Tasks.Parallel.wasm":{sha256:`a9edf29a589d922756b61c31e151f792e0189f653b584c41329934b8809b444e`,bytes:15637,mediaType:`application/wasm`,layer:{path:`wasm-dotnet/runtime/layers/vbnet-00.pack.gz`,offset:7996622,bytes:15637}},"wasm-dotnet/runtime/vbnet/System.Xml.Linq.wasm":{sha256:`937ef5ff8a2252bd5c88167090f6f864fb7f760322a270b21df422f54521180a`,bytes:4373,mediaType:`application/wasm`,layer:{path:`wasm-dotnet/runtime/layers/vbnet-00.pack.gz`,offset:8012259,bytes:4373}},"wasm-dotnet/runtime/vbnet/System.wasm":{sha256:`8e898ef2158280fd3d14ea113e4a5e8edb71455fe5a288eeec471ba922a434e7`,bytes:4373,mediaType:`application/wasm`,layer:{path:`wasm-dotnet/runtime/layers/vbnet-00.pack.gz`,offset:8016632,bytes:4373}},"wasm-dotnet/runtime/vbnet/WasmDotnet.Compiler.wasm":{sha256:`b09e779cf849e7d92ee173db5515be90a77d70fc5b48e6fb151862ea2ca18efd`,bytes:69397,mediaType:`application/wasm`,layer:{path:`wasm-dotnet/runtime/layers/vbnet-00.pack.gz`,offset:8021005,bytes:69397}},"wasm-dotnet/runtime/vbnet/WasmDotnet.Stdin.wasm":{sha256:`fb1de53e58715855614aa0fa79280bc9e8ec8cf552e17763368a17ad34f52bce`,bytes:3861,mediaType:`application/wasm`,layer:{path:`wasm-dotnet/runtime/layers/vbnet-00.pack.gz`,offset:8090402,bytes:3861}},"wasm-dotnet/runtime/vbnet/blazor.boot.json":{sha256:`9137e55948ff4569748d69120ec92545a3f265c556579e125ea3e4a3a9894678`,bytes:7751,mediaType:`application/json`,layer:{path:`wasm-dotnet/runtime/layers/vbnet-00.pack.gz`,offset:8094263,bytes:7751}},"wasm-dotnet/runtime/vbnet/cs/Microsoft.CodeAnalysis.VisualBasic.resources.wasm":{sha256:`04093e3a5d1823220f6c40b716e647b63386c71c2e56d4c3bc1d6dfd2533834f`,bytes:292629,mediaType:`application/wasm`,layer:{path:`wasm-dotnet/runtime/layers/vbnet-00.pack.gz`,offset:8102014,bytes:292629}},"wasm-dotnet/runtime/vbnet/cs/Microsoft.CodeAnalysis.resources.wasm":{sha256:`9a5c8fbc8cbf693ac3f5c591fa7694ddd2258328b41dde572f216381288d230a`,bytes:37653,mediaType:`application/wasm`,layer:{path:`wasm-dotnet/runtime/layers/vbnet-00.pack.gz`,offset:8394643,bytes:37653}},"wasm-dotnet/runtime/vbnet/de/Microsoft.CodeAnalysis.VisualBasic.resources.wasm":{sha256:`cbca0e81ac3f19512623f778c557f11e3febdb278ccad75f7716bdec29a142d8`,bytes:308501,mediaType:`application/wasm`,layer:{path:`wasm-dotnet/runtime/layers/vbnet-00.pack.gz`,offset:8432296,bytes:308501}},"wasm-dotnet/runtime/vbnet/de/Microsoft.CodeAnalysis.resources.wasm":{sha256:`5e73b0323639ffe0ecacc753bbab657fe145e496d419fd036427aa0d9ad2f4d9`,bytes:39701,mediaType:`application/wasm`,layer:{path:`wasm-dotnet/runtime/layers/vbnet-00.pack.gz`,offset:8740797,bytes:39701}},"wasm-dotnet/runtime/vbnet/dotnet.js":{sha256:`f4697f2c0de6d3266d9881d1d3bca86fc24b166379798b2e1905f5db40bd65bb`,bytes:42864,mediaType:`text/javascript`,layer:{path:`wasm-dotnet/runtime/layers/vbnet-00.pack.gz`,offset:8780498,bytes:42864}},"wasm-dotnet/runtime/vbnet/dotnet.native.js":{sha256:`9f22eaf4974a81ded46c9cc0edc682b2a3918b8c4c658eb99d5f6547902ec914`,bytes:148289,mediaType:`text/javascript`,layer:{path:`wasm-dotnet/runtime/layers/vbnet-00.pack.gz`,offset:8823362,bytes:148289}},"wasm-dotnet/runtime/vbnet/dotnet.native.wasm":{sha256:`3ffd699bfac3d871dd7f7697cd844e2a7305bda724ad80a32e14f3250657d1d9`,bytes:21740839,mediaType:`application/wasm`,deliveryPath:`wasm-dotnet/runtime/vbnet/dotnet.native.wasm.gz`},"wasm-dotnet/runtime/vbnet/dotnet.native.wasm.gz":{sha256:`0b37c4f1b1268d79f3e707af7e385c1b35101726549f06fe792a8cfb0a277b35`,bytes:6972675,encoding:`gzip`,mediaType:`application/wasm`,uncompressedSha256:`3ffd699bfac3d871dd7f7697cd844e2a7305bda724ad80a32e14f3250657d1d9`,uncompressedBytes:21740839},"wasm-dotnet/runtime/vbnet/dotnet.native.worker.mjs":{sha256:`5bca00fcf6664a97e54c58286bb235abfb3faa2de8582aaaf046d4520c1838d5`,bytes:2854,mediaType:`text/javascript`,layer:{path:`wasm-dotnet/runtime/layers/vbnet-00.pack.gz`,offset:8971651,bytes:2854}},"wasm-dotnet/runtime/vbnet/dotnet.runtime.js":{sha256:`8dea669b9580f3e9e3222cfc0407887b7b8ccda953c2048a54693ad5ede2c40c`,bytes:232671,mediaType:`text/javascript`,layer:{path:`wasm-dotnet/runtime/layers/vbnet-00.pack.gz`,offset:8974505,bytes:232671}},"wasm-dotnet/runtime/vbnet/es/Microsoft.CodeAnalysis.VisualBasic.resources.wasm":{sha256:`9fa1505c7756996d2b453548d4c618e23a851d80e28e475fe733a64f534b1dd3`,bytes:303893,mediaType:`application/wasm`,layer:{path:`wasm-dotnet/runtime/layers/vbnet-00.pack.gz`,offset:9207176,bytes:303893}},"wasm-dotnet/runtime/vbnet/es/Microsoft.CodeAnalysis.resources.wasm":{sha256:`fef6f3876c1289b90b1be87104d74ebe2b61ab45911231d923d5127ea113cddd`,bytes:39189,mediaType:`application/wasm`,layer:{path:`wasm-dotnet/runtime/layers/vbnet-00.pack.gz`,offset:9511069,bytes:39189}},"wasm-dotnet/runtime/vbnet/fr/Microsoft.CodeAnalysis.VisualBasic.resources.wasm":{sha256:`4929a1aca4e5ec3988b61c97e565e103726a16b2b845ecff897c3756f722b36a`,bytes:311061,mediaType:`application/wasm`,layer:{path:`wasm-dotnet/runtime/layers/vbnet-00.pack.gz`,offset:9550258,bytes:311061}},"wasm-dotnet/runtime/vbnet/fr/Microsoft.CodeAnalysis.resources.wasm":{sha256:`8e167e434812ab15faa6135c808c19cbda743f3ec475b142ad706bb6c96cd660`,bytes:39701,mediaType:`application/wasm`,layer:{path:`wasm-dotnet/runtime/layers/vbnet-00.pack.gz`,offset:9861319,bytes:39701}},"wasm-dotnet/runtime/vbnet/it/Microsoft.CodeAnalysis.VisualBasic.resources.wasm":{sha256:`61c666de7630135b011cf793adbb26a091d1275514edf45f372cc15d7b8afc12`,bytes:308501,mediaType:`application/wasm`,layer:{path:`wasm-dotnet/runtime/layers/vbnet-00.pack.gz`,offset:9901020,bytes:308501}},"wasm-dotnet/runtime/vbnet/it/Microsoft.CodeAnalysis.resources.wasm":{sha256:`d0e8e7692c25c1e4e39c3862fa77d94e4a3b9c2325380f9f1a22fa7e6979575d`,bytes:39701,mediaType:`application/wasm`,layer:{path:`wasm-dotnet/runtime/layers/vbnet-00.pack.gz`,offset:10209521,bytes:39701}},"wasm-dotnet/runtime/vbnet/ja/Microsoft.CodeAnalysis.VisualBasic.resources.wasm":{sha256:`cd45301c6ba384db885186bd879f71bb21d66408df2fa71b143f312f02ae184f`,bytes:344341,mediaType:`application/wasm`,layer:{path:`wasm-dotnet/runtime/layers/vbnet-00.pack.gz`,offset:10249222,bytes:344341}},"wasm-dotnet/runtime/vbnet/ja/Microsoft.CodeAnalysis.resources.wasm":{sha256:`0170006336c2590bcfe155a894e041643bcf27f8718c8f29e9b7ec83a56a8a64`,bytes:43285,mediaType:`application/wasm`,layer:{path:`wasm-dotnet/runtime/layers/vbnet-00.pack.gz`,offset:10593563,bytes:43285}},"wasm-dotnet/runtime/vbnet/ko/Microsoft.CodeAnalysis.VisualBasic.resources.wasm":{sha256:`cacb05ec3235f2b40d452a4e4891ea2e81d69e43e463174e056e226a5f0ba348`,bytes:313621,mediaType:`application/wasm`,layer:{path:`wasm-dotnet/runtime/layers/vbnet-00.pack.gz`,offset:10636848,bytes:313621}},"wasm-dotnet/runtime/vbnet/ko/Microsoft.CodeAnalysis.resources.wasm":{sha256:`c273548046b7d4ff01bddb62e7640fd5f39041cbef56240398cb4c3f69e7975f`,bytes:39701,mediaType:`application/wasm`,layer:{path:`wasm-dotnet/runtime/layers/vbnet-00.pack.gz`,offset:10950469,bytes:39701}},"wasm-dotnet/runtime/vbnet/pl/Microsoft.CodeAnalysis.VisualBasic.resources.wasm":{sha256:`405195b1d4814b54d665699eeaca6e7f1b818c035f3e316e47836a882b1bba10`,bytes:318229,mediaType:`application/wasm`,layer:{path:`wasm-dotnet/runtime/layers/vbnet-00.pack.gz`,offset:10990170,bytes:318229}},"wasm-dotnet/runtime/vbnet/pl/Microsoft.CodeAnalysis.resources.wasm":{sha256:`7417edd7a418a858074e10277c36cf2f5e068193b8c5ec3716e4f646f489bc31`,bytes:39701,mediaType:`application/wasm`,layer:{path:`wasm-dotnet/runtime/layers/vbnet-00.pack.gz`,offset:11308399,bytes:39701}},"wasm-dotnet/runtime/vbnet/pt-BR/Microsoft.CodeAnalysis.VisualBasic.resources.wasm":{sha256:`cac733ff5df9dcab0a389dec1a1cfcb80d8fe4b4f6af3367589f4f3549db4667`,bytes:297749,mediaType:`application/wasm`,layer:{path:`wasm-dotnet/runtime/layers/vbnet-00.pack.gz`,offset:11348100,bytes:297749}},"wasm-dotnet/runtime/vbnet/pt-BR/Microsoft.CodeAnalysis.resources.wasm":{sha256:`921393dcb10c6c087c0c3b73b493de8a2b8b6033dd2010fa724a8ae56e65446e`,bytes:38677,mediaType:`application/wasm`,layer:{path:`wasm-dotnet/runtime/layers/vbnet-00.pack.gz`,offset:11645849,bytes:38677}},"wasm-dotnet/runtime/vbnet/ru/Microsoft.CodeAnalysis.VisualBasic.resources.wasm":{sha256:`0c9431a0d97e31415f7483e750dff26fe23eb21c62249552c7b596c325e2d6c8`,bytes:401173,mediaType:`application/wasm`,layer:{path:`wasm-dotnet/runtime/layers/vbnet-00.pack.gz`,offset:11684526,bytes:401173}},"wasm-dotnet/runtime/vbnet/ru/Microsoft.CodeAnalysis.resources.wasm":{sha256:`63ee787aea6292dcdbdab9ef2487cef244ebbbbbafee3e1212770399f8ce7b96`,bytes:49941,mediaType:`application/wasm`,layer:{path:`wasm-dotnet/runtime/layers/vbnet-00.pack.gz`,offset:12085699,bytes:49941}},"wasm-dotnet/runtime/vbnet/supportFiles/0_runtimeconfig.bin":{sha256:`eba865048cf85bf45a627bfda964b22784be8e1616d250d9349e962a186e8d34`,bytes:1551,mediaType:`application/octet-stream`,layer:{path:`wasm-dotnet/runtime/layers/vbnet-00.pack.gz`,offset:12135640,bytes:1551}},"wasm-dotnet/runtime/vbnet/tr/Microsoft.CodeAnalysis.VisualBasic.resources.wasm":{sha256:`54a97f18c97c3e43ebf6c1864005423b32f2f47f822d0ec751060804bb450ca7`,bytes:294165,mediaType:`application/wasm`,layer:{path:`wasm-dotnet/runtime/layers/vbnet-00.pack.gz`,offset:12137191,bytes:294165}},"wasm-dotnet/runtime/vbnet/tr/Microsoft.CodeAnalysis.resources.wasm":{sha256:`1f05bc34b37b713aa565f61ed7a801fdadd00813ba6462a2f35ac0a5045379ce`,bytes:38165,mediaType:`application/wasm`,layer:{path:`wasm-dotnet/runtime/layers/vbnet-00.pack.gz`,offset:12431356,bytes:38165}},"wasm-dotnet/runtime/vbnet/zh-Hans/Microsoft.CodeAnalysis.VisualBasic.resources.wasm":{sha256:`784c21ddead39042a5d73a782a81b2163dc8e5f8d7e2c4fb258459348a051328`,bytes:268053,mediaType:`application/wasm`,layer:{path:`wasm-dotnet/runtime/layers/vbnet-00.pack.gz`,offset:12469521,bytes:268053}},"wasm-dotnet/runtime/vbnet/zh-Hans/Microsoft.CodeAnalysis.resources.wasm":{sha256:`85e94866e88998e4b88920ad7bcd3e4de57f91ec9c5b0e3331369ded3102739d`,bytes:34581,mediaType:`application/wasm`,layer:{path:`wasm-dotnet/runtime/layers/vbnet-00.pack.gz`,offset:12737574,bytes:34581}},"wasm-dotnet/runtime/vbnet/zh-Hant/Microsoft.CodeAnalysis.VisualBasic.resources.wasm":{sha256:`a86304e9f69afaecc4846c0b9ef93bc9466657fae5cc7518e97fb6e211804823`,bytes:267029,mediaType:`application/wasm`,layer:{path:`wasm-dotnet/runtime/layers/vbnet-00.pack.gz`,offset:12772155,bytes:267029}},"wasm-dotnet/runtime/vbnet/zh-Hant/Microsoft.CodeAnalysis.resources.wasm":{sha256:`ad5707a586422ee6256c8a9f044d26378c971706424b661b47b4f93f2a1e368d`,bytes:34581,mediaType:`application/wasm`,layer:{path:`wasm-dotnet/runtime/layers/vbnet-00.pack.gz`,offset:13039184,bytes:34581}},"wasm-dotnet/types.js":{sha256:`01ae2a5b120382f9a648ced7ee8507493a134f216d100fc61600c6c9738235d2`,bytes:44,mediaType:`text/javascript`},"wasm-duckdb/assets/duckdb-browser-eh.worker-CwdVMcbT.js":{sha256:`fa889e6068c40426dea67c08cf16ce0cad7404eae94f6a2522adcabb5898eb93`,bytes:773223,mediaType:`text/javascript`,deliveryPath:`wasm-duckdb/assets/duckdb-browser-eh.worker-CwdVMcbT.js.gz`},"wasm-duckdb/assets/duckdb-browser-eh.worker-CwdVMcbT.js.gz":{sha256:`2ff841811020e72e0388e95a56e1ea16f95751f53a6857ed61a4d43b9a48a762`,bytes:188713,encoding:`gzip`,mediaType:`text/javascript`,uncompressedSha256:`fa889e6068c40426dea67c08cf16ce0cad7404eae94f6a2522adcabb5898eb93`,uncompressedBytes:773223},"wasm-duckdb/assets/duckdb-browser-mvp.worker-BEKIasyR.js":{sha256:`964f678d3bfa5a23deb154e0a7950634a4d1415e571040ab2d47815dc3f13582`,bytes:839642,mediaType:`text/javascript`,deliveryPath:`wasm-duckdb/assets/duckdb-browser-mvp.worker-BEKIasyR.js.gz`},"wasm-duckdb/assets/duckdb-browser-mvp.worker-BEKIasyR.js.gz":{sha256:`f8643e522dcc65ab550462f9eda333d148d0faf2b76d2a2936cba436c5e4a573`,bytes:193871,encoding:`gzip`,mediaType:`text/javascript`,uncompressedSha256:`964f678d3bfa5a23deb154e0a7950634a4d1415e571040ab2d47815dc3f13582`,uncompressedBytes:839642},"wasm-duckdb/assets/duckdb-eh-CfdE9-rk.wasm":{sha256:`3abdec74989dcc54d2f2ea5621f611f3c45db1e7dff2f408476014d82beb2029`,bytes:35913747,mediaType:`application/wasm`,deliveryPath:`wasm-duckdb/assets/duckdb-eh-CfdE9-rk.wasm.gz`},"wasm-duckdb/assets/duckdb-eh-CfdE9-rk.wasm.gz":{sha256:`6e5ba7ff057e90550ee781fa593f066f4abfdde77323da4c969c8aaddc62c147`,bytes:8090177,encoding:`gzip`,mediaType:`application/wasm`,uncompressedSha256:`3abdec74989dcc54d2f2ea5621f611f3c45db1e7dff2f408476014d82beb2029`,uncompressedBytes:35913747},"wasm-duckdb/assets/duckdb-mvp-DQDXaYzB.wasm":{sha256:`ee5560145a3d3e0ffa6dce697be802c08842f139a594698eecc7c754f7ad5f05`,bytes:41325187,mediaType:`application/wasm`,deliveryPath:`wasm-duckdb/assets/duckdb-mvp-DQDXaYzB.wasm.gz`},"wasm-duckdb/assets/duckdb-mvp-DQDXaYzB.wasm.gz":{sha256:`9156e6acfe1a155846eb73de3fdf751463665660e5ca4f0a69da25e33a6499f8`,bytes:9215786,encoding:`gzip`,mediaType:`application/wasm`,uncompressedSha256:`ee5560145a3d3e0ffa6dce697be802c08842f139a594698eecc7c754f7ad5f05`,uncompressedBytes:41325187},"wasm-duckdb/runtime-manifest.v1.json":{sha256:`5a2d5d01ca9b4387683ce7c979618d0c5fa20598340910c48fe9a305ec19c51c`,bytes:989,mediaType:`application/json`},"wasm-duckdb/runtime.mjs":{sha256:`3e0a04fbc5f29ee62882881cbae124b24a555863584613c79ca4165d80df13b7`,bytes:205704,mediaType:`text/javascript`},"wasm-elixir/AtomVM.mjs":{sha256:`5562f7bca73575cc965d2e8f36bec19ba75b56fb85ff7277713af3ecfb08e409`,bytes:304708,mediaType:`text/javascript`,deliveryPath:`wasm-elixir/AtomVM.mjs.gz`},"wasm-elixir/AtomVM.mjs.gz":{sha256:`c68474b30b58043be0b70b729bb2dbbe56ff5594b58357f72dac669e11f49c60`,bytes:74151,encoding:`gzip`,mediaType:`text/javascript`,uncompressedSha256:`5562f7bca73575cc965d2e8f36bec19ba75b56fb85ff7277713af3ecfb08e409`,uncompressedBytes:304708},"wasm-elixir/AtomVM.wasm":{sha256:`55658601a27822079eaa8280e1082a7fda1f85436966e56636bb54fb3bcaf03c`,bytes:4234209,mediaType:`application/wasm`,deliveryPath:`wasm-elixir/AtomVM.wasm.gz`},"wasm-elixir/AtomVM.wasm.gz":{sha256:`c2bf951ccae72d562f920b24f1ba944c773a4395e311909dfeae6e127b9fd518`,bytes:1434358,encoding:`gzip`,mediaType:`application/wasm`,uncompressedSha256:`55658601a27822079eaa8280e1082a7fda1f85436966e56636bb54fb3bcaf03c`,uncompressedBytes:4234209},"wasm-elixir/bundle.avm":{sha256:`e848c7b1e0d73af284641afeb1dd5f235ace83a44a9d0a3d35a29c536042b21a`,bytes:7118212,mediaType:`application/octet-stream`,deliveryPath:`wasm-elixir/bundle.avm.gz`},"wasm-elixir/bundle.avm.gz":{sha256:`8780669718b86172236754b1f00aad38e96cbe8879bf3b5f9c29696043a17ad1`,bytes:3463541,encoding:`gzip`,mediaType:`application/octet-stream`,uncompressedSha256:`e848c7b1e0d73af284641afeb1dd5f235ace83a44a9d0a3d35a29c536042b21a`,uncompressedBytes:7118212},"wasm-elixir/runtime-build.json":{sha256:`39f57e2fa170cf54878db4722ea15a4108536833fd832d25202cf97191973405`,bytes:876,mediaType:`application/json`},"wasm-fennel/fennel-1.6.1.lua.gz":{sha256:`108b12fe2acb5c47c74c461d7ecbf5e00fb72102a9b927df985b9b4b858e49c0`,bytes:62385,encoding:`gzip`,mediaType:`application/octet-stream`,uncompressedSha256:`c3d45602041e7d8ef8a212563573df040c48a85c648a29fb4597ebed4bc38ec2`,uncompressedBytes:301522},"wasm-forth/runner-worker.js":{sha256:`8687b1564fe91c027ba258b18acdce370745c0ac2aec35c7d02cf0421460b145`,bytes:11027,mediaType:`text/javascript`},"wasm-forth/runtime-manifest.v2.json":{sha256:`1b8a12f15b6c2056b249c9b7680823ebaf7df4e86444e1efd5c0c70072c88c3c`,bytes:364,mediaType:`application/json`},"wasm-forth/waforth.js":{sha256:`254a973285f5c63b2be52db4a74090029075d8fe2cc52909d40e4c5f6d28eeb0`,bytes:33434,mediaType:`text/javascript`},"wasm-fortran/LICENSE-LFortran.txt":{sha256:`b692eb7625eb749213c5e2abb64e8ac6b02949848fc453200735f81bbdbeed1b`,bytes:20794,mediaType:`application/octet-stream`},"wasm-fortran/LICENSE-f2c.txt":{sha256:`44561c447e91203ddc747beeca5cc2794d95ee982c17c578670e4f0408bc3904`,bytes:1212,mediaType:`application/octet-stream`},"wasm-fortran/SOURCE.txt":{sha256:`e186b66e9da3fa19f102871e7e5ac73ff26226736381c960ccd418252a005790`,bytes:1453,mediaType:`application/octet-stream`},"wasm-fortran/analyzer-worker.js":{sha256:`e9fb38a3e4af9dceccd59d0c121da6f684c198a9a3370e2c8c9930bf02eac569`,bytes:2388,mediaType:`text/javascript`},"wasm-fortran/analyzer.js":{sha256:`882b090ef00ba807fae50a4320798a242cf0d57f4e8e45322764453d7c6c6d99`,bytes:1279,mediaType:`text/javascript`},"wasm-fortran/f2c.h":{sha256:`660cb39d8f39e360186b3343a554a20332a3ec9e0a1b6c4539d54aba8c2fc0ea`,bytes:4707,mediaType:`application/octet-stream`},"wasm-fortran/f2c.wasm":{sha256:`c424b41cd1d33ec41878fbb0c2fc2f2fb42aa1586b3e6097390d48125739929f`,bytes:636297,mediaType:`application/wasm`,deliveryPath:`wasm-fortran/f2c.wasm.gz`},"wasm-fortran/f2c.wasm.gz":{sha256:`488c151580a05ae655a374c89866edbddb73755d6bab52550cfd08e00495babd`,bytes:225632,encoding:`gzip`,mediaType:`application/wasm`,uncompressedSha256:`c424b41cd1d33ec41878fbb0c2fc2f2fb42aa1586b3e6097390d48125739929f`,uncompressedBytes:636297},"wasm-fortran/lfortran.data":{sha256:`e0ed1268df40ae501202c874d6905863a27268696aa8654e85e547bf41b4e6bf`,bytes:158146,mediaType:`application/octet-stream`},"wasm-fortran/lfortran.js":{sha256:`2dd933ff9ed2b32a2a2b9c380b00a5fd5e76669b2eaa6d8241e318a1df83edf7`,bytes:101177,mediaType:`text/javascript`},"wasm-fortran/lfortran.wasm":{sha256:`05951756b5784f3d18aaddcbb79b27000dcaea35facddd767a773179919f0508`,bytes:15249121,mediaType:`application/wasm`,deliveryPath:`wasm-fortran/lfortran.wasm.gz`},"wasm-fortran/lfortran.wasm.gz":{sha256:`fde8816c2057043a051f772168f3cbbf909148d5d063bcd6f183af984c536043`,bytes:2913454,encoding:`gzip`,mediaType:`application/wasm`,uncompressedSha256:`05951756b5784f3d18aaddcbb79b27000dcaea35facddd767a773179919f0508`,uncompressedBytes:15249121},"wasm-fortran/libf2c.a":{sha256:`06a036b00a77edce8a27f7cf2bf15538ff7ef5d88ba6d764e156d138c3bea225`,bytes:461120,mediaType:`application/octet-stream`,deliveryPath:`wasm-fortran/libf2c.a.gz`},"wasm-fortran/libf2c.a.gz":{sha256:`1f60676878156de269d82d7d45840f8cd03473a2090ec9343c495c1fc1a08bd3`,bytes:155956,encoding:`gzip`,mediaType:`application/octet-stream`,uncompressedSha256:`06a036b00a77edce8a27f7cf2bf15538ff7ef5d88ba6d764e156d138c3bea225`,uncompressedBytes:461120},"wasm-fortran/runtime-build.json":{sha256:`41b9c21d61d348719139ecdcf08af09c477b80d320cc80a448d86b6cfbd59cde`,bytes:525,mediaType:`application/json`},"wasm-gleam/compiler/gleam_wasm.js":{sha256:`e7534733174686371994aaf69a8c7cc0d9ba206419e075c50823f648b3f7980b`,bytes:14912,mediaType:`text/javascript`},"wasm-gleam/compiler/gleam_wasm_bg.wasm":{sha256:`6f2f5943a3874eb8188291cee8c779bb6a2b760626cd236b04f1359756aef8c1`,bytes:3471893,mediaType:`application/wasm`,deliveryPath:`wasm-gleam/compiler/gleam_wasm_bg.wasm.gz`},"wasm-gleam/compiler/gleam_wasm_bg.wasm.gz":{sha256:`9d1865c43c98b479f7bc192eaf6afc2b35a2f0a60a967bab00323dc1ca508e82`,bytes:1194728,encoding:`gzip`,mediaType:`application/wasm`,uncompressedSha256:`6f2f5943a3874eb8188291cee8c779bb6a2b760626cd236b04f1359756aef8c1`,uncompressedBytes:3471893},"wasm-gleam/javascript/dict.mjs":{sha256:`67435ecfe61bddcfe1c9040120952fae9b0dc950a2770bd3e4eeff4f607cf9d3`,bytes:23205,mediaType:`text/javascript`},"wasm-gleam/javascript/gleam.mjs":{sha256:`9c181aeb462fa80608297e3190111dde0c1ddaf75b77459c168528a21ef33c1e`,bytes:32,mediaType:`text/javascript`},"wasm-gleam/javascript/gleam/bit_array.mjs":{sha256:`7fceb51edadd0fe1ff886967a3ef1e78991270fd5a9c0e7911383e488bf8e562`,bytes:1725,mediaType:`text/javascript`},"wasm-gleam/javascript/gleam/bool.mjs":{sha256:`2509f32fea9ecb22fb1e00e0ac266373f1bf274c80c4a7fd67965cb0866c7249`,bytes:1723,mediaType:`text/javascript`},"wasm-gleam/javascript/gleam/bytes_builder.mjs":{sha256:`8a5de7c13e496522daddcc19637366875853267ff7248ce0867576a5e3c10f75`,bytes:3520,mediaType:`text/javascript`},"wasm-gleam/javascript/gleam/dict.mjs":{sha256:`74e147f8b6dca6603f2b5ac37ceed8794c7b87b04a0dea235d7f76ec238802aa`,bytes:6221,mediaType:`text/javascript`},"wasm-gleam/javascript/gleam/dynamic.mjs":{sha256:`e91e1b3b20edbf8ffd37cd19d98c4089e4b494a2c9a66d07c30eea0117d9b7b4`,bytes:20488,mediaType:`text/javascript`},"wasm-gleam/javascript/gleam/float.mjs":{sha256:`0b308be2eb933b15fc08541edcdfe79316d46d31d9a15f3e8bb8df82596ddec5`,bytes:3446,mediaType:`text/javascript`},"wasm-gleam/javascript/gleam/function.mjs":{sha256:`4626f4310aecf4a659c32b2982b28c867ec382e1765eedfabfe316de7034a3a5`,bytes:1322,mediaType:`text/javascript`},"wasm-gleam/javascript/gleam/int.mjs":{sha256:`1212cdc338b4a3f38a6d71737bd68ba68e987612d807db6a2043e3298c038f9d`,bytes:6223,mediaType:`text/javascript`},"wasm-gleam/javascript/gleam/io.mjs":{sha256:`86bee4d0a558196067be076d5cdca8a93bdc53486ccd87d1a2c8090aa5f9ec9f`,bytes:658,mediaType:`text/javascript`},"wasm-gleam/javascript/gleam/iterator.mjs":{sha256:`9d897115801660899a8a66e0df11e2392b8fe00ca1138fb7fcac324fdc4ac323`,bytes:21878,mediaType:`text/javascript`},"wasm-gleam/javascript/gleam/list.mjs":{sha256:`f7410a243a0a82de0cbfbac47b397d799ce0a5fbd0ae05ede63cdea300550de0`,bytes:40097,mediaType:`text/javascript`},"wasm-gleam/javascript/gleam/option.mjs":{sha256:`10fe1e22ead6142efb1089b18b1e71ffc570b08d3b31013f0c73422943c88c0a`,bytes:2720,mediaType:`text/javascript`},"wasm-gleam/javascript/gleam/order.mjs":{sha256:`4066f10d8fbf394b75d3bfe8501598ee18ef26bcdf7487724e5ab813a8ccae32`,bytes:1608,mediaType:`text/javascript`},"wasm-gleam/javascript/gleam/pair.mjs":{sha256:`4a9c4dcb44b4995adc8fb5a3b4fd35cae01369c7f17f9454f09305e771193a3f`,bytes:487,mediaType:`text/javascript`},"wasm-gleam/javascript/gleam/queue.mjs":{sha256:`6e588e189d8f56a6556b5fa284ff91fd2afc1edcb7a85b8fd68fdba64275bced`,bytes:3616,mediaType:`text/javascript`},"wasm-gleam/javascript/gleam/regex.mjs":{sha256:`10a4cacb5d8bb4d9989d299008f71d4c631a14715e99747c0d23e746f9b52096`,bytes:1175,mediaType:`text/javascript`},"wasm-gleam/javascript/gleam/result.mjs":{sha256:`e5fbc10a8963e0718b8af3dd989465250f5f4d76d8f17d44d7d9110d5916af06`,bytes:3444,mediaType:`text/javascript`},"wasm-gleam/javascript/gleam/set.mjs":{sha256:`e96229ab56d07220f78a4dbb40abf96fe0f49d740c35581a00e6a66d15ebbea2`,bytes:2370,mediaType:`text/javascript`},"wasm-gleam/javascript/gleam/string.mjs":{sha256:`93812bc67afa27ff82ea65b9912bb27f73c9a2b10785dfc25360a24edc888152`,bytes:7720,mediaType:`text/javascript`},"wasm-gleam/javascript/gleam/string_builder.mjs":{sha256:`8cde81eb69125b81644de4e5e2a982e34301680ed3798d5ff2baf4359ea1a205`,bytes:2051,mediaType:`text/javascript`},"wasm-gleam/javascript/gleam/uri.mjs":{sha256:`6a30e0d5c2e6a73a265e8f789d6f1038b6b2fa293e8b0e31554016ac7f797243`,bytes:12390,mediaType:`text/javascript`},"wasm-gleam/javascript/gleam_prelude.mjs":{sha256:`83a25385b27d02d9e4516a43e17e5c0ceca587ec94827bfdff1bd764b82e0e80`,bytes:7949,mediaType:`text/javascript`},"wasm-gleam/javascript/gleam_stdlib.mjs":{sha256:`8e048e1bb26b598abf4b7db14e062591a2c4880854d17381b5348c974f21229b`,bytes:21144,mediaType:`text/javascript`},"wasm-gleam/runner-worker.js":{sha256:`d41115d9299cc1e79b687b7ea4f6e82e8a13cffc7f0dfde8343a08c9826f1520`,bytes:21837,mediaType:`text/javascript`},"wasm-gleam/source-manifest.v2.json":{sha256:`d12d7d15826fe1de5189b0743c1769807500c19e6d8afae8bf9535fb225c3dec`,bytes:12219,mediaType:`application/json`},"wasm-gleam/src/dict.mjs":{sha256:`67435ecfe61bddcfe1c9040120952fae9b0dc950a2770bd3e4eeff4f607cf9d3`,bytes:23205,mediaType:`text/javascript`},"wasm-gleam/src/gleam/bit_array.gleam":{sha256:`15c3c643370ae43d0a6b1d7911750bc5fca805286e4817ed0f9fffce00dda3e7`,bytes:5680,mediaType:`application/octet-stream`},"wasm-gleam/src/gleam/bool.gleam":{sha256:`09379714087867004e2e1db57f119d568b710d457cc23639afe132fcd057dd51`,bytes:7082,mediaType:`application/octet-stream`},"wasm-gleam/src/gleam/bytes_builder.gleam":{sha256:`07c17bdfe67c2fdac75c7de3fa9453ea2cbe724e4d9fc238660782a623096c35`,bytes:5691,mediaType:`application/octet-stream`},"wasm-gleam/src/gleam/dict.gleam":{sha256:`66ac4b82b7814590b8c432b6b974b996bc0dfcb1f0e2df9f94499622d386e418`,bytes:13817,mediaType:`application/octet-stream`},"wasm-gleam/src/gleam/dynamic.gleam":{sha256:`9c5906382110d216d8b1ec8f7928419e70563dcdd16a65e1629c0cf4c45888d1`,bytes:37646,mediaType:`application/octet-stream`},"wasm-gleam/src/gleam/float.gleam":{sha256:`e1bfd4f316d5cfd6572cd2097f3c972a241825afb3fb16403b657adfc6522318`,bytes:10952,mediaType:`application/octet-stream`},"wasm-gleam/src/gleam/function.gleam":{sha256:`55f5a6343b13d24208551408a23cbfe0fd0c67b053007499ca389267c621e5fb`,bytes:4490,mediaType:`application/octet-stream`},"wasm-gleam/src/gleam/int.gleam":{sha256:`3d7e41b53583a5a0d2633d9cf5f586f92a3d45d9083f7e316462bc95546085b8`,bytes:17176,mediaType:`application/octet-stream`},"wasm-gleam/src/gleam/io.gleam":{sha256:`ad71598d61f8bd98f91776aca5c482f781320e448b9c9d9e99abe97f58cc7f7b`,bytes:2461,mediaType:`application/octet-stream`},"wasm-gleam/src/gleam/iterator.gleam":{sha256:`1432b6caa22351c71fa0179d0438ad0dbe4273d3c1759407fa3114a5045847ce`,bytes:37070,mediaType:`application/octet-stream`},"wasm-gleam/src/gleam/list.gleam":{sha256:`ffd71633fa1d6cbd03bc15c5d6fd3d9b66f043386e6c2cf5e7603155f23385ac`,bytes:52264,mediaType:`application/octet-stream`},"wasm-gleam/src/gleam/option.gleam":{sha256:`f5a4d999d04ae316fffeeea085d9fd1adeed44e3c5a2744972a414c86ab5cf5d`,bytes:7204,mediaType:`application/octet-stream`},"wasm-gleam/src/gleam/order.gleam":{sha256:`c72c1da6ff7b4e06cf157a0758ee6fe9e67b06088f462c249eb804424c41cffd`,bytes:3153,mediaType:`application/octet-stream`},"wasm-gleam/src/gleam/pair.gleam":{sha256:`3defaee82f71823b7a562b1ee7f03be372868e18d5e724d851fc52ffd01aadfe`,bytes:1467,mediaType:`application/octet-stream`},"wasm-gleam/src/gleam/queue.gleam":{sha256:`8fdc49a6a68096b6ea75aed2a98adf1b8344dc3fae6c988f32063a41e36bbbfc`,bytes:7113,mediaType:`application/octet-stream`},"wasm-gleam/src/gleam/regex.gleam":{sha256:`ea1ff9c5c9edd4e12a72cf5669a97a9540b08c4180d891979ac6dc48d4aa0352`,bytes:4965,mediaType:`application/octet-stream`},"wasm-gleam/src/gleam/result.gleam":{sha256:`9a00815d6529e97b9f833dad5d773e26eed427c889b15b6297231773821c6e0c`,bytes:9771,mediaType:`application/octet-stream`},"wasm-gleam/src/gleam/set.gleam":{sha256:`430bb63f84446739b045ee8f9849333786c36b6e6e3224507178afd1a03fc24c`,bytes:7575,mediaType:`application/octet-stream`},"wasm-gleam/src/gleam/string.gleam":{sha256:`a51748571a0284f8dc2430177b0a808fba72afdb4b21e572c140d6f5d531fe99`,bytes:21133,mediaType:`application/octet-stream`},"wasm-gleam/src/gleam/string_builder.gleam":{sha256:`22eabab1b23c79c520193c14f8a2f6301aae330e3b9dde579a764a2bfe7d77cf`,bytes:7326,mediaType:`application/octet-stream`},"wasm-gleam/src/gleam/uri.gleam":{sha256:`ac286b26f3db33a0b4c3dfe219a26b5c053deb68567d76a3274e57aa0ccc3536`,bytes:12300,mediaType:`application/octet-stream`},"wasm-gleam/src/gleam_stdlib.mjs":{sha256:`8e048e1bb26b598abf4b7db14e062591a2c4880854d17381b5348c974f21229b`,bytes:21144,mediaType:`text/javascript`},"wasm-go/asset-url.js":{sha256:`467dab13423ed13a46bdea3bc4745fb95a93f6c986c12bc1e7277afe121f53ea`,bytes:304,mediaType:`text/javascript`},"wasm-go/browser-execution.js":{sha256:`28b336fa3d7fdb433ad6c5ef8927bfed518c1466a1333769f700dc33a9f5a347`,bytes:14491,mediaType:`text/javascript`},"wasm-go/build-planner.js":{sha256:`9968d69a75718914a45c6546cdd22b4b80440cd0f86895eb97a24e02e43d9309`,bytes:10263,mediaType:`text/javascript`},"wasm-go/compiler-support.js":{sha256:`62f37fb55e716a50e20e4bdbc61765de0486c34d4a68e8f0773b231b79f05251`,bytes:5302,mediaType:`text/javascript`},"wasm-go/compiler.js":{sha256:`5afb92116f071c71015a9a26d3c368e4388be04e8583a2780e8ebb66a454ac4f`,bytes:27349,mediaType:`text/javascript`},"wasm-go/index.js":{sha256:`a30e8a484b737a08e1710d7d9b0630603bbe55c4d7515e21118533c902ea54f6`,bytes:1106,mediaType:`text/javascript`},"wasm-go/runtime-asset.js":{sha256:`6a359674ec569c7aad8b831b3591f536e80fa953f64afe61056fa49e980124af`,bytes:29609,mediaType:`text/javascript`},"wasm-go/runtime-manifest.js":{sha256:`3e987299031f74d5f7ed7de54a5daadb05604fdfff047064e8c7f2001cd043d8`,bytes:14237,mediaType:`text/javascript`},"wasm-go/runtime/runtime-build.json":{sha256:`00226711d99209057a1519d7ffe1dddc1fb6a656f31c7bc0763235a6b3dd84d4`,bytes:11890,mediaType:`application/json`},"wasm-go/runtime/runtime-manifest.v1.json":{sha256:`63f3cf89895207371ed310039721b65cb8227be284ed6d9a2556fb174b7d432b`,bytes:103726,mediaType:`application/json`},"wasm-go/runtime/runtime/wasm_exec.js":{sha256:`0c949f4996f9a89698e4b5c586de32249c3b69b7baadb64d220073cc04acba14`,bytes:16992,mediaType:`text/javascript`},"wasm-go/runtime/sysroot/chunks/js-00.index.json":{sha256:`327e24e3370fc1a0debec666940aa0c6357f5c64a2d6202bafc49aa0ab325d54`,bytes:5637,mediaType:`application/json`,deliveryPath:`wasm-go/runtime/sysroot/chunks/js-00.index.json.gz`},"wasm-go/runtime/sysroot/chunks/js-00.index.json.gz":{sha256:`d78e0183d43e743182976522b4bf6f24701cfaca684474cbdfe731fe76bd28b1`,bytes:814,encoding:`gzip`,mediaType:`application/json`,uncompressedSha256:`327e24e3370fc1a0debec666940aa0c6357f5c64a2d6202bafc49aa0ab325d54`,uncompressedBytes:5637},"wasm-go/runtime/sysroot/chunks/js-00.pack.gz":{sha256:`4ef51d4ad704e80aa4f15bfd4c0788a7cfdf670864638d8627d98e45d5c686b4`,bytes:849461,encoding:`gzip`,mediaType:`application/octet-stream`,uncompressedSha256:`53b88c646fdc5716bafba536f1814b8e07046487b27a8d40caad220415ebd46a`,uncompressedBytes:3199537},"wasm-go/runtime/sysroot/chunks/js-01.index.json":{sha256:`38996ea889290fc83349215d371ff4140d774b2c84857d3320d77b0c0c25c4e4`,bytes:6425,mediaType:`application/json`,deliveryPath:`wasm-go/runtime/sysroot/chunks/js-01.index.json.gz`},"wasm-go/runtime/sysroot/chunks/js-01.index.json.gz":{sha256:`075d61498a5a43cf0a1a250b75cd84692367f644ebd33e6181bd93d042b403df`,bytes:1016,encoding:`gzip`,mediaType:`application/json`,uncompressedSha256:`38996ea889290fc83349215d371ff4140d774b2c84857d3320d77b0c0c25c4e4`,uncompressedBytes:6425},"wasm-go/runtime/sysroot/chunks/js-01.pack.gz":{sha256:`52e470a7287abcd3bdc82e3127862cec484ad5d2faf1f6306ba1f02c645990f1`,bytes:485807,encoding:`gzip`,mediaType:`application/octet-stream`,uncompressedSha256:`8a4536f19d4d2ecb0a6d77f4c5ec3a8ca567c383c352bbab7a2273e3e12f2406`,uncompressedBytes:1441234},"wasm-go/runtime/sysroot/chunks/js-02.index.json":{sha256:`7b7a3eef861a6eaaa861c33d1f6b1e579a980ed1b897dab06b09c02ba6cf3134`,bytes:6821,mediaType:`application/json`,deliveryPath:`wasm-go/runtime/sysroot/chunks/js-02.index.json.gz`},"wasm-go/runtime/sysroot/chunks/js-02.index.json.gz":{sha256:`92f6a8c05a4ba63a038e0a641e0cc165978d8903a38bf62a7dd2ef08bb8005e6`,bytes:1026,encoding:`gzip`,mediaType:`application/json`,uncompressedSha256:`7b7a3eef861a6eaaa861c33d1f6b1e579a980ed1b897dab06b09c02ba6cf3134`,uncompressedBytes:6821},"wasm-go/runtime/sysroot/chunks/js-02.pack.gz":{sha256:`6982928d733c507ae9b2893b11f6e69f7758c87510d630aa5947948e9b270b23`,bytes:154896,encoding:`gzip`,mediaType:`application/octet-stream`,uncompressedSha256:`491960e9ca0d4fc315058b7c539f6af239b644c499f357f664ad322455031bb3`,uncompressedBytes:288768},"wasm-go/runtime/sysroot/chunks/js-03.index.json":{sha256:`952ea8f77851e80d13a079fb710b990baa218704cde8b6368758da20e7b06d85`,bytes:11125,mediaType:`application/json`,deliveryPath:`wasm-go/runtime/sysroot/chunks/js-03.index.json.gz`},"wasm-go/runtime/sysroot/chunks/js-03.index.json.gz":{sha256:`05bceb93a15e3285caaef26e8550b55df2171d42a974f3f90246e9ac08f72dab`,bytes:1360,encoding:`gzip`,mediaType:`application/json`,uncompressedSha256:`952ea8f77851e80d13a079fb710b990baa218704cde8b6368758da20e7b06d85`,uncompressedBytes:11125},"wasm-go/runtime/sysroot/chunks/js-03.pack.gz":{sha256:`9a40a7a281baf626165f2ca43275d1adeac00ed0a38d6d812c07777a1bd74a69`,bytes:146495,encoding:`gzip`,mediaType:`application/octet-stream`,uncompressedSha256:`f16d2facef80823c07a3479d7b286251468e6a866b21c9c6961fbae1320a1e9f`,uncompressedBytes:290524},"wasm-go/runtime/sysroot/chunks/js-04.index.json":{sha256:`1735a192963616c9f3598ee560fd1786b61ca642eddde22f142dee2c12f32173`,bytes:1531,mediaType:`application/json`,deliveryPath:`wasm-go/runtime/sysroot/chunks/js-04.index.json.gz`},"wasm-go/runtime/sysroot/chunks/js-04.index.json.gz":{sha256:`bfcd3ea819a44ebeac527bdc68adf21bd6ddc13af52b19c32db68b88c68be9ef`,bytes:402,encoding:`gzip`,mediaType:`application/json`,uncompressedSha256:`1735a192963616c9f3598ee560fd1786b61ca642eddde22f142dee2c12f32173`,uncompressedBytes:1531},"wasm-go/runtime/sysroot/chunks/js-04.pack.gz":{sha256:`cbf9a238ef2d5c02059850898c086b443779b401e0ee2127c6b8adf039402e6b`,bytes:124602,encoding:`gzip`,mediaType:`application/octet-stream`,uncompressedSha256:`1f43ea1bf8ad33b5a82a99679b197f7da6f468cab741bddb79c709e0134c6738`,uncompressedBytes:222547},"wasm-go/runtime/sysroot/chunks/js-05.index.json":{sha256:`71c56a882f7d56d170a29b266f3eda5dd99c678386c04b300f7b36e00f2124b0`,bytes:3157,mediaType:`application/json`,deliveryPath:`wasm-go/runtime/sysroot/chunks/js-05.index.json.gz`},"wasm-go/runtime/sysroot/chunks/js-05.index.json.gz":{sha256:`162306c846b0b26f1da22e241b0476643d551fbd52ecf241a86246e6072ff3ae`,bytes:584,encoding:`gzip`,mediaType:`application/json`,uncompressedSha256:`71c56a882f7d56d170a29b266f3eda5dd99c678386c04b300f7b36e00f2124b0`,uncompressedBytes:3157},"wasm-go/runtime/sysroot/chunks/js-05.pack.gz":{sha256:`a0ac00a3e3d0fb7b3a521f9abcc5ca2d61cd7905bf678559a5f1aac5665ae6b6`,bytes:125237,encoding:`gzip`,mediaType:`application/octet-stream`,uncompressedSha256:`3a320fd442e84e8503887aaf14afa63657d71b888a6df1f4b07579e42e1e014e`,uncompressedBytes:208172},"wasm-go/runtime/sysroot/chunks/js-06.index.json":{sha256:`d333598be2c2a17acb5cc2ee0eb815f9532ab5fa025bc8fdb2049211bd38305b`,bytes:1994,mediaType:`application/json`,deliveryPath:`wasm-go/runtime/sysroot/chunks/js-06.index.json.gz`},"wasm-go/runtime/sysroot/chunks/js-06.index.json.gz":{sha256:`4e9efdcaaaf8b0a295c85d1cff83ba3aa8e00dece03be1ddfafcd81b7ebea7d7`,bytes:457,encoding:`gzip`,mediaType:`application/json`,uncompressedSha256:`d333598be2c2a17acb5cc2ee0eb815f9532ab5fa025bc8fdb2049211bd38305b`,uncompressedBytes:1994},"wasm-go/runtime/sysroot/chunks/js-06.pack.gz":{sha256:`b6ebdafff9ecbacf697ded15a4d5285a24ca70678197d3efe53ac7639549104b`,bytes:166804,encoding:`gzip`,mediaType:`application/octet-stream`,uncompressedSha256:`86c686f071da43147ba81b973d5ba59bcf38958ad9b3c7a333fad1eeaeae8af6`,uncompressedBytes:293600},"wasm-go/runtime/sysroot/chunks/js-07.index.json":{sha256:`42736b955636fb89db81a9c129e56bd8839846d06573d17b3a7e55fc124e2ea2`,bytes:2283,mediaType:`application/json`,deliveryPath:`wasm-go/runtime/sysroot/chunks/js-07.index.json.gz`},"wasm-go/runtime/sysroot/chunks/js-07.index.json.gz":{sha256:`0f4ce39b82b6e661c0bd83f78c8c486438e1212ae8e0bce38052cf4616cb61a5`,bytes:476,encoding:`gzip`,mediaType:`application/json`,uncompressedSha256:`42736b955636fb89db81a9c129e56bd8839846d06573d17b3a7e55fc124e2ea2`,uncompressedBytes:2283},"wasm-go/runtime/sysroot/chunks/js-07.pack.gz":{sha256:`894b82562458fc7062ab49672ad3da9743841b7c86604946614f4b2f238e1ced`,bytes:91783,encoding:`gzip`,mediaType:`application/octet-stream`,uncompressedSha256:`1a9044df903c66054a0ae28366b9c6485ee891e0159637e122830dc8405eaa87`,uncompressedBytes:154572},"wasm-go/runtime/sysroot/chunks/js-08.index.json":{sha256:`2d4b86b7d22e892d132bbd2d96d547120b25f5b1b12f80d83063e1857a851b59`,bytes:2722,mediaType:`application/json`,deliveryPath:`wasm-go/runtime/sysroot/chunks/js-08.index.json.gz`},"wasm-go/runtime/sysroot/chunks/js-08.index.json.gz":{sha256:`f7cf14e38e24d9eb483844beae9cf08580338c6e2de7716ead6d79b7244f6249`,bytes:531,encoding:`gzip`,mediaType:`application/json`,uncompressedSha256:`2d4b86b7d22e892d132bbd2d96d547120b25f5b1b12f80d83063e1857a851b59`,uncompressedBytes:2722},"wasm-go/runtime/sysroot/chunks/js-08.pack.gz":{sha256:`ea8bc8b1500355af8136cd7f8cd9d77f711db83291ed391bab6087cc1b0f6c30`,bytes:114916,encoding:`gzip`,mediaType:`application/octet-stream`,uncompressedSha256:`67805ab69e294e7db6dacb5e9140af4be549881df53e91c36741b59509ec935f`,uncompressedBytes:185633},"wasm-go/runtime/sysroot/chunks/js-09.index.json":{sha256:`34f46edb3503157e4a8c31b3702043727e4c2b1749f5933a5cd2dbdb2c5f0d71`,bytes:8507,mediaType:`application/json`,deliveryPath:`wasm-go/runtime/sysroot/chunks/js-09.index.json.gz`},"wasm-go/runtime/sysroot/chunks/js-09.index.json.gz":{sha256:`6dcd48c45ffd445bcba6b2bc18100fe0e160e87fdb73eefa54aa96f9208c9b95`,bytes:1192,encoding:`gzip`,mediaType:`application/json`,uncompressedSha256:`34f46edb3503157e4a8c31b3702043727e4c2b1749f5933a5cd2dbdb2c5f0d71`,uncompressedBytes:8507},"wasm-go/runtime/sysroot/chunks/js-09.pack.gz":{sha256:`b8b8655904f6aa989f71699e75171951dc69c2d1f4b535acad3fb0f9449675ef`,bytes:187096,encoding:`gzip`,mediaType:`application/octet-stream`,uncompressedSha256:`a5c2d5defd3eb6f643ff32d9dcf5ee57eae4ee65733e0b86c58237a24472d5b7`,uncompressedBytes:355339},"wasm-go/runtime/sysroot/chunks/js-10.index.json":{sha256:`7e60a34fd23886168879b6a30eb2f7069bafdaee6bd0cb1fce1eaaf10f0330a7`,bytes:3052,mediaType:`application/json`,deliveryPath:`wasm-go/runtime/sysroot/chunks/js-10.index.json.gz`},"wasm-go/runtime/sysroot/chunks/js-10.index.json.gz":{sha256:`ffac413eed772e357db970af76942da48a99f203ce2b016de711dab6c9362f0c`,bytes:562,encoding:`gzip`,mediaType:`application/json`,uncompressedSha256:`7e60a34fd23886168879b6a30eb2f7069bafdaee6bd0cb1fce1eaaf10f0330a7`,uncompressedBytes:3052},"wasm-go/runtime/sysroot/chunks/js-10.pack.gz":{sha256:`561baa7552283900ada6cc8b9b169ee0c0497c386a04bb69f79c89bbcd35a502`,bytes:214268,encoding:`gzip`,mediaType:`application/octet-stream`,uncompressedSha256:`b58fa4fc6237f809ec9e2b5d038c53e01a44a7f81c9b8a6d02e3efc1bdf0aee4`,uncompressedBytes:441853},"wasm-go/runtime/sysroot/chunks/js-11.index.json":{sha256:`f62a75d7241fb141f69dc0c340251d658671137fba209dbcce4f571df2ed29ae`,bytes:3557,mediaType:`application/json`,deliveryPath:`wasm-go/runtime/sysroot/chunks/js-11.index.json.gz`},"wasm-go/runtime/sysroot/chunks/js-11.index.json.gz":{sha256:`5aed1ec9606816fa8442d83296f51ac7dbc90720526c432a5141fda6e22c0d7f`,bytes:657,encoding:`gzip`,mediaType:`application/json`,uncompressedSha256:`f62a75d7241fb141f69dc0c340251d658671137fba209dbcce4f571df2ed29ae`,uncompressedBytes:3557},"wasm-go/runtime/sysroot/chunks/js-11.pack.gz":{sha256:`c534a917fd366e82063646ceac5c307e82b7a069fa06b2232f12d367abebf5a4`,bytes:85805,encoding:`gzip`,mediaType:`application/octet-stream`,uncompressedSha256:`ae89aad8c3a3970e820aecf4cfa8e492c76fb063bf993454135a3a7ca9247c7a`,uncompressedBytes:160604},"wasm-go/runtime/sysroot/chunks/js-12.index.json":{sha256:`2c0b70ed1cd881b94c14894deca8c7730ae35df0b2b15e721b6893f2e8bfc777`,bytes:318,mediaType:`application/json`,deliveryPath:`wasm-go/runtime/sysroot/chunks/js-12.index.json.gz`},"wasm-go/runtime/sysroot/chunks/js-12.index.json.gz":{sha256:`b227fc9bf8d01cb945bb1b4ddd8ecfcc58b99d0eab6f6b799f274fa271f35d57`,bytes:199,encoding:`gzip`,mediaType:`application/json`,uncompressedSha256:`2c0b70ed1cd881b94c14894deca8c7730ae35df0b2b15e721b6893f2e8bfc777`,uncompressedBytes:318},"wasm-go/runtime/sysroot/chunks/js-12.pack.gz":{sha256:`edaeeb5664a3b7a1c95e61c3a9152506d8e9394801b71ddbab142d9352165534`,bytes:313330,encoding:`gzip`,mediaType:`application/octet-stream`,uncompressedSha256:`5ba21133aca1afb3eab9b79aeb8026efff5f2b526139c1c1ea3f4efa41c5b37a`,uncompressedBytes:1106552},"wasm-go/runtime/sysroot/chunks/js-13.index.json":{sha256:`575a7b0cb641415fecdbaf2dc3a90cd8fcf0dc6cbfff3f8c500ce71b3cb5e401`,bytes:722,mediaType:`application/json`,deliveryPath:`wasm-go/runtime/sysroot/chunks/js-13.index.json.gz`},"wasm-go/runtime/sysroot/chunks/js-13.index.json.gz":{sha256:`7481ac9e344f1ddaff5169bf006a489b5f1769ad35b39402e54cdd7f642717cc`,bytes:278,encoding:`gzip`,mediaType:`application/json`,uncompressedSha256:`575a7b0cb641415fecdbaf2dc3a90cd8fcf0dc6cbfff3f8c500ce71b3cb5e401`,uncompressedBytes:722},"wasm-go/runtime/sysroot/chunks/js-13.pack.gz":{sha256:`4232f4365aad645f03ced3c1673d68a730ca872eebfc82497e8494786b9bb3bd`,bytes:626203,encoding:`gzip`,mediaType:`application/octet-stream`,uncompressedSha256:`c9a60aeab32155c204b5d23a06b58456dd952b53da5ca5c73fe015cc73ed14b5`,uncompressedBytes:2141226},"wasm-go/runtime/sysroot/chunks/js-14.index.json":{sha256:`b2c64481100c4c22486971ab12ec168a0b23eaa7908afdfe4874dfad9d507684`,bytes:5202,mediaType:`application/json`,deliveryPath:`wasm-go/runtime/sysroot/chunks/js-14.index.json.gz`},"wasm-go/runtime/sysroot/chunks/js-14.index.json.gz":{sha256:`aa0bc1bae890503cff682eed4c89b2777fc5a07f547301f884fb4e1378dfcf73`,bytes:860,encoding:`gzip`,mediaType:`application/json`,uncompressedSha256:`b2c64481100c4c22486971ab12ec168a0b23eaa7908afdfe4874dfad9d507684`,uncompressedBytes:5202},"wasm-go/runtime/sysroot/chunks/js-14.pack.gz":{sha256:`0d8d1920c7e0573a7669c8ac47d2fdd8c875e88bfa89abc1e4c4d958518dbb3e`,bytes:322297,encoding:`gzip`,mediaType:`application/octet-stream`,uncompressedSha256:`a944562a6a54fc6159cb96d8f49ee49431dd4d37df3ae8babc5ce7cfae852401`,uncompressedBytes:606327},"wasm-go/runtime/sysroot/chunks/js-15.index.json":{sha256:`67f3c7999628798d025abf7f79f1692f8c10e53d20b149b95da3722cc2f2adf7`,bytes:3793,mediaType:`application/json`,deliveryPath:`wasm-go/runtime/sysroot/chunks/js-15.index.json.gz`},"wasm-go/runtime/sysroot/chunks/js-15.index.json.gz":{sha256:`9cc4cd40ef28e788f442d3a8717ec5b8afa7ec67ac3735107d5cdd3a7e6dc558`,bytes:686,encoding:`gzip`,mediaType:`application/json`,uncompressedSha256:`67f3c7999628798d025abf7f79f1692f8c10e53d20b149b95da3722cc2f2adf7`,uncompressedBytes:3793},"wasm-go/runtime/sysroot/chunks/js-15.pack.gz":{sha256:`266fc4bc6906dd88c74901f6ccdd61f3d6d7a15c5e527506f1036b4c90024b45`,bytes:171292,encoding:`gzip`,mediaType:`application/octet-stream`,uncompressedSha256:`5f5a813a652c94fba884f7eece06ae03f3d84ebb3257a14aef9766822a994448`,uncompressedBytes:306499},"wasm-go/runtime/sysroot/chunks/js-16.index.json":{sha256:`d56658571c46d4ec5671d962dcd28adc6ca4a17c35b6ce2b118ec0e946a14095`,bytes:5109,mediaType:`application/json`,deliveryPath:`wasm-go/runtime/sysroot/chunks/js-16.index.json.gz`},"wasm-go/runtime/sysroot/chunks/js-16.index.json.gz":{sha256:`f7d688f2752a8fadab493cafa0147b9efed71bd1030d61a142a5ecb8e1ee3fd5`,bytes:809,encoding:`gzip`,mediaType:`application/json`,uncompressedSha256:`d56658571c46d4ec5671d962dcd28adc6ca4a17c35b6ce2b118ec0e946a14095`,uncompressedBytes:5109},"wasm-go/runtime/sysroot/chunks/js-16.pack.gz":{sha256:`fb9bab46e278a81e4fb9cb9a0bce166e9508da3d4db27b430a8ddf41af38d529`,bytes:102119,encoding:`gzip`,mediaType:`application/octet-stream`,uncompressedSha256:`1ccd8b9b0d9a236357351c128db38419c55916c20088e336670b500bc9308d7a`,uncompressedBytes:179014},"wasm-go/runtime/sysroot/chunks/js-17.index.json":{sha256:`dbb0a46ab8280978e619c3c6f2d169811f31afa540179c468c0aa2149f0a4144`,bytes:278,mediaType:`application/json`,deliveryPath:`wasm-go/runtime/sysroot/chunks/js-17.index.json.gz`},"wasm-go/runtime/sysroot/chunks/js-17.index.json.gz":{sha256:`45a3b094ce299d981f1fdca0e8d3562e91a3553b214dcc2ef2d64f941266be32`,bytes:190,encoding:`gzip`,mediaType:`application/json`,uncompressedSha256:`dbb0a46ab8280978e619c3c6f2d169811f31afa540179c468c0aa2149f0a4144`,uncompressedBytes:278},"wasm-go/runtime/sysroot/chunks/js-17.pack.gz":{sha256:`8e4a2133c816ae48623aa4f791e4a483f2d529b02a852f44b66c52b4a42db31b`,bytes:74123,encoding:`gzip`,mediaType:`application/octet-stream`,uncompressedSha256:`87025be8e39d00dbbf609241a8023b62626f489df2508b242aa5ff564c22a0e0`,uncompressedBytes:375159},"wasm-go/runtime/sysroot/chunks/wasip1-00.index.json":{sha256:`2d24465d5a508603c3494c93105162149d8d4b47b43a30261dc987beb34d2dfd`,bytes:3277,mediaType:`application/json`,deliveryPath:`wasm-go/runtime/sysroot/chunks/wasip1-00.index.json.gz`},"wasm-go/runtime/sysroot/chunks/wasip1-00.index.json.gz":{sha256:`9fa82596a4c9ede443242385f199a0b01a8d319549e4d873658031a694f66c02`,bytes:617,encoding:`gzip`,mediaType:`application/json`,uncompressedSha256:`2d24465d5a508603c3494c93105162149d8d4b47b43a30261dc987beb34d2dfd`,uncompressedBytes:3277},"wasm-go/runtime/sysroot/chunks/wasip1-00.pack.gz":{sha256:`edfe6aca40f6bbd20aab58673768ef54db8a09cfa4890096e3c809a616dd8f31`,bytes:2567401,encoding:`gzip`,mediaType:`application/octet-stream`,uncompressedSha256:`5efeec916412a90b74279dab1e8d8321bc48e4e85d582ae6ad606746a4d226d4`,uncompressedBytes:11755796},"wasm-go/runtime/sysroot/chunks/wasip1-01.index.json":{sha256:`8aaac4c5b4e481f8f26134d05b8f030d8fe530570b339498f03edc24a1abcf04`,bytes:3733,mediaType:`application/json`,deliveryPath:`wasm-go/runtime/sysroot/chunks/wasip1-01.index.json.gz`},"wasm-go/runtime/sysroot/chunks/wasip1-01.index.json.gz":{sha256:`ba3146d45bfb18f150144ff14d1b4d7abf3cd01ae944d8526d4020f49d674ce9`,bytes:700,encoding:`gzip`,mediaType:`application/json`,uncompressedSha256:`8aaac4c5b4e481f8f26134d05b8f030d8fe530570b339498f03edc24a1abcf04`,uncompressedBytes:3733},"wasm-go/runtime/sysroot/chunks/wasip1-01.pack.gz":{sha256:`d86266b1938db41b612044cd0f16bed3289bb40fd2d439890f007a86c3c888c4`,bytes:2798542,encoding:`gzip`,mediaType:`application/octet-stream`,uncompressedSha256:`9a9a974ac5f96c12a0a214df10c525abd82ce38e5bfe44df873b6a8a0cd05108`,uncompressedBytes:12153088},"wasm-go/runtime/sysroot/chunks/wasip1-02.index.json":{sha256:`172b9554308d5fab86da95e9a4aa4b3e303ac1cda13ceaf9ac856ccf5e44a63a`,bytes:3927,mediaType:`application/json`,deliveryPath:`wasm-go/runtime/sysroot/chunks/wasip1-02.index.json.gz`},"wasm-go/runtime/sysroot/chunks/wasip1-02.index.json.gz":{sha256:`10477b1f279fbece6a988d5ef5d3749610dac568975aa74328d7afcd50b1f71e`,bytes:715,encoding:`gzip`,mediaType:`application/json`,uncompressedSha256:`172b9554308d5fab86da95e9a4aa4b3e303ac1cda13ceaf9ac856ccf5e44a63a`,uncompressedBytes:3927},"wasm-go/runtime/sysroot/chunks/wasip1-02.pack.gz":{sha256:`555a4b1820a5f00128f6eb823287c2742a05a9adedb603058d71903a1743f814`,bytes:1875429,encoding:`gzip`,mediaType:`application/octet-stream`,uncompressedSha256:`de185584c26d0f39a81806b917643c5ed9db8fb655e0f3c09915508f5c7d95d6`,uncompressedBytes:8382162},"wasm-go/runtime/sysroot/chunks/wasip1-03.index.json":{sha256:`f92f88f9377fd3913389b3e78fe7e71af2e561e2dad75a691474f9af20108639`,bytes:6317,mediaType:`application/json`,deliveryPath:`wasm-go/runtime/sysroot/chunks/wasip1-03.index.json.gz`},"wasm-go/runtime/sysroot/chunks/wasip1-03.index.json.gz":{sha256:`fd00ac6d8bf897b34b15ad57cdecb2db772b77d742cd16e57ebe6417c92467e5`,bytes:933,encoding:`gzip`,mediaType:`application/json`,uncompressedSha256:`f92f88f9377fd3913389b3e78fe7e71af2e561e2dad75a691474f9af20108639`,uncompressedBytes:6317},"wasm-go/runtime/sysroot/chunks/wasip1-03.pack.gz":{sha256:`6d19912b525f69809932449fb9e0d313ef581a5612cc208712a04fe9b9ef2e31`,bytes:1591715,encoding:`gzip`,mediaType:`application/octet-stream`,uncompressedSha256:`da9bb920398f269b34ebf2752d64323ec405c9bd66dc579f770de359f6dd9861`,uncompressedBytes:5719484},"wasm-go/runtime/sysroot/chunks/wasip1-04.index.json":{sha256:`162ebd0ccc8314c4788083636337908a0b3391d6d0b63c1cef96ff518779577d`,bytes:898,mediaType:`application/json`,deliveryPath:`wasm-go/runtime/sysroot/chunks/wasip1-04.index.json.gz`},"wasm-go/runtime/sysroot/chunks/wasip1-04.index.json.gz":{sha256:`4b5620915ec56dce557a485800ad50a626a0cac08528ae6285fa34e9fbf52e33`,bytes:301,encoding:`gzip`,mediaType:`application/json`,uncompressedSha256:`162ebd0ccc8314c4788083636337908a0b3391d6d0b63c1cef96ff518779577d`,uncompressedBytes:898},"wasm-go/runtime/sysroot/chunks/wasip1-04.pack.gz":{sha256:`f5292f87db00ed37accb5c74de8c80dbfa8590191e5778ce98aa46c672352185`,bytes:1804581,encoding:`gzip`,mediaType:`application/octet-stream`,uncompressedSha256:`0612f1eca4d0e593561c60cf81b25fe2b284a3fe72550a176f533af3f36a8201`,uncompressedBytes:7910952},"wasm-go/runtime/sysroot/chunks/wasip1-05.index.json":{sha256:`eaac24b47d8eed9e0917ddb2f15a839f64d63d3279442e4e3b4777d647e4ae25`,bytes:1842,mediaType:`application/json`,deliveryPath:`wasm-go/runtime/sysroot/chunks/wasip1-05.index.json.gz`},"wasm-go/runtime/sysroot/chunks/wasip1-05.index.json.gz":{sha256:`0831c9313fa500e9a31089c9ef53bf4921f75b015ad0737fc6c7dbfa0a811f9f`,bytes:421,encoding:`gzip`,mediaType:`application/json`,uncompressedSha256:`eaac24b47d8eed9e0917ddb2f15a839f64d63d3279442e4e3b4777d647e4ae25`,uncompressedBytes:1842},"wasm-go/runtime/sysroot/chunks/wasip1-05.pack.gz":{sha256:`e64f27b54fac4f67e62aea97ed45d7e483242dc9a3b523839d6ac7183a7ab4e4`,bytes:1662125,encoding:`gzip`,mediaType:`application/octet-stream`,uncompressedSha256:`1265354740b3cf8dc3faf278c8516f230a3ab925ecab4d725c376c6a25aa0e60`,uncompressedBytes:7529064},"wasm-go/runtime/sysroot/chunks/wasip1-06.index.json":{sha256:`be2de4f1d8ca39a297c6bb02f09dc904fd577573db7898fe3224379802bb0bb0`,bytes:1175,mediaType:`application/json`,deliveryPath:`wasm-go/runtime/sysroot/chunks/wasip1-06.index.json.gz`},"wasm-go/runtime/sysroot/chunks/wasip1-06.index.json.gz":{sha256:`236fa5d7204995bab74f5a07a0de6e64027f0a5fe5465cc879770511dd3b775a`,bytes:335,encoding:`gzip`,mediaType:`application/json`,uncompressedSha256:`be2de4f1d8ca39a297c6bb02f09dc904fd577573db7898fe3224379802bb0bb0`,uncompressedBytes:1175},"wasm-go/runtime/sysroot/chunks/wasip1-06.pack.gz":{sha256:`26abd7567e712e3c22809ae69c831b558ddee7c252e7b2b288e810a17d0b9b0c`,bytes:1834136,encoding:`gzip`,mediaType:`application/octet-stream`,uncompressedSha256:`ce8bdc80c8f79ca62f666f74138d1a2699cf39c5d2cd2f6ff68e68bdac336002`,uncompressedBytes:7938254},"wasm-go/runtime/sysroot/chunks/wasip1-07.index.json":{sha256:`b9b8536d81863e5eeeae83312c74b16bae93dd4d92777d682b502b8b344f6cb0`,bytes:1330,mediaType:`application/json`,deliveryPath:`wasm-go/runtime/sysroot/chunks/wasip1-07.index.json.gz`},"wasm-go/runtime/sysroot/chunks/wasip1-07.index.json.gz":{sha256:`758334a1441432892506a871c60772c870e0f4959ec988d8d4514aab199eae3d`,bytes:352,encoding:`gzip`,mediaType:`application/json`,uncompressedSha256:`b9b8536d81863e5eeeae83312c74b16bae93dd4d92777d682b502b8b344f6cb0`,uncompressedBytes:1330},"wasm-go/runtime/sysroot/chunks/wasip1-07.pack.gz":{sha256:`f26dc3bcba009be2852d8d885978ff697ce3680a0bf1667b5ba03c03072fa474`,bytes:1090654,encoding:`gzip`,mediaType:`application/octet-stream`,uncompressedSha256:`cbe123fed1d6d406442ffacec819b6ba8f2ffb7d17e5a43961d33f5d211270cf`,uncompressedBytes:4256866},"wasm-go/runtime/sysroot/chunks/wasip1-08.index.json":{sha256:`a53642494a3c7d8a5a7e748e3998d558f96daecfe73f886c30c1be5939f3c2c9`,bytes:1594,mediaType:`application/json`,deliveryPath:`wasm-go/runtime/sysroot/chunks/wasip1-08.index.json.gz`},"wasm-go/runtime/sysroot/chunks/wasip1-08.index.json.gz":{sha256:`b514b956c995987eeed0aab1a3e5299a8eee40c8003c700d531a69902c2fcb70`,bytes:392,encoding:`gzip`,mediaType:`application/json`,uncompressedSha256:`a53642494a3c7d8a5a7e748e3998d558f96daecfe73f886c30c1be5939f3c2c9`,uncompressedBytes:1594},"wasm-go/runtime/sysroot/chunks/wasip1-08.pack.gz":{sha256:`3809830460e07e8b5bf0c3de239e7026cd17f7660525091ee68cd7e481b64c25`,bytes:1926191,encoding:`gzip`,mediaType:`application/octet-stream`,uncompressedSha256:`452ab98c430109043cb866209f71cf080eaab4cc245797587fc7933a7d72ec48`,uncompressedBytes:8306028},"wasm-go/runtime/sysroot/chunks/wasip1-09.index.json":{sha256:`320eed355173b189d42a70415d0a12f6f0bd91976dc0375750c63101275fa8d4`,bytes:4871,mediaType:`application/json`,deliveryPath:`wasm-go/runtime/sysroot/chunks/wasip1-09.index.json.gz`},"wasm-go/runtime/sysroot/chunks/wasip1-09.index.json.gz":{sha256:`8f1417a40eb879ff749749ee033e56c2fe59903280569fa57cb953c4562602a7`,bytes:846,encoding:`gzip`,mediaType:`application/json`,uncompressedSha256:`320eed355173b189d42a70415d0a12f6f0bd91976dc0375750c63101275fa8d4`,uncompressedBytes:4871},"wasm-go/runtime/sysroot/chunks/wasip1-09.pack.gz":{sha256:`34d8ab38689476f0695364e22e51f1817d7015c16c2a3b1d86d0f751de037b26`,bytes:1894164,encoding:`gzip`,mediaType:`application/octet-stream`,uncompressedSha256:`2291fcee51360171943fcfa4269ffeb29003e11941ed0ec8fef13c637c93376f`,uncompressedBytes:7799820},"wasm-go/runtime/sysroot/chunks/wasip1-10.index.json":{sha256:`22a94819e515a1f087d26978592d54f7c7b023aa685ac4edad9b7a28b6ffdf45`,bytes:1755,mediaType:`application/json`,deliveryPath:`wasm-go/runtime/sysroot/chunks/wasip1-10.index.json.gz`},"wasm-go/runtime/sysroot/chunks/wasip1-10.index.json.gz":{sha256:`cc50acf072a08d64f3fc13d3ac6a74b30477146ccf88db228024b375d8e894d1`,bytes:407,encoding:`gzip`,mediaType:`application/json`,uncompressedSha256:`22a94819e515a1f087d26978592d54f7c7b023aa685ac4edad9b7a28b6ffdf45`,uncompressedBytes:1755},"wasm-go/runtime/sysroot/chunks/wasip1-10.pack.gz":{sha256:`f5d5709a83ede5056a99a859853538cc6517d8489ddb3280c9f98ba923f9d61b`,bytes:2048640,encoding:`gzip`,mediaType:`application/octet-stream`,uncompressedSha256:`72604798e121407e3da16f0855582c94cd7e8fc0e7e7eda09323cd5b9dbea888`,uncompressedBytes:8120128},"wasm-go/runtime/sysroot/chunks/wasip1-11.index.json":{sha256:`d675d962b2acac56495d85f092deaefe72c00f36d1c54d0faf4112e7f6f38f41`,bytes:2069,mediaType:`application/json`,deliveryPath:`wasm-go/runtime/sysroot/chunks/wasip1-11.index.json.gz`},"wasm-go/runtime/sysroot/chunks/wasip1-11.index.json.gz":{sha256:`c3ea674f5a7237a99973709a223b79f848916139550690e3fcc7ef999a25a998`,bytes:470,encoding:`gzip`,mediaType:`application/json`,uncompressedSha256:`d675d962b2acac56495d85f092deaefe72c00f36d1c54d0faf4112e7f6f38f41`,uncompressedBytes:2069},"wasm-go/runtime/sysroot/chunks/wasip1-11.pack.gz":{sha256:`c4ec4a50258a8281c314c103cab86f727965d97d6511e8895d9b14f1e6eda70f`,bytes:1447606,encoding:`gzip`,mediaType:`application/octet-stream`,uncompressedSha256:`294b424eef144ab6a6704e1a52277e6cb2a0dd09e294674039c6039dd785c988`,uncompressedBytes:6037442},"wasm-go/runtime/sysroot/chunks/wasip1-12.index.json":{sha256:`41dbf9f2d729dd2d8bae0dd7a5f05e96c3450b9be74d30bdd76a6f092b5141a5`,bytes:205,mediaType:`application/json`,deliveryPath:`wasm-go/runtime/sysroot/chunks/wasip1-12.index.json.gz`},"wasm-go/runtime/sysroot/chunks/wasip1-12.index.json.gz":{sha256:`02889f4dbde556bfccb587ec0f11f0410c7f2a262353dc56fc6a7704fa00e637`,bytes:162,encoding:`gzip`,mediaType:`application/json`,uncompressedSha256:`41dbf9f2d729dd2d8bae0dd7a5f05e96c3450b9be74d30bdd76a6f092b5141a5`,uncompressedBytes:205},"wasm-go/runtime/sysroot/chunks/wasip1-12.pack.gz":{sha256:`4a02d0720b1e172b0445b6d27a491188a5ff82ec7fe4ea30f39fe1c8b9852296`,bytes:748138,encoding:`gzip`,mediaType:`application/octet-stream`,uncompressedSha256:`a0cd6e35743ef5c4dffcb62b0c3151dabe3b7d9ed06db7bb41b4057cda8ff4f5`,uncompressedBytes:3669172},"wasm-go/runtime/sysroot/chunks/wasip1-13.index.json":{sha256:`77cb55843e94d13476ca64c312559b188a4236ce4927f0e16f2ca95322a0154f`,bytes:434,mediaType:`application/json`,deliveryPath:`wasm-go/runtime/sysroot/chunks/wasip1-13.index.json.gz`},"wasm-go/runtime/sysroot/chunks/wasip1-13.index.json.gz":{sha256:`81a1ee7102cf785982f7b56988173e730349cde39a412de02778c5dee3cac251`,bytes:216,encoding:`gzip`,mediaType:`application/json`,uncompressedSha256:`77cb55843e94d13476ca64c312559b188a4236ce4927f0e16f2ca95322a0154f`,uncompressedBytes:434},"wasm-go/runtime/sysroot/chunks/wasip1-13.pack.gz":{sha256:`6161e95c9fc29308b14b589b0b0cf4579df7e9c693d59f16f05c96a67a5f2210`,bytes:1801548,encoding:`gzip`,mediaType:`application/octet-stream`,uncompressedSha256:`cbe5d5842cc108c8392f6555687d3c43e66d1ff3c407917a3bc28d878d14be3b`,uncompressedBytes:8074708},"wasm-go/runtime/sysroot/chunks/wasip1-14.index.json":{sha256:`e6656325c93dab978bae2b5312bebf71c06ccaf800ebda0275bca95317038487`,bytes:3e3,mediaType:`application/json`,deliveryPath:`wasm-go/runtime/sysroot/chunks/wasip1-14.index.json.gz`},"wasm-go/runtime/sysroot/chunks/wasip1-14.index.json.gz":{sha256:`200c41af348e935e8f07240cd474cd71b4d0ab748349ba654f5122f816f25fd5`,bytes:600,encoding:`gzip`,mediaType:`application/json`,uncompressedSha256:`e6656325c93dab978bae2b5312bebf71c06ccaf800ebda0275bca95317038487`,uncompressedBytes:3e3},"wasm-go/runtime/sysroot/chunks/wasip1-14.pack.gz":{sha256:`13ba06ea9e2dbd64cd7b16336c95a1d4a776773fd4a3443a34f43dd858980a5e`,bytes:2047969,encoding:`gzip`,mediaType:`application/octet-stream`,uncompressedSha256:`574d1b1837dc117638bb071cf8390bffa81c4f921e4b64625e201ab12de7ceab`,uncompressedBytes:7985870},"wasm-go/runtime/sysroot/chunks/wasip1-15.index.json":{sha256:`14f6ddff0ff52658cb5ff62fa91a36e2a1231f049e3960eb2ca6e505a749f90d`,bytes:2199,mediaType:`application/json`,deliveryPath:`wasm-go/runtime/sysroot/chunks/wasip1-15.index.json.gz`},"wasm-go/runtime/sysroot/chunks/wasip1-15.index.json.gz":{sha256:`29b841c5fb9bcf3bbc8ebaf07ebf42e99b66da62822d9773ad9148bb9d8a3338`,bytes:492,encoding:`gzip`,mediaType:`application/json`,uncompressedSha256:`14f6ddff0ff52658cb5ff62fa91a36e2a1231f049e3960eb2ca6e505a749f90d`,uncompressedBytes:2199},"wasm-go/runtime/sysroot/chunks/wasip1-15.pack.gz":{sha256:`ab914f6d45a93046ccfffd9704816bb697f57c65acce5d47665c2e4a51c82ba3`,bytes:1806046,encoding:`gzip`,mediaType:`application/octet-stream`,uncompressedSha256:`0bdb60e08e9a3b63024d1bba96bf2a37bd6957496d8a0fc8eeb2cc4a50a9f738`,uncompressedBytes:7715390},"wasm-go/runtime/sysroot/chunks/wasip1-16.index.json":{sha256:`a62c4ee56f2ae2aaaa45b3016313e384172050934ad6691a0c645d6a20aeb979`,bytes:2906,mediaType:`application/json`,deliveryPath:`wasm-go/runtime/sysroot/chunks/wasip1-16.index.json.gz`},"wasm-go/runtime/sysroot/chunks/wasip1-16.index.json.gz":{sha256:`17f8630daa40bd823563c606211d3c6d8dde1881448b4bcbe2344fd08edc84a6`,bytes:597,encoding:`gzip`,mediaType:`application/json`,uncompressedSha256:`a62c4ee56f2ae2aaaa45b3016313e384172050934ad6691a0c645d6a20aeb979`,uncompressedBytes:2906},"wasm-go/runtime/sysroot/chunks/wasip1-16.pack.gz":{sha256:`d35ce263a27c26c12fe84b7a3bd53f083e9875c3732403f7df8760371f4822be`,bytes:1492176,encoding:`gzip`,mediaType:`application/octet-stream`,uncompressedSha256:`88626b6eebff6c6be41f7c80c4e42f98596ce5942ac807fa9432eaef22ecae4b`,uncompressedBytes:6139636},"wasm-go/runtime/sysroot/chunks/wasip1-17.index.json":{sha256:`16c94fab8bbedf84d38c293ce94e2f6e923eff4e68f9b4c7efc9e30283875c9a`,bytes:102,mediaType:`application/json`,deliveryPath:`wasm-go/runtime/sysroot/chunks/wasip1-17.index.json.gz`},"wasm-go/runtime/sysroot/chunks/wasip1-17.index.json.gz":{sha256:`f44cdce4197cd3b5533ed068d600b3f41e4d107cf839c701b6115f4655f8a164`,bytes:103,encoding:`gzip`,mediaType:`application/json`,uncompressedSha256:`16c94fab8bbedf84d38c293ce94e2f6e923eff4e68f9b4c7efc9e30283875c9a`,uncompressedBytes:102},"wasm-go/runtime/sysroot/chunks/wasip1-17.pack.gz":{sha256:`f61f27bd17de546264aa58f40f3aafaac7021e0ef69c17f6b1b4cd7664a037ec`,bytes:20,encoding:`gzip`,mediaType:`application/octet-stream`,uncompressedSha256:`e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855`,uncompressedBytes:0},"wasm-go/runtime/sysroot/js.stdlib-index.json":{sha256:`5cafe1de8c680c1f115f85a03bef8872977961856d7f82660251178af83b644e`,bytes:99592,mediaType:`application/json`,deliveryPath:`wasm-go/runtime/sysroot/js.stdlib-index.json.gz`},"wasm-go/runtime/sysroot/js.stdlib-index.json.gz":{sha256:`bae0c5e11296090ea7557b5d630e8da0b1cc59dfb3e1891bdada87c08f738972`,bytes:8157,encoding:`gzip`,mediaType:`application/json`,uncompressedSha256:`5cafe1de8c680c1f115f85a03bef8872977961856d7f82660251178af83b644e`,uncompressedBytes:99592},"wasm-go/runtime/sysroot/wasip1.stdlib-index.json":{sha256:`3de5535e91ce9ed967d56dd702f1ec4b4f85b9cf53cff9f389c0010b259b5a26`,bytes:99450,mediaType:`application/json`,deliveryPath:`wasm-go/runtime/sysroot/wasip1.stdlib-index.json.gz`},"wasm-go/runtime/sysroot/wasip1.stdlib-index.json.gz":{sha256:`c572256f62f5868d5378805eab4b765f7b3bd809d1398dad43833fa47ce32c96`,bytes:8151,encoding:`gzip`,mediaType:`application/json`,uncompressedSha256:`3de5535e91ce9ed967d56dd702f1ec4b4f85b9cf53cff9f389c0010b259b5a26`,uncompressedBytes:99450},"wasm-go/runtime/tools/compile.wasm":{sha256:`0d2ac2c371dedcba797e85adec742876e0eb742a9898453a5bfe006fa7ea5b89`,bytes:49046581,mediaType:`application/wasm`,deliveryPath:`wasm-go/runtime/tools/compile.wasm.gz`},"wasm-go/runtime/tools/compile.wasm.gz":{sha256:`22ba5e5313dbe8fe7c43b437c7767cb21dce09d1b107a5e905633c9860911478`,bytes:9705969,encoding:`gzip`,mediaType:`application/wasm`,uncompressedSha256:`0d2ac2c371dedcba797e85adec742876e0eb742a9898453a5bfe006fa7ea5b89`,uncompressedBytes:49046581},"wasm-go/runtime/tools/link.wasm":{sha256:`4ac3defc29110fe4697486f130be64deeb6622abc5969e20b0c0b80a1ad5738d`,bytes:11163140,mediaType:`application/wasm`,deliveryPath:`wasm-go/runtime/tools/link.wasm.gz`},"wasm-go/runtime/tools/link.wasm.gz":{sha256:`c020de2ce6cc52e4b25a97141b30e329c318848b2385f7592fa1c5dc42d2b877`,bytes:2973793,encoding:`gzip`,mediaType:`application/wasm`,uncompressedSha256:`4ac3defc29110fe4697486f130be64deeb6622abc5969e20b0c0b80a1ad5738d`,uncompressedBytes:11163140},"wasm-go/tool-module.js":{sha256:`44392fedfe4de0665585f5469a58e3875cf241a9f67992e82462a2e8ac03eae0`,bytes:2816,mediaType:`text/javascript`},"wasm-go/tool-runtime.js":{sha256:`7b15d20ff44c075b7ca4a7df0eb0ad60038e3f2663571380836a216f5e792aff`,bytes:5381,mediaType:`text/javascript`},"wasm-go/types.js":{sha256:`01ae2a5b120382f9a648ced7ee8507493a134f216d100fc61600c6c9738235d2`,bytes:44,mediaType:`text/javascript`},"wasm-go/vendor/browser_wasi_shim/debug.js":{sha256:`a91848ee180529e2a60c05dfb9584cad19cd4e1c6f391fdb76a938bcae4c0328`,bytes:414,mediaType:`text/javascript`},"wasm-go/vendor/browser_wasi_shim/fd.js":{sha256:`9e82e1fc1bfd3e3573f64349dc42b4b624ed61d24e5c553f2bb4d041444f166c`,bytes:1906,mediaType:`text/javascript`},"wasm-go/vendor/browser_wasi_shim/fs_mem.js":{sha256:`85dbc9e0ee784d9ff8b55452644e00bf7058e32355aab974f8b71d7d85772324`,bytes:12206,mediaType:`text/javascript`},"wasm-go/vendor/browser_wasi_shim/fs_opfs.js":{sha256:`4b96aaeb5ac5986cf802cbf22b975c656682d22a38248160c96fc2ded5644869`,bytes:2280,mediaType:`text/javascript`},"wasm-go/vendor/browser_wasi_shim/index.js":{sha256:`7e2fd52ee3f728bb0b1d6e449724e0f13e3d586bb25bde6e02a66366175b5605`,bytes:316,mediaType:`text/javascript`},"wasm-go/vendor/browser_wasi_shim/strace.js":{sha256:`ece435d3784d928d02bff4d015b7cb686f8c06de8536ff9f8ebc38a8f403a3be`,bytes:318,mediaType:`text/javascript`},"wasm-go/vendor/browser_wasi_shim/wasi.js":{sha256:`168eb977a826f75ab0c39f9322f78cc58dbd5b233019ad1d6a7e940af8a7c4aa`,bytes:16429,mediaType:`text/javascript`},"wasm-go/vendor/browser_wasi_shim/wasi_defs.js":{sha256:`0db0f42ba330749a7b05095ea1fd0ff63fd2b30e84cead30fe4c28359d15f194`,bytes:9027,mediaType:`text/javascript`},"wasm-go/wasi-guest.js":{sha256:`1aa4d9b6c39b9476715dcdc3d9cc1d77ba2b88f7d16f59923a4de7a46d5754c3`,bytes:3501,mediaType:`text/javascript`},"wasm-go/wasm-memory.js":{sha256:`e50b1e7670ec7dcb9f4b3dc4c6bb660c81fea66b1c0e5b3186383802118e18f8`,bytes:6706,mediaType:`text/javascript`},"wasm-golfscript/golfscript.rb":{sha256:`84f932a624b19afe6ef2a3ebe09a9b832f765a87460a79cde22323615c468f38`,bytes:19231,mediaType:`application/octet-stream`},"wasm-golfscript/runtime-build.json":{sha256:`8374cdb096716f59bb3058ae440cfcc3ba155d3f4b9056127a23f51af002d6fa`,bytes:1276,mediaType:`application/json`},"wasm-grain/LICENSE-grain-compiler.txt":{sha256:`8224a89fea46649b1ec4338c71a736d4a358e799ef239dfbe592a10bfb4df7ec`,bytes:7651,mediaType:`application/octet-stream`},"wasm-grain/LICENSE-grain-stdlib.txt":{sha256:`7a7e23ff2b9f4a275793b20ef057195e11f4637d4e5cedaa0c64387eeb7ab30c`,bytes:1139,mediaType:`application/octet-stream`},"wasm-grain/grainc.js.gz.bin":{sha256:`38cf8c42ed83447287e0bc54c768661a110b7becf1b93bdfdd6da30537c4e289`,bytes:3417153,encoding:`gzip`,mediaType:`text/javascript`,uncompressedSha256:`0a85cf0120aafd873e41eb901a18090453010f8f819074b77c14e1c359cafd1e`,uncompressedBytes:20872240},"wasm-grain/runner-worker.js":{sha256:`c36b478c25f000a9a9ecdb186490cf8fce07ece9b5ac271031aa2e97f75cabab`,bytes:28127,mediaType:`text/javascript`},"wasm-grain/runtime-build.json":{sha256:`227d8e1fa48be982b973ad27b874638bfe56f29d7246a4b4185f71736aed998c`,bytes:1913,mediaType:`application/json`},"wasm-grain/stdlib.pack.gz.bin":{sha256:`7180475667a3129821be12aa787f449e58de62b0bb5c0e5472077b73b9e5cafa`,bytes:1653344,encoding:`gzip`,mediaType:`application/octet-stream`,uncompressedSha256:`c56e83cbea649be5dd94ce98ae648b8f98e40203761ef7b1ad0a799048ee08eb`,uncompressedBytes:5066092},"wasm-haskell/bsdtar.wasm":{sha256:`e13ebb15ca0971f6629a6313bc043c532dd9be3a0e6bb0b7f8a395de835ad0c0`,bytes:1240004,mediaType:`application/wasm`,deliveryPath:`wasm-haskell/bsdtar.wasm.gz`},"wasm-haskell/bsdtar.wasm.gz":{sha256:`1f33a412ff4a5af22a9bcf66021c0b090cb9fb229f599ae5e9aa35c7bfc3bb7a`,bytes:417731,encoding:`gzip`,mediaType:`application/wasm`,uncompressedSha256:`e13ebb15ca0971f6629a6313bc043c532dd9be3a0e6bb0b7f8a395de835ad0c0`,uncompressedBytes:1240004},"wasm-haskell/dyld.mjs":{sha256:`d2260e7669868741fde2f1ba8cd38a9d63bff532c8ccb53d18b210b60af915d9`,bytes:83177,mediaType:`text/javascript`},"wasm-haskell/rootfs.tar.zst":{sha256:`35f68f56fdb72111f150ba05ad31efed2f6fc77ee7026fb4b197ae7901a67adf`,bytes:49091550,mediaType:`application/octet-stream`},"wasm-haskell/runtime-build.json":{sha256:`c54b5445ad8120732f89298b416002e73a82c17e560f2489225be95c9329e387`,bytes:8136,mediaType:`application/json`},"wasm-haskell/runtime-manifest.v1.json":{sha256:`6742a02493c28ff4513b2085876808fa7f4dab25420b8c39898577e1a4c3520e`,bytes:581,mediaType:`application/json`},"wasm-haskell/runtime-manifest.v2.json":{sha256:`39081ab8519c216d0a880a5e61bb1f60918f1d0f69389edd7768ad81816f4996`,bytes:7842,mediaType:`application/json`},"wasm-hy/funcparserlib-1.0.1-py2.py3-none-any.whl":{sha256:`95da15d3f0d00b9b6f4bf04005c708af3faa115f7b45692ace064ebe758c68e8`,bytes:17842,mediaType:`application/zip`},"wasm-hy/hy-1.3.1-py3-none-any.whl":{sha256:`fef54e98b2080cd3993d5ce5a4310ef2b0fc756c972203b86fedc0e0f2908f53`,bytes:122343,mediaType:`application/zip`},"wasm-j/jamalgam.js":{sha256:`a4abe92ddf874d06d01d6873e151b641837b79d4075529fa17541b576eeb92e3`,bytes:170649,mediaType:`text/javascript`},"wasm-j/jamalgam.wasm":{sha256:`22549b50a69575ce09326f08fbf35396edfe4eedc583c8dd273d06ebbe920358`,bytes:4832581,mediaType:`application/wasm`,deliveryPath:`wasm-j/jamalgam.wasm.gz`},"wasm-j/jamalgam.wasm.gz":{sha256:`e49723087dd8c9b40e24a769e82269552ef16a39fcb4d2c0840815a695ee57e7`,bytes:1418554,encoding:`gzip`,mediaType:`application/wasm`,uncompressedSha256:`22549b50a69575ce09326f08fbf35396edfe4eedc583c8dd273d06ebbe920358`,uncompressedBytes:4832581},"wasm-j/jamalgam.wasm.gz.bin":{sha256:`e49723087dd8c9b40e24a769e82269552ef16a39fcb4d2c0840815a695ee57e7`,bytes:1418554,encoding:`gzip`,mediaType:`application/wasm`,uncompressedSha256:`22549b50a69575ce09326f08fbf35396edfe4eedc583c8dd273d06ebbe920358`,uncompressedBytes:4832581},"wasm-j/runner-worker.js":{sha256:`98ccb3f1328b5b4029866a73b15c71dbdd1d7575dbaff3914aac5100f391118a`,bytes:14059,mediaType:`text/javascript`},"wasm-j/runtime-manifest.v1.json":{sha256:`e582373a24823b4ba2ed67d1083261ddd0f9b4849fe33149e0ac51bbdf569dd4`,bytes:181,mediaType:`application/json`},"wasm-j/runtime-manifest.v2.json":{sha256:`828fbbef8e90aaf6445b0badd121f926f50c42de6e06f43e7332d149a06e3f10`,bytes:1275,mediaType:`application/json`},"wasm-janet/janet.js":{sha256:`4c8a59b012fee0e785cbcdfa57cddb2a04e2f963d91897a1bbd8d7f45b240555`,bytes:69382,mediaType:`text/javascript`},"wasm-janet/janet.wasm":{sha256:`8f3dc1632ba071f0f5e0d9d79e664fd018638cc32edf8d91bd02dcdd058dcc71`,bytes:829432,mediaType:`application/wasm`,deliveryPath:`wasm-janet/janet.wasm.gz`},"wasm-janet/janet.wasm.gz":{sha256:`8f9b1f38c6a2aabb937c0dae11c0ab2bb68704f95d519f16ef8413682c113a1d`,bytes:316923,encoding:`gzip`,mediaType:`application/wasm`,uncompressedSha256:`8f3dc1632ba071f0f5e0d9d79e664fd018638cc32edf8d91bd02dcdd058dcc71`,uncompressedBytes:829432},"wasm-janet/janet.wasm.gz.bin":{sha256:`8f9b1f38c6a2aabb937c0dae11c0ab2bb68704f95d519f16ef8413682c113a1d`,bytes:316923,encoding:`gzip`,mediaType:`application/wasm`,uncompressedSha256:`8f3dc1632ba071f0f5e0d9d79e664fd018638cc32edf8d91bd02dcdd058dcc71`,uncompressedBytes:829432},"wasm-janet/runner-worker.js":{sha256:`cf081654226f8e2dcc2ac778bf95cc72bf9c27bd641bec0a10ab15e07103726d`,bytes:21453,mediaType:`text/javascript`},"wasm-janet/runtime-build.json":{sha256:`7bc1074fe85f276172c67bd52f94bb0455540df516264a8dec3b8c011a877e8b`,bytes:1448,mediaType:`application/json`},"wasm-janet/runtime-manifest.v1.json":{sha256:`190ecf985cb4ebcc435e14f8b3872ff215dd9c67b3830b21391df1f86d576672`,bytes:490,mediaType:`application/json`},"wasm-janet/runtime-manifest.v2.json":{sha256:`e116626fbbee3c5c60a4f9126de2e6e076c1cc0231f589387dd8bf0ad887cf92`,bytes:2705,mediaType:`application/json`},"wasm-julia/julia.data":{sha256:`8e9347b29cb8b4301cf40fdc4e1f4bdc51a7f06f3f12958fbd2730fba2ba38b1`,bytes:42960896,mediaType:`application/octet-stream`,deliveryPath:`wasm-julia/julia.data.gz`},"wasm-julia/julia.data.gz":{sha256:`6c35eea7607974239cb3350273311c9458b890aa7d5c57c879388395b042e6f8`,bytes:14260930,encoding:`gzip`,mediaType:`application/octet-stream`,uncompressedSha256:`8e9347b29cb8b4301cf40fdc4e1f4bdc51a7f06f3f12958fbd2730fba2ba38b1`,uncompressedBytes:42960896},"wasm-julia/julia.data.gz.bin":{sha256:`6c35eea7607974239cb3350273311c9458b890aa7d5c57c879388395b042e6f8`,bytes:14260930,encoding:`gzip`,mediaType:`application/octet-stream`,uncompressedSha256:`8e9347b29cb8b4301cf40fdc4e1f4bdc51a7f06f3f12958fbd2730fba2ba38b1`,uncompressedBytes:42960896},"wasm-julia/julia.js":{sha256:`729bebdacd0243b760360c1b9c6c18735db3c85b9047d8cb2ed63d4801a4fb7f`,bytes:278345,mediaType:`text/javascript`,deliveryPath:`wasm-julia/julia.js.gz`},"wasm-julia/julia.js.gz":{sha256:`fdb4b6d7417c2c02f0becd71ec24d01c11f920e97ec77ace2e3676d1667b9e65`,bytes:57115,encoding:`gzip`,mediaType:`text/javascript`,uncompressedSha256:`729bebdacd0243b760360c1b9c6c18735db3c85b9047d8cb2ed63d4801a4fb7f`,uncompressedBytes:278345},"wasm-julia/julia.js.gz.bin":{sha256:`fdb4b6d7417c2c02f0becd71ec24d01c11f920e97ec77ace2e3676d1667b9e65`,bytes:57115,encoding:`gzip`,mediaType:`text/javascript`,uncompressedSha256:`729bebdacd0243b760360c1b9c6c18735db3c85b9047d8cb2ed63d4801a4fb7f`,uncompressedBytes:278345},"wasm-julia/julia.wasm":{sha256:`027467183dff7f2e91574da93dbd1ea82f6875be1636d786212bb3c1b3538d45`,bytes:2573366,mediaType:`application/wasm`,deliveryPath:`wasm-julia/julia.wasm.gz`},"wasm-julia/julia.wasm.gz":{sha256:`590d2e91f5360ab663b8a640c51007d3112064ad0c79e347eac85d87c010fddf`,bytes:858693,encoding:`gzip`,mediaType:`application/wasm`,uncompressedSha256:`027467183dff7f2e91574da93dbd1ea82f6875be1636d786212bb3c1b3538d45`,uncompressedBytes:2573366},"wasm-julia/julia.wasm.gz.bin":{sha256:`590d2e91f5360ab663b8a640c51007d3112064ad0c79e347eac85d87c010fddf`,bytes:858693,encoding:`gzip`,mediaType:`application/wasm`,uncompressedSha256:`027467183dff7f2e91574da93dbd1ea82f6875be1636d786212bb3c1b3538d45`,uncompressedBytes:2573366},"wasm-julia/runner-worker.js":{sha256:`1e4980140a6f38b08c03fe0a7b57d4c3a5a289a94c4f96274d16a40a4adb58f0`,bytes:28124,mediaType:`text/javascript`},"wasm-julia/runtime-build.json":{sha256:`50670b9ecb180109dc875738069abe4db0fae3286c03e36fd73c5aff22c8a4ba`,bytes:2426,mediaType:`application/json`},"wasm-julia/runtime-manifest.v1.json":{sha256:`ba7fef86ffb24c28dfe6dffe53e6f3f538b0f5e90929fae20ec6ba88934cf261`,bytes:280,mediaType:`application/json`},"wasm-julia/runtime-manifest.v2.json":{sha256:`72984da57e0474eb1922b138564d02558624442a3e169a0f302ee5c31073ef47`,bytes:4130,mediaType:`application/json`},"wasm-lean4/lean-init-00.pack.gz.bin":{sha256:`c2cea0798b8b3e910188eb79d3d0101452c874f693294d2cf8c360fde125c08e`,bytes:22626621,encoding:`gzip`,mediaType:`application/octet-stream`,uncompressedSha256:`19734bd892d96cbf4ec7b1d13e1bdccbbee022f3288908ee535e2facfc99d483`,uncompressedBytes:50331648},"wasm-lean4/lean-init-01.pack.gz.bin":{sha256:`6e65383d8de425a0c0f5b48430aa5be7c9f2066138080bf213a0435b0fd1d874`,bytes:22633878,encoding:`gzip`,mediaType:`application/octet-stream`,uncompressedSha256:`2ea9fcd0ede724bfc93bf032b7ee3d09724fbd83a17afaaaad534859e74b1200`,uncompressedBytes:50331648},"wasm-lean4/lean-init-02.pack.gz.bin":{sha256:`57cc57d61067fc77d8b72008299e25956a121cd3fdf628941420966de1f762e5`,bytes:23039094,encoding:`gzip`,mediaType:`application/octet-stream`,uncompressedSha256:`75273ea353191316cb8fc31900ef36ffa7424a4bd62061cdbbba8477510ed3bc`,uncompressedBytes:50331648},"wasm-lean4/lean-init-03.pack.gz.bin":{sha256:`e310ddf310d6d89dc7cc583f01213a1eab2684c1ada9e77368ca16637009d72a`,bytes:22382973,encoding:`gzip`,mediaType:`application/octet-stream`,uncompressedSha256:`480c12f5b808c18f692e9f5f5666bee3c6a2b0473075a3dd1417039b2bf05553`,uncompressedBytes:50331648},"wasm-lean4/lean-init-04.pack.gz.bin":{sha256:`f1345c223483bbb8e3c25e73042c5526efbd24301df95c74d30b4799493e6697`,bytes:21886461,encoding:`gzip`,mediaType:`application/octet-stream`,uncompressedSha256:`5daed6ecf33bfb049e294c72ed161d6a0260440aa371b2be34f26b78377e1178`,uncompressedBytes:50331648},"wasm-lean4/lean-init-05.pack.gz.bin":{sha256:`9f8deb32469cbe66669381c8f0fb5d379d506f7935beb29393b19d2c52ac8a52`,bytes:9812693,encoding:`gzip`,mediaType:`application/octet-stream`,uncompressedSha256:`73ca4bd7a0d07f15d3b88298b7dd273406a92e36da96cb555ebb986ee85b7b14`,uncompressedBytes:24923128},"wasm-lean4/lean-init.index.json":{sha256:`030b375cee435f12f7163c58c16d128340f9e20fa27a77ab646198be61906555`,bytes:321866,mediaType:`application/json`,deliveryPath:`wasm-lean4/lean-init.index.json.gz`},"wasm-lean4/lean-init.index.json.gz":{sha256:`1113c7610e33ac50d622a61ffbc1b62930d2cd773d72a5fe8ff5d89962795ac7`,bytes:38340,encoding:`gzip`,mediaType:`application/json`,uncompressedSha256:`030b375cee435f12f7163c58c16d128340f9e20fa27a77ab646198be61906555`,uncompressedBytes:321866},"wasm-lean4/lean.mjs":{sha256:`16d6d6cb07c844bedf745f856a364ec61e86c13c4fe13a2e57c0c698a5c5f727`,bytes:108528,mediaType:`text/javascript`},"wasm-lean4/lean.wasm.gz.bin":{sha256:`89dc3cb841d487f9e29c1dc3069e7aeb1a63e5ec0267b8250552e3fe90f855bf`,bytes:20239874,encoding:`gzip`,mediaType:`application/wasm`,uncompressedSha256:`d81dbde2ba4aaf0546affca2756477b6d1365a5633080d7119f737e5906ed919`,uncompressedBytes:113033667},"wasm-lean4/producer-receipt.json":{sha256:`e60eb3fdcc108fa7c6127c5a8925ffb622706facb17bc4f84e9ed27f82495fa1`,bytes:4596,mediaType:`application/json`},"wasm-lean4/runner-worker.js":{sha256:`469ef5ec7accf4c221d06134ccd4989f14e9229c61dd35c386617a015aec6f03`,bytes:15759,mediaType:`text/javascript`},"wasm-lfortran/lfortran.data.bin":{sha256:`6d6dbe72e4f23f9761eb8005c8a737490750f54dbb173c6455a9c9cb9489c99f`,bytes:179758,mediaType:`application/octet-stream`},"wasm-lfortran/lfortran.js":{sha256:`348d5472c307da2bae15eb73e8a38da0e7c2a4cfaebacbccbee2b163806a59c3`,bytes:968283,mediaType:`text/javascript`,deliveryPath:`wasm-lfortran/lfortran.js.gz`},"wasm-lfortran/lfortran.js.gz":{sha256:`dce3c058984ff07a9ff5edb867d07afc830dd195f2e279cb7031d0f8f02a5aae`,bytes:205454,encoding:`gzip`,mediaType:`text/javascript`,uncompressedSha256:`348d5472c307da2bae15eb73e8a38da0e7c2a4cfaebacbccbee2b163806a59c3`,uncompressedBytes:968283},"wasm-lfortran/lfortran.wasm":{sha256:`b7c8ef4e942e9965a511b8700955c47c1f48d4ef18c61953a4847a6dcd680181`,bytes:80662569,mediaType:`application/wasm`,deliveryPath:`wasm-lfortran/lfortran.wasm.gz`},"wasm-lfortran/lfortran.wasm.gz":{sha256:`8689eff2f78bbe3116032a5978208ee1d142e3ed5a562dfc8633a336929e7451`,bytes:20044335,encoding:`gzip`,mediaType:`application/wasm`,uncompressedSha256:`b7c8ef4e942e9965a511b8700955c47c1f48d4ef18c61953a4847a6dcd680181`,uncompressedBytes:80662569},"wasm-lfortran/producer-receipt.json":{sha256:`11c9baef85c5221440edc4462690312cda62b48998a133b9a397ce32c6a97c45`,bytes:6932,mediaType:`application/json`},"wasm-lfortran/runner-worker.js":{sha256:`e801cbf4dca7be9fc6fd1205dc4e6ab17af4530f42527dcc8e544eb8373a1469`,bytes:11569,mediaType:`text/javascript`},"wasm-lisp/index.js":{sha256:`b348035226520634ef9b6a988250d74838d482567ac3cdc9c7dc35cff8549813`,bytes:4949687,mediaType:`text/javascript`,deliveryPath:`wasm-lisp/index.js.gz`},"wasm-lisp/index.js.gz":{sha256:`ebe19362d5ab44955ee01dbd801d66c277b973f8b35e789654c37be02f8c7eac`,bytes:1618458,encoding:`gzip`,mediaType:`text/javascript`,uncompressedSha256:`b348035226520634ef9b6a988250d74838d482567ac3cdc9c7dc35cff8549813`,uncompressedBytes:4949687},"wasm-lisp/puppyc.core.wasm":{sha256:`1ca14713fa3bfc9f040b8f3eb501bbc5e689c1d38bacb4bf2f904cdc7c7d5a4f`,bytes:130,mediaType:`application/wasm`},"wasm-lisp/puppyc.core2.wasm":{sha256:`43577ba9adba36ba5f331671daf13e8a3bac4f46bb45a637ca46794a9c7067e1`,bytes:565397,mediaType:`application/wasm`,deliveryPath:`wasm-lisp/puppyc.core2.wasm.gz`},"wasm-lisp/puppyc.core2.wasm.gz":{sha256:`5844269ccd9593813df9c1288e9b0388962e24e07c5aebe332307ec3c19d5e71`,bytes:79941,encoding:`gzip`,mediaType:`application/wasm`,uncompressedSha256:`43577ba9adba36ba5f331671daf13e8a3bac4f46bb45a637ca46794a9c7067e1`,uncompressedBytes:565397},"wasm-lisp/puppyc.js":{sha256:`ab9977a08a53895e285c597701dbe8a5ac2fb73dd85cee928d4849e0acf493e0`,bytes:237726,mediaType:`text/javascript`},"wasm-lisp/runtime-build.json":{sha256:`621968e935587fe7d5d0f1361dabc89c08b7c1ad6b994d0f34e752f9920fbae9`,bytes:4227,mediaType:`application/json`},"wasm-lisp/runtime-manifest.v1.json":{sha256:`421c6ca7cb7741018ccf613c28f84cf653959b57f51be13906f03b1c59970750`,bytes:359,mediaType:`application/json`},"wasm-lisp/runtime-manifest.v2.json":{sha256:`f8d1197afabea4c50904a1865abd74757e5dd924034f37e36a132d3833c558c8`,bytes:6157,mediaType:`application/json`},"wasm-lolcode/lolcode.wasm":{sha256:`39cd197d5b8681ee37817f87ac86a07ca692407e0226e78e8470d37b57e0ce64`,bytes:837757,mediaType:`application/wasm`,deliveryPath:`wasm-lolcode/lolcode.wasm.gz`},"wasm-lolcode/lolcode.wasm.gz":{sha256:`d34eb3f1da53037307c8044ade58d87f3e16410a9b5dacaa41ccf1d9a84591fe`,bytes:260834,encoding:`gzip`,mediaType:`application/wasm`,uncompressedSha256:`39cd197d5b8681ee37817f87ac86a07ca692407e0226e78e8470d37b57e0ce64`,uncompressedBytes:837757},"wasm-lolcode/runtime-build.json":{sha256:`3b8d65ce7d94113255bcd59e6dbe760b76dbe5e1685ef17011274a1d6acaf48e`,bytes:8187,mediaType:`application/json`},"wasm-lua/glue.wasm":{sha256:`95f3f19ddb740125883bc41d5ec670cd0828e7b58c8bdad385323cbff497b55c`,bytes:271581,mediaType:`application/wasm`,deliveryPath:`wasm-lua/glue.wasm.gz`},"wasm-lua/glue.wasm.gz":{sha256:`4e5bec83bd25c0ba42ba7cadd4a5a7e77d685c545876c713391fcb34e9d3a319`,bytes:110908,encoding:`gzip`,mediaType:`application/wasm`,uncompressedSha256:`95f3f19ddb740125883bc41d5ec670cd0828e7b58c8bdad385323cbff497b55c`,uncompressedBytes:271581},"wasm-lua/index.js":{sha256:`468741b2758445af7b7a426995a72995c2f5623ef0e8661c76cd34f3cbb009a0`,bytes:113706,mediaType:`text/javascript`},"wasm-malbolge/malbolge.wasm":{sha256:`27cc66d75e63524b000b62b1117ad45cb3dabc4885530800175affc40f895840`,bytes:16067,mediaType:`application/wasm`},"wasm-malbolge/runtime-build.json":{sha256:`cd3ed74c394c198e990f90b4fa4fda30f04e873a992fe868fd537e3bc9e6f0dd`,bytes:2151,mediaType:`application/json`},"wasm-nim/clang/clang.js":{sha256:`06cd96ca1f66204a61133b2cabb0dd97132ddf65931f7fc1586fede9ee01754a`,bytes:19511,mediaType:`text/javascript`},"wasm-nim/clang/clang.js.bin":{sha256:`06cd96ca1f66204a61133b2cabb0dd97132ddf65931f7fc1586fede9ee01754a`,bytes:19511,mediaType:`application/octet-stream`},"wasm-nim/clang/clang.wasm":{sha256:`2a466f0e990329d3230b869d04fc20803eae96a7feb3a3f6c93e25a77b8aed1d`,bytes:31214472,mediaType:`application/wasm`,deliveryPath:`wasm-nim/clang/clang.wasm.gz`},"wasm-nim/clang/clang.wasm.gz":{sha256:`4b454f6b421ae8d28d14d69c1957aaf8516049c02d1f93f29193af84502c8778`,bytes:10620308,encoding:`gzip`,mediaType:`application/wasm`,uncompressedSha256:`2a466f0e990329d3230b869d04fc20803eae96a7feb3a3f6c93e25a77b8aed1d`,uncompressedBytes:31214472},"wasm-nim/clang/clang.wasm.gz.bin":{sha256:`4b454f6b421ae8d28d14d69c1957aaf8516049c02d1f93f29193af84502c8778`,bytes:10620308,encoding:`gzip`,mediaType:`application/wasm`,uncompressedSha256:`2a466f0e990329d3230b869d04fc20803eae96a7feb3a3f6c93e25a77b8aed1d`,uncompressedBytes:31214472},"wasm-nim/clang/lld.wasm":{sha256:`36419ed202011765222098d7701218378b67f634d50f0a4625059ae2c9860f48`,bytes:19490094,mediaType:`application/wasm`,deliveryPath:`wasm-nim/clang/lld.wasm.gz`},"wasm-nim/clang/lld.wasm.gz":{sha256:`e1da2a0166cf6fe4ed8b18fb46de565d07dd7f252176ecf1948bbca3eef83340`,bytes:6769787,encoding:`gzip`,mediaType:`application/wasm`,uncompressedSha256:`36419ed202011765222098d7701218378b67f634d50f0a4625059ae2c9860f48`,uncompressedBytes:19490094},"wasm-nim/clang/lld.wasm.gz.bin":{sha256:`e1da2a0166cf6fe4ed8b18fb46de565d07dd7f252176ecf1948bbca3eef83340`,bytes:6769787,encoding:`gzip`,mediaType:`application/wasm`,uncompressedSha256:`36419ed202011765222098d7701218378b67f634d50f0a4625059ae2c9860f48`,uncompressedBytes:19490094},"wasm-nim/clang/memfs.wasm":{sha256:`2c72ee42bd9430029dda8c6bafc9f37143f6fe88d5f1ea950a70259ab748bcfe`,bytes:345442,mediaType:`application/wasm`,deliveryPath:`wasm-nim/clang/memfs.wasm.gz`},"wasm-nim/clang/memfs.wasm.gz":{sha256:`d86f141eacd58a93511fbfb7c4e81d498eb7106a8a57df1bea7d33df3ce1f403`,bytes:18974,encoding:`gzip`,mediaType:`application/wasm`,uncompressedSha256:`2c72ee42bd9430029dda8c6bafc9f37143f6fe88d5f1ea950a70259ab748bcfe`,uncompressedBytes:345442},"wasm-nim/clang/memfs.wasm.gz.bin":{sha256:`d86f141eacd58a93511fbfb7c4e81d498eb7106a8a57df1bea7d33df3ce1f403`,bytes:18974,encoding:`gzip`,mediaType:`application/wasm`,uncompressedSha256:`2c72ee42bd9430029dda8c6bafc9f37143f6fe88d5f1ea950a70259ab748bcfe`,uncompressedBytes:345442},"wasm-nim/clang/sysroot.tar":{sha256:`2435a7b549af30c2be7ec249c405bc2e911ab0c6003012f0909ec3c131bff867`,bytes:9297920,mediaType:`application/octet-stream`,deliveryPath:`wasm-nim/clang/sysroot.tar.gz`},"wasm-nim/clang/sysroot.tar.gz":{sha256:`9ba7e60b92b824c45f9b3a983dfa2f4d4feed627f276c6369d7518c15f133cf4`,bytes:1829599,encoding:`gzip`,mediaType:`application/octet-stream`,uncompressedSha256:`2435a7b549af30c2be7ec249c405bc2e911ab0c6003012f0909ec3c131bff867`,uncompressedBytes:9297920},"wasm-nim/clang/sysroot.tar.gz.bin":{sha256:`9ba7e60b92b824c45f9b3a983dfa2f4d4feed627f276c6369d7518c15f133cf4`,bytes:1829599,encoding:`gzip`,mediaType:`application/octet-stream`,uncompressedSha256:`2435a7b549af30c2be7ec249c405bc2e911ab0c6003012f0909ec3c131bff867`,uncompressedBytes:9297920},"wasm-nim/nim/nim-bundle.js":{sha256:`170a78937e21ac0ec47e7d3f0eccefc261178f336ba92ab43acdb2f73ffd1301`,bytes:6566418,mediaType:`text/javascript`,deliveryPath:`wasm-nim/nim/nim-bundle.js.gz`},"wasm-nim/nim/nim-bundle.js.gz":{sha256:`3b2ba2c1975bc8663ad21e2bd38f4c32b0ae109b3464312163dcc9c5e246ceec`,bytes:1873825,encoding:`gzip`,mediaType:`text/javascript`,uncompressedSha256:`170a78937e21ac0ec47e7d3f0eccefc261178f336ba92ab43acdb2f73ffd1301`,uncompressedBytes:6566418},"wasm-nim/nim/nim-bundle.js.gz.bin":{sha256:`3b2ba2c1975bc8663ad21e2bd38f4c32b0ae109b3464312163dcc9c5e246ceec`,bytes:1873825,encoding:`gzip`,mediaType:`text/javascript`,uncompressedSha256:`170a78937e21ac0ec47e7d3f0eccefc261178f336ba92ab43acdb2f73ffd1301`,uncompressedBytes:6566418},"wasm-nim/nim/nim.wasm":{sha256:`40e8c62fb96ee786fcd91f0ee2306241adeaf38c148bc8ec9788e0cc5cb26567`,bytes:4812366,mediaType:`application/wasm`,deliveryPath:`wasm-nim/nim/nim.wasm.gz`},"wasm-nim/nim/nim.wasm.gz":{sha256:`48f519c32c4f202c1685c0509ad593612e289845549e824fdf95823f36f18f67`,bytes:1558514,encoding:`gzip`,mediaType:`application/wasm`,uncompressedSha256:`40e8c62fb96ee786fcd91f0ee2306241adeaf38c148bc8ec9788e0cc5cb26567`,uncompressedBytes:4812366},"wasm-nim/nim/nim.wasm.gz.bin":{sha256:`48f519c32c4f202c1685c0509ad593612e289845549e824fdf95823f36f18f67`,bytes:1558514,encoding:`gzip`,mediaType:`application/wasm`,uncompressedSha256:`40e8c62fb96ee786fcd91f0ee2306241adeaf38c148bc8ec9788e0cc5cb26567`,uncompressedBytes:4812366},"wasm-nim/nim/nimbase.h":{sha256:`28491d05916eab446de054370808030b33b63fd5623dcd454212adec27ee934d`,bytes:20734,mediaType:`application/octet-stream`},"wasm-nim/nim/nimbase.h.bin":{sha256:`28491d05916eab446de054370808030b33b63fd5623dcd454212adec27ee934d`,bytes:20734,mediaType:`application/octet-stream`},"wasm-nim/runner-worker.js":{sha256:`5b320df97e0c100a45bbadf4fa486f45c1970e9b7df0a1c1e448408147e53a73`,bytes:43945,mediaType:`text/javascript`},"wasm-nim/runtime-build.json":{sha256:`f734345d2908576beeafcb6fc9af6101431c125a4385792d7c58389b457bcdc3`,bytes:5168,mediaType:`application/json`},"wasm-nim/runtime-manifest.v1.json":{sha256:`120f4c8c8c8686fab17979953839db639e0c4827362d3e9e4dc20dcaf92907f4`,bytes:672,mediaType:`application/json`},"wasm-nim/runtime-manifest.v2.json":{sha256:`b9d11fcc43eab9764b5864c37952e932d2d08e33c33c18278ef4f312ba6c0089`,bytes:7002,mediaType:`application/json`},"wasm-objectivec/foundation-headers.json":{sha256:`116eaafa65f0bf65d64bd4143abc5c00aea54de19fe4bf9e4cbe88965db9d719`,bytes:1581430,mediaType:`application/json`,deliveryPath:`wasm-objectivec/foundation-headers.json.gz`},"wasm-objectivec/foundation-headers.json.gz":{sha256:`9e84b448b1a5c6e5cf62b4ece62cbe7f6ae06f45a26e90f068c7119850e66494`,bytes:313306,encoding:`gzip`,mediaType:`application/json`,uncompressedSha256:`116eaafa65f0bf65d64bd4143abc5c00aea54de19fe4bf9e4cbe88965db9d719`,uncompressedBytes:1581430},"wasm-objectivec/headers.json":{sha256:`64bf5a09feffa612e6f82cfc52f3d6a9c5e4fc3064c3824c24aeea59cb544d8e`,bytes:83231,mediaType:`application/json`},"wasm-objectivec/libffi.a":{sha256:`dcdf2754536c93dcadca640a26fe4eb415ee58c15db7a53072e0f18f322e2cbd`,bytes:4966,mediaType:`application/octet-stream`},"wasm-objectivec/libgnustep-base.a":{sha256:`1915b83476f7a520d8ae85c2e02603d245ba6bfc96d7e2593a552d079a7c4526`,bytes:15220588,mediaType:`application/octet-stream`,deliveryPath:`wasm-objectivec/libgnustep-base.a.gz`},"wasm-objectivec/libgnustep-base.a.gz":{sha256:`3ab03c769a2c08e444e495cb538d4283faf33e70627f28b3b862ce54fd75482b`,bytes:4671198,encoding:`gzip`,mediaType:`application/octet-stream`,uncompressedSha256:`1915b83476f7a520d8ae85c2e02603d245ba6bfc96d7e2593a552d079a7c4526`,uncompressedBytes:15220588},"wasm-objectivec/libgnustep-base.o":{sha256:`4022983db158350fe82ccd8c6eaf1c9e1305ee9233a6d7e3f9d5508a4f937aa7`,bytes:13557664,mediaType:`application/octet-stream`,deliveryPath:`wasm-objectivec/libgnustep-base.o.gz`},"wasm-objectivec/libgnustep-base.o.gz":{sha256:`95fa3a5817a2a5c5b5f2073f1256886123259da0b492a2aa7d13058c5a5fb748`,bytes:4060570,encoding:`gzip`,mediaType:`application/octet-stream`,uncompressedSha256:`4022983db158350fe82ccd8c6eaf1c9e1305ee9233a6d7e3f9d5508a4f937aa7`,uncompressedBytes:13557664},"wasm-objectivec/libobjc.a":{sha256:`1dde20d4ce78eed271ab725062ef25f1923b20d51384943c9b8f7177eb1fc2d9`,bytes:190272,mediaType:`application/octet-stream`},"wasm-objectivec/runtime-build.json":{sha256:`22a061daaabdf7301b1edffa20c31b6b6f677fc177899f41896c8fd5cefe9bac`,bytes:2602,mediaType:`application/json`},"wasm-octave/runner-worker.js":{sha256:`6efb48c22da84b1bbf627534b025a8929707406c974cb3a1d453104428945726`,bytes:9387,mediaType:`text/javascript`},"wasm-octave/runtime/bin/octave-cli-10.3.0":{sha256:`a4a7bdbb2ee5b4284a34ee76864c591697ed131965b4f0daca1f1777c65e6303`,bytes:541430,mediaType:`application/octet-stream`},"wasm-octave/runtime/bin/octave-cli-10.3.0.js":{sha256:`a4a7bdbb2ee5b4284a34ee76864c591697ed131965b4f0daca1f1777c65e6303`,bytes:541430,mediaType:`text/javascript`,deliveryPath:`wasm-octave/runtime/bin/octave-cli-10.3.0.js.gz`},"wasm-octave/runtime/bin/octave-cli-10.3.0.js.gz":{sha256:`72c38877ff26778a851125a0d49176e1fc19456e804a452712c093d1533ed378`,bytes:124319,encoding:`gzip`,mediaType:`text/javascript`,uncompressedSha256:`a4a7bdbb2ee5b4284a34ee76864c591697ed131965b4f0daca1f1777c65e6303`,uncompressedBytes:541430},"wasm-octave/runtime/bin/octave-cli.wasm":{sha256:`4a5beeb2b115c945aef3d0eabd45199d07b93835de6b9c0ef0d98b35b4a452cf`,bytes:41072033,mediaType:`application/wasm`,deliveryPath:`wasm-octave/runtime/bin/octave-cli.wasm.gz`},"wasm-octave/runtime/bin/octave-cli.wasm.gz":{sha256:`ae143ada53ac4cca6d31b352ed908e2b6b7f755fb68d73a2d528e902e0388342`,bytes:9954028,encoding:`gzip`,mediaType:`application/wasm`,uncompressedSha256:`4a5beeb2b115c945aef3d0eabd45199d07b93835de6b9c0ef0d98b35b4a452cf`,uncompressedBytes:41072033},"wasm-octave/runtime/lib/octave/10.3.0/liboctave.so":{sha256:`8b3d0820fb91357be8eaaf5b73d4d496a3ed1afc1e87d27a2afc792aeb0cacec`,bytes:25717874,mediaType:`application/octet-stream`,deliveryPath:`wasm-octave/runtime/lib/octave/10.3.0/liboctave.so.gz`},"wasm-octave/runtime/lib/octave/10.3.0/liboctave.so.gz":{sha256:`223b1eef6bdc0660dd007cc964009f2c10c1b974fbb61d6e7f7a781e39aa1277`,bytes:6660750,encoding:`gzip`,mediaType:`application/octet-stream`,uncompressedSha256:`8b3d0820fb91357be8eaaf5b73d4d496a3ed1afc1e87d27a2afc792aeb0cacec`,uncompressedBytes:25717874},"wasm-octave/runtime/lib/octave/10.3.0/liboctinterp.so":{sha256:`045789904ded5fe4122c394796fb706f9d37897d3793ac2586577915b1819731`,bytes:28531285,mediaType:`application/octet-stream`,deliveryPath:`wasm-octave/runtime/lib/octave/10.3.0/liboctinterp.so.gz`},"wasm-octave/runtime/lib/octave/10.3.0/liboctinterp.so.gz":{sha256:`eed299d7151b191076dcf4297e13888dd8b941cd39bb776d87d5e18ac5d52939`,bytes:6996767,encoding:`gzip`,mediaType:`application/octet-stream`,uncompressedSha256:`045789904ded5fe4122c394796fb706f9d37897d3793ac2586577915b1819731`,uncompressedBytes:28531285},"wasm-octave/runtime/lib/octave/10.3.0/liboctmex.so":{sha256:`b5524f73438d8d27d5633a6f10075a964c51f63de79cfc60eb04b3c645cebac5`,bytes:7013189,mediaType:`application/octet-stream`,deliveryPath:`wasm-octave/runtime/lib/octave/10.3.0/liboctmex.so.gz`},"wasm-octave/runtime/lib/octave/10.3.0/liboctmex.so.gz":{sha256:`ade7561359298b672d188ae5344919bc1eae77a0d434cbecfa9d236e4648d03f`,bytes:1941436,encoding:`gzip`,mediaType:`application/octet-stream`,uncompressedSha256:`b5524f73438d8d27d5633a6f10075a964c51f63de79cfc60eb04b3c645cebac5`,uncompressedBytes:7013189},"wasm-octave/runtime/lib/octave/10.3.0/oct/wasm32-unknown-emscripten/PKG_ADD":{sha256:`56365a62dbc03f82b055e115e74d3c5fa9094ad2b51fec6256df7252ff310ab4`,bytes:2591,mediaType:`application/octet-stream`},"wasm-octave/runtime/lib/octave/10.3.0/oct/wasm32-unknown-emscripten/__delaunayn__.oct":{sha256:`e3563009df295285d68ff50adde227d2fc3e3059ef21cb9863b1a5e52a6c47b2`,bytes:6962989,mediaType:`application/octet-stream`,deliveryPath:`wasm-octave/runtime/lib/octave/10.3.0/oct/wasm32-unknown-emscripten/__delaunayn__.oct.gz`},"wasm-octave/runtime/lib/octave/10.3.0/oct/wasm32-unknown-emscripten/__delaunayn__.oct.gz":{sha256:`e5142a45a7359493626e4240b7bc6626fa559e2034eaff1836279eb8c42eaf63`,bytes:1929756,encoding:`gzip`,mediaType:`application/octet-stream`,uncompressedSha256:`e3563009df295285d68ff50adde227d2fc3e3059ef21cb9863b1a5e52a6c47b2`,uncompressedBytes:6962989},"wasm-octave/runtime/lib/octave/10.3.0/oct/wasm32-unknown-emscripten/__fltk_uigetfile__.oct":{sha256:`f2467e6a25ba7d9af26571cd18a450f84ccc72ba454686c06d0a634d8fac23b3`,bytes:7633957,mediaType:`application/octet-stream`,deliveryPath:`wasm-octave/runtime/lib/octave/10.3.0/oct/wasm32-unknown-emscripten/__fltk_uigetfile__.oct.gz`},"wasm-octave/runtime/lib/octave/10.3.0/oct/wasm32-unknown-emscripten/__fltk_uigetfile__.oct.gz":{sha256:`1dbd78ed1423d838e332c90e5e25fa4cc13f393b1631adcbe2b0281a14f5d72f`,bytes:2207712,encoding:`gzip`,mediaType:`application/octet-stream`,uncompressedSha256:`f2467e6a25ba7d9af26571cd18a450f84ccc72ba454686c06d0a634d8fac23b3`,uncompressedBytes:7633957},"wasm-octave/runtime/lib/octave/10.3.0/oct/wasm32-unknown-emscripten/__glpk__.oct":{sha256:`a7b48f3cc481c0d2c43b610d2a80c96db76bbb96f50d1931e44017242c8f7ff6`,bytes:6962911,mediaType:`application/octet-stream`,deliveryPath:`wasm-octave/runtime/lib/octave/10.3.0/oct/wasm32-unknown-emscripten/__glpk__.oct.gz`},"wasm-octave/runtime/lib/octave/10.3.0/oct/wasm32-unknown-emscripten/__glpk__.oct.gz":{sha256:`40dc42f640d353eebff4be94f40db4286c66ed9db68a61a9459d40ebb62b7f57`,bytes:1929728,encoding:`gzip`,mediaType:`application/octet-stream`,uncompressedSha256:`a7b48f3cc481c0d2c43b610d2a80c96db76bbb96f50d1931e44017242c8f7ff6`,uncompressedBytes:6962911},"wasm-octave/runtime/lib/octave/10.3.0/oct/wasm32-unknown-emscripten/__init_fltk__.oct":{sha256:`66c12b2773330a6dbeb85b44bb5138014c90d97ad7a11cfd63c886f32f61cb74`,bytes:7634914,mediaType:`application/octet-stream`,deliveryPath:`wasm-octave/runtime/lib/octave/10.3.0/oct/wasm32-unknown-emscripten/__init_fltk__.oct.gz`},"wasm-octave/runtime/lib/octave/10.3.0/oct/wasm32-unknown-emscripten/__init_fltk__.oct.gz":{sha256:`53d789bcfa78d82f800b95a75bfc75681540c0202cfa6b6cb585f9fd6aeb5bed`,bytes:2207810,encoding:`gzip`,mediaType:`application/octet-stream`,uncompressedSha256:`66c12b2773330a6dbeb85b44bb5138014c90d97ad7a11cfd63c886f32f61cb74`,uncompressedBytes:7634914},"wasm-octave/runtime/lib/octave/10.3.0/oct/wasm32-unknown-emscripten/__init_gnuplot__.oct":{sha256:`4aff605d7ec8a8b9765a43d7bc391907509d1c9f6a98bcff44f433c1e449944b`,bytes:7001255,mediaType:`application/octet-stream`,deliveryPath:`wasm-octave/runtime/lib/octave/10.3.0/oct/wasm32-unknown-emscripten/__init_gnuplot__.oct.gz`},"wasm-octave/runtime/lib/octave/10.3.0/oct/wasm32-unknown-emscripten/__init_gnuplot__.oct.gz":{sha256:`374087bc35521ba9a34216c52a634d80cc7217b5df127894833b024bc3fb7aca`,bytes:1939951,encoding:`gzip`,mediaType:`application/octet-stream`,uncompressedSha256:`4aff605d7ec8a8b9765a43d7bc391907509d1c9f6a98bcff44f433c1e449944b`,uncompressedBytes:7001255},"wasm-octave/runtime/lib/octave/10.3.0/oct/wasm32-unknown-emscripten/__ode15__.oct":{sha256:`d12d305ee2d094568cb1b0dabfe97420692d9d3b8be01f8a6e2df6683020ef46`,bytes:6962970,mediaType:`application/octet-stream`,deliveryPath:`wasm-octave/runtime/lib/octave/10.3.0/oct/wasm32-unknown-emscripten/__ode15__.oct.gz`},"wasm-octave/runtime/lib/octave/10.3.0/oct/wasm32-unknown-emscripten/__ode15__.oct.gz":{sha256:`124d68b569a2ef683dad596fb987cbfc73f912373d96537d409d75ed8f16cb4a`,bytes:1929901,encoding:`gzip`,mediaType:`application/octet-stream`,uncompressedSha256:`d12d305ee2d094568cb1b0dabfe97420692d9d3b8be01f8a6e2df6683020ef46`,uncompressedBytes:6962970},"wasm-octave/runtime/lib/octave/10.3.0/oct/wasm32-unknown-emscripten/__voronoi__.oct":{sha256:`ecbb7a802437cf8b6f3bcf7e1b828a6ffe6271fb7820241f49a55e321b966706`,bytes:6963110,mediaType:`application/octet-stream`,deliveryPath:`wasm-octave/runtime/lib/octave/10.3.0/oct/wasm32-unknown-emscripten/__voronoi__.oct.gz`},"wasm-octave/runtime/lib/octave/10.3.0/oct/wasm32-unknown-emscripten/__voronoi__.oct.gz":{sha256:`0997da5f6a0d92be568b987f6a977d2e5dc96d0b911d62c2e752c287ce6fc25e`,bytes:1929937,encoding:`gzip`,mediaType:`application/octet-stream`,uncompressedSha256:`ecbb7a802437cf8b6f3bcf7e1b828a6ffe6271fb7820241f49a55e321b966706`,uncompressedBytes:6963110},"wasm-octave/runtime/lib/octave/10.3.0/oct/wasm32-unknown-emscripten/audiodevinfo.oct":{sha256:`6133ebebc462b7a848b2292c05acfb3a51a60a3bb854c0d77bfa9b04f9970347`,bytes:7002044,mediaType:`application/octet-stream`,deliveryPath:`wasm-octave/runtime/lib/octave/10.3.0/oct/wasm32-unknown-emscripten/audiodevinfo.oct.gz`},"wasm-octave/runtime/lib/octave/10.3.0/oct/wasm32-unknown-emscripten/audiodevinfo.oct.gz":{sha256:`a5efc0ea2094e89c3a11bb80136d8dfab90bb02459f043a46ec5f341ed1f91b7`,bytes:1932255,encoding:`gzip`,mediaType:`application/octet-stream`,uncompressedSha256:`6133ebebc462b7a848b2292c05acfb3a51a60a3bb854c0d77bfa9b04f9970347`,uncompressedBytes:7002044},"wasm-octave/runtime/lib/octave/10.3.0/oct/wasm32-unknown-emscripten/audioread.oct":{sha256:`6b4e00a4d6ae36975ab31a3faf9630770b297d115631ab8d6c41bb56071c2a83`,bytes:6965747,mediaType:`application/octet-stream`,deliveryPath:`wasm-octave/runtime/lib/octave/10.3.0/oct/wasm32-unknown-emscripten/audioread.oct.gz`},"wasm-octave/runtime/lib/octave/10.3.0/oct/wasm32-unknown-emscripten/audioread.oct.gz":{sha256:`ae2a4c4aecb4e657361cca4befbd21f28ac6a75b4c8167499e6437a190f12858`,bytes:1930244,encoding:`gzip`,mediaType:`application/octet-stream`,uncompressedSha256:`6b4e00a4d6ae36975ab31a3faf9630770b297d115631ab8d6c41bb56071c2a83`,uncompressedBytes:6965747},"wasm-octave/runtime/lib/octave/10.3.0/oct/wasm32-unknown-emscripten/convhulln.oct":{sha256:`2050d757c9697a331d111fdc49a5081b6976c14a22e1b905b436d1bd784a2ccd`,bytes:6962883,mediaType:`application/octet-stream`,deliveryPath:`wasm-octave/runtime/lib/octave/10.3.0/oct/wasm32-unknown-emscripten/convhulln.oct.gz`},"wasm-octave/runtime/lib/octave/10.3.0/oct/wasm32-unknown-emscripten/convhulln.oct.gz":{sha256:`4ec46e02cbb7c5270a4ac9db0b1a458d85956de3a470020385f52e8919626d5d`,bytes:1929680,encoding:`gzip`,mediaType:`application/octet-stream`,uncompressedSha256:`2050d757c9697a331d111fdc49a5081b6976c14a22e1b905b436d1bd784a2ccd`,uncompressedBytes:6962883},"wasm-octave/runtime/lib/octave/10.3.0/oct/wasm32-unknown-emscripten/fftw.oct":{sha256:`659b7105b1ea2d4b59ce7272b1c93c82b67adeae1c424401586e02381b2bcd48`,bytes:6962877,mediaType:`application/octet-stream`,deliveryPath:`wasm-octave/runtime/lib/octave/10.3.0/oct/wasm32-unknown-emscripten/fftw.oct.gz`},"wasm-octave/runtime/lib/octave/10.3.0/oct/wasm32-unknown-emscripten/fftw.oct.gz":{sha256:`191a5db3351a2163bec89d1438c75bc28f0ba51b0582781d6f8824487c49f2d0`,bytes:1929805,encoding:`gzip`,mediaType:`application/octet-stream`,uncompressedSha256:`659b7105b1ea2d4b59ce7272b1c93c82b67adeae1c424401586e02381b2bcd48`,uncompressedBytes:6962877},"wasm-octave/runtime/lib/octave/10.3.0/oct/wasm32-unknown-emscripten/gzip.oct":{sha256:`607d3aa8c22302d008d4bae47f63401989ff3a6c3eefcfe2f38e2046ae0ab352`,bytes:6963614,mediaType:`application/octet-stream`,deliveryPath:`wasm-octave/runtime/lib/octave/10.3.0/oct/wasm32-unknown-emscripten/gzip.oct.gz`},"wasm-octave/runtime/lib/octave/10.3.0/oct/wasm32-unknown-emscripten/gzip.oct.gz":{sha256:`3f519b77a9862cf67e9c61e0e431ac13d9c4027583d37a4dfcf36957a14ec2cd`,bytes:1929901,encoding:`gzip`,mediaType:`application/octet-stream`,uncompressedSha256:`607d3aa8c22302d008d4bae47f63401989ff3a6c3eefcfe2f38e2046ae0ab352`,uncompressedBytes:6963614},"wasm-octave/runtime/runtime-manifest.v1.json":{sha256:`d6517c5ac4c3e8342b49b91a1873ff0e894cebf0d305f24d3447bc54cf5b23b3`,bytes:200045,mediaType:`application/json`},"wasm-octave/runtime/share/octave/10.3.0/data/penny.mat":{sha256:`765cefa1b75aa655c72d09d16459fd7f7c242c17e44d90429b6e9b0eb427be34`,bytes:55675,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/data/west0479.mat":{sha256:`2fb227adaac714a92027fc249c0e3c43f29f654917d821efdb6e3172da093eff`,bytes:39123,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/doc/octave_interpreter.qch":{sha256:`b68088aa0f1415f36e555f70f95d47ce86968a2e2f2aec17b0a4372246ca9b2c`,bytes:5193728,mediaType:`application/octet-stream`,deliveryPath:`wasm-octave/runtime/share/octave/10.3.0/doc/octave_interpreter.qch.gz`},"wasm-octave/runtime/share/octave/10.3.0/doc/octave_interpreter.qch.gz":{sha256:`92fc01079e8d3a0c26bc4415946cf5c5bf7d5b4483ea4b36436ba0e1c85f2873`,bytes:4052075,encoding:`gzip`,mediaType:`application/octet-stream`,uncompressedSha256:`b68088aa0f1415f36e555f70f95d47ce86968a2e2f2aec17b0a4372246ca9b2c`,uncompressedBytes:5193728},"wasm-octave/runtime/share/octave/10.3.0/doc/octave_interpreter.qhc":{sha256:`51831a06a196616c2e614ce53743dfde9c83a492169bf955628bea71d0085b4e`,bytes:552960,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/etc/CITATION":{sha256:`76dffab4a081ca869133f2c86a9d771b39aa7f6bda79d4e6c1146373f8ccbcb8`,bytes:769,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/etc/NEWS":{sha256:`0e2f410c26233121bc3a50df04764a63b25afb2400a467af3e3e1306a8cec89e`,bytes:24141,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/etc/built-in-docstrings":{sha256:`2704fff13c2a390a5a2d2c703dbc91f888785ce3a92a66915a966090d5cfb1b1`,bytes:694361,mediaType:`application/octet-stream`,deliveryPath:`wasm-octave/runtime/share/octave/10.3.0/etc/built-in-docstrings.gz`},"wasm-octave/runtime/share/octave/10.3.0/etc/built-in-docstrings.gz":{sha256:`d5b2c9e99d7f5b9259b61416ae66f392ebe472bf2f07fe824472ad15800edb2c`,bytes:158310,encoding:`gzip`,mediaType:`application/octet-stream`,uncompressedSha256:`2704fff13c2a390a5a2d2c703dbc91f888785ce3a92a66915a966090d5cfb1b1`,uncompressedBytes:694361},"wasm-octave/runtime/share/octave/10.3.0/etc/doc-cache":{sha256:`cd8cdb42e432de7d3c63d2533e8d0b434b2ac71ae17a132ec0951651ff346c19`,bytes:2141499,mediaType:`application/octet-stream`,deliveryPath:`wasm-octave/runtime/share/octave/10.3.0/etc/doc-cache.gz`},"wasm-octave/runtime/share/octave/10.3.0/etc/doc-cache.gz":{sha256:`130f68952df78653f114f10ca97aedad72e4a28970adf89b6cf8a0f27348ab16`,bytes:424794,encoding:`gzip`,mediaType:`application/octet-stream`,uncompressedSha256:`cd8cdb42e432de7d3c63d2533e8d0b434b2ac71ae17a132ec0951651ff346c19`,uncompressedBytes:2141499},"wasm-octave/runtime/share/octave/10.3.0/etc/macros.texi":{sha256:`649203bb427ac2926daedfdcbd506e6f8b3be503ce9988d9deb2ba6d356db128`,bytes:3692,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/etc/profiler/flat-entry.html":{sha256:`5d74699bd918c9082d4498c9e9f4ef0e7a8a9231e504000e46c57068e8fce0fa`,bytes:119,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/etc/profiler/flat.html":{sha256:`886fd768972e211139f3d20d5bb77f44e9182ad087a5e681f3ac471ec964a956`,bytes:532,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/etc/profiler/function.html":{sha256:`3a9ebe096fbe09275e8b651452bedc818f364e28da2a2aea16f2e191476a04da`,bytes:572,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/etc/profiler/hierarchical-entry.html":{sha256:`4e76d375d610bca5b700e4b7b90ef0b7cc82e235f943b638a38431b531e35ecb`,bytes:115,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/etc/profiler/hierarchical.html":{sha256:`83b55e8fc588adac990851a81986d717e87517bed5ffbb0a8918488bce6ffe9d`,bytes:547,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/etc/profiler/style.css":{sha256:`eb664bc0a21e62a90c07677670cc1d5ecf88c51f1a5702f0ed39200328d59f64`,bytes:872,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/fonts/FreeMono.otf":{sha256:`9caa77b38deba808dafd1894819b122a8bf5f61419e279da79f3e3efdcfce2c3`,bytes:392560,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/fonts/FreeMonoBold.otf":{sha256:`cf52bf6456cfd2fdcea36c6f4af60421b695715e3c22a56c72e6b29c0b79a8a6`,bytes:203480,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/fonts/FreeMonoBoldOblique.otf":{sha256:`3ce26a00120b91cad1a07f16d0b588e6c31ee99eb91f3bf34eb88644ba913e5e`,bytes:194740,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/fonts/FreeMonoOblique.otf":{sha256:`e3867fbdc2d1b4f7bb53abb70c3ea35f5cfa16470285db404a08b588515afd07`,bytes:245512,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/fonts/FreeSans.otf":{sha256:`d3e9138ccf76ef516cc6af867e4e7ed8776331947235824f924c5886186b0c80`,bytes:856800,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/fonts/FreeSansBold.otf":{sha256:`860760177d95ed4bd030cd2cd05f29ce23737dbd5ff7080954bb7f5802d0f42d`,bytes:305436,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/fonts/FreeSansBoldOblique.otf":{sha256:`d7385b41aed42d731cfec5c2b01933fa738931af0f8d8d258eddac9657228663`,bytes:233476,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/fonts/FreeSansOblique.otf":{sha256:`16034e8e2a3ff4a988f15423bf2252b69c1f750feb9123a39dd65297c39737a9`,bytes:473976,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/imagelib/default.img":{sha256:`f5bc060c9986c4385f4605d580559fe6ffce6d1c380b14b37f0a8017f0c9fce0`,bytes:1226,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/imagelib/octave-logo.ico":{sha256:`1a2f0f6a104cc81e8df137911d867e601e535bbb7f7286c6998f8fecd3112204`,bytes:29273,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/imagelib/octave-logo.svg":{sha256:`57f121fdbc6a227c8341cb0d79b25391e7c400801402cb9ddaf1a63f45d6f879`,bytes:3961,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/imagelib/octave-sombrero.png":{sha256:`16670aa91f7b419d9cfbcbe30c1cfc5827e4a15c9a2e235a25acdaf95bc5e02d`,bytes:23362,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/+containers/Map.m":{sha256:`d4e34cb6900898cadc6bb39724a260569d8271130cb336aa531c4f3bee944b2d`,bytes:30681,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/+matlab/+lang/MemoizedFunction.m":{sha256:`fb129a05095ba96429d8933fcb3c54295a89a55f3b961e504a986697ce5142f8`,bytes:7016,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/+matlab/+lang/makeUniqueStrings.m":{sha256:`80c3d7effc1a9cb224cd33978f465de473c4d9f6744bcf3864e13f6d84b05813`,bytes:8319,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/+matlab/+lang/makeValidName.m":{sha256:`9390b59c26494dfe91592a8d33da106c5ca95864147d6ea0dcbe15e6ef45aa09`,bytes:5528,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/+matlab/+net/base64decode.m":{sha256:`fbf7b73b77c4046d2e3355f2ddd3085cb1fcf43a985a930545577618ec7785a7`,bytes:2321,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/+matlab/+net/base64encode.m":{sha256:`ce84741c821249f4973ff49389741dd326dec2debcd2379da2cd1184baee1430`,bytes:2348,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/@ftp/ascii.m":{sha256:`682044d88c2bea3fff1ce6393b9ad7fc6df0f452680fe6a9a5e962f73c314008`,bytes:1551,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/@ftp/binary.m":{sha256:`8d633ddb7868980b0f357711d0766938bfeb0fa13d0ea3652a6a1a25a44c1ac1`,bytes:1511,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/@ftp/cd.m":{sha256:`a62912a5182cf96a6dcd91c324360189aea8b5f74912bfa57ea0e8bcc6ddac70`,bytes:1881,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/@ftp/close.m":{sha256:`64d24e940b557b4a4e41903977d37d7146953bbd2dc38ee98ae652fcb48b8bb5`,bytes:1376,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/@ftp/delete.m":{sha256:`2cf6a463d4ec33f06ddca95c36312acc2ecdd03816dd17df02c9af0ffd0ef6fe`,bytes:1431,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/@ftp/dir.m":{sha256:`62d37285c01bc6a1eb3ccb2f86cbc008267e29c2a379b6ffc6a7d68524fde7c7`,bytes:1732,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/@ftp/disp.m":{sha256:`f65d3cf38bc8b2eb1d37daf07414031f4d8ef7ea1dafaba8fdc822bc5f2fc6e1`,bytes:1285,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/@ftp/ftp.m":{sha256:`cc474d2564cb843cbdcc54468f0b26bf9fef27016f7ec84e24b495d4f1074814`,bytes:2788,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/@ftp/loadobj.m":{sha256:`8f08817d5372cb5abbe759a62bcb7f4da93c4feeaaf98925c95fa3d861e12347`,bytes:2013,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/@ftp/mget.m":{sha256:`5b16885fe04609bb8a916ce7c4dd76f8ec3fd252ae63d8134e4457bd09af3c09`,bytes:1926,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/@ftp/mkdir.m":{sha256:`cafdb1e03c07a04b9ba3a47e5c78e908dffb118b33a519b356c06f2fce6edb5a`,bytes:1421,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/@ftp/mput.m":{sha256:`a4ff427b0bf0a0c16106ef209ed9425f606e9759dd9d42266abf93880400bf94`,bytes:1889,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/@ftp/rename.m":{sha256:`17146f633805a60d6263732de21e3d3f65f64abd8eb53c63167306a6293a9854`,bytes:1518,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/@ftp/rmdir.m":{sha256:`dfe3c19c4c373c32e214b4d656d0c29715d7b30d5654b59aad3d6010f228f1b6`,bytes:1447,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/@ftp/saveobj.m":{sha256:`e6c9be82d6807d4141ba55be91d11d04e7f76f6b6c534d6e8a30a776a1e6e09d`,bytes:1734,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/audio/@audioplayer/__get_properties__.m":{sha256:`c81c57e9806dade7b614f1b2a34b699a49cd4d64797cefc68ec7f6b4ff22de88`,bytes:2233,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/audio/@audioplayer/audioplayer.m":{sha256:`f9f69205cc7b32d58da36e1ee7b0731571edb4e06e5f727d97e23d585c6ac124`,bytes:5525,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/audio/@audioplayer/disp.m":{sha256:`2e86cce8013868cae71174c9e66cad93ff4146db43d7f47a0083ca4422a3c0e2`,bytes:1454,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/audio/@audioplayer/get.m":{sha256:`1fd40ee750d2e04e8d9be363ad387d29952ce42ff89e88c443bbae4251deb042`,bytes:3587,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/audio/@audioplayer/isplaying.m":{sha256:`92cecff40021f8c79194fd8e9ea2e30ad56538b882a278a5be38ea87c9b6293a`,bytes:1515,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/audio/@audioplayer/pause.m":{sha256:`e72ea87b74bc2eb20227cef371c49a39eb670c16fb3749ed0a7aa8a7d19f44cf`,bytes:1362,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/audio/@audioplayer/play.m":{sha256:`77ba9ca29c8d7b9e55b788388b2841b7cc9156f4cefd749e35bb9227d3276fb3`,bytes:1871,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/audio/@audioplayer/playblocking.m":{sha256:`0aca9bf88394f37a98af8cadf037c4ac2cb93a52430aae02e4632a02d42062a8`,bytes:1919,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/audio/@audioplayer/resume.m":{sha256:`7b319114b94f2e025887492492bca0043136ef9310c12a714fe97911cb01b793`,bytes:1384,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/audio/@audioplayer/set.m":{sha256:`1d6ca968bd1bb90df97f7fc2c2a6c9495322e04d1f261dcf97a2831eb1e6949b`,bytes:4106,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/audio/@audioplayer/stop.m":{sha256:`81a2f9038d387bade974fb3608cd7960728700eeebac7f7482ed728678ea7afc`,bytes:1419,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/audio/@audioplayer/subsasgn.m":{sha256:`6d0e5f0c4b7c172552c5a4f873042b7367dc6dbe8a40cc38c0aa6205377aea89`,bytes:2081,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/audio/@audioplayer/subsref.m":{sha256:`6a749c7a9b7f99892c30088986e1ee52e068ff35bbbd2e93971bb2ebe685c224`,bytes:2024,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/audio/@audiorecorder/__get_properties__.m":{sha256:`54c4eee52a27782591ef52e787ea0faa24f305fc99352a4de98b9887fe3cb480`,bytes:2293,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/audio/@audiorecorder/audiorecorder.m":{sha256:`2c81167d5f701702f640bb45bfc3fac8a0c160d846a09bdaffb5e6bc3987cc5e`,bytes:3779,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/audio/@audiorecorder/disp.m":{sha256:`977fcfd8c2c6d6cd3e1dca567d120ce3e0f03b86eec70d06f8bf157a697906b7`,bytes:1470,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/audio/@audiorecorder/get.m":{sha256:`58fc4a2d01c885d1fdb759d8859df5dba77886cfb3b97406c48b12dd8cf6eb43`,bytes:3535,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/audio/@audiorecorder/getaudiodata.m":{sha256:`22fa22f7ff5a019cfea0834b4240570521837ae6286e1b1ca10c31111de45021`,bytes:3523,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/audio/@audiorecorder/getplayer.m":{sha256:`c3f0a9f57a4d41627d9e7ec8f0995a8451fa2778631571d837ee602a190425e0`,bytes:1832,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/audio/@audiorecorder/isrecording.m":{sha256:`13c61ae990b9730a73f241aafdfe3b747472934db9a9f8936fef7b8d3570c5cb`,bytes:1541,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/audio/@audiorecorder/pause.m":{sha256:`f294418c66298486f67799e1aee520730e041b9c64c9bc900bd70a83cc88c358`,bytes:1389,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/audio/@audiorecorder/play.m":{sha256:`10c584ef5d6095efa9a66bf1821b1b1cbf4f5a38df72a1c66ee17584ccbed264`,bytes:2067,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/audio/@audiorecorder/record.m":{sha256:`5dfc9deb6baf8eae9a10f7658e5052e73540702f01328076613a8f482524af5d`,bytes:1730,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/audio/@audiorecorder/recordblocking.m":{sha256:`af400cb54c0cb645224a13b5b45b3986772977e9ede35678b800236f89c93538`,bytes:1545,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/audio/@audiorecorder/resume.m":{sha256:`9deaf138eee5d8f7b2211a5721b9c745bfa6f26b0a0a71e208ffddb6b6a67200`,bytes:1411,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/audio/@audiorecorder/set.m":{sha256:`313012e8edb1d7376becfc7405452109dcf1997f24ce0580963f2bf93097e842`,bytes:4191,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/audio/@audiorecorder/stop.m":{sha256:`aa9fbdadfaf2c399bffa89f159b901504e3ac5943284daee64a161e0d048ab83`,bytes:1428,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/audio/@audiorecorder/subsasgn.m":{sha256:`f0ebf0d7ec22bf5975a2d385b31136b74ebd8aa0f5e1ddc0214cdf819b914222`,bytes:2100,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/audio/@audiorecorder/subsref.m":{sha256:`12fa6c2cbecca378d84b674f4faf0d7fa9f182db408f90d8ca073b0ca0240a87`,bytes:2050,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/audio/lin2mu.m":{sha256:`bcba9a3582390ffeca8449d802c08c971763e8c259dbdfaf3f0d00fae04fcdb3`,bytes:3173,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/audio/mu2lin.m":{sha256:`5536623e802bca3dfa2fab1615960eb1ff8527ac5bfd0e93f3ac9a3479785238`,bytes:4481,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/audio/record.m":{sha256:`1450271fb2bc1f8d4649dedd60f3214692e789a4a4447b46d0481f653e6ca4f5`,bytes:2356,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/audio/sound.m":{sha256:`2a01f5b3f4d2eb38d0a8942d1cd8439adc97ec0721bb613b97de91335c2526c5`,bytes:2541,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/audio/soundsc.m":{sha256:`d375374e43210a1e1957ded40cc224b01380dd1c7b4e7a8644fca33f5eb331f0`,bytes:3944,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/deprecated/dsearch.m":{sha256:`4cb92e023066fa61fc61b6c20e6a44385be6d2ed138fda3dbac6a7743d0e5f0d`,bytes:2371,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/elfun/acosd.m":{sha256:`69510ca7d63a691c180a3676990c1915a9f459eb8be0d2db5b6394a33e70e100`,bytes:1407,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/elfun/acot.m":{sha256:`bfa7f26e46468f2e7c116180581fe44c3187a25013478960d413ab7e883fabf3`,bytes:1519,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/elfun/acotd.m":{sha256:`ffd0e34b73d0a30a9a897af5adcec5768c12ccf7349af6c64b7d2b8c5f4977c9`,bytes:1403,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/elfun/acoth.m":{sha256:`da2f17a7061f340a5bc737cc41b06e00a6d4e4696b5c33838b07f49da90d2b7e`,bytes:1513,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/elfun/acsc.m":{sha256:`2c0acd6bf043fd8835f4da4c64382ab951cdad094b24213d9b1fca5ee1ac0f31`,bytes:1516,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/elfun/acscd.m":{sha256:`d6ae9d7309d9bf2a17fb6fe1a16dc805af35a904ffb472becbd169ec8f701cfc`,bytes:1409,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/elfun/acsch.m":{sha256:`7c0b90660f6812ec55e90d7258294061cecbe7a9b6ad24641f38512881617d87`,bytes:1421,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/elfun/asec.m":{sha256:`9ab1958c6d5ac07e01db15321ac4c520c05711552ceb5c14f26a22a5da4ad128`,bytes:1528,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/elfun/asecd.m":{sha256:`d2f876f3ae5240ef9760d2617018979bdaa2af1b1175d2e9d1cd47bb0ffa9228`,bytes:1407,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/elfun/asech.m":{sha256:`527864ad4649a3bde417da4e79b01df6d5215e8b3693eea8239cee37963d60f7`,bytes:1684,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/elfun/asind.m":{sha256:`bfe349cf8b2b0cc6385b25db8a6fa549559a6df3ce4b05770d83fe498a9da935`,bytes:1405,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/elfun/atan2d.m":{sha256:`abf49630f6bf0f1fbc0af2d3d09014e7edf4871b09befc53eeb0a8465dee599f`,bytes:1527,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/elfun/atand.m":{sha256:`cf605a8637b90dfed83aa706faa6260c2b333f19f84814e5229b0366a136311a`,bytes:1408,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/elfun/cosd.m":{sha256:`39cc399d00a39b7988a248c64de999f14a30b11fe19d3502d7d4a8cc3b21f58c`,bytes:2192,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/elfun/cospi.m":{sha256:`5be541b0b1cd484d90d1b9ea6b7e4433472d24f3b5eb45ed3a1f88a8196261f0`,bytes:2466,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/elfun/cot.m":{sha256:`ab45ac639537880025f3dbc476bb80dcb77682b5ac115130fbf3d59233b7f551`,bytes:1515,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/elfun/cotd.m":{sha256:`2c6083506474a9965f199d37c3187d6308b9c96a386d63dec193923a487e811c`,bytes:1463,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/elfun/coth.m":{sha256:`27038ffbb2265c55f3ff8e5c748d2337ff4f95434d78727991628af55b994b6c`,bytes:1410,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/elfun/csc.m":{sha256:`2ae6c3fa21742237a45ef2ca44021c3c2cf2fe741161f5a169566842ba990bb1`,bytes:1515,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/elfun/cscd.m":{sha256:`b01c5699c82c2bd99d49dc0939810d551bb6b14f1ff7825a66c27c722f2aecc5`,bytes:1464,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/elfun/csch.m":{sha256:`6b252fdc62f8733ca91f58c970f9a2987f41f1930481a465843c9cb80a45fcd6`,bytes:1410,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/elfun/sec.m":{sha256:`b3741ba983a6d54b98dd6b90b95d7839aa9ecfb0cd0ba16173abb414f01ba328`,bytes:1521,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/elfun/secd.m":{sha256:`81a7aca8c8ae5e99f7ea08c5dcb4570b392c2dc630f38a0ad74ece60c800c3c1`,bytes:1460,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/elfun/sech.m":{sha256:`2af3ca12f6260c1ebac61f1a3297f30f37b2a82db47c682f1e99b48a30343c2a`,bytes:1397,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/elfun/sind.m":{sha256:`d154e1f1e0165635444c959841d34da6ad08a7afaa4de34c8e9992a7a21f199f`,bytes:2541,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/elfun/sinpi.m":{sha256:`1d6337cdd3d6e1c75b98f146440214404ab0eb5a1dc129e39e5ae7ad851ff8b4`,bytes:2350,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/elfun/tand.m":{sha256:`00f0bde0bc9c3d6279303f5ba8060c6bed907c8ee4c22238d23ef6fdfb92e5e6`,bytes:1734,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/general/accumarray.m":{sha256:`9ec4d2f1d425c3fa8a6f232ebb9fa0cfe89d15190d7e7ae2eb11f89827175a47`,bytes:15366,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/general/accumdim.m":{sha256:`77b91a08a6378b011cf365e497d61804e1cc9587af1217a244b7cc0f565b4faa`,bytes:6355,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/general/bincoeff.m":{sha256:`6e42d9e4711f56e92d91c14fa913b4e5753c84da5e453f451434fcb7298d80d2`,bytes:3424,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/general/bitcmp.m":{sha256:`532fda25510872a14916cef9aca4cf0efdd9b71c7b976b5a747397896c9dd8b7`,bytes:4391,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/general/bitget.m":{sha256:`63d92618d5a304ba05e11f1df3533b5f7d6b3c6a3994b70aa2cb8bc26dbf5160`,bytes:3857,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/general/bitset.m":{sha256:`2c9110435b098d5dfab04fae7017a39c158162970856531b83364a6673b78d62`,bytes:4917,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/general/blkdiag.m":{sha256:`f12f00a8831059035fa71e67c13791bc7fd0e6b2a47a78fb5d9aebfa6383a406`,bytes:3213,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/general/cart2pol.m":{sha256:`4fcd806e5345771450e57d747c5141ec9da0c59aa71afbc2e3f50bf3959c281e`,bytes:7221,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/general/cart2sph.m":{sha256:`ac26d5e6508bb7fcd5e1d20a704be161b56752d0cc33bfe5546459b4e069c30f`,bytes:6267,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/general/cell2mat.m":{sha256:`da6783eae186f563da517d38b9e0ff1fc062d39a43b0b028f555e554a473688f`,bytes:4528,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/general/celldisp.m":{sha256:`b4796cb30ef23518201e07c3218a0cc1dd93a0268bb7b5e3e39f76472b0aa25b`,bytes:2576,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/general/circshift.m":{sha256:`d0d671d09aa3a2e957104e6c47bd26427e3c70546a99bd5a8da5849cbb5dbb87`,bytes:4538,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/general/common_size.m":{sha256:`78e01d66c3d551e318c55afb7b15aedce58ed1452bb021b593e74026b9dcc065`,bytes:3135,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/general/cplxpair.m":{sha256:`4c99cc20c54ac9486039a51ea816f134948069324a08ca2de24fec76c56f339c`,bytes:6630,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/general/cumtrapz.m":{sha256:`a4166973887f9d9ada87f36dff81240c7109032f7ca3121cdaf760b4b46a2700`,bytes:5473,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/general/curl.m":{sha256:`ab2953afbe83fd6d55e038a42591d9de065649a9c577d53c39658abe02546549`,bytes:5491,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/general/dblquad.m":{sha256:`5908afb03ce34087313e32540a456f8f4435cb7cf93775e939e641cb4c0d3c07`,bytes:3749,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/general/deal.m":{sha256:`c09760521ad69c9a32406a3b03fd774ffc49ce36b5760d4fdba218a92ec38dff`,bytes:2745,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/general/deg2rad.m":{sha256:`792e65116f830f775fb4d1c2c30125748be37cf3558ede462604b12f9d63d916`,bytes:2273,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/general/del2.m":{sha256:`05a6bab3efea05c5e7db4727bafe852dda509c542b4e0270c3a084be0dfbc390`,bytes:9966,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/general/divergence.m":{sha256:`880da99f9f4c0b479751cb09151a382047f89242af2928702e053360b0dd93ae`,bytes:4211,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/general/flip.m":{sha256:`e806b4a489de5332a6cb6684bcc0116ae31d6abb2c7b825767d407bc54fe91b4`,bytes:3002,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/general/fliplr.m":{sha256:`54975ba5c8753fa52ca85ab49ee64ed133ae24799e66920175ba915d21b116e3`,bytes:2403,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/general/flipud.m":{sha256:`762a55aa04cac90039243881ca8d253663e1398ca2984a83cd5959634a619809`,bytes:2360,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/general/gradient.m":{sha256:`93b63bdf35f30f238f1fad3557583009303d06561fea412454e84d18071ec6e8`,bytes:10403,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/general/idivide.m":{sha256:`9cd0aa9daaa5c9e3b4c7337e4dbc90953eca046699fbc57307beef8676226c83`,bytes:6609,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/general/int2str.m":{sha256:`abf1d1d14375f182d94d05da7583b53b124bc9d82bf3fc161144684e8c3045b1`,bytes:3299,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/general/integral.m":{sha256:`6322f28c54c099051b47ea015a36979e2898f0ea527244e7193a13a622826259`,bytes:12541,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/general/integral2.m":{sha256:`e58fc75d5e13d252cc451eb431d879d599a2648ef4628360b28563c212324871`,bytes:14491,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/general/integral3.m":{sha256:`d6a71e610deedfac39ea172ccc94934552ba1700330caf13def7fca89b696943`,bytes:15197,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/general/interp1.m":{sha256:`4319805bfc3aef720f5f7f9a6364059102fa1a1418aaca3ad0ac1d95f9e12e01`,bytes:31980,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/general/interp2.m":{sha256:`f31423d63707a3c3520dafbf659790ed4c86196020bbf45a267a6caae33806e4`,bytes:27381,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/general/interp3.m":{sha256:`2fbef0d57285538872aab0ca7ac480b1b371902628b2b70c507b78f528d729a4`,bytes:11291,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/general/interpft.m":{sha256:`91f610e9fb0af2d1e90414a6667845e9e6d5b4e69c8a3f5c425e044424704e85`,bytes:4447,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/general/interpn.m":{sha256:`289553428f99afb6ec04c17b89d1d99227ad4e188af49409fd725d42d65f8c82`,bytes:13423,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/general/isequal.m":{sha256:`9abe1fc68008e81cdd6b5a3f1f2b87807de4c1685f72d1c2498903f5c0de9399`,bytes:19975,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/general/isequaln.m":{sha256:`3a14320cdb25b4e431559d5f7497c07a42f9f5e6d040bddf3fe5b2bcac36ccb3`,bytes:10689,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/general/isuniform.m":{sha256:`0b57d3c6c2e8f58cf262c31a30db05e3f0cc7663fdd01029a9110356b117b6ad`,bytes:4142,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/general/logspace.m":{sha256:`71f9c6d90fb51fb4e8deb47ec0974e3a55f9ab40ac8e6e27faf7eb172a55f4b7`,bytes:4467,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/general/nextpow2.m":{sha256:`8de49271951f6d6e8f7bf0b510f259b13282c22537b651cfc37a4ec3a7b2c88f`,bytes:4241,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/general/num2str.m":{sha256:`74ed32e24d7865ab7871442845d19ec9b094f4fb1c5f75d15e8d7bd4c0c8bd1c`,bytes:10620,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/general/pagectranspose.m":{sha256:`fe7dde19b9c6fc19ccfe9e081f001c9b90df282f6df82debcce457ee348fa1c8`,bytes:1782,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/general/pagetranspose.m":{sha256:`5b22437e718519bfbe2cdaa070ee18bd4fcb6f21529d62546f347aa2e7705a69`,bytes:1754,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/general/pol2cart.m":{sha256:`1ce830bbc6716399656a83b0ef55c1b9ce5c0adbd99ef2a09d2504f6235e79b8`,bytes:7496,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/general/polyarea.m":{sha256:`dda525579fe6de25ff3baed59ea12ffd00bd1efd70ccf192586322f160201906`,bytes:2522,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/general/postpad.m":{sha256:`e5c009336ee10c1d05155fe6cd1a482b0e25c699bfb8fe04f659da74e7066f24`,bytes:3720,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/general/prepad.m":{sha256:`b64c16262757c7958f18b9323ffff38ce82bac0086fde39ed615ae29538cdd7d`,bytes:4066,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/general/private/__splinen__.m":{sha256:`27a1492788a25760dfbe9ae48154abadbe08631b80eafd7b8de7427c65b901c2`,bytes:2050,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/general/quad2d.m":{sha256:`46e3061dff9f96f9a3bdb15d128e11678411efe71c577ee4e80a7850e65f8f3b`,bytes:20645,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/general/quadgk.m":{sha256:`8a65c316d83736ad49b729021464b226c939dcae94204db75e57aefed4eb551b`,bytes:25228,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/general/quadl.m":{sha256:`238fecc68aa601a88192464cc79e2ad4565b188931a069ed5495b4704de13af7`,bytes:7384,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/general/quadv.m":{sha256:`5e7e36deb849c4fdada80a587e5fea4c291797d2ead203c1ebd004fe3c1dd0cb`,bytes:8269,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/general/rad2deg.m":{sha256:`e960b8edb94259a1174096900c2d014fa199cf7cb1e155bb70f6427ab482d028`,bytes:2254,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/general/randi.m":{sha256:`4f0a9555b098ec8f76c236ec071721043e955e88518c387392e6b328a26ba3a1`,bytes:8400,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/general/rat.m":{sha256:`d20193ca3f78c94e61a37c1062abc34630dd77b62cc4ae2fd9e7bff052d24fda`,bytes:9821,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/general/repelem.m":{sha256:`bad6ea115c43c5a6859e1833b5bfa474dc756aeeaa47770af4a465f12e9b7590`,bytes:16567,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/general/repmat.m":{sha256:`1221c515771900afd631bf0330a2e52e84443159e469637d333b9e8f6f5db129`,bytes:6797,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/general/rescale.m":{sha256:`3e135724b81f27844295967465a590ceaaaf3d31ddeedb1a1096605970e76682`,bytes:6131,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/general/rng.m":{sha256:`cf421b8ee23c21fc850b72f3c3a8d3191dabcde87e21e9b10e5d8a9a63d904ee`,bytes:9743,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/general/rot90.m":{sha256:`cb1b3fea68348e1b90e9cd14c67044d897f695a8c156e2093d4c896a80cb5bbd`,bytes:3999,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/general/rotdim.m":{sha256:`7535539b2e85c75579e44dc3e1cb0aab2146ca7ab70e9fb09accca0a6198257c`,bytes:4616,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/general/shiftdim.m":{sha256:`e1c1cab191045b475ef867d8eb44108beee62b834196cce670427aab4b6a51c6`,bytes:3145,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/general/sortrows.m":{sha256:`d8705c3a6cec97e2d30e1259cadf4c3981af2a42c4eb74e9115b7673a1cf2d7e`,bytes:4671,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/general/sph2cart.m":{sha256:`af0394325ab1b518911f3fed45d15dc8cdfa6427ea7633d9232464f53a77c91b`,bytes:5979,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/general/structfun.m":{sha256:`4757f3c27828c59e552fdd2cc8a95150bf7fb3dc00ee8eb3cb27eb03600c0bdc`,bytes:6198,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/general/subsindex.m":{sha256:`0943839ad03834cb52a4065fe7fa6c9e82e24aa8e0abfa8e458c4f3bd5c43ead`,bytes:2427,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/general/trapz.m":{sha256:`1445df5fa29da3f00a008df6b95ee2bc2ef7e80f854cf4525a0b067c6a7348ea`,bytes:5360,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/general/triplequad.m":{sha256:`edd6cde705c80dfdaf439da303556e81995e8f760ab3fda67427eccd79b1bc98`,bytes:4129,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/general/xor.m":{sha256:`77e493577f43f12727e0c0d06f47e0c2bd1ee2a0ac7f567aa267376c8944f670`,bytes:3233,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/geometry/convhull.m":{sha256:`9a843187035f2bd7ccaccf37762dcd13a30c0564ac4d9a33ddbf05e3f5f398bf`,bytes:6519,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/geometry/delaunay.m":{sha256:`a0561c02e10b9c90e273de10c95400f6a746f14696a307aa4e5fc4aae784aa10`,bytes:7700,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/geometry/delaunayn.m":{sha256:`aa57b0aa98728a6ec62910c27c6358d75e7136cf42eda1a256bc514f4da88c5a`,bytes:10704,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/geometry/dsearchn.m":{sha256:`7ccbcdf7d8763b1a583df36d1ee4c87204dae747cc73e142cd4baf9d89f0d697`,bytes:2944,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/geometry/griddata.m":{sha256:`ce4256378ed2373c25f49059895b38bd97e88f870e6001c4714724867fcc74a7`,bytes:14594,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/geometry/griddata3.m":{sha256:`ac134ebcef344e701e8fbad8461065f33a4d79ce5dbde8a062a50398c4dfe9fb`,bytes:5277,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/geometry/griddatan.m":{sha256:`4f970140b9cfdad9a4239b287c3939f78a7f81200ce0957db17e68544d3cc7a0`,bytes:7318,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/geometry/inpolygon.m":{sha256:`086f6db62f0919da232b77400d8110c2b535d897c1e69343b11e70bcedb5b45b`,bytes:5969,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/geometry/rectint.m":{sha256:`a139ccc6de19ea9e14d92d50adc1fe68bb256ad082a98bba819e3fb3355773c0`,bytes:4385,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/geometry/rotx.m":{sha256:`14eec57890e48c39cbb7dba357b9cf8c1b9354190241beee79742cb6f1fa67ae`,bytes:3079,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/geometry/roty.m":{sha256:`bcbd51226c70e1c7812c78ebb9861a0f6eb53c4f8a45a26b835f5459f99a2037`,bytes:3132,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/geometry/rotz.m":{sha256:`7f4e88cf064aba8dc3512a5a86f85f3531d4cd73a75bc8711feabbd946da478b`,bytes:3127,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/geometry/tsearchn.m":{sha256:`fd3d4f018ea616d047ab81b7ab5596dc39a8950067e67b6246c5c4a6fc13a6e4`,bytes:4208,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/geometry/voronoi.m":{sha256:`7a86129a57daa8e46c073bc894d009f1637af348a181bebd2ae62da8f7836f0f`,bytes:7292,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/geometry/voronoin.m":{sha256:`2ffdc2225695f3e1ea54e13166f0f8a0f013f69cdbd79ab8385322ef518a0697`,bytes:2840,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/gui/dialog.m":{sha256:`60b002cb0e559ed611ff422bbf7b34a3e10920b13333ceac091fda8bcf9e2110`,bytes:3223,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/gui/errordlg.m":{sha256:`43cd1d3dac7e99b5b9d7e4435fe6893bc96c57c97d312e6ebf26845f19541c5c`,bytes:2828,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/gui/getappdata.m":{sha256:`28b2056b8793cda6f380d637a8eef04d497e93ed514268f17e0851f69810d514`,bytes:3085,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/gui/getpixelposition.m":{sha256:`86eb3f74ef3429ce95c4306014a9ca5ba07fe52bf5126e15556f92a6b21685e2`,bytes:4335,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/gui/guidata.m":{sha256:`6f69ee86c083248a844a6eceff2fe3ea1a64254ef116727dc7b8dde53e360c51`,bytes:2236,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/gui/guihandles.m":{sha256:`c73a3a77a51ada772cb3d076910bb8c556183deca08a3f59d8f7b9fbe84683dc`,bytes:2542,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/gui/helpdlg.m":{sha256:`4a9aab6e06cccb7cf7047cdc1f72888ac7d66623f31620b713f6b3c174a31eb7`,bytes:2533,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/gui/inputdlg.m":{sha256:`2a24632789b759184fddc0f1dd54ad97a0ace3765170fefb508d16b4d76a6ebf`,bytes:9335,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/gui/isappdata.m":{sha256:`19f58408c85ab663b0f2967d6410ced38810b7391cfe7fac7a4cc3f7c7553d78`,bytes:2316,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/gui/listdlg.m":{sha256:`26238f68e0d8912cc86ddd32ed21ed74179281e23133cff278c91f91eb2d21b0`,bytes:7002,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/gui/listfonts.m":{sha256:`f4379e2b627a571b6689c88fe7652dad35d55ec5b54bc5d22f21059978bfdc63`,bytes:2413,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/gui/movegui.m":{sha256:`483c4ffc2c5a85e576f508eb7009c9e8641f7501b342262d84fbefd317c6d3ad`,bytes:7254,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/gui/msgbox.m":{sha256:`1935f5c4cf140e1f5f14884212a2afbfa7a498a557c7e65236ec0a1174e7d38e`,bytes:12266,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/gui/private/__file_filter__.m":{sha256:`30a3f2639bd3ac869cc23c62dfc9cbdf1444a36cffea4a1f6a5fcf0036f20996`,bytes:3139,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/gui/private/__fltk_file_filter__.m":{sha256:`e3e9f154070d5ac086c29957010118e04edd651428a101cf6f1d83c211d1a1dc`,bytes:2145,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/gui/private/__get_funcname__.m":{sha256:`f190a8cf18c6226e0fe27ed5bcc61b4838d80477b7d4f7a7f57ea7882db9bda6`,bytes:1791,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/gui/private/__is_function__.m":{sha256:`d419d3033bbb2dc83e3c741f944b661517cad64610921154593932b17c8ee99e`,bytes:1366,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/gui/private/__ok_cancel_dlg__.m":{sha256:`1adb337041b2a182a39861921e735f4f495c0131733179ed7554b58a45666ee8`,bytes:2296,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/gui/private/__uigetdir_fltk__.m":{sha256:`494300fcf812d0c953343415751467b523509bf5fc534f261572162e36554344`,bytes:1440,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/gui/private/__uigetfile_fltk__.m":{sha256:`e6f9018091fa59c6a2ea644a3e8863617a4c38854f9e565863760b13ed4fc1c5`,bytes:1693,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/gui/private/__uiobject_split_args__.m":{sha256:`b2adcee3bcfd2e095146d6502f4b5d82cededdc84b8f82ef84f303e309943201`,bytes:2263,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/gui/private/__uiputfile_fltk__.m":{sha256:`467affb03ebad08598bdc0b8c739f25708db714d99b86ff8b5e4af58d59b9a92`,bytes:1685,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/gui/questdlg.m":{sha256:`221a5b51adb7224019d2e419d0284de6252f0357d8c6cc812ade78cd04f527aa`,bytes:6718,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/gui/rmappdata.m":{sha256:`2a016299c94c8e5fc8371c1693a1dba1007f466277492c39a889c0bc81ad3983`,bytes:2872,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/gui/setappdata.m":{sha256:`8f65c5cdc497828ad0277ab9fe49eb9ae0c785a9446651f7de4781c7534a4a17`,bytes:5076,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/gui/uibuttongroup.m":{sha256:`31ab86a3d8d33687ffcd9f2668289b944e8bb055720801ed67b9680da0635901`,bytes:8273,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/gui/uicontextmenu.m":{sha256:`086af382d9d6fd66e9470d3f4fa5841c281b48d2d618785774ce07de80b1e729`,bytes:2416,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/gui/uicontrol.m":{sha256:`faafd0ccf2c40499a1cce50b62f912ad256e8b5db23c84ffa7f39e3226c8f913`,bytes:5532,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/gui/uifigure.m":{sha256:`c14368cb4748a9d36476d91e75fd383587c5e44b7877d022930c5eb3440fce6a`,bytes:3703,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/gui/uigetdir.m":{sha256:`a117c65553120cc7ed343b703e20cee7ea2c0b0ad8ba60077391e6c34d5e1042`,bytes:2592,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/gui/uigetfile.m":{sha256:`d55e162b6036d7c7656b41d364c5e6ad823a0bfa431eb1db06e8ffb1685a95ba`,bytes:6855,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/gui/uimenu.m":{sha256:`2bbed5876e794fd57b9740c022cca579f5a554506b4307b4a8aa62132930c25f`,bytes:5655,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/gui/uipanel.m":{sha256:`e71c81d57b9247782fa5417e2f1f9e305fd0d1d390d4cccba32b6c3ea463803d`,bytes:2692,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/gui/uipushtool.m":{sha256:`4397e67f859174d5c603d77fb6fc6d41c2436891d9cdd70e9d7654f704ff248c`,bytes:3004,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/gui/uiputfile.m":{sha256:`7a2539d2f1124941e0c459e74638dc455bec56bf9c26ab7c092e6858bd9e65aa`,bytes:4885,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/gui/uiresume.m":{sha256:`f7f4ef406e1464e7a00c879cdea76ae47d8ccdd2eb92fd23fc3420119297bfaa`,bytes:1753,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/gui/uisetfont.m":{sha256:`4448802877c10ef0cc6be5377df6b84cb57c323e22109a2bf26466446ea9e343`,bytes:11901,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/gui/uitable.m":{sha256:`5f3541c0897c2243a03e643f0c1d12407c352da0713d35830e6f848a86867303`,bytes:11610,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/gui/uitoggletool.m":{sha256:`e47db1f531ef5958f207d5bab57c30a3e9f50d3ed0b864467ffe318401a72441`,bytes:3042,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/gui/uitoolbar.m":{sha256:`d9df57461cccc1b918e0a6c40e4e794da444ab79917196584321063022e371de`,bytes:2409,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/gui/uiwait.m":{sha256:`9ae7658116c667cbb2259aee1554a5a54d77f634cc13216c6c505d24b2383d97`,bytes:2965,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/gui/waitbar.m":{sha256:`26e165421a7638340aa3788adc3342db379b5ef925dd537fa553ae6a356b4def`,bytes:9823,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/gui/waitforbuttonpress.m":{sha256:`64a640e26c34ceb62ecda39d2f9c54d552437f4b25e98c17b73ce3ad0190e420`,bytes:1586,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/gui/warndlg.m":{sha256:`bea09afe30c5b42a1c3411ceeb7363bec939c332669d6f0feef927589ce64554`,bytes:2848,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/help/__gripe_missing_component__.m":{sha256:`5a28e42dba005ec5ca22b51fbe373553c7efd4b358a2e3e973ba971ee07f86f7`,bytes:2707,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/help/__makeinfo__.m":{sha256:`9e0c6b409d26ffb38425e64b6ad4a2b6fc545d4b1ead1b8ef878998b9c6009cc`,bytes:6953,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/help/__unimplemented__.m":{sha256:`bace9411c097eb2c4dad8abef3c48e864d129221d4cafa47ed148a8fd4dec957`,bytes:46987,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/help/ans.m":{sha256:`158afe8d175cc553adbc4ce0caa1e89f990c0f3269224c9d286a24b62eb46544`,bytes:1428,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/help/bessel.m":{sha256:`ae3368352a7f6c7de02c97169aacc8c3b60cded14696446f5c9e084492931f65`,bytes:3917,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/help/debug.m":{sha256:`9f895c03f7db97ea68a490ca6197dc18edacf5c9f1e59302222045aa6b99e8f4`,bytes:3334,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/help/doc.m":{sha256:`98400666afb4d50aff40493d8144781f00e8a4fe704f6a4602f5f5175c44cea6`,bytes:3643,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/help/doc_cache_create.m":{sha256:`d38476c5f569913652aa67fa3891e7198850ae6379490716633eca633a9ad054`,bytes:4906,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/help/error_ids.m":{sha256:`987e55b46b279339e98e21f3f6b4e1f7088903c5d0c4ddb1795232c105e41264`,bytes:2255,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/help/get_first_help_sentence.m":{sha256:`7b6ef00e8b9fb835dbb13208210c96a217734c85b7552d910859916d8d710f23`,bytes:7293,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/help/help.m":{sha256:`f97c4ac3e8fa603055536bc8129d20615c9d82b30f5bf461cfc0c331caf9168e`,bytes:6707,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/help/lookfor.m":{sha256:`4ca79d3e6010f8a2e79562ebbfb8c60a6b231ce155c83ffbfcec516c49715bdb`,bytes:7249,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/help/print_usage.m":{sha256:`f50dcf482757985fc588daa79540d91e43d9b74d0abc9823e826fc100db99e0d`,bytes:8919,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/help/private/__additional_help_message__.m":{sha256:`c0dd62a1987f6de1bdacc01dc19e19054b7676b10637258a38b1c053398fae43`,bytes:1614,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/help/private/__strip_html_tags__.m":{sha256:`53ded77586e91331d4dbd81051268b2f5195af116942a0c4a47c9f952106865d`,bytes:2757,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/help/slash.m":{sha256:`39af499c4a42073ceaf2ceab123da122ba70411a95b05e8e0dd1307cdd531fc1`,bytes:3344,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/help/type.m":{sha256:`560143357eca8d773577fca93953c2c3306336d537485439a6190a832822d336`,bytes:4822,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/help/warning_ids.m":{sha256:`e2deaeb204be8b96254e81dbcac7e99a40d892720b0b6c2873112ee31023052b`,bytes:19554,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/help/which.m":{sha256:`95742241980b7ea4161ec372599e35e04ebc4d153c0c82749ae5622a56274160`,bytes:3949,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/image/autumn.m":{sha256:`4b6c6d54dd5d5752da5949e9ede97bef15b93dfad43b227cb1ff12aa76cdb95c`,bytes:2748,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/image/bone.m":{sha256:`ee2371c173ff104541b06d4a506e02b8bdf103e87e09828ed0eb2669ee87cf41`,bytes:3633,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/image/brighten.m":{sha256:`95a3771095fba95c3b9b0b2bb28382cd74caaca82d0f4ca35630e8aa45c6a617`,bytes:3257,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/image/cmpermute.m":{sha256:`1d31584d2b3fc5436e409d7088d808378117925404ce14ecaf56da1026c8d47a`,bytes:5120,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/image/cmunique.m":{sha256:`edc4c74e202e0dacf62bad4311b5b5b0cc7d16867ffc257ec4860b9c057521f0`,bytes:6915,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/image/colorcube.m":{sha256:`687efa981f9c3776756d65d033ed87b123d900829369d9cf029f1551f5ea00b5`,bytes:4403,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/image/colormap.m":{sha256:`ab4eb88ee11e7e2d28a062768a8a5cadbe4513f7310040b0e7e3515a8664f094`,bytes:8986,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/image/contrast.m":{sha256:`1e5e9dd40ee44300c7f231f21ade665e719755d3068f0fba227bcad602c224c1`,bytes:2322,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/image/cool.m":{sha256:`ea96d1765aac859ff853ea94c9599ca0db0641145e4b41d164ae13931cc5f4f7`,bytes:2688,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/image/copper.m":{sha256:`5aa2bfe4b62fa974e96ccce857ba72b172da40d87ee2f0e6227c1eb5b2f4f7c1`,bytes:2827,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/image/cubehelix.m":{sha256:`87357a3c90f86907867a0799a3ae30364e489fd0b1af7b7736c9e57924c9d126`,bytes:4381,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/image/flag.m":{sha256:`4625addbc949a41205070043a7f334b90d56df27ee52de697f18b32c4aa2a395`,bytes:2988,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/image/frame2im.m":{sha256:`125ae573cdbfaaa0ed46f5718324d406762e7564920f3e6a4d69b35e3abbbc7f`,bytes:3219,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/image/getframe.m":{sha256:`cf3869609c11bb7f1c6102c3168d7b8b323bbcfe13af847babeec1f136964b0d`,bytes:7042,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/image/gray.m":{sha256:`1b52b9437049f216dc8bb44445d3e46a2cedce5789b2a9fed02c8b386f346fc2`,bytes:2663,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/image/gray2ind.m":{sha256:`f8d5bb5a806841b601faeeb5a4e5b40a70b699db8b94cecdb6f3123c3df96b44`,bytes:4344,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/image/hot.m":{sha256:`c3b9183a0e66ac0379aab7896411a530216b2e30d2fd80d3e9b0174c87c0e25c`,bytes:3337,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/image/hsv.m":{sha256:`e4dd014f0be4c070c24118ea14ebb09690ac11d1b22d9430eee7fcd541a1c295`,bytes:3070,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/image/hsv2rgb.m":{sha256:`e9b4f2313c7e62b4a9e1b2764ccfd7beb7e7d8dc215785824414ad5a7bfcbb1e`,bytes:6595,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/image/im2double.m":{sha256:`ae913dcdf37fb89017e4c7bc337a74f84c43d435452e290112a9708d93ac36cd`,bytes:4889,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/image/im2frame.m":{sha256:`6fa6b44b1f38ad0836df756dd2cf63d127892bfae3df3a99a8b0ee5c0b4c02f3`,bytes:3344,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/image/image.m":{sha256:`de3b33f868bf6fa1d013931f85649f6620e161c806cc3eb5c0524bc6cd201f99`,bytes:8267,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/image/imagesc.m":{sha256:`de0637513eb5e8707b97362f2757df8d6b05578090b28828e6ceca0065f29ef7`,bytes:5973,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/image/imfinfo.m":{sha256:`7488708c21d5f7632851ba7282add0dbc6dbdf88920086b2cda72bf32a6abffd`,bytes:6471,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/image/imformats.m":{sha256:`0e09734c3c6600464b4339854efbd25f1d80599ebd06c7bda4387d0d1a29d2ba`,bytes:16445,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/image/imread.m":{sha256:`f4b05ec0fcae212af5b752049c89bae4d09045b61afa4fee9c2d541b8daf09ba`,bytes:8435,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/image/imshow.m":{sha256:`ad9c2cce14a9a8115031b1b3385caa8258682a2356741632fd8f15f1919fc406`,bytes:9490,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/image/imwrite.m":{sha256:`02707415e9a8c46f6b64e8e16727cb4442a7833bc2c8c476268c6676f36e1889`,bytes:9569,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/image/ind2gray.m":{sha256:`09dcb0f12217c908fd433df2b40426f9112094684dcff0db7a0404846a4b0279`,bytes:3874,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/image/ind2rgb.m":{sha256:`d5dcf61a342cd8c73c5fd08cf8c4a1df0e5b2d5e12cb9b0686708b12cbf124de`,bytes:5797,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/image/iscolormap.m":{sha256:`c291f661962d157ceb2be04df9a49bf087226bc1f9c38b047c7a400ae4af794d`,bytes:1950,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/image/jet.m":{sha256:`2c6bd1773c3737d76a8271d69218c34d7c3550e60d8a03fea1f529093edba351`,bytes:4270,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/image/lines.m":{sha256:`82d48ea8548fd9d71980174c0045cdf784971271994d1269a57d36d50699de3b`,bytes:3070,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/image/movie.m":{sha256:`6577ef3dcd2fb4958abf7c325102cbe32344ce6386b96d7106016be7e838620a`,bytes:8031,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/image/ocean.m":{sha256:`0e614bee27820bbaf02ef2a3cfd9ee1ac6064884f4dd82a480afda6e764fbc8b`,bytes:2998,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/image/pink.m":{sha256:`ee429d5142fbc398e183b06cd811eb5dd85bf84b5c6fb93d3d9a12cb637190d1`,bytes:3554,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/image/prism.m":{sha256:`e9bc7427eb99041d3b66d30e4ca9af51cbc138d4783c00208ac577115cf4bcb9`,bytes:2877,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/image/private/__imfinfo__.m":{sha256:`f2df200a7b3001ebb6a79ab2c1efcf00f5ce72a981f37fa45d5edfc8e6dbc5e5`,bytes:1642,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/image/private/__imread__.m":{sha256:`899a9caede87c367225d9119a55742db29170c3c889041acda8a45495cd0a9e9`,bytes:5870,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/image/private/__imwrite__.m":{sha256:`843280018006f572f9886e7c4ca2b42810cc063f10f2f63b2635eaa583832df6`,bytes:9078,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/image/private/colorspace_conversion_input_check.m":{sha256:`bdcd19c242ab78edb2c8f1d19875e9c5ff6fd1caa14c898f4d15577466a31c4f`,bytes:3143,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/image/private/colorspace_conversion_revert.m":{sha256:`34b34488e86a8a954e9a50889ee4e99c5d12270f29246839fd0e55cb93e78fe7`,bytes:1749,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/image/private/imageIO.m":{sha256:`93b2daf1ee1e186e6e028602ae7f533ab1e653fa7f37f1db3a238fdab46b0c30`,bytes:5231,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/image/private/imwrite_filename.m":{sha256:`53f9937571e81fbc07f895ffef7416648a0058f2d95b3da54af01879c8a75947`,bytes:3160,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/image/private/ind2x.m":{sha256:`dee785f2c19bc6654e5f452948d54b825b6f34a9dd53ea5fc677719ea929accc`,bytes:3311,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/image/rainbow.m":{sha256:`deb4d610413814d8255836f7a9a88f50b13dad891db744307f9a20f923f23eb5`,bytes:3179,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/image/rgb2gray.m":{sha256:`5efac4073ccb09dc518f9b7cb4fee937649a762872507d03a8e6a5b8fd85f60d`,bytes:4994,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/image/rgb2hsv.m":{sha256:`5c72156987dd377601c25b2d39b98567facf0c6f8b24d6ce31fe4981c4faed7b`,bytes:5532,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/image/rgb2ind.m":{sha256:`645f4adf0f30d7e3ee230c8a87cdb9a9e4a86dd8017c7979445994d9afe4e802`,bytes:5386,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/image/rgbplot.m":{sha256:`fd61fad763ff44db347bc64d1bdd42e15c350f2ead456014d7cfed5cd8c89913`,bytes:3040,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/image/spinmap.m":{sha256:`870f1f119786cef33f82f449b77d3358e0ad284f9b3f50194f4bc893179af16d`,bytes:2422,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/image/spring.m":{sha256:`b2ee65bb4fad57af077b9283094cb81eb9bed8f1a416a5cc2a1cc143b580bf69`,bytes:2767,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/image/summer.m":{sha256:`26774a1dc614a26856883acac67dc1837655c8260dc589c502fd07c16c25d920`,bytes:2765,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/image/turbo.m":{sha256:`4ef3030bcf75f4e9b8d57a4614873cc4d8ebd95d79251636749424404a8ef9d3`,bytes:16645,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/image/viridis.m":{sha256:`ac9b5788626a31202f2dead113c97c771ce10c815c766b2bf18feaac607936a3`,bytes:18056,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/image/white.m":{sha256:`aeeb25914e6e0d42a0f189ffccc97c357d84dd65f917696422d52383701bcf7e`,bytes:2516,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/image/winter.m":{sha256:`477df2bdb4cd0f621ec4de60fe0d97ae729a542850d11e710684552c484e3229`,bytes:2732,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/io/beep.m":{sha256:`b35e417d5289cb624366288386efcd08a0a34810ea7c8633abc8d9ec87d85f83`,bytes:1451,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/io/csvread.m":{sha256:`a94e9b2391a7a3f4cd2a12449bf3d721cba0415de4f8174f439e831348d6146f`,bytes:1826,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/io/csvwrite.m":{sha256:`0a1fcc8b22a9460e14cea6aa870536c947530687cdfb2205b40c2760c8072a41`,bytes:2096,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/io/dlmwrite.m":{sha256:`0bd65842906e40885b3d7b3068ce7a3af0d95e7dc591b873d920c300f02439dd`,bytes:6902,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/io/fileread.m":{sha256:`1475cec958afba63133d65da4bbe84735a1bba8270d48fc7d046736562483424`,bytes:3565,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/io/importdata.m":{sha256:`dea088e822d259574caaf40f8a799342534c3b8a4233245a474e252c3cbc9b70`,bytes:20459,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/io/is_valid_file_id.m":{sha256:`070afbe09f54616ecca46e9e004bf0be25834d11bf8333d4b66f44a7e0c35eac`,bytes:1867,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/java/javaArray.m":{sha256:`1cde9a827cfb6502146017c0453e29cd17f9ed691fdbe5efa68aa07356244d7b`,bytes:2119,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/java/java_get.m":{sha256:`982740d8b3f628f36c3d521ee93dca511b990a0203337d8e84d87b1a93a3523e`,bytes:1905,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/java/java_set.m":{sha256:`f70081de2278b3fc545e7bfea3f310c18ba2346687ebfd37c8e3240ce5388bc1`,bytes:1956,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/java/javaaddpath.m":{sha256:`bb634de513778ba0f8c2ed0221d77ed90e603c07094d66feaa56bbb3acce13f6`,bytes:6067,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/java/javachk.m":{sha256:`02ad02162b81cf6d83fa925667ec3538a6c7e045f6d18ec60344abb12723ae9d`,bytes:5663,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/java/javaclasspath.m":{sha256:`1378682d6862383d7a473d016f74c4b29c80ece00cee2dcdbe6dfde75978eac1`,bytes:4144,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/java/javamem.m":{sha256:`6e718ad4966195919f272b3eef26ef1637ea71bfa61d3858b716c1dcd3f684f2`,bytes:3620,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/java/javarmpath.m":{sha256:`b0a8bbebb2e06399af67bccc494094d3bef6f52405bb246646ba63fff1a61da9`,bytes:4110,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/java/octave.jar":{sha256:`6f901ca5c0a50ab08cb10e10572bdc3ee767b3be6df00d84c52af8c38654e696`,bytes:14318,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/java/usejava.m":{sha256:`1ee5a77f02a12a03dd4f1f9fb3a56dbb28d3d315ec6436a7ccdc50ede1a65dea`,bytes:2992,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/legacy/@inline/argnames.m":{sha256:`7e91abeb5934911d0c9d891ec9d0ae96dfeedfadb048570228760c953429b66b`,bytes:1455,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/legacy/@inline/cat.m":{sha256:`e19d08f5937d7c5a72fc112bae4c8c4e73ce9482bd94b683a78d34bc8b8afacf`,bytes:1410,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/legacy/@inline/char.m":{sha256:`7301a0fb9fc97d2527e6a6fbf8515ea693b9a88072bee9c2609042a8cf4f3b75`,bytes:1409,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/legacy/@inline/disp.m":{sha256:`0560d24401cd8d351a8dd987391158063e1f59909e3262bcb49505ed85451ef0`,bytes:1442,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/legacy/@inline/exist.m":{sha256:`2545bfeac441c808d28eea80ad3adc06c468cb8e549198321c80476e0391f116`,bytes:1251,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/legacy/@inline/feval.m":{sha256:`0889a6c69d152525a7e60f9e2c02e96694e30533a0f56464ffb7c8e53f500679`,bytes:1337,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/legacy/@inline/formula.m":{sha256:`97d55e4f0cf1181880692b92da5f2cbc5f4fb972710ab76ad9a5a2ec70fe56b1`,bytes:1400,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/legacy/@inline/horzcat.m":{sha256:`bb2e6809673e3f02ae8bdc7a9ad1bf0ec45790853fcacd317feb870f27ffd2e8`,bytes:1435,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/legacy/@inline/inline.m":{sha256:`6dd55dc73354a550cd3a04e56f8d0698423d899a8d5f79c75bda29c36c72196d`,bytes:5975,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/legacy/@inline/nargin.m":{sha256:`29048e399457379691b80892cd8ce56630b3e362b54424b10ed688f69a048e86`,bytes:1292,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/legacy/@inline/nargout.m":{sha256:`dffcaa6a4c3c8f036bffb5165819fb914ad6468882882bc602bf65bd586eb92c`,bytes:1395,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/legacy/@inline/subsref.m":{sha256:`1a539d3a03ecbdf84fa26f92abd6a225d5c8ecfb22266e25750745ff133ab298`,bytes:1616,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/legacy/@inline/symvar.m":{sha256:`8bf4aee2b06113d6ea7b6f01f748022ef97c0ce74de5c24fcc499f03f6b8762a`,bytes:1453,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/legacy/@inline/vectorize.m":{sha256:`f2c8343ce526377a79189704e9e02da1fb9f4f06efd53cfd85ede3d9c8377d0b`,bytes:1741,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/legacy/@inline/vertcat.m":{sha256:`049e0506db4bc8470f35be8c5ca7d0f2963b4c91d970e8883728e8626574313e`,bytes:1433,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/legacy/__vectorize__.m":{sha256:`cb90d92b8699c1c85fa4432e0d498c8525898cc203fcab9f8afc907c4b369e00`,bytes:1903,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/legacy/caxis.m":{sha256:`131445bc514d844aa2e7437a11e2039e3a272728c58f1cd255585678b96307eb`,bytes:4465,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/legacy/findstr.m":{sha256:`e4793fc3e484f48ae4540923e280a43ee11663a8131e830c329e327682c49388`,bytes:4995,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/legacy/flipdim.m":{sha256:`d37173adee1d5b7c3764edf42ae472a415301aa5c6dbd5ef1ca3201e6a26cc25`,bytes:1517,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/legacy/genvarname.m":{sha256:`9ca2e233fff134fad599ab4f9c3ebabf626a9a95959a0c12c1b39b4c38b7f92a`,bytes:7930,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/legacy/isdir.m":{sha256:`81b93407f26e077a8069c96e9c775525d979a4a885ca7e3f7c55087d13c50282`,bytes:2235,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/legacy/isequalwithequalnans.m":{sha256:`1d5f6dca9dc258c5f365362d8ed200fc3353dcbe8fda2b70e82cecad2bbb632f`,bytes:1721,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/legacy/isstr.m":{sha256:`69cb6f0bd66fe6895f7172a6829941e289bb17d4f03a0e43649f1c71211cc422`,bytes:1648,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/legacy/maxNumCompThreads.m":{sha256:`859a9ebe8fe470519091de2ff11a7d1b12fdc11478e87adbefd780d8fa1abae3`,bytes:2551,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/legacy/setstr.m":{sha256:`2029b9d1b557b89768a0bc85f8ef16eaa18fb5a94a84a4c8bcf63337869875df`,bytes:1650,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/legacy/strmatch.m":{sha256:`dabdf0b80f6bc13cebd3deb60e9c6061a55c729a4d503c9a7ebd4de4430c4965`,bytes:5740,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/legacy/strread.m":{sha256:`fcef0be3e168754f5ac36006e55486c6dc21ee41d4ad0e79306ad0a94c47074e`,bytes:42103,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/legacy/textread.m":{sha256:`2eb64cf04d484acb32769b830a9bdf51ffa06077d7f5c267fca5fe7636211722`,bytes:17462,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/legacy/vectorize.m":{sha256:`41d38fafdfb3fcb53e13486ec7e01114b6c867295df940673fbac2c61931b851`,bytes:2923,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/linear-algebra/bandwidth.m":{sha256:`baf720cc6b8b22a3e695fc9e6ece0a0a259aad1d5aff0bd94ae95485675e29c6`,bytes:3707,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/linear-algebra/commutation_matrix.m":{sha256:`1fff1e2e78318761c4cbfaf1d363cebe82fcacf19a35f1a845f08e0898e42e3a`,bytes:3057,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/linear-algebra/cond.m":{sha256:`f6623a8b95205ccc8e1d37f9417196b6e2ca0572f2a9839d4384b9ed1aa6e22b`,bytes:3420,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/linear-algebra/condeig.m":{sha256:`187bbb64ceb2716ccd5afafc242c2631bd9639eb65c32206f58a3a627236189e`,bytes:4260,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/linear-algebra/condest.m":{sha256:`aa49841e4f030a1ed97ae0bd589c517e15d55f885dacb4672ccadaea61bded21`,bytes:12524,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/linear-algebra/cross.m":{sha256:`850fcb4c9dba899c927fd1eecdeb4ada550c90aa54dc0983da186328b56b1f08`,bytes:7072,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/linear-algebra/duplication_matrix.m":{sha256:`6ddf54b6db597d6b3f8fc6c190d0f093b7e4575fe0256ca2fa53fc144d6d32c8`,bytes:3070,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/linear-algebra/expm.m":{sha256:`06fa2a8dff43ca97ae534087b8ced2cf8a1507dc2e0f4af9453a17c11d58228c`,bytes:4337,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/linear-algebra/gls.m":{sha256:`650cea0c1c51d7c5b3b5b866f2de911ec28b84e77050d716336abb2ab8655fb7`,bytes:4895,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/linear-algebra/housh.m":{sha256:`f4594f4e90e36b1d2bd4b3065737b345a78d2cd732b77be816e4479bd07dfebc`,bytes:3410,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/linear-algebra/isbanded.m":{sha256:`b535ca27ab379053a5ce15dd9bccaa47c4e26b3e5032cd88e219711d43e7627a`,bytes:2956,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/linear-algebra/isdefinite.m":{sha256:`2f04eb4bc4f58369669be2c2eb34904ae4418c4eb8f0848dfa77c8cb6b91de48`,bytes:3106,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/linear-algebra/isdiag.m":{sha256:`e4e0037814a1274edd2a3752a66689d773dfb233e96c3ea035f4a14f765e726c`,bytes:2054,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/linear-algebra/ishermitian.m":{sha256:`4a45416c4c443f159f8b681db6cbe46d05deca4d57985ee8b6aadcf04389f668`,bytes:5095,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/linear-algebra/issymmetric.m":{sha256:`d3e10d0895d469a3e52bf99d91c82d0feea40b83d204ae24332ebab76178589e`,bytes:5134,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/linear-algebra/istril.m":{sha256:`53e46117a8f80607946d60748fdcd6b6222fc1f6900884bd1fe40f2663cb6e85`,bytes:1889,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/linear-algebra/istriu.m":{sha256:`3fc50176a68203af69788004b074ddf28e9809dd1e42b537bc4e6971675ebd64`,bytes:1891,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/linear-algebra/krylov.m":{sha256:`cb4efcb6b850d9132bf76079c922939e5983f5ee5e26979e694fff678da1303c`,bytes:7106,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/linear-algebra/linsolve.m":{sha256:`84998554a47a30fc9b03f885a77081b926134baded5492f10308090d46505e61`,bytes:4508,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/linear-algebra/logm.m":{sha256:`ff9fd24137c3e6af5d77a3bd45dc0c49efc4d9659bce2c145d8e0f59fcccc0fa`,bytes:6310,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/linear-algebra/lscov.m":{sha256:`0dee545e90ff9bc0ee2114c8bfb721b8c0bb69611914d1d573dec0aabd445e11`,bytes:7934,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/linear-algebra/normest.m":{sha256:`e905f1512713f46570971deadce24d6f463d4e01c43d33fb2ada0132f769f957`,bytes:3142,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/linear-algebra/normest1.m":{sha256:`842b3be1918aa7c192d5ab01758859577eefd8af7f575117d8690c25daa0beb6`,bytes:12238,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/linear-algebra/null.m":{sha256:`c6b9968e7db1f68eeacc544b66b9f22df9223a50c3541f24ed84cbbdd389bcb9`,bytes:3470,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/linear-algebra/ols.m":{sha256:`099e9340f67103d3a7a525523cc7dc4174f20af6cea571bae4408519e4cb4123`,bytes:5491,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/linear-algebra/ordeig.m":{sha256:`26b54add8c773301519ef4ea8525ae070d5a924c773dda6ed63d9beaf561b1a6`,bytes:5079,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/linear-algebra/orth.m":{sha256:`1b9f953d9f9e8277baa17f7c0dc6ac80feb254fc22db0f227c882e4869ef59b3`,bytes:2226,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/linear-algebra/planerot.m":{sha256:`857b667d27ed5f12d8ad6f12b45dfa1425bb701654df251284ba3b5502fc851e`,bytes:2520,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/linear-algebra/qzhess.m":{sha256:`3456fa60f90d1b59c8f85826483f5367ac2ecbeb1a6c4dc31857097cf208e994`,bytes:4321,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/linear-algebra/rank.m":{sha256:`5ff3d7760150ca4d594f1a37d6a907a0e0bb31157ece4f861e95d800e7ff6a85`,bytes:4297,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/linear-algebra/rref.m":{sha256:`5e8b918af23a12166a631abf55aeb8df5cce6b38b9104471340e45931cd12651`,bytes:3601,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/linear-algebra/subspace.m":{sha256:`f4ce850d6f83c2deff2c15eba75e99223d6e18d88cd7f0b158a7ef7077a493a2`,bytes:2611,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/linear-algebra/tensorprod.m":{sha256:`9c1895b55114b470b52fd2c2ff199ca466e6dd0c8868339fe6488a21865d8e85`,bytes:21727,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/linear-algebra/trace.m":{sha256:`602099fe009033ce4642d6496b5fefb61c80b64a449d7a9659554ff8dd3d7bf2`,bytes:1849,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/linear-algebra/vech.m":{sha256:`60551030b4271314e7de08d4dc00bdebffad6eb51878a20700d253637f2d71b2`,bytes:1973,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/linear-algebra/vecnorm.m":{sha256:`a633342a1839a75ad8e838bfc0fd4bc6a05ddad7216b057af4dd500793444e8b`,bytes:4299,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/miscellaneous/bug_report.m":{sha256:`ed9d64fadd73d4fad2374654b42a10bff54e7165394d71c01cc58358390513bc`,bytes:1868,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/miscellaneous/bunzip2.m":{sha256:`d441ae02a6f249f7248481327a49c77a315b0a9fb6c41a38f3ec2d165a7c3218`,bytes:1901,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/miscellaneous/cast.m":{sha256:`4d389982ec915021a4a9777c13a4f7021ad54f7b25be63f2c4decc949623cdc5`,bytes:5747,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/miscellaneous/citation.m":{sha256:`9335d7bb4362b93877af70519d8a8fa919037648a9694e15b94f9397fb92bc2f`,bytes:2216,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/miscellaneous/clearAllMemoizedCaches.m":{sha256:`9ae8b3a937b4b78d84c09215a31dc4dae9c7e45861611e34a73e9e7691e7c049`,bytes:1489,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/miscellaneous/clearvars.m":{sha256:`5811fe3145c6fda4098d88184fb3f9d3ba9051127c99f080b574c0a36e538b95`,bytes:6730,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/miscellaneous/compare_versions.m":{sha256:`4dfe6646e52fee5cf5b7d1048f00282e2293693bbd35176979310af3fa1f28bb`,bytes:8842,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/miscellaneous/computer.m":{sha256:`342debbeadbfb129bc29f260e293acc93245230d1bde9aa897cba70a088cac43`,bytes:4466,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/miscellaneous/copyfile.m":{sha256:`99059d9e8f5c40c6cf00dd029aa146a9f9efedf46a96319756b1f0b2c0487d37`,bytes:5849,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/miscellaneous/delete.m":{sha256:`10a8ee3e7da6e1442d5dc7eae04d3f247eb9789e4747510942fc6eb91f6bc262`,bytes:3313,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/miscellaneous/dir.m":{sha256:`5c0f0abc5461e8ac8c6103b38b354989c767105da1fd7a5f5c0699bdc8dcc109`,bytes:9064,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/miscellaneous/dos.m":{sha256:`49db653c05797dc789bd99be59f1e51aa7f75d94e1f5da098b529ed029affdbd`,bytes:2452,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/miscellaneous/edit.m":{sha256:`76f9ac10d87acd8eb897970069e60c33851093231493241c1d4b1f897b0341c7`,bytes:22265,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/miscellaneous/fieldnames.m":{sha256:`78d786a32c52b21fdca38ef99a995b343eb31d569c8158a9acdb87ad6e9def44`,bytes:4161,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/miscellaneous/fileattrib.m":{sha256:`fe6f57d93b4b67cfdd7b67538ba0327926e69e6385bfcdcce5c3472acb12b3da`,bytes:5912,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/miscellaneous/fileparts.m":{sha256:`11ab888e66c7aaae66802ff90e9253d3327e5e50b4027448a72ea74faf96e9cd`,bytes:4192,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/miscellaneous/fullfile.m":{sha256:`62e9538591f62521848da6fa5a0abc129408d4b79198151d9f709882bd9e8e8c`,bytes:6298,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/miscellaneous/getfield.m":{sha256:`4ffab100a3cad738f8712e50b3ba5a0f12a55bef57c7c41cce667b87a116f0cb`,bytes:2430,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/miscellaneous/grabcode.m":{sha256:`854811112c262f52ec3220e91c0c2f870d5094d5f92eee51f220aee6830ab1c7`,bytes:3241,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/miscellaneous/gunzip.m":{sha256:`fff30897d775290b4505652f7d1b17d15bfa822eba43ca51746bbe9a0c481c19`,bytes:2014,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/miscellaneous/info.m":{sha256:`c67cfc1b9b31e47028e1316ac1d8aaf084aa8fc64403170c33ae64c2fe367de0`,bytes:1965,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/miscellaneous/inputParser.m":{sha256:`f758e4e1b1e440bf3e0888c55d8006bdf0b507b32f7ef860fad58fff8201484a`,bytes:37859,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/miscellaneous/isdeployed.m":{sha256:`6ea18af52a8d59ecaf75fdd7d8273918736052546035bc7631b882c8f6ec8d76`,bytes:1424,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/miscellaneous/isfile.m":{sha256:`3c97b9f1a11a0d5426961e7f43898356840046bca35c45e80a7fed052d370be1`,bytes:2420,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/miscellaneous/isfolder.m":{sha256:`d7b5b06b9177c6f99a0de3b745c90a27c62068dfd1e71befdf4ef75dfd61c2f5`,bytes:2393,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/miscellaneous/ismac.m":{sha256:`1d9062bcea382b8bdf86dcee7f00f9c647c4e1a0a94ec5794537b7d0da56e681`,bytes:1312,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/miscellaneous/ismethod.m":{sha256:`1ed63bbe68c992dc72fc27301aaf58a991b6b61bbfcebd61db9b14b99fb143b2`,bytes:1955,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/miscellaneous/ispc.m":{sha256:`786e1fe8524a83a05cd6cc3e3e1c25221a78cfce2ee41be7cfbb6815fb88fb60`,bytes:1313,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/miscellaneous/isunix.m":{sha256:`e8d8419eb8bf01b88acd66778a6006153914ac8d7feb2f2a461db6acc0ad3c15`,bytes:1316,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/miscellaneous/jupyter_notebook.m":{sha256:`2e273cef3f977391ec85a44960afd89bf9cbf42d9f606581c89e25ce23406e1b`,bytes:22840,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/miscellaneous/list_primes.m":{sha256:`d5fef53cfe400015007536a2f64b376c554fd0c200f1bcb6c869470146efbe0b`,bytes:2150,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/miscellaneous/loadobj.m":{sha256:`1ff1332224a647392e51bac0a73239c59b904bb8b12e02a9b8a2bab43bd7df5e`,bytes:1702,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/miscellaneous/ls.m":{sha256:`a4bb76c9d863317c9b7025e41d9c40cbf40fc81789de6c445b1e2d31b3579e0c`,bytes:5154,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/miscellaneous/ls_command.m":{sha256:`7accbb1cab43391e28b737a36f2e374084d2842beff8e794f1d5f09ba1ec8d75`,bytes:2080,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/miscellaneous/memoize.m":{sha256:`93ff1b4ab3e03ba2f5ab2833d4611c6ca30cbeb428b2d4740525ead554891877`,bytes:3331,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/miscellaneous/memory.m":{sha256:`3a767e28f8d4aae4c18023069bbeb20eb55be15f6c5c67e3c84630e66fadc82c`,bytes:10083,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/miscellaneous/menu.m":{sha256:`bb5e1cded62474c2d20ea76a17d5193e46e5624a3cbf7061d78f9c02c4c28d42`,bytes:3724,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/miscellaneous/methods.m":{sha256:`5232a49d5c57c0474ba06ce301c83a30a767e5b3bd8139ed95bb20a619947cf9`,bytes:5837,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/miscellaneous/mex.m":{sha256:`d929af572fedf1304a667f1144e57e49f29230c34e462ab8c39ca9746266d4a1`,bytes:2047,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/miscellaneous/mexext.m":{sha256:`2e0fe9e8ab2d408f2ab59fa8e326589c6abe4768900f690a38bcc484e71bcb30`,bytes:1449,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/miscellaneous/mkdir.m":{sha256:`bf3d4130b227c125499459985ae178e21348ff964972a97984fa3197336e207d`,bytes:4191,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/miscellaneous/mkoctfile.m":{sha256:`cc6a98e3a2040289340a3c3f5b5160797b870702aabeab7d615b031e5b08516f`,bytes:7957,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/miscellaneous/movefile.m":{sha256:`15eef976b25c7100f616ccdab93aabc5c2dbb0e214de476c000adc365d8792cf`,bytes:6540,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/miscellaneous/mustBeFinite.m":{sha256:`7b00f8deccc0ecd4e3b57c802cd2d668ef5b5e7b23ca81fcbbc7c705cb94f071`,bytes:2018,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/miscellaneous/mustBeGreaterThan.m":{sha256:`c10757bc5f7366e4a141ec3af1332f44c1306950d5a253b2df7e3fc82edc9b9a`,bytes:2477,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/miscellaneous/mustBeGreaterThanOrEqual.m":{sha256:`47fc772d53f4f19eaceb03f74f67af1c5e8cdc4d51cc979271a92d31827b5c21`,bytes:2613,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/miscellaneous/mustBeInteger.m":{sha256:`1ee07a6abfbfac36531552cdae88a75a84189c7c385d7b065edbd116a483db21`,bytes:2607,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/miscellaneous/mustBeLessThan.m":{sha256:`c8b58bea4b9c6b8e3a9c7bf5006642adfbc9eb92001da8baa463eaceb6d52774`,bytes:2523,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/miscellaneous/mustBeLessThanOrEqual.m":{sha256:`8227b8ab378945366774c37764792bcfa0640702d9bd73ab2ec90770ada34b88`,bytes:2593,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/miscellaneous/mustBeMember.m":{sha256:`2f9d3060b0c78f89ce201b58e1c777a7721a3affcc84830ee35ad887c4b4ae08`,bytes:2670,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/miscellaneous/mustBeNegative.m":{sha256:`16336a24e7b39496eebd355166905911d04e5b0d8f3dc047d3c0ac151b400823`,bytes:2185,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/miscellaneous/mustBeNonNan.m":{sha256:`5fbba6d3b4c17b711de8e337443e5b8da4b150ec5c96bedbdd4f7f09c20fe5ac`,bytes:2014,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/miscellaneous/mustBeNonempty.m":{sha256:`d5f768d525eac416016bcda232e53e487f2859963494c36d4a65f91520aad64a`,bytes:1882,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/miscellaneous/mustBeNonnegative.m":{sha256:`7748f0ec1894b67a24e41e616063883332fd7d940fdebf4b5712f8046a0675ff`,bytes:2443,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/miscellaneous/mustBeNonpositive.m":{sha256:`86b1fb40bd040e6b66138341c8edcbdea165d2a32f0fe5fe00bdfa8799642724`,bytes:2310,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/miscellaneous/mustBeNonsparse.m":{sha256:`edce82300aa476c58e70ec9ee3fe5164a8ee0c66944211bb0569e11036f29cae`,bytes:1754,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/miscellaneous/mustBeNonzero.m":{sha256:`d35f008d90d5b711d9593f53930b755473998257143522717eb6b75415b42018`,bytes:2059,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/miscellaneous/mustBeNumeric.m":{sha256:`46489e1527be361011618b14fe4836c44367bcb7480dd190f23a99acf8ca463b`,bytes:1913,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/miscellaneous/mustBeNumericOrLogical.m":{sha256:`e55ec4971a07d08854e283a76c27be888fbb3164bdbc218593fb0a333ceb6ce7`,bytes:2069,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/miscellaneous/mustBePositive.m":{sha256:`d8dddcfea117071b1f615ec0fa7d4146991835c2f22b0a1a5c70907ad66c21c4`,bytes:2424,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/miscellaneous/mustBeReal.m":{sha256:`1ab1fe377c02ce62181f642cfe2d36bd2e1ed0b8c4c139275d3b251a0145e003`,bytes:1795,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/miscellaneous/namedargs2cell.m":{sha256:`a4c80607e63f7880ab15b473fcb97e30f8d73c5c580954eab8cbc5189c9b69a5`,bytes:2124,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/miscellaneous/namelengthmax.m":{sha256:`ef9c8d4dd63290ce31c0f2034ad1ce17414e95e5d6c1619d51c91d8dd4fdfa5e`,bytes:1629,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/miscellaneous/nargchk.m":{sha256:`ff952463bbbdb4217476a6fffe2a43a0ed8b2bfb9769234da6eb289701e78c51`,bytes:3576,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/miscellaneous/narginchk.m":{sha256:`5fd71e8a17f4ed4d31d741ce06248a0d6cf00e2463e306d4f736eec57548b699`,bytes:2489,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/miscellaneous/nargoutchk.m":{sha256:`7e4a8d4c7103a35226a8635ccb2106ef51c788fcc1898839635af8416e0562e4`,bytes:5206,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/miscellaneous/news.m":{sha256:`243ed212c3c0fde55ec206c9a2fc976b474b843e2a746095252e79377f5501f3`,bytes:1666,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/miscellaneous/nthargout.m":{sha256:`7c75c98d4fcab2c1e7b299e7345c4b08ad7aaff102dccc8bdd8bc8053e18b3d4`,bytes:4672,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/miscellaneous/open.m":{sha256:`19c1a0314cc87780b827665e57d36fdfb65888f55c39310c526de6f327559aa4`,bytes:4131,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/miscellaneous/orderfields.m":{sha256:`14264ce6cad4336903a8973c0615890e831670bf1aa3ef74ba7dffb29805818a`,bytes:6641,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/miscellaneous/pack.m":{sha256:`3fbd7a5d43b4d6e0eb7486da755b0bcc27b8c818591cf0efec241d36b09cba5f`,bytes:1315,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/miscellaneous/parseparams.m":{sha256:`3dcc58223ea2335ccb67f6ab4311dc48c5d41790d32e8f3cc61b15d14ebe06d2`,bytes:4418,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/miscellaneous/perl.m":{sha256:`7ca559d3a18098d1b433e8ddd79c528ee7d1f096d65fc8261271ead9dfa04432`,bytes:2494,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/miscellaneous/private/__memoize__.m":{sha256:`2dc64f43c59678961d8f09bfff52ef9ea46a3a7da6189b98e44fea589809feab`,bytes:1813,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/miscellaneous/private/__publish_html_output__.m":{sha256:`810baa04bd26e2fcbf934424479e0dd5226691a3998b73558c438480226cd5f7`,bytes:10496,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/miscellaneous/private/__publish_latex_output__.m":{sha256:`52de5d70802af838665b735d48dfa8a8617b6d4474e0d8dbf7ff23ad5d5c7e29`,bytes:8231,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/miscellaneous/private/__w2mpth__.m":{sha256:`fe028142358302e6cdf0174694ebc5f6cbcff94a2a6f01ff7465f54bc4df9ba9`,bytes:2516,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/miscellaneous/private/display_info_file.m":{sha256:`8855104e9b64454fc609209321d86e9a6bbb3f955f82a49bdd1346c7abbe1089`,bytes:2135,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/miscellaneous/private/tar_is_bsd.m":{sha256:`6d58b67a12c5f0bf0b2098ef2e86e7b8e43a0f5ace16faa9b90f96be881afff7`,bytes:1830,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/miscellaneous/publish.m":{sha256:`fc72e65543795a8eeb25c452d2a4ee07a26a9dde52d90957b5cb25da79e19b2d`,bytes:37095,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/miscellaneous/python.m":{sha256:`e555a7d3b5a9ab073a7905fd0faf0d4d047ba6d4e01dc1f650360110e72229ad`,bytes:3232,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/miscellaneous/recycle.m":{sha256:`7571e56f59472b8874f39d54ed0b52c7b5e8e9a80ce774b37bc38a1108fa1366`,bytes:2441,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/miscellaneous/run.m":{sha256:`f02da0ca4eb5bb30039d8dcb1df84467f35fb3532df643a3b77ee5180b294b4c`,bytes:4986,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/miscellaneous/saveobj.m":{sha256:`7d79bdd4e68e23c2f6c131a7b1fd113de0f4837b2d738f0217c626205469efee`,bytes:1849,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/miscellaneous/setfield.m":{sha256:`069abee14cae628d33e354b47499c18446f3e951ced98468fbbb3bf1bfdd4699`,bytes:4943,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/miscellaneous/substruct.m":{sha256:`809789822d9d17f12058775b53eed3e4395c22163182e7b228fb1867d6dc8225`,bytes:2954,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/miscellaneous/swapbytes.m":{sha256:`31f67a20287728aa304e3b31f87a4c26368549b51a2394d7f07019bf204e7273`,bytes:2398,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/miscellaneous/symvar.m":{sha256:`1094e6b87616abf2854190eec5c92a8299359621dc52efa232f82c14d8db317e`,bytes:2071,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/miscellaneous/tar.m":{sha256:`719be1627e8b3cbd3f83e4eec3d8e68a506bc748582723bef8b1e3609f9c0fe0`,bytes:5243,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/miscellaneous/unix.m":{sha256:`8668596ebb31587aa8876133e0d5b05e21df34be4fdfa73489df73bd60c581fb`,bytes:2313,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/miscellaneous/unpack.m":{sha256:`b8ad1ef3535da70f052d45028486f25703be32b4106de12db5f0a053047ad1d6`,bytes:12700,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/miscellaneous/untar.m":{sha256:`0e64abfd78be7f3a5ed1a2774d3375bbe0bdda0be6656a0b041f35790b20e519`,bytes:1800,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/miscellaneous/unzip.m":{sha256:`ce052db47df958855d2a850e766e66f749bb90915c9d671c20b58209a119d777`,bytes:1800,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/miscellaneous/validateattributes.m":{sha256:`4bc136095a8636b23dd1e649080d5962799fc55f8d5924341612c870f719c878`,bytes:26533,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/miscellaneous/ver.m":{sha256:`c35ebe4de30f0e846f5c0ca11288540fb563f30cd7220b43a583a061a530eda6`,bytes:4537,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/miscellaneous/verLessThan.m":{sha256:`19f3cdfd2bb3ed6a4f7a0086b48f03fcb86a01dfea9e8e4e8cbe5585bde10e72`,bytes:2950,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/miscellaneous/version.m":{sha256:`5849a6cb706b4792fedc3e8ea96a396cfba034231df1f7fb4255505793ef7ad1`,bytes:4694,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/miscellaneous/what.m":{sha256:`c200b068496ecc4e66445c4f037749e06d6380327724c3dff80fab0b81af949d`,bytes:5336,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/miscellaneous/zip.m":{sha256:`bd4b50d40d6beba04b71cc7ddcaa4c1992b4624b73a7f69196f389f69a0791ba`,bytes:4863,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/ode/decic.m":{sha256:`941f443ad22ae860285ad8aee4dd1fa7edb25760af698518c666d5256fde20a0`,bytes:9116,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/ode/ode15i.m":{sha256:`552bdd2157e5ab7358ce2045be0b2dbc1c887c38d4b1b527e62a50346b1ad16e`,bytes:23654,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/ode/ode15s.m":{sha256:`b8895c494c5848ea649b3d705b892281be16d385d1a0e630e39a2344284e2605`,bytes:27417,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/ode/ode23.m":{sha256:`ce4828ff62aae2b5de63f319c2361f5fab1ce9dc25b66b15a959f725ecbc93e0`,bytes:22296,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/ode/ode23s.m":{sha256:`40cde6dd9036e8c04fdeda0caea862651e58890bf84fcb5e2064ad0ecfb7020c`,bytes:22453,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/ode/ode45.m":{sha256:`64cc319a0355cd948b93b27c30c31c35b8a13f0dae58d1d6607214f9116eeaa7`,bytes:22787,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/ode/odeget.m":{sha256:`2d87af1d82a48cca3f03ef951f33b4f5cb63f55d3acf7810f70cbd4d19d71752`,bytes:3242,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/ode/odeplot.m":{sha256:`6f4904f1882050ce484741bb27500e1a2f840471ae51aa0313483e14844cc3de`,bytes:5017,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/ode/odeset.m":{sha256:`7d97a96cf313c035385f42bb06ce7d80f465ac02a2f6f9587e49e46a9f391a9b`,bytes:10745,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/ode/private/AbsRel_norm.m":{sha256:`447697751218a584e8c24502ace5dcdd0906ef87d7220b0bca94564e9db5a9ec`,bytes:1578,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/ode/private/check_default_input.m":{sha256:`fdeff26eee66134463f9a18f0d3d9ffef4799c2b7a834cc567c47efcf12d4910`,bytes:2944,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/ode/private/integrate_adaptive.m":{sha256:`d194f60b77a5f0e2482af336057b88ad37beb71a1baee051db0f783abfa31dd7`,bytes:10473,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/ode/private/kahan.m":{sha256:`494f02c1b4b76b965217e5e1384c8117062a522ad7182f0419e9fc5dbecf9a51`,bytes:2313,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/ode/private/ode_event_handler.m":{sha256:`be7c1b288298c616995b4728a393249b03e4a834c7503793c363f9c291736be4`,bytes:7886,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/ode/private/odedefaults.m":{sha256:`88580d9eefee805088d62eb551f4592fa0675bddd6aaa0e5ab8b1952f5162bdd`,bytes:5551,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/ode/private/odemergeopts.m":{sha256:`9193b0ffee70ec8e89989e82f6170597484baf799d2c7514051e0f4807754df6`,bytes:2121,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/ode/private/runge_kutta_23.m":{sha256:`37da914548aac5f4538b6d0e000b00ea9d02cf7ea81c9ed52afb44eef6e162d1`,bytes:4785,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/ode/private/runge_kutta_23s.m":{sha256:`6b6e51952cbf93c096f94d71c21a12e5e9dd6c9484bec91f422a7f01d0f7b035`,bytes:7298,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/ode/private/runge_kutta_45_dorpri.m":{sha256:`105b129b0c11e8681b4b7b99d2fd2d41a1cdde50106855dfb8f59a68f0b3679e`,bytes:5539,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/ode/private/runge_kutta_interpolate.m":{sha256:`f6cc0ef35ab5ec35efb97fa50bf224590eaac717b076e8a3dc93496ad4d5b7f2`,bytes:4165,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/ode/private/starting_stepsize.m":{sha256:`2a3e854ef58b5573d2feffb934d742df980aba94648667586e673d75a6fb2467`,bytes:2770,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/optimization/PKG_ADD":{sha256:`43ec2d2cf82f183b6ee0eb4ae5c91cf1b9b55059b70180bd734a97b44f195709`,bytes:799,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/optimization/__all_opts__.m":{sha256:`6ac1151aacd3d536d51706cecabca7481a2ef784ff87fd9a71891c67177d3422`,bytes:2420,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/optimization/fminbnd.m":{sha256:`c8dc48289194d9b0af5a5b393c9acca5c93bd0ce87a50676a81c74ba9a54bbca`,bytes:11582,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/optimization/fminsearch.m":{sha256:`c38481957d9a769d3f8d3d06f04461750600738d432c7bbe5bcb0c9b21024005`,bytes:19633,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/optimization/fminunc.m":{sha256:`22c35314d2bb56f38c815b72796ec84539ecb66f225b444e21f9f1a252d6ae70`,bytes:15974,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/optimization/fsolve.m":{sha256:`57e2f9010210d8bd15c5573b352a82482256710e0d7fc1573f3921fa6ab84541`,bytes:22355,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/optimization/fzero.m":{sha256:`9103e2adbb477389245a0b4b1f9ff8401d11a01ba9b90876cfac6dffd103b98a`,bytes:13549,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/optimization/glpk.m":{sha256:`e359bed62038789516096daf369e4ab454595a7df659657da2e106fe593af869`,bytes:17963,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/optimization/humps.m":{sha256:`eab5d6415a04e130ec10f3c6924473735e533df5bc6669af65d6b88c500fe570`,bytes:3509,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/optimization/lsqnonneg.m":{sha256:`f4f7f1da590644ee6e58057671c57270bfcd5961fef7101c0a8ac48a80a4c3b6`,bytes:8818,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/optimization/optimget.m":{sha256:`4b12d857197cb2318b8670a2307167b023a2c9f3d2959bed4b0c2a85be8d65a4`,bytes:3826,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/optimization/optimset.m":{sha256:`62b7f87724e512771ef3cc2e3159736a3cf92211da127b187e90995fca980f46`,bytes:9324,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/optimization/pqpnonneg.m":{sha256:`8e1fe6e7a99854ef9d796514c598917b6eb15ca3505c6c2c001ad26eceff74fa`,bytes:8739,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/optimization/private/__fdjac__.m":{sha256:`990950359db349c43cd6a9e8951b55c36132ca5d7a323e595c3547e6fa47cb77`,bytes:1898,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/optimization/qp.m":{sha256:`b0490b4934c7fce90174b955503e88931e953d2e146760085c33337489077b7f`,bytes:13633,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/optimization/sqp.m":{sha256:`8b379d59e047f6804e0b0b3d99ddaad6134c5bf6cedda9b8721de9f105afb767`,bytes:20411,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/path/import.m":{sha256:`908df42f20118d3a102cdd23a759ed9f05b4d10276ef8abb2f1d097889e015e5`,bytes:2232,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/path/matlabroot.m":{sha256:`91a5b0c3b4ab6e079d5275df04a049f723d3df765d006e84187997bf98efefb5`,bytes:1401,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/path/pathdef.m":{sha256:`c66d09155522b55c13a6551ce0cdd47aa02cb3ffd9bca56b68f5a1df85f28f6a`,bytes:4109,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/path/private/getsavepath.m":{sha256:`3b67a5feb47c2dcb9a36583b553e9134fc4447fdff03ca9462e1861ff1d7092e`,bytes:2272,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/path/savepath.m":{sha256:`ba6bb3ceebf1a7d943500a317bfc8d0724c5a1a5f2938551771706484d15be25`,bytes:9352,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/pkg/pkg.m":{sha256:`1b307994fd9dda858dfeb516c444df020fbddf8cd33845f8231635791531bf02`,bytes:30975,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/pkg/private/build.m":{sha256:`4307ae86a7868fe572509110de0356257ac682315c485edd06ef8eed928a48d0`,bytes:3889,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/pkg/private/configure_make.m":{sha256:`56b5bc96459626429d34e46ceec268313408fb7a7e4b87b8a3af7580a6bb4454`,bytes:7208,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/pkg/private/default_prefix.m":{sha256:`bca1e6b5f26fe5481d49d1666dbf57b016f1d36c7d70704757d83c276536cdaf`,bytes:1905,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/pkg/private/describe.m":{sha256:`5d3403dd578b26005e21e951fbb75d0d8bba4d4ae82e7008c335090aa33a5052`,bytes:7727,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/pkg/private/dirempty.m":{sha256:`3cee197cbe1af879de939c781f45df3136fe43b96c426792eb5db48e54d7e93f`,bytes:1648,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/pkg/private/expand_rel_paths.m":{sha256:`87caaf56dfe79d9eb8ef18b4c3bfef1ebcf8478691cdd5f66c65ff393fecc64c`,bytes:1638,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/pkg/private/get_description.m":{sha256:`7430fd5ff15d0aeb6da02d565a38d248e9c8914cbbc6c700466c98729e6f4bd6`,bytes:5963,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/pkg/private/get_forge_download.m":{sha256:`451842f424e78c98799a7df151e3a64d08da3827cdbefd114586cdcff45a2f49`,bytes:1378,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/pkg/private/get_forge_pkg.m":{sha256:`df0f4d534451a4c415d9115e78b79a5e1af1fb6d523022d04422dcf72332b231`,bytes:3682,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/pkg/private/get_inverse_dependencies.m":{sha256:`32c25150ac81536d4c1e5429cb711449297ccf4d1ad088713317a27ba50df060`,bytes:1887,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/pkg/private/get_unsatisfied_deps.m":{sha256:`c061e616ea7e213cfaed03921b4598391c68df598fbc9beeacbec80f520e21ca`,bytes:2186,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/pkg/private/getarch.m":{sha256:`18865aa63b1362af0697b319be95c1cef87ff1890bdc6d9383a407e45bc5c7d8`,bytes:1333,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/pkg/private/getarchdir.m":{sha256:`1c4b3116cc0efa39cf512aba589ac2892bfc36494df32c2a80fe619c31e8b6da`,bytes:1254,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/pkg/private/install.m":{sha256:`4c335a63640c65292ca5310b85ac7c8a6e18374b8afcec24e41019ae1bcf37c2`,bytes:26213,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/pkg/private/installed_packages.m":{sha256:`05eb87f664f17691ec68ab34fc2a2d2ed536847be89d5d58a60e76a765dbe161`,bytes:5602,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/pkg/private/list_forge_packages.m":{sha256:`3cf32110a5d3a425f72fbe82baa6beec2573c29d24f107925211c1228a0a0a90`,bytes:2779,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/pkg/private/load_packages.m":{sha256:`7e3323231bf623d44e72b74ec3de8e7ee755572a5880a45e8214551f7cade4de`,bytes:1988,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/pkg/private/load_packages_and_dependencies.m":{sha256:`11c6fd43b5a5df67cd8da6f6cf8e856a676a8b9b76c7114efd016015bd5a7d4b`,bytes:3516,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/pkg/private/make_rel_paths.m":{sha256:`36de3f93df5a1d702eb8de3d03f9c0633eb2b02fba24dac2fdaf4f363021cab2`,bytes:1637,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/pkg/private/rebuild.m":{sha256:`cb0614fedba35150a75800c2d8e5699999edbe17a16c59f5f4b8294e48abe943`,bytes:3156,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/pkg/private/save_order.m":{sha256:`e5e69f42ba00b9e8156805ac8de08aea12a40a46ebcb462a64150d1328753bfd`,bytes:2072,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/pkg/private/standardize_paths.m":{sha256:`5e92f46ae9304863929dfdce989c618f85886631e725f3dac09ecca50353093f`,bytes:1823,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/pkg/private/uninstall.m":{sha256:`f07bf13e95332bdd7ff5c368ce2cdbc92459e827c34b263159f38ebe1fb1430f`,bytes:6150,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/pkg/private/unload_packages.m":{sha256:`843b5371a1cd6540a29d1d53438ee5e5bb0812cf83d0e01c9884f3ec7077c959`,bytes:4296,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/appearance/__clabel__.m":{sha256:`49c2fd3f9a6551ceea143379eac4e155d8c6a00ef8329172585c4e73bc084bdc`,bytes:4182,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/appearance/__getlegenddata__.m":{sha256:`5e0a9dc87aa4f820242c1a767e56f3318298d28b92f7104e9ecfd42dd4df6f6d`,bytes:1822,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/appearance/__rotate_around_axis__.m":{sha256:`57310dabe3ec047861ca88235539315376cf5c20f0f26822cd388f010e3d7473`,bytes:2165,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/appearance/annotation.m":{sha256:`da8a2d15405bc83c23c79aa415b1913ede8e2e3da482f4ee29cfbe719582039a`,bytes:48172,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/appearance/axis.m":{sha256:`c44bbe300e391e7ae42aac243cf06b0f68eef33b447f0abd9d046e220b0a3101`,bytes:18278,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/appearance/box.m":{sha256:`421c1a3f3168198f563ef856eed46a4ecff542e7c07c8180b96e9ca182d9cc34`,bytes:2818,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/appearance/camlookat.m":{sha256:`a2ed2fd192dbe8bfa9fd91a8ebab9fe76fbcf2b1d4e7148354138ad726ac824e`,bytes:9229,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/appearance/camorbit.m":{sha256:`1d451caeb453047dc4138094e9d617a6082ffe43868b66a5344f83e37d62a749`,bytes:8511,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/appearance/campos.m":{sha256:`946b37b6e889f7420e8dbf69029263929f8a07e0a08350fafbe341f7e6cbca97`,bytes:4616,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/appearance/camroll.m":{sha256:`5224ae406a33370e69050d272e0355fdc3d1458fac900de77ae35436ba577231`,bytes:4662,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/appearance/camtarget.m":{sha256:`760f9698b3f611ea65a2660c33a41b83f6642abeb903980b11552ed2dbded097`,bytes:4919,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/appearance/camup.m":{sha256:`00ad809a3d41299ac5c481fe68414d41034514a0e43571765631bafe51248f51`,bytes:5038,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/appearance/camva.m":{sha256:`b6270a6608e848dcc917baf2a9a49bc10153228040c0b73fc9397a68ee40e3f4`,bytes:4331,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/appearance/camzoom.m":{sha256:`a0382f1c3d1090b2ec72923afe9c14927c8159fa7efb7b42893531970919a03d`,bytes:4002,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/appearance/clabel.m":{sha256:`2fe3e50d7237ae54d65004e782c6507104d2781d1f922955ea51ea783df7d785`,bytes:5099,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/appearance/clim.m":{sha256:`c5442da73cd0e03d59edeba13aa877e04aa38384d4481c993669d1feecf59d83`,bytes:4371,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/appearance/daspect.m":{sha256:`f29a36b52779f40c63de6f1ef32b397e9d106b6551d3c958e3f126cb0fdf28a6`,bytes:4074,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/appearance/datetick.m":{sha256:`b4ab2ca79d8901f04c287ad410ce980240d76833ec4321c6b87790425b93f335`,bytes:10207,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/appearance/diffuse.m":{sha256:`3641314caf278e1f08379cb4726c22391e0897badb21d6f5c6c07bf6dce231be`,bytes:2162,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/appearance/grid.m":{sha256:`bebe2da70642e05c75d21f97ab07ac4cb3e07b8b0bc24d7eae8634e70b2753fe`,bytes:10097,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/appearance/gtext.m":{sha256:`002a9772f4bf9c8684a7d76452b91968fd5ee637518c4542141d0c68467d6648`,bytes:2788,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/appearance/hidden.m":{sha256:`6b8bb8ec643ae2959dc9210f81b0f81e31c93eed3b45fa36b0ecfbe2134edb7f`,bytes:3003,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/appearance/legend.m":{sha256:`cd1e746335fffc4a8f141224313ac93dbaaf0e3bf7135d76acaabc3b57ff3526`,bytes:68758,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/appearance/lighting.m":{sha256:`ffcdf61ad6000a2047709e7d8899f5f849b94115403ca243d6c7bf2a2143ab83`,bytes:6584,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/appearance/material.m":{sha256:`6d6088b1e5fbf434ee9a1a9aef198cb1adb6e796a85fd741721c1fbf1ed7ffa5`,bytes:11567,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/appearance/orient.m":{sha256:`7bda64c554e0107e5a083449ad7a673e69cb195e62633ef3270c46e71e53ca7a`,bytes:6132,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/appearance/pbaspect.m":{sha256:`8a0f2ce434f1377b485da75b7b5075627022b3b866a77a6767948085b65b1bd0`,bytes:3556,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/appearance/private/__axis_label__.m":{sha256:`1c5e5a46b1feacaae832705a9bd9fe94de6b88b345ece6cd85a7fd8d7b14cc88`,bytes:1569,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/appearance/private/__axis_limits__.m":{sha256:`a088956124d2b3af63275b4d90fed41a99dc683cf28acd221ad2ac38dfaab69f`,bytes:2946,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/appearance/private/__gnuplot_legend__.m":{sha256:`aebe7b8f5526a316f1483cfc259bf8593cfd3ffac60d8145447f3e7dc5d02cf8`,bytes:64758,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/appearance/private/__tickangle__.m":{sha256:`2d8dfb98d8d1dbf0f659a7010620a13f106dfa440f7aa779b329512ade722347`,bytes:2072,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/appearance/rticklabels.m":{sha256:`fad7376a170b19011441f64a4f1e9351158056587d7ed5f2eb0d46bb6f9bcc95`,bytes:9383,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/appearance/rticks.m":{sha256:`1730f0e1a102685d93bdd7ac375c20d55dcd25341a7c41b88eced2f4b8ccae65`,bytes:4447,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/appearance/shading.m":{sha256:`f153a4c8e1b03244d7416c9b687359cfe1f96c08a1223fe27effe518c33aee08`,bytes:8839,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/appearance/specular.m":{sha256:`f99ce95aae7bf2652522653bbd841b877a3f3a170f96968de83db5eefdaea391`,bytes:3470,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/appearance/text.m":{sha256:`6f746731f94af6996a18e580372339ae32fec0ee61654c4e1247ec1f0864d01d`,bytes:14931,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/appearance/thetaticklabels.m":{sha256:`c1834257054f2705fd591eb541ddf0e4ce6eac30b4564f36ea6acb228325df0b`,bytes:9439,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/appearance/thetaticks.m":{sha256:`753e705e3e587a4574e5a24953e576c701f6205d1029b8d832cd81c05363d028`,bytes:4767,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/appearance/title.m":{sha256:`79198cf924f3352dc2706f78b759853c10a921f2247f00f7b45154fdab37d6b2`,bytes:4387,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/appearance/view.m":{sha256:`cff29a4b7808174aac617b583adfb79028534fb9a3c5c535e6dce428c224dfef`,bytes:6047,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/appearance/whitebg.m":{sha256:`e16c7188ba3a004ca7bfd772c50105136afd7d1ccdf75afd6fd88f1c84aed10e`,bytes:8800,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/appearance/xlabel.m":{sha256:`48a151258d8e2be088a4ea9a7eb312c8db3896ae05d230203dba63a559fc455a`,bytes:2976,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/appearance/xlim.m":{sha256:`99c112a3157f8243ada51110c91d5c351aa9e2a10c40f27eaa4d0f3c9eb94e95`,bytes:4996,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/appearance/xtickangle.m":{sha256:`021b3d71b08b5075efc8e3f879ed162505ba65f1535de968b4d330f0cfc7cc35`,bytes:3271,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/appearance/xticklabels.m":{sha256:`52bec41749910d9f10f3908bcdb34bb33cbbe4e8e60e99812d67474b2b2976d1`,bytes:6083,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/appearance/xticks.m":{sha256:`d8104920b659eb5503f656d39d464566cc27bfe0ca398897a87e78866bc2008a`,bytes:4869,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/appearance/ylabel.m":{sha256:`abab066a48590c21ba0872c7bdb28d04f94c341c067f81ab788898140bc2b301`,bytes:3050,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/appearance/ylim.m":{sha256:`998787f173c4bf52aafde983839c9b7599f1359105f51e2ff2d5c6094263013d`,bytes:4496,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/appearance/ytickangle.m":{sha256:`1c621eb84dd12725d35c463180f1803024113116e716a571f41b6d542bbf675c`,bytes:3271,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/appearance/yticklabels.m":{sha256:`d750df5c6d6b0c023c34b95c9d75ad2664e2cbcb30ac4ca68e7c9e936336496d`,bytes:6065,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/appearance/yticks.m":{sha256:`6fdadec62bacc775eb95b163ced844b39218bdb581a595e5c7ce080101d80099`,bytes:4883,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/appearance/zlabel.m":{sha256:`aabd2fbd3ceccaf947d6997f91759714cc9c595840a8336f6226684ddf5c757a`,bytes:2992,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/appearance/zlim.m":{sha256:`23ff72e46d8a5268d902c10d63bbdb8d66471b1e99f47a94634df34bb8520dd7`,bytes:4496,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/appearance/ztickangle.m":{sha256:`d922923b124bcd4483d71a35c54fedce5e4dee97774373d6a2542e1331abf126`,bytes:3271,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/appearance/zticklabels.m":{sha256:`e2ac7cb42b1c6d22ac34b3302526a4d123c9a58f96ad87498563522f08063d93`,bytes:6082,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/appearance/zticks.m":{sha256:`6adc9c69384be14ef4e0c28860392ac09a07760b875fe139e130fdfc5732ddbf`,bytes:4870,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/draw/area.m":{sha256:`5ad9b4de7b0e1a6c53fc4a6a417dda1d263bcec94b7f10ff6e631563bbcf90b1`,bytes:8553,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/draw/bar.m":{sha256:`02d9cd9bdd4fa867f81c2d97be1b9b5d9ffe184f9c1f6b43c2ac8d119faa6584`,bytes:32615,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/draw/barh.m":{sha256:`92b7d1449947d02c33001912f2c06ab02d8aa966c68d6d448e5c062c57897df3`,bytes:32140,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/draw/camlight.m":{sha256:`6882f97cc3dadbf7eec0ba8e59d59375935e70b8b5cfde7eeffd8fbee68296da`,bytes:9311,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/draw/colorbar.m":{sha256:`149bbfa98a9484181876750973c5fc1d35cf30a736b2a46b0d3e0c6df3f92ca4`,bytes:27552,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/draw/comet.m":{sha256:`8fff01ac4289c4c3ab9e3a1dcca51c2c578af6ef9a7dcf47850a2fb643008000`,bytes:3383,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/draw/comet3.m":{sha256:`4c24df980d1736b6ebc5fa46bc092815da2d83c0241f250e5338c3df04e22221`,bytes:3537,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/draw/compass.m":{sha256:`e30667da7d8880fbfbc44ebc8e1ddc70fa5e62b47c8f194c3f4fce52b05c3b49`,bytes:4538,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/draw/contour.m":{sha256:`5fbd4ce21aa235f3edb7029452a3841641199b32b3d2756f842db652ae6762b3`,bytes:4401,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/draw/contour3.m":{sha256:`6a23c21265604c9db56c25b63b6d59243a3771ef677b61502197843ee4aa5e39`,bytes:3641,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/draw/contourc.m":{sha256:`d5d5391c412fa49bf18e63526c3683d0c0e2c39becebff5bc3b5c83c97ea6391`,bytes:6291,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/draw/contourf.m":{sha256:`675574721c8890c9de9e1b03d1837814f0043a81ba140876d4773cf89dc71737`,bytes:3938,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/draw/cylinder.m":{sha256:`d04b9a50a7f78a8fabb338dc16c8944b8fc152bb30b57dee9ccb08cb6735cefe`,bytes:3541,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/draw/ellipsoid.m":{sha256:`6caf61c5dd7494b6025c9e8ca9a044ab1786e533b97714f74eecb50b317b6386`,bytes:3814,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/draw/errorbar.m":{sha256:`3388f1ba9e20d6943a9c1d4769595583da0c21a9eb1087cf840d5ebfcc770971`,bytes:9257,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/draw/ezcontour.m":{sha256:`8fe3c98ffe843fb71862e9c35f4ad1c2129dcf0644d7bd3db13bc310665181a9`,bytes:2655,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/draw/ezcontourf.m":{sha256:`ec0457412fd91359fd890667e5331bd3c00dd74f9ed46f8b82bfca8355a0fd77`,bytes:2671,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/draw/ezmesh.m":{sha256:`5b86692e356d0aa468acc41608103d97921d6cc1c711865dd8784ee5fbb4df38`,bytes:3526,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/draw/ezmeshc.m":{sha256:`25bbcf46e45b96daa4f0bfa4394f1b7c9529e159cb188b8e2a6de0bd3feb1c90`,bytes:3188,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/draw/ezplot.m":{sha256:`303ba3e05f92566b53596555a2f5b37983aa8c55d8c6d55b8fc1fcb76a8740d6`,bytes:3868,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/draw/ezplot3.m":{sha256:`00e7e63e0c1b8ac320c20c9d47ac9e043c110ee66dbfbc4e5e55dbf645746ef0`,bytes:2823,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/draw/ezpolar.m":{sha256:`a3d67b48271de546aa5d4e553d1aecaa1ea887e8b9202acc493644b0dec40a0a`,bytes:2415,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/draw/ezsurf.m":{sha256:`ba98faf202dc45d4168fda5651453153bca7fe364d7a11ed53a5f22255b224e4`,bytes:3848,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/draw/ezsurfc.m":{sha256:`6f68da286e9b95b07329b9956f9c44046aa69a40f12755bf97e2c025612313df`,bytes:3175,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/draw/feather.m":{sha256:`71660bf5beec40347cf9d5dd71351b118a1d7a936ccfe32277855ef5b5b9f4f1`,bytes:4223,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/draw/fill.m":{sha256:`2044a40c6d4d1744e548d916e38bf67792eee54afc068176172399fc31ca8dc1`,bytes:6869,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/draw/fill3.m":{sha256:`221a5eb649115f79df152b94d0157aae250cb8afa9de2c01d180f49569d0d2bf`,bytes:7504,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/draw/fplot.m":{sha256:`e91e0a95fed18882abb656e2faea1de812c6a83c0af277bf80ade50de5088c06`,bytes:10411,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/draw/hist.m":{sha256:`935f7b5c23e34aacf0e8ef510b48e96470e2f30218ac009ac4c9a1be7a97857d`,bytes:14779,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/draw/isocaps.m":{sha256:`fea867d84dfe2a3bf612cb7d4f0f1e9a4a0b639eac3362a7a54d62aa82b2552b`,bytes:18996,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/draw/isocolors.m":{sha256:`535a27dc52c0962228a3688b691211324c70a10f2221368db51da0366931a548`,bytes:6897,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/draw/isonormals.m":{sha256:`5fdf17741ff0866468cf8803d588a47526fa2b3c4c36e36f9e3778a99c136a49`,bytes:7492,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/draw/isosurface.m":{sha256:`e01761572246b6c1185e0e25d330b8aa855e0faab1f2e95aa4dcb258ef5dcc20`,bytes:19705,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/draw/light.m":{sha256:`e2c5db2eadb2ef31bc948840c64c63d8342969f57cada95af316cbdbd0c7277a`,bytes:21352,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/draw/lightangle.m":{sha256:`b9d60a0cec09934275a5ad352cf556a1050c7950764b26fb2b80ab7aacf1c283`,bytes:5080,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/draw/line.m":{sha256:`00e49eab1135cb25af63e6b61edadfa0214a1dcc0042dea55e69d06e5298c40f`,bytes:4900,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/draw/loglog.m":{sha256:`df3e1fea07900a97b176f90103fe7196cb8110e011bf7b400afb008dbd253e01`,bytes:3499,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/draw/loglogerr.m":{sha256:`2e8244d72f3e60acf011b0625d5437a73d6df9fe67aaf8a28c6fa0cd01a91ba7`,bytes:3485,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/draw/mesh.m":{sha256:`b2aafd5c3e15527ab4a644e8f931d6b1ddc76d01f69926f19d20f4248ccacece`,bytes:4911,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/draw/meshc.m":{sha256:`8f9192493bcefd9b6cd7115d35caed1dcda6e5460bfa42368c65de2c35ff3d52`,bytes:4518,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/draw/meshz.m":{sha256:`168c311908e201dcc81b9551e26287cf4a76e7f93b40587332b9244e9b858235`,bytes:5884,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/draw/ostreamtube.m":{sha256:`a32ce56f16aa03d67ddc765b9fe9bf25e29c0fc5ddb94f3e4e1e33d65634de0d`,bytes:10996,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/draw/pareto.m":{sha256:`4673d5cae289358ed28487a13a7a02ec6705c6380e7adc8e2898cbe8d1c75298`,bytes:4955,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/draw/patch.m":{sha256:`f1d5e458530fff8961b3f5b76d218f05b991bbb780d389a49ca5d68f202d688d`,bytes:11127,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/draw/pcolor.m":{sha256:`38984bb13689c6675a9ce2a92f75adeb2d5bab7f55d8a82fffb413cc2f8591dc`,bytes:4189,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/draw/peaks.m":{sha256:`2514839beda073c9973f348c026b00c826b8572c412ad05fbe9c73b548caa829`,bytes:3391,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/draw/pie.m":{sha256:`3ff901ced9766ee28a72c7c032a884e25a51014503d256a0426e6f7fa180d8ba`,bytes:3857,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/draw/pie3.m":{sha256:`5b496152e054e74c1246cc9cd391b057c91a3bc9c29fe894409579dc16a65025`,bytes:3897,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/draw/plot.m":{sha256:`120defa87396007746580aff1cd34c267a0c0b508868f0b5f46025802005c719`,bytes:9792,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/draw/plot3.m":{sha256:`fb854c574069381b986baf1a67ebecbe83b23b224f457e0ef7b367ca3435c4b2`,bytes:12029,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/draw/plotmatrix.m":{sha256:`d2943d83d464110a9a015c56bf48f741014df13b189e5af59a25b90fe80055fa`,bytes:5941,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/draw/plotyy.m":{sha256:`beb9779844cd4c4a1be6f5610a93d1cd28b711e4bcee701d14e09705c59afe31`,bytes:10182,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/draw/polar.m":{sha256:`b2bee646f4854d275d2e5c4790de7dded2051ac9b7531076a9675a5918554954`,bytes:22472,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/draw/private/__add_datasource__.m":{sha256:`90303fd5b30a6abbc9174d9edc5b503de8eaef40f16f9794ef9594328d1c103b`,bytes:1859,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/draw/private/__bar__.m":{sha256:`60ca3a87119e9b64935abff5fe0217f3a9f3eafd93eaa1995db9186558b0b8af`,bytes:18983,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/draw/private/__calc_isovalue_from_data__.m":{sha256:`9ae5b9620c4c5d73be7eaa6ebf3131df53afe4e071f5928711fd68937cd75311`,bytes:2278,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/draw/private/__contour__.m":{sha256:`df3c76bcfc64a3e31adcb29f38e55b9a0e7ddbbdc25f46d3badfd2f1e6c7b93a`,bytes:19530,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/draw/private/__errplot__.m":{sha256:`ffde84dbd9701a82e76502b71569c498122566303df3f02e996b40d6c479307f`,bytes:12795,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/draw/private/__ezplot__.m":{sha256:`de0c6c8dc8033ee5b3e115c30a734bac39734791ede985b39b57f0b89ac7eeac`,bytes:17411,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/draw/private/__gnuplot_scatter__.m":{sha256:`85a418890dd5613448be2e369127b7d8d09137e841681326f5716ffda4644614`,bytes:12403,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/draw/private/__interp_cube__.m":{sha256:`4ba79813342f0f85ac65454e94d44bf2ff08223eabb575b6905341f3c3c84a5c`,bytes:7454,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/draw/private/__line__.m":{sha256:`bfc83e969700e9b14c00b1455e61a1dd3d55b26a43e122fcdeed0da9e23d3294`,bytes:5800,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/draw/private/__marching_cube__.m":{sha256:`4ee134dfba28a6bbd3fa6c5a453749d4bbd3ac161e5580958ff86ed899b7c802`,bytes:25146,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/draw/private/__patch__.m":{sha256:`ad6dcfca4d36a2de0cc192d89fe3640f3520f0d45a243603ed3005679f9952d5`,bytes:5495,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/draw/private/__pie__.m":{sha256:`7a9c0cce34e2d5ab307eb90fd1ac27d5587f42e957d021a369546dbf59aa5863`,bytes:5604,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/draw/private/__plt__.m":{sha256:`074fb73a9beb1f286f2d9d1db70b5d2e7f3c0e877173f7225e75e8d46b26c2fc`,bytes:13395,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/draw/private/__quiver__.m":{sha256:`e6321c529fe9a149ddb0f1d7bb94ed007793b666cea2866711683fa8aa145dd8`,bytes:16390,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/draw/private/__scatter__.m":{sha256:`ed6c5c3ae6e063d447b119ce7ce057b9f7c41ab0fc30e1ce9665092ade4bfb30`,bytes:5687,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/draw/private/__stem__.m":{sha256:`18135b8546901bf334e62da1836c7894e892c7916ef00729d31ac1a77b0e32b1`,bytes:13571,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/draw/private/__unite_shared_vertices__.m":{sha256:`d55db79bd4b8b19a35d05cff25b620f5e2ccbaa765291902794ba3967a0b5528`,bytes:2381,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/draw/quiver.m":{sha256:`8f396e23958565361841fb74a244954adfca26b6fda6cf6a3d1e8d2467f1ad6a`,bytes:24005,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/draw/quiver3.m":{sha256:`6a61bb3d2468c60d49952a12a9323a552a495e663e1b4d4754b0a48cf58103aa`,bytes:17048,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/draw/rectangle.m":{sha256:`eb3fb0b641e74d01fada1cec0b14f139dfa2b899a3cc9f2a410e5be2a15a016b`,bytes:8407,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/draw/reducepatch.m":{sha256:`f42e21737e02b94cdfe3430a504f474a4add28b2a7c81e9547375bae3ae36b7b`,bytes:16943,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/draw/reducevolume.m":{sha256:`56be6a056ce7325e1892c511f23a6e934789632ab5b8182c69dd4501c8acca85`,bytes:9510,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/draw/ribbon.m":{sha256:`eba6bdd0913c4723dbd18ed050d6969a765605593663833ad7f00ae84889c54c`,bytes:3664,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/draw/rose.m":{sha256:`b8522c22c483e02f2f13a7071e017ccbdc07fbb571c41394a6127b371d949915`,bytes:8120,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/draw/scatter.m":{sha256:`f95757916f4b51aee9a98a2cf884ddfc5c29d8f4df4434670913e0a7c34246eb`,bytes:7476,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/draw/scatter3.m":{sha256:`59032710e37fe982b35992540b122a1dab182dfea209626a8230a5107debeda2`,bytes:4582,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/draw/semilogx.m":{sha256:`ce4ec46054fb7e3bb94a4df9600ee7a3283c1c50a72c764258b933f1a33a01b1`,bytes:3822,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/draw/semilogxerr.m":{sha256:`6499c043ba020dbf54cceee4cd23982be472ea95713cc047a3015819eb9e445a`,bytes:3462,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/draw/semilogy.m":{sha256:`d2d1d1cccb35c96e5edf9e3d643efbb24e59e8e34d7a060b63242075544f3d5f`,bytes:3820,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/draw/semilogyerr.m":{sha256:`12a7468a9a9370643d78509ef8b0e994d98cfd1f269aa5eddec2b87b86654b7b`,bytes:3470,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/draw/shrinkfaces.m":{sha256:`e9d17fde237a21410c309c593e726b0ef5d8e955fd7a36a46628ce1564b817c0`,bytes:7984,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/draw/slice.m":{sha256:`0bb52df324be461dcb90c4d22d6874a00e2c700b2b9e4d801dade7267cb8295f`,bytes:7166,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/draw/smooth3.m":{sha256:`07f0ea52403e1f1f9361f806df3fdb42862eef02f42fa7d4251fa71ae35a03ce`,bytes:9106,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/draw/sombrero.m":{sha256:`f42be24af500bada2e2d5bc410d0164fc609a17896f7b86f00c73006c2d4aa5d`,bytes:2613,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/draw/sphere.m":{sha256:`355e7c72a96bdef3f6c031a55a4aa24af4bba14bae867df431a3112cdac38af8`,bytes:3252,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/draw/stairs.m":{sha256:`d496230fa544ce9b4e3b35b0261dc156fb983738254cbe54f6ff78efbe815824`,bytes:9598,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/draw/stem.m":{sha256:`513a446e9b213ea4997ba3f386f1c50665c5a5960966e6d988a9c02c3f477d04`,bytes:6815,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/draw/stem3.m":{sha256:`15428bd05c0f32f6eabf2912f8e84eda1ab29e0d59292f8b6a55e2d131d38ef1`,bytes:3543,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/draw/stemleaf.m":{sha256:`1f50f906ef112187f5fcf25c1f235a0cad32b37d9dc1619a155d1be0d57409b8`,bytes:23550,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/draw/stream2.m":{sha256:`ee778bf8056ab0029e96d26f901c7ae36afeff2e673573a553115f96de0543eb`,bytes:7815,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/draw/stream3.m":{sha256:`7ccd7b49d230337293814d76972e7a7d5d13a7e260fb51b2387fbc63360e5f32`,bytes:9431,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/draw/streamline.m":{sha256:`8897da5372038d00cacd39082ae2984aa72f5c7adc42e0db80af9f1c05a3fc8c`,bytes:5375,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/draw/streamribbon.m":{sha256:`b893a0a5a9387a272dadc89933fc4f497d41cc80886e7eb89a715eaf37d289ad`,bytes:14307,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/draw/streamtube.m":{sha256:`d501f650c68cb74f6124767f0219acac6e22fed95481b5f64cc42f4155d69573`,bytes:11645,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/draw/surf.m":{sha256:`8de1890bd820c9c1466d031119342a2c8c75e8e2f9d4411693884a420cddda44`,bytes:4189,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/draw/surface.m":{sha256:`40982c68bec8e7563f6c6220094495d3702a3b4fa986f059ee66e3764323474c`,bytes:6889,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/draw/surfc.m":{sha256:`2a2159daa05597b0070abac3811b6d9e277bb303f0319d480b3e627e5371073a`,bytes:5076,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/draw/surfl.m":{sha256:`341b238af5a3faf2ef76e6b7af6e793fa85e40a2d02015c4e477e396b0e5eb87`,bytes:7082,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/draw/surfnorm.m":{sha256:`720818c3919d1fd1119715c2f753737c7465f9928cc98f90f580c3afe7f31b9c`,bytes:7878,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/draw/tetramesh.m":{sha256:`91d24ebfec9c8d8b97a98ee3f035e03641e681a89873f79a90224de06abd5027`,bytes:5447,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/draw/trimesh.m":{sha256:`df30eccc197e303b9e96b8d75463a3511c54951d1d57703e8d5c8fa458f35975`,bytes:4918,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/draw/triplot.m":{sha256:`90b043687b1995975bf704dc3a28dd71bfc1bad2a8544d282e78a3c1298ac97c`,bytes:2403,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/draw/trisurf.m":{sha256:`4fe63ca004b06ead328d7e6278d08b50656d717c6d6f99ac0b37c9907bac2da9`,bytes:6112,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/draw/waterfall.m":{sha256:`d86c1b2fab6922b79abe729252cf4146a0b3ad3eabfa27742fd52717b57f803a`,bytes:3456,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/util/__actual_axis_position__.m":{sha256:`d64cf5bdb1455c5e8e8d0ec20901456996ef9c66c948b3fe489301e815969cd9`,bytes:3710,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/util/__check_rendering_capability__.m":{sha256:`98c22b063e7ef6423ff46a2f725bc7fe6dd5ad140c4dee13bce789bdf54945e1`,bytes:1521,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/util/__default_plot_options__.m":{sha256:`ed71cd1f1f3e00004a41861d60d632968add2061ee7772db3450013e895b5fdb`,bytes:1697,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/util/__gnuplot_drawnow__.m":{sha256:`7151ef4ab8100960257835fe3576497d269067b91783e4d7a3b0fbdb7bda4070`,bytes:14800,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/util/__next_line_color__.m":{sha256:`d5d36d053862b47fc5ec005ef9bda7230497f1bb874f43b7f43c2f0cc3b6f48f`,bytes:2534,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/util/__next_line_style__.m":{sha256:`2ba4dac1ee04624d0315f05a3c40d45f78bafee35019f9ba6dbc226361ee49a8`,bytes:2416,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/util/__opengl_info__.m":{sha256:`2270358386cf0113f6070721cbed981babbe139884296251f751ff47e8872855`,bytes:4584,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/util/__plt_get_axis_arg__.m":{sha256:`da07e431450e31836b3f2c51b6eb333d1dea27626d3fd45ddd76c7df9d428e3b`,bytes:2737,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/util/__pltopt__.m":{sha256:`661fc2be1afd4b0b7a650d2aa12f76b8d8981c8c1ca1464efc4b6770797f278f`,bytes:8237,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/util/allchild.m":{sha256:`0298906e640212ae61c21bbb3becb1df307d0e83770646beb9b090be89310ba2`,bytes:2341,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/util/ancestor.m":{sha256:`ab68615c3058892cbb830fd0f0bfb51dd7421b1d37a3589202e4b5f9149fb111`,bytes:3729,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/util/axes.m":{sha256:`2ca1eb51318afb1cabd2209f34f3d27c74f5fb3f28c151533141cb9f3fdac2ee`,bytes:10244,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/util/cla.m":{sha256:`7551486aa7aeda78eb76a608d4dfa8076591aec46d69171cb7e3412a8caf5fd9`,bytes:3808,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/util/clf.m":{sha256:`2727b5d98bc77c1fe7aa1061f2013ce4173f3b9ebea0483f83b092497db9a3f6`,bytes:4728,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/util/close.m":{sha256:`a97f44eaf56891ca658c72123b8919350caa51739bdef65504e644a4c82d99b5`,bytes:6169,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/util/closereq.m":{sha256:`8f6d8e204c11db69f87430a1f3359ddc431955e0ba776f064782c8bfbdf547aa`,bytes:1561,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/util/colstyle.m":{sha256:`fcc94b39dc31a7808f2aa88313e0f13db83046980e0a7b7c2ac76894b68da306`,bytes:2574,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/util/copyobj.m":{sha256:`1191a02d2e8591c0ec7a71589496ce875ba96383abb692b7ba02bb27abd01222`,bytes:8286,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/util/figure.m":{sha256:`e05fcc79ba100e40e4ff52b6f6d80c56750052935ee5150c0785ed3e3ea46f9e`,bytes:4304,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/util/findall.m":{sha256:`e446b7d020353fdfb85c382be48ff82bacd4874ab1a147d039084d1db3e23414`,bytes:3176,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/util/findfigs.m":{sha256:`c9be7a1a7b9448c40106f48f6f4b8ed07063d6518b1b21100a9e9029b791e44b`,bytes:2728,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/util/findobj.m":{sha256:`14d1107a1c20b6a522118f41277e8ac0a4da8a26c4e427241512f4bfb5a43407`,bytes:14338,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/util/gca.m":{sha256:`c8c9da5308222034c7c152bc9431f8c11732f46dfb9983abb34c5891efe0b725`,bytes:2283,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/util/gcbf.m":{sha256:`d9a4a38832e6c4b9d2d80f95b9cf67547718faecbb5a18e5b96de225ddad0c8c`,bytes:1505,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/util/gcbo.m":{sha256:`f70bff1f3014c64355398e445417e3a9b442f0f6bea4cc458fdd0f5698c0077f`,bytes:1856,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/util/gcf.m":{sha256:`abde2bc5acfdff3b097cd21d38b5ef4664f4707e931e1eb036d8c9f66818fab3`,bytes:2457,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/util/gco.m":{sha256:`6391878e48491bd02cea1d12f67d599f4258b222bf705d947bb4491d160db800`,bytes:2303,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/util/ginput.m":{sha256:`ffb9f7d601871f8434b42de91942b96da292cdf2f5324cb60358e294b5797a45`,bytes:5295,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/util/gnuplot_binary.m":{sha256:`57ce606955016d2db7415df85c419767049f88ab032be069d3bbfa8141ec288e`,bytes:2721,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/util/graphics_toolkit.m":{sha256:`d0531c85d7b340a4f27511f8a984b9c5126b5d83aa37c9cf1667b765aeb70898`,bytes:4694,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/util/groot.m":{sha256:`c1cb2f23d13c9ef8498ac3dbbd59879bfd92b0cbac243fbad25dfa53b726e64c`,bytes:2367,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/util/gui_mainfcn.m":{sha256:`13ab9fa614825792f6e32a3b111b8493bf8e78c8bfd37e26b9167308142583fe`,bytes:2681,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/util/hdl2struct.m":{sha256:`03e03735edea619356a056cf4d173a16f82aec2b9487e6d771be3aa7a9f60826`,bytes:5450,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/util/hggroup.m":{sha256:`dc8527dc4d7b1e8d379f36c89c6c9e42614c36a2f005d8ada5e4304b0970341b`,bytes:2571,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/util/hgload.m":{sha256:`0bdd462eabbf18f5e9f3200b43ad0125a339e30886d19e1c97f196b8b9391210`,bytes:4717,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/util/hgsave.m":{sha256:`cd4d384f23633ca367cc9fab6cbb3ca2bf403e591b833bfe65a05d2f5027208d`,bytes:4583,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/util/hgtransform.m":{sha256:`063078e369a4c59217bf1158e9f7877d95281d74120a22a50310ce220c26b21b`,bytes:7343,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/util/hold.m":{sha256:`c6c4cf4749790f540d37346cf6f9c7f526abd0d48211dc906686a7e8f0a381a6`,bytes:5389,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/util/isaxes.m":{sha256:`d68366e78dd468c86990049f71e6290143131ce1c1b77a62b7475b0e2c073c38`,bytes:2005,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/util/isfigure.m":{sha256:`c7d72e46e8072115718c89267c1dd917e6aa649cdb6ad23f4f48501b86cd9632`,bytes:1980,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/util/isgraphics.m":{sha256:`af4cb409f66eb5bf37a101d70e23ec044f586f1c57a77b4165fdd001ac882c33`,bytes:3556,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/util/ishandle.m":{sha256:`2d61ec031851e5042a76a0ddfb3c8694ef01549f9a8e3922c032ce0ced2a74fe`,bytes:2474,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/util/ishold.m":{sha256:`47e0de33ecf47017c99a783f23fedd8c2112bf88644035da9e93ea750f426471`,bytes:2845,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/util/isprop.m":{sha256:`8eb04cbc5a7da138477cffc1b846bddedc3a511678f7255b2ee0fcc846c7ba61`,bytes:2913,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/util/linkaxes.m":{sha256:`0fee9e5f1aba8accbfccd84119629f34ab6093600cd0d7bc04c4ae621ea3fd3e`,bytes:4995,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/util/linkprop.m":{sha256:`c8ee3bc239b6a77727854b9e82669484b3e796efb3aa6983386cb8799de6e9b2`,bytes:5746,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/util/meshgrid.m":{sha256:`2233081cacefac99d398c20e7983d4d50c4d74e194822bbaa190b5e8bed8b57a`,bytes:5152,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/util/ndgrid.m":{sha256:`3598d43bf883126ee9ceaf63fc3254370f6f4f931a0d0066981a77cda15fdde0`,bytes:4265,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/util/newplot.m":{sha256:`5797878da9f99508cbcd9ab493623c136bbb21a1714cc8ee2489693fcf9d7028`,bytes:9043,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/util/openfig.m":{sha256:`8363ee00bc20336ab61c4860e92a3b621d328a432d59e5c7e942ef68cb9d90e3`,bytes:5583,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/util/pan.m":{sha256:`e24c2a4a40d58cffd152114c148b3590be84ceb8583557f964e24ab4b0480e84`,bytes:3503,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/util/print.m":{sha256:`f8e895c8b080554059fe9bd7030468c88969d03ad583ea6beb27605154f4eec4`,bytes:41429,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/util/printd.m":{sha256:`c55b67a328d2c872c0cd4dd3adf29cc6d161ee2aef3478d8948010917dc8d159`,bytes:4199,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/util/private/__add_default_menu__.m":{sha256:`12d970e08d4e263f889996bbbc6d36cff8a137c611f5f25ec3a0ecedaf5ea65d`,bytes:14717,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/util/private/__ghostscript__.m":{sha256:`fbb9e2461e6679e3edfa2fce98a6edee68c535709bc6f923463861d8818f6c47`,bytes:6762,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/util/private/__gnuplot_draw_axes__.m":{sha256:`49e220e435ecdb11cb4b09ff7fee1c8b7adadbd815a033ec7678268b9277a9d8`,bytes:99927,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/util/private/__gnuplot_draw_figure__.m":{sha256:`1a593dc29260d310043cdaf6babacfcc3ff97526d59757864bea8be4a8aad68a`,bytes:9190,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/util/private/__gnuplot_get_var__.m":{sha256:`e02fcb850b0154fcf409bdacc8df7151154529a8f3010c32df47b5d526c9721a`,bytes:4702,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/util/private/__gnuplot_ginput__.m":{sha256:`5773bf824c160ccaceb0a023b1ee3af28ae1347604a70ad97b7385ede0404e18`,bytes:4748,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/util/private/__gnuplot_has_feature__.m":{sha256:`0d9e48eee95ef94bce5fa7970b13fb24bebbc658c977724957bbd768ceaafbf1`,bytes:2157,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/util/private/__gnuplot_has_terminal__.m":{sha256:`157d5f1d006bd5f09f7fa595914aa95baef1492cf783079cd7bd37646e7b93cc`,bytes:1947,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/util/private/__gnuplot_open_stream__.m":{sha256:`a83f20175f25a217228b20df5f6ee9fae4654d8f925cb4e7ca3d5ee6f3369810`,bytes:1779,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/util/private/__gnuplot_print__.m":{sha256:`27ec408ca153bfcc3c51ff199368c52f47b94e558acb7693735172763975dc9d`,bytes:13616,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/util/private/__gnuplot_version__.m":{sha256:`d600afa81add8ede31cb1fdd6ec7252a6123da69cb1f4e6cc8117b1720f9d87f`,bytes:2272,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/util/private/__opengl_print__.m":{sha256:`2a1005664a2fd43ee243289645d9e6eef144ebe106ff96f019201a189650473c`,bytes:7433,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/util/private/__print_parse_opts__.m":{sha256:`23ade9ea7ba11ec5b67fe0ad5145804d985e558fb1f249198e65763b87d2d402`,bytes:29296,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/util/private/__set_default_mouse_modes__.m":{sha256:`837788e6a3478f42fd5cdbc6e806320abe44b9ec19ba3c977b49feb9b452f6eb`,bytes:1807,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/util/refresh.m":{sha256:`4e6f430bcc265ccf3122e5e152993fc903a99f7a3fe57e4709c75d1f9158c5be`,bytes:1558,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/util/refreshdata.m":{sha256:`d9eb612f28b40a961d70fde61bae438145ba02416fdd72bbcc1b0dbb49f64f1a`,bytes:3691,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/util/rotate.m":{sha256:`f5f664db2047099c972b8a13525cfec018b988cfb4c1f390cc4c8a8af20ac618`,bytes:5593,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/util/rotate3d.m":{sha256:`cfb19d2da95e6c7894836795a8ad212eb4f9c794b21d3bd14e577a57514bdd23`,bytes:3142,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/util/saveas.m":{sha256:`8569338ab55781fabff38524e28ab9ecd62bb272709cf22a43e176cd2c7eb77a`,bytes:4161,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/util/savefig.m":{sha256:`e87eabc5163cfffca60e6f2e0f193ab43b51eeaf6f05b46046a36b267831f5a8`,bytes:4084,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/util/shg.m":{sha256:`c68d20c6c4ed3f8dbd7e26cbdcd9a9f077c4918bd6a759aa66f0f19404b06ab4`,bytes:1590,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/util/struct2hdl.m":{sha256:`dfe0f230532e8d71cfadfc8bc06811e3d76112f2416c3afaa34ee044cdbc5b69`,bytes:26909,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/util/subplot.m":{sha256:`f30ca9d9fbb5ed80d83a9a2a88d43543d4413d080c57c05455077128e6b3f390`,bytes:20568,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/plot/util/zoom.m":{sha256:`101cdb3c9c884d127e1bb86d8d5ac92bc2496cb7c4c14c1eb684f1a60bac1778`,bytes:5948,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/polynomial/compan.m":{sha256:`199eab17ad872a52cdaaa911cb56c32f17bd4c33fc955c1ff734febe7d07189f`,bytes:2931,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/polynomial/conv.m":{sha256:`f39286ac9f02f139659e3a2ee063094e3b53f100bae3675ddecd2af3b45d85ce`,bytes:4214,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/polynomial/deconv.m":{sha256:`3406ac88114b11859b622b37dc42280b2e6377d26eb61b52cdb9085cd8ddb58a`,bytes:3752,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/polynomial/mkpp.m":{sha256:`4fa642ff0b4a8dd0979d2f176fe2b3d0a08ab8ba3f6ff5692728113349ed28ef`,bytes:4761,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/polynomial/mpoles.m":{sha256:`19fd66c0eebdacca0bcffbc199dd19ac75ead1258bb7003dd5a5e616ee94bed5`,bytes:5117,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/polynomial/padecoef.m":{sha256:`b27432faa2b7d139ffd6e1e1af233b3ca14ff4848f34ce14dd6476c6854d3aab`,bytes:5341,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/polynomial/pchip.m":{sha256:`4542ddc9e92769094def1593292b848e4fa5feae8f968d553322ff4608deafc5`,bytes:5543,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/polynomial/poly.m":{sha256:`c01dd1147329a4dd8b0a0c911072efd8e44ab5f3260b0c0f91c1e543112017ec`,bytes:3896,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/polynomial/polyaffine.m":{sha256:`1cfaeecd60faf80eac7d5653b6da2c0daff6a6328727d721e6c4a797cdc60302`,bytes:2497,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/polynomial/polyder.m":{sha256:`a9cabf4411d7e78f46d553b4a337dd8f1241fb237d2c3a045dfa28e8b7b62d2e`,bytes:3075,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/polynomial/polyeig.m":{sha256:`c010f7f0440b6ec06f4829ec3d449004f490a8e5840986c52ba4adfae7600d14`,bytes:3275,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/polynomial/polyfit.m":{sha256:`ad390b53987cc718d5b8a52a3bd75b39b131ab2d0f0b54f24c21d05b4be49b67`,bytes:10725,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/polynomial/polygcd.m":{sha256:`a5cc9ae0f36870b2053c6b00a16b10983f3a8c74db5b44cf1602a0f3a49adfbf`,bytes:3223,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/polynomial/polyint.m":{sha256:`633d58252b4e1cb4d6939337da5eb11a1547e096f2b1a687c3a1dd9caedb90e0`,bytes:2239,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/polynomial/polyout.m":{sha256:`97b58cde2fcbad661ffbff7e3c2bbb9a9a37c2aec3bfa6585352b0d8c1d86c65`,bytes:2839,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/polynomial/polyreduce.m":{sha256:`5f0839fbca91ec56045da169638038ae618201aa72f7dae9fc49da7de41e2a7c`,bytes:1870,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/polynomial/polyval.m":{sha256:`9b27395e4ce88a7e28776deefacaaa8d7c1f2981c09e03619a64e89316a2521b`,bytes:6726,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/polynomial/polyvalm.m":{sha256:`f8bd98c5988f3cfa49da2e771be0f3a2d8cf4b2eebd9c1923eca1d8067b5ffc0`,bytes:2190,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/polynomial/ppder.m":{sha256:`674422206756a09354de1ae0dbd98f78af9832e0ed6e36bdb769c76c4d64b976`,bytes:2342,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/polynomial/ppint.m":{sha256:`cfc5d70ec89a96918441758b06fd61b99f91f5bb71d997aaa549d1bd257628a8`,bytes:2041,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/polynomial/ppjumps.m":{sha256:`5784f598bb104932f79b72a4371c02eb337adc1e0b22d384a5254fe9e7cb90f9`,bytes:2552,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/polynomial/ppval.m":{sha256:`286ad8baf55fe27607b493d30a2788185c8dcd387c2aac97098c6c978f08a2a1`,bytes:4394,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/polynomial/private/__splinefit__.m":{sha256:`e2c2ca3ef8c5ca33728b70b8966c47b989cf5c002c12d42618f4a77f4e418239`,bytes:16809,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/polynomial/residue.m":{sha256:`9b2fbccb8844b435c8ede5f0056c3136a953d6e41dcc3bc9af551ffe0f91805f`,bytes:11261,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/polynomial/roots.m":{sha256:`dc7d73642f4a943fccbf5032a929d2af41db95ffe878c0cef94a8036548d2137`,bytes:3369,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/polynomial/spline.m":{sha256:`54c56f23a9f9330631befa353b4c9924defeb8167fa5cf2c0d8f24e0e8a989ae`,bytes:9482,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/polynomial/splinefit.m":{sha256:`4642785ea2ec1d701a0a003da41c0b67b60ea057f90f4c76f6ee94a043b550dd`,bytes:8634,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/polynomial/unmkpp.m":{sha256:`dc3fd5b15646e148a4863abdcd4fc8c47ab28b6b67d21786321e6ff94a160973`,bytes:3392,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/prefs/addpref.m":{sha256:`c9ace3f6a63d81f08bc0fa47024e329a85ac3642b8af9ff91443fc064f13b949`,bytes:4053,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/prefs/getpref.m":{sha256:`60e9d6e18f8f5a8b1eb1dc5b53461b653d2e4bc815cb16d20a54a4d63dd9153a`,bytes:5680,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/prefs/ispref.m":{sha256:`a1a5e03448fbd76d47ddb101e6ba204f51d4f9cd660b1ef8dbba9a47abbaa209`,bytes:3180,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/prefs/prefdir.m":{sha256:`d7ea33bb185470bb1ce98bfbe43d8fae67470080990822bd53aecf84de3367ac`,bytes:1701,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/prefs/preferences.m":{sha256:`535a360bdd9d3ce518c204c84e5e1e9c5322572ce5c5f36ae26ee91eb7a54883`,bytes:1460,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/prefs/private/loadprefs.m":{sha256:`a59acca778bcf8dc74e55a96ac87c4775e58ddfda336f2ef07b73900f6e2b616`,bytes:1379,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/prefs/private/prefsfile.m":{sha256:`75417d742b75fda92fb5d3f5ab1299808a53c4ee961bd521f754ebb591dceaa7`,bytes:1274,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/prefs/private/saveprefs.m":{sha256:`82a29e890887169a709cabdf3ad03687821efe4e0079bd197e54fb0bd33ea014`,bytes:1261,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/prefs/rmpref.m":{sha256:`628e09493e9be5b92baae26815624a04aae6903c5d32ca0711b6ef36c9b536bd`,bytes:3835,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/prefs/setpref.m":{sha256:`88dfcd1fa0e18df0875129b3addae31a2d25ab7716155c4510851d60396afdd6`,bytes:3574,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/profiler/profexplore.m":{sha256:`7a8a54dd54086d101cb58103297d726018f35ea0ac2c21137988096838a00dd8`,bytes:4973,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/profiler/profexport.m":{sha256:`48599273a71e933d73eda6c2b3d2a5eeb571ccbc79e34402657da60cebeb27fc`,bytes:9504,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/profiler/profile.m":{sha256:`7c9adb428a6d2a747e6f9d76b993ce539e23241d66aea82760c758b410ec6666`,bytes:5130,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/profiler/profshow.m":{sha256:`d0f392ececae0bccdba13d33bbe429aa9cb435b6b949e1671f667b0551d15506`,bytes:3868,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/set/intersect.m":{sha256:`dff2c534478bea3056d713ee892e179efae70e92792f49b8b17d7be40059951c`,bytes:8482,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/set/ismember.m":{sha256:`f50b44bf3c413a4282acf664fdf35653735b47d36fabc3a5027d66c3a9b769fb`,bytes:9459,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/set/ismembertol.m":{sha256:`ab89c783a208bd82ceb3e8b363f0f6596089f4dc33f1de6d70f39ee392df84cc`,bytes:10620,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/set/powerset.m":{sha256:`9363765c575dcd79b4674054b482c6b6e1d5acb215df2291ccc2ecf0fc3cc7fe`,bytes:3616,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/set/private/validsetargs.m":{sha256:`b57efeef0aff69831f58031cc00a86559ec2db4de09b112ef0b6805fef847108`,bytes:3261,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/set/setdiff.m":{sha256:`548fd1632dd00374c193f417b9f73dfa090118655c87a6e2c98e6a68a85ff130`,bytes:6599,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/set/setxor.m":{sha256:`b4deecc4cdc628ce80a6aa3f0e5312edcb4623933916bac146aa02fff6e0a334`,bytes:7433,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/set/union.m":{sha256:`7417865f8e7f82d6d7eaf37fbe323150a28341028bfb08287eb64183d3b1434d`,bytes:7779,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/set/unique.m":{sha256:`461ed24c64987255b0c21ff0c9f121ffabbd1fbaa60d1f6684467f617d7610e8`,bytes:15488,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/set/uniquetol.m":{sha256:`94826fb8674445471a458a3ec761ab435224f2f36242efe9b4f3b88ed8b149f4`,bytes:16559,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/signal/__parse_movargs__.m":{sha256:`6220505f9bade378b07a5351ddeb4f9c9eeca798fa3c81b4281981938665a4af`,bytes:3811,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/signal/arch_fit.m":{sha256:`b449d3370580aa9d826e56795857dccf532e19fe48fde6b4f6719a8d46a4ca59`,bytes:3673,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/signal/arch_rnd.m":{sha256:`e127acb543fe87bf72e92de79cc664e5975390f94bbd709c7457bec54113ecbe`,bytes:2953,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/signal/arch_test.m":{sha256:`da2bc63e8d504b668596b0cc1445fdfe8ce6c261832601f7d8b2728393abd76b`,bytes:3128,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/signal/arma_rnd.m":{sha256:`e2eb1b846c5f8d8f430cd7315015950ef3a6dd964c7c02e8b0edef73512440fe`,bytes:2513,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/signal/autoreg_matrix.m":{sha256:`92c12223b80cdaa00a09c61d6cbb443a1efb646cb09fc9867f29cd6170c2cc18`,bytes:2070,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/signal/bartlett.m":{sha256:`0e4a74a05b06d24c68b3b36fc2beecd4396bdf16267213ade18f5adbe6c7dfbd`,bytes:2005,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/signal/blackman.m":{sha256:`c2dbaf34343b70fa298df99223e53dc38a0628e5ea62ba0e6613753c4f8a4fc0`,bytes:3047,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/signal/detrend.m":{sha256:`699e7b32439870c8a9f2a6354a3a823cb61daf40b819f6d6f613a4d57fe106a6`,bytes:3010,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/signal/diffpara.m":{sha256:`424cb8c8d0621c187f9dfcfb46f872d19c21099269ff318d63a9c0f412d3baa8`,bytes:2657,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/signal/durbinlevinson.m":{sha256:`8ccfcd88fdebae4b43abea601bc6465947f5dc32a2d353c4e67d612fdd0f94df`,bytes:2659,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/signal/fftconv.m":{sha256:`6bc772fd2aa19747fdd20c6890404854702458e11afd28fa4f837adbc3df1bd8`,bytes:3410,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/signal/fftfilt.m":{sha256:`ab34059b380c044cb898e279818724a6ed071665fef3bb662b31b18a7e94a332`,bytes:5956,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/signal/fftshift.m":{sha256:`c75d315b48d897d95b803161e1194376a2530bd890d1ed7c722acf66d069a32b`,bytes:4249,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/signal/filter2.m":{sha256:`daebac7f3c0e634bb4c30a4bcf7e25659aaa00a54b4623532de63298b7fe8672`,bytes:1955,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/signal/fractdiff.m":{sha256:`e01c7ca9913978dda5000493f539d814e7b4615f976c9b5d525ed5a0d7cced48`,bytes:1913,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/signal/freqz.m":{sha256:`87608708d07b17e913822711c1ab6b3fc182cd0bc943555d46631722767d599a`,bytes:6835,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/signal/freqz_plot.m":{sha256:`3388454340bcc12b15601eb65ab20d1dce1904cb8d187d0a9a4e547dea415e0b`,bytes:2153,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/signal/hamming.m":{sha256:`0d1f7f1e24a89b8720b00f2549445ef93dcf8793b7b90575ce16ac093e214c13`,bytes:2904,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/signal/hanning.m":{sha256:`a4d29f846e86802941c9b2fe20fda71b40f65ffd113927b84ad3753b5af10a81`,bytes:2889,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/signal/hurst.m":{sha256:`5efd553ab5830155c7ee76caf62ff0dd348b06366d2c52ce8e93c23a8e58433e`,bytes:1619,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/signal/ifftshift.m":{sha256:`211e7227e044d5689dc95ba32dea63bb61707ccf55f6abdef7c98a337cd53172`,bytes:3646,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/signal/movfun.m":{sha256:`2cb195bccbe71afa10cec16b1ed01f384375b387927b0051d40abdcfb1921a7b`,bytes:76235,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/signal/movslice.m":{sha256:`ff01de7447f6cd0ad9338c57a7b0f70baf9b36dfb3ce02c613a5a34979939941`,bytes:19904,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/signal/periodogram.m":{sha256:`e8d805bb2cbd103ecc9af3b8fb14e4ab0768c86bc69124f7c4ef6c1db1f94af9`,bytes:6676,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/signal/private/rectangle_lw.m":{sha256:`e2a19d3428787795914055626310d5a5c0f35ea1ace68213180790abb200cede`,bytes:1332,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/signal/private/rectangle_sw.m":{sha256:`04779b75dffc684530630aa27c347f3e1cfca105145d011cb7cefa6a8793ccb1`,bytes:1414,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/signal/private/triangle_lw.m":{sha256:`9723497077b06cbdfed0de411a453d5cc24309a44a04b9cfa5c6b45c4590135c`,bytes:1334,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/signal/private/triangle_sw.m":{sha256:`b31760b637d2c67cad3e565c23c45ed94f42d98aa21d05b98aeeaee8a66c6bf6`,bytes:1407,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/signal/sinc.m":{sha256:`fd0fc60d8764e8449ef4cfd639e26bb39938d4e734b9b1d5513a42aad209ce2d`,bytes:1587,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/signal/sinetone.m":{sha256:`d118ad0895cc901cc07f5ab348a0a0841c86c95aef3362c85a68d45faf6cdc9b`,bytes:2084,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/signal/sinewave.m":{sha256:`d8c4eb8b2ce9c8a555e85d166d30ccf43b01cdd36e378988983d663915f8e713`,bytes:1956,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/signal/spectral_adf.m":{sha256:`84a617f828da455c0f69a8ee7c4fc2f03a1a52471eb2604dd4ce4137848e270c`,bytes:2413,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/signal/spectral_xdf.m":{sha256:`f1f20e12e140d4515b72301b76fcc3b7829cb3c92b550ca1ee2287065d953909`,bytes:2452,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/signal/spencer.m":{sha256:`b5065f1dceb650f4be5b388d2c8cb7add816ebaa1cbbbda805be2f9b1bf87bf6`,bytes:1594,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/signal/stft.m":{sha256:`25b10a98b0f769dcb4efd90991c9efcd1c51236acf4ed73576af5f51dc8fe3cb`,bytes:3866,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/signal/synthesis.m":{sha256:`116645aa4140439d2a3edf63f74f75470f99131a1f1447e06e8b1e172810b352`,bytes:2107,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/signal/unwrap.m":{sha256:`0b12e6a36a3dd1dcd0036eee38ed460e4160488eed860edb7e685c0f0dd636c4`,bytes:10030,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/signal/yulewalker.m":{sha256:`d8a9c787d7162798558a71909eacc6551bba2897bd025ade94adbc5b927fa8b5`,bytes:1673,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/sparse/bicg.m":{sha256:`53340fc241f1e62963b87f6a79ef17c459ab20489da934786cce6e188f36b73e`,bytes:18465,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/sparse/bicgstab.m":{sha256:`71e47ac034f6eee64d0ede48139f82c0d50da7852a9134fb0bbe5f895d7cc968`,bytes:16374,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/sparse/cgs.m":{sha256:`8dcfe8afc6fe40190bad5f4c8332a4fd68d6507f3bc484adcb231c96ad45e098`,bytes:14610,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/sparse/colperm.m":{sha256:`2e1ff37a855636e003432dfce92a3a1422bd219ff9d9c4c8ae1a2537b457f6ad`,bytes:1607,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/sparse/eigs.m":{sha256:`ab4ee1cb3b421e56056e654ff1d4712050ce9788725d24b4f14084d2f19257f6`,bytes:55846,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/sparse/etreeplot.m":{sha256:`315bab2f81c2c0a75ee999582e116412fdf519b4a97c982984b6d0e66f636d3a`,bytes:1667,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/sparse/gmres.m":{sha256:`9de04c23fae612629184e6caad3c5e20874ad93bf32e3411e73509d7818d11a9`,bytes:22350,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/sparse/gplot.m":{sha256:`fcd7242c33a4b0eb0f3842152d31852f596cdb0708bdd72b5471126cd3ba7831`,bytes:2649,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/sparse/ichol.m":{sha256:`f4af28cfc6dee4a33bbd1d48c7329ccc45f585e1d7742f11f21ccc21ca8317ae`,bytes:14795,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/sparse/ilu.m":{sha256:`5bcf627bec40e832a421c6d9111270cabbea3866f608b60d72b8ffe10e4705f0`,bytes:18169,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/sparse/nonzeros.m":{sha256:`9d7e576787c11ab37006f7e4ed069ce51e6676c03442074fbdabd450ac630ef4`,bytes:1643,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/sparse/pcg.m":{sha256:`d71b17357070c8ed7a218bf3fcf7273c708337121325eca77881d58319252fb4`,bytes:21926,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/sparse/pcr.m":{sha256:`b2730fa473d9d6112a7d0126766898a566af5339c9d6b868f3a1c6c6151964d1`,bytes:13616,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/sparse/private/__alltohandles__.m":{sha256:`96610e0c457bbe43d4ecd71bdf2210bca9aab27e3d0b68c7f60aaf2b1b27d15f`,bytes:5048,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/sparse/private/__default__input__.m":{sha256:`c122dad4b285ec2e6a8b23eab4c904f36db4da4db427d47fc06f4be9f49ef17b`,bytes:2181,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/sparse/private/__sprand__.m":{sha256:`c4983a97ca36c2acd8776c64df596e944ef02faeb8e86095a83fac5dc57f48e7`,bytes:5319,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/sparse/qmr.m":{sha256:`9e2d1a25243bfe4195721a740128231e8085b2ad8660c5b9a5925c9c866d39b4`,bytes:9729,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/sparse/spaugment.m":{sha256:`f39c79cef384a0e2b4e889bc78e6a6aa1d12d23805ea3f6f79efbf8211082546`,bytes:3467,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/sparse/spconvert.m":{sha256:`68f7cb145dad609a6b2c002124ef77a99ea7bf8110b40ca358dbd8878bee47a5`,bytes:2600,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/sparse/spdiags.m":{sha256:`d859464b34ae2d8711a431435e22c0dee9c9a62c50c1672b0212a76ec5bca169`,bytes:5261,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/sparse/speye.m":{sha256:`316661ba3fc03746c71594f8f10b486e4ad4dc0f378bebd60d9c89c70f99ae93`,bytes:2679,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/sparse/spfun.m":{sha256:`4cfd0a1a99b69073b0e83076665d92338fa2cee986bb65e7348ee1420d7d5eb6`,bytes:3074,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/sparse/spones.m":{sha256:`23c15e6a74e58c66c93513a5265c4b5a271a6f0a0a51e5e470620be2cf0622d2`,bytes:1602,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/sparse/sprand.m":{sha256:`d775d4c452c4782e2c98c9156fa87b1751728bc7c513a15f8f0b283960e3212d`,bytes:4207,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/sparse/sprandn.m":{sha256:`4f8b4a2886de13773a6e3dc2eb7207dc789ddd4b5eb2035cb9bf231b56240282`,bytes:4212,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/sparse/sprandsym.m":{sha256:`f0be10e178dded859c2fd143d3ff3071374cfc081add9abef9502be921a6326d`,bytes:5819,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/sparse/spstats.m":{sha256:`12442deffa82453e0874b7c756293c8ccf66ed5856d2d74142849a2191c69c5a`,bytes:2427,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/sparse/spy.m":{sha256:`f4bdb84295940ea210caf813f681e91a609e3bf73029a53fe76bef38b854023b`,bytes:2445,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/sparse/svds.m":{sha256:`843c5f4b7141f68a9b6ea5d6179de8354176a45cd9accf3706a5f45019e4b52b`,bytes:10273,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/sparse/tfqmr.m":{sha256:`8c59bda0aecfbd428ca5c25ffec379f7335fd11971640c8d37bda0cdf5432c6f`,bytes:16190,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/sparse/treelayout.m":{sha256:`06529a1a2e34f82aee34284c9a39525a8f7a5f0bdf1a894e79199f14b26ac352`,bytes:7230,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/sparse/treeplot.m":{sha256:`3e2f2a90ba03135edb35a814a268592d31856a450893de76c196b9e3fdc1878a`,bytes:7103,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/specfun/beta.m":{sha256:`fa0d1c644881a368683082df49799b8f27d69ff571efde4ca1ec2fcf249fb49d`,bytes:2969,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/specfun/betainc.m":{sha256:`f4172714366a417be1fa27cf0775ff462f090e3af134b94b02c10f29472f04fa`,bytes:10126,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/specfun/betaincinv.m":{sha256:`63aef7b861ae04f2f345594f9121d133ab991e0348338368c692992d4b4f806b`,bytes:10648,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/specfun/betaln.m":{sha256:`a5a5b441e921eb7e92b4bc12c2025f566ad64c4b953afd547f74fdf6b6520d7f`,bytes:2212,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/specfun/cosint.m":{sha256:`c59818f3bc066be0bc1326d3c09c7f1b15544793359b1b38d23e103b74a4f727`,bytes:8018,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/specfun/ellipke.m":{sha256:`bab92f5cf155706b12ce59eabad3a3cbf02a42c28e231a427a3f27b22fcae405`,bytes:6484,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/specfun/expint.m":{sha256:`ede264b0f07b75b2d16c56344c5d15779cbde16746c2116cdf81e9db4c8a6ff1`,bytes:9253,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/specfun/factor.m":{sha256:`d43a7ec932f31ee5d8d62c644857cbdb20db71c1ec3a631aba0a75c722195032`,bytes:7605,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/specfun/factorial.m":{sha256:`3d163dfadadaa7e352a9a31f849005ea4aabe1b5eb1cb9a5ef5938df9da2fbcc`,bytes:2714,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/specfun/gammainc.m":{sha256:`77bd560f9feabe3342e9958eade0548bc455401ae7bf36765683de580f73b3a3`,bytes:18953,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/specfun/gammaincinv.m":{sha256:`b272d2b87dd2310be247e27194cb50fe992974e555a458e9afa3eb045c9eadc0`,bytes:9450,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/specfun/isprime.m":{sha256:`6afd851219d0bb4dfd4976118e72e6adc6c60304cf29be2c697972eb565f5496`,bytes:7122,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/specfun/lcm.m":{sha256:`15b0600273779b978ab5ebd2a36950f16f99480ba5ed44c341923054703d94ca`,bytes:3638,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/specfun/legendre.m":{sha256:`4f7a1237fffc83357fd5d0e94555b4b375186cc6c5fc1da2d3a328f486cb3b75`,bytes:8972,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/specfun/nchoosek.m":{sha256:`4826ec4b888007767402dd766e6eb9bca695597d88339b7545209fd54ceac7c8`,bytes:10767,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/specfun/nthroot.m":{sha256:`a11f27e82bd58ba0058b5693dd34646d460eca2c5df4773d74549a7ce47e6f72`,bytes:3396,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/specfun/primes.m":{sha256:`cda1204108f6d142dd99e80141f57ef1d032d5ae03b986f35ffbb35584e846e9`,bytes:4970,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/specfun/reallog.m":{sha256:`0e01025a5767e601c86a039bcb3d16d3a92a08a4aefb58137f9bc37208866411`,bytes:1745,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/specfun/realpow.m":{sha256:`ec3e942db3653b71e5fe1fd27b248f712a93585a00eecd89c8320a651fe9cf4e`,bytes:1904,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/specfun/realsqrt.m":{sha256:`be7e5a38396be6d885f3da1d12feb3e717881dbfe5090fdf0473c40cd7aa5df3`,bytes:1703,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/specfun/sinint.m":{sha256:`03448c6a7ba8a63de7944c1bcfcd0166cd9d06426e6c6fb30b3fca1dcb1f7afd`,bytes:5811,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/special-matrix/gallery.m":{sha256:`ce10db79da22893b2d25622b22f8ff8ef9070184b38d6c3ceb657ed30a2aed8f`,bytes:115537,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/special-matrix/hadamard.m":{sha256:`d3e2a9af4ab8dc4b541cda1eaeb664f36005fb4bb2abe25b8cb09cfd0a7eb483`,bytes:6274,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/special-matrix/hankel.m":{sha256:`9bb0cfb7c2a6d000ddf5497af82e49eddc8e9c339a8aa94b7df7b4e67f1e3475`,bytes:3045,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/special-matrix/hilb.m":{sha256:`78641bec1fb5db2fda2a473127fca731a90482d560112a400788544041cd8265`,bytes:2297,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/special-matrix/invhilb.m":{sha256:`245e1f939ec880e812e1ad138fe0e8e77a38ab9defd6010c9d4f9e208237d28e`,bytes:4157,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/special-matrix/magic.m":{sha256:`dd716e8dc932b7c220986c03d06bd911f9355d7126f3437d08a0d4917d3aa5da`,bytes:2984,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/special-matrix/pascal.m":{sha256:`bf656dcc827bee84851966f6a6d6e4765e52defdc5dc682c6a956e540f694c75`,bytes:2993,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/special-matrix/rosser.m":{sha256:`badf672fac59ecc842a9522ad44240dd6468c38fbc76c91dad045a0d6e6d4122`,bytes:1866,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/special-matrix/toeplitz.m":{sha256:`b3331b95add098f2b771b98928a8c2dc417b7370b71c8de2e5491051888e8c5a`,bytes:4308,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/special-matrix/vander.m":{sha256:`6ba8436fd5084ebeb2ef4c78e702f69a5f31c4961befdffdef8a063fc7783204`,bytes:3129,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/special-matrix/wilkinson.m":{sha256:`167eff0c7366c5766fdb076fc5ec8340f1e3c1c137369b7117766ac88560b6c0`,bytes:2163,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/startup/inputrc":{sha256:`647778231817ff3d3b37efe00e69737f2d667b66b18efb6f4b5bfac3e3dcdb36`,bytes:1296,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/startup/octaverc":{sha256:`7079a4794354d546e9e58c132cb6278ee79a981c8a5a424cf22a457ca1e88857`,bytes:1011,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/statistics/bounds.m":{sha256:`f2667a72e8a53dc862a33c61821a4fdf882e58389597f319c376211c24bc18f0`,bytes:4078,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/statistics/center.m":{sha256:`0eb2fa7cbf7d0ecee82f8070abb3b075ceba5133621d10548f4a60e1e5e3ddd6`,bytes:3338,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/statistics/corr.m":{sha256:`f5a723b6b401e029c0497d2d19a7989f0902a01c26f03e3497897b403fb05b5e`,bytes:7836,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/statistics/corrcoef.m":{sha256:`222468beef38e3c65868ab98b4830f5a196df37bcfe3b3faa2959e7a7f0d8559`,bytes:8940,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/statistics/cov.m":{sha256:`f57f7962288a07fbcce9fe57cdd86947a1ac1c3cb2c3762305013f571fc48bef`,bytes:19630,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/statistics/discrete_cdf.m":{sha256:`a001d1cdfb764601c9043514a8876170d5769d71add4bb655294b15eaee13186`,bytes:3090,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/statistics/discrete_inv.m":{sha256:`058dc85a3d37739f562b3aafea8076a80709f30d1171b32a240f8dbcba0b8c47`,bytes:3320,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/statistics/discrete_pdf.m":{sha256:`8177e6bda3e0cd33a5b348090e8c84a1a4c130855df06cd14177b29ce12b7f3b`,bytes:3133,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/statistics/discrete_rnd.m":{sha256:`ce67c5af0e74e7f18d1594506446757d62286635c8a0673e3122949f140f0b36`,bytes:4116,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/statistics/empirical_cdf.m":{sha256:`4c064f87c86afc90d223cea9fb8ee76b01d96ca871c68b3226066b152920becc`,bytes:2116,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/statistics/empirical_inv.m":{sha256:`64f59607c6cf828265f789af5fe3d732905901f2afc0e9bee22fcd88d38c99fd`,bytes:2055,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/statistics/empirical_pdf.m":{sha256:`6d2c59927f68cd664f13d3c2a1509855628c8cec29f37fe4ac05f0d9c76414c2`,bytes:2230,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/statistics/empirical_rnd.m":{sha256:`5b8cbce366b047826956651723cf09d8def21ff2a3dc8edf3f999acef103437e`,bytes:2639,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/statistics/histc.m":{sha256:`16ac515dc8f7706423c3b6f453aadce457c41bda294f8dbaa90942b931012de9`,bytes:5490,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/statistics/iqr.m":{sha256:`4c4241d5e02b6c8a2825bd183ce163967522330b2dc28e86fa360186c5d1240b`,bytes:11936,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/statistics/kendall.m":{sha256:`c08dacff8facff2b7886a00556dae05e00ab46a9977b762eb00290aa298a83db`,bytes:3926,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/statistics/kurtosis.m":{sha256:`662c21be7b3b3369c286b80673237cfe3cc7a506aa400653fc118021f3b4e751`,bytes:5458,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/statistics/mad.m":{sha256:`3107ca6e8660604867d3168458e2af4af478d8662b765646bbe88a2154cfe958`,bytes:8959,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/statistics/mean.m":{sha256:`73baaaf8ca3604b37a018295c7f1662c1a961b8f9970a1e814e729d32ff4f31d`,bytes:21536,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/statistics/meansq.m":{sha256:`378ca201f8a363e0f12e970b67638444868921dd0ecf4f30fa1332365a93b7ec`,bytes:2846,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/statistics/median.m":{sha256:`3ac84b7ffb6f06bbeb4e99b5990e3d4fa76c70b21367903c21a545c0750439d9`,bytes:26725,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/statistics/mode.m":{sha256:`a21ac585359d5ec1777ba1f400a3506436b020a20168a967afe5a9fd696344f7`,bytes:9900,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/statistics/moment.m":{sha256:`40a4d8e8933ce0e9b1cb1e95e12993cd2e30540b113a48810befff85785473bf`,bytes:5743,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/statistics/movmad.m":{sha256:`47fed79babdb745eb67868c74675aa41ab9329bb77f62abb17e0fa7e917e6d3a`,bytes:8275,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/statistics/movmax.m":{sha256:`9c99ecc6ba5f87cc434f2e0ab5c3a0a15eb8e10550dd5160211449329cec345f`,bytes:4979,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/statistics/movmean.m":{sha256:`9073fa6b0f6b92c7864f35e1ef2f7c534d0910c38877f0412316146b7bce66f1`,bytes:4806,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/statistics/movmedian.m":{sha256:`75de81f6f58d4a61e4a13ce1eb19a258a92dcf8d2b716bb7e3436052267f87f0`,bytes:4805,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/statistics/movmin.m":{sha256:`96918783fa3ed91ee31f8515436b3a4659805610afd3ebe2a0bfdeb457bd8f2a`,bytes:4929,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/statistics/movprod.m":{sha256:`f5ebeb291c558bf4cfea0ce2075f6664ea9f0f005799e03915855354897e51ec`,bytes:5155,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/statistics/movstd.m":{sha256:`5754e27e040f1e0406c8a0226e812f39752b44294d10bbf0e5d9a173a958238e`,bytes:7132,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/statistics/movsum.m":{sha256:`e5be7fbf4a879421290a7616a470b8384d173f260cffd37bba5a6706f9056c9c`,bytes:4979,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/statistics/movvar.m":{sha256:`5470a21fc6f7fdcc93f2f059b585ec3e19f9515bc9ce1ac4379a296d75d1db91`,bytes:6907,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/statistics/normalize.m":{sha256:`8e310745a520ac6bd83196aa290644da0be9b57b494c5c7eae882ff2bdb1520f`,bytes:26385,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/statistics/prctile.m":{sha256:`047ef6138d5ef878a964f5fc37f4c5a7ba01f45842529180277407c1064db4cc`,bytes:5634,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/statistics/quantile.m":{sha256:`e1913985a4753fedae1a6486dcf85f2411eef8c9ba96077c56edb15760781b5d`,bytes:15275,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/statistics/range.m":{sha256:`90038cef095eb118946cc8e627f929dd6f9bcd132f8e9dee018d6a365a34de8d`,bytes:2134,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/statistics/ranks.m":{sha256:`07c83f7cd5a85bbc74a1b0bb2a7eb8e18c2c21b8e468d6313814599f452a4362`,bytes:5795,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/statistics/run_count.m":{sha256:`e5aea8ff673db04b48d06dd795fb8caba41dac587cdf58c9dac36ce1d44ca633`,bytes:3395,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/statistics/runlength.m":{sha256:`de6c4a04bcabdb44148ae4355bb8e6cf8baec103c49259109d26f6ac8239fe76`,bytes:2294,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/statistics/skewness.m":{sha256:`2e78b399ca4d52ceca817b1148589d86abbfa88733b2731e1c3db345ea7e08b2`,bytes:5529,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/statistics/spearman.m":{sha256:`ec6ba7dfb9f82f92455fa5debf093683e1c440ae2e953f5c03b44062ecde1109`,bytes:3310,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/statistics/statistics.m":{sha256:`fa717db87541758df626d9a7ac921f5b95e8788862723ce988329ff8443e59ba`,bytes:3313,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/statistics/std.m":{sha256:`ee2a6b9da21efaf0710b6f8c5662dbed13117cb8fc4198d8fec0cba70d8f72df`,bytes:5622,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/statistics/var.m":{sha256:`c0012ea37ea0130497a6329fc189df56c9ad6286b22c0be408d1796e380b92a7`,bytes:31242,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/statistics/zscore.m":{sha256:`8ab71aac20bff51994de211dfb8ca5e9aa4b73abef1ea184f1fcea2fd3b4743e`,bytes:3641,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/strings/base2dec.m":{sha256:`ca369bbd13b3158e6d70055fbc1dff0213ebff6ad649307693dca43fdcb6ec02`,bytes:4630,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/strings/bin2dec.m":{sha256:`77e407f1c2245748999076277f9643b662152966122089c69fcf154917f71eb9`,bytes:2359,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/strings/blanks.m":{sha256:`074a98299755975927387ae61f03f1d58352d486ebbf4e0fe4aa488c2ed86f13`,bytes:2090,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/strings/cstrcat.m":{sha256:`2c6cd8f68db43581f092c155cce43cebc32ff779f36670902586665208c90bb4`,bytes:2320,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/strings/deblank.m":{sha256:`a3c38d4bb2f391a293cfd4ccc5072f1ae6ad9a29573d0123f4cc64e55dcf4540`,bytes:3348,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/strings/dec2base.m":{sha256:`69cd33391b6ab93ec0abd99a095c5df5de6be99c531a46cf858bde71f029f630`,bytes:11649,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/strings/dec2bin.m":{sha256:`d00d2afe81e3f8204c0389e98ce086b7eed22f8cb221b3720de9c2bc9026c60c`,bytes:5284,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/strings/dec2hex.m":{sha256:`d050a88fe75695c4cc2f6b8d785a51f5d8c67c01dbf9cc5c7215e4b2928274bb`,bytes:4476,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/strings/endsWith.m":{sha256:`c8b5398c9a9e06da148a98d5fca431197f998e04e8e9763d372fb05dd690dbcf`,bytes:6252,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/strings/erase.m":{sha256:`c697a3ef2cb61b1e7426261d576e1c8f3cea26e89ecfdf610307d1aeafdbabd9`,bytes:5098,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/strings/hex2dec.m":{sha256:`c9e4698d320dbb6e8c562558eaedadd7d8f5094e04709a7ccc7e4433ba3738e1`,bytes:2075,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/strings/index.m":{sha256:`d41df98fa7fecde343bf5b5361ad08a966b2dcb022e307173d0f5246bd257da2`,bytes:3609,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/strings/isletter.m":{sha256:`f8835ebbf28d0ff1928912687ab8149c97dec3ad29043628f39262aefaad34e2`,bytes:1518,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/strings/isstring.m":{sha256:`b56ddaf0f3831ca76cdd3a13eb02d965e6c61d10719cba187edc035e7fbed077`,bytes:2224,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/strings/isstrprop.m":{sha256:`d3dcae3ffd0956523a58e5375d82c5ad72f4ad649d805d9fe0dabefa1ad8fd72`,bytes:5432,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/strings/mat2str.m":{sha256:`8bfafb5b410e99a29b244563dae4b63d1c84591e3f55c20a6b591acf4c602993`,bytes:4787,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/strings/native2unicode.m":{sha256:`ba81d8a0018e4df7d464ce4db232d0c8f988a5955f93948db4d289070d938297`,bytes:3967,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/strings/ostrsplit.m":{sha256:`bd103000ad3d80028443022f2c8a95701853e269bbf57c47bf4ef59078054c1d`,bytes:3952,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/strings/regexptranslate.m":{sha256:`ab6b67ec89dab86a28f06a420f8ea2c63d17fe7123a4d6af9af7975506401e2f`,bytes:3056,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/strings/rindex.m":{sha256:`7619ebd78e5b87b798f44a53b6a3fac5cdf704121bfc1e73acdf8366126f2cae`,bytes:2087,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/strings/startsWith.m":{sha256:`bd3d35b34468284f8c6923d9bf79d4344a5441f3b4dfce5ab55dd7af43ca71d3`,bytes:6194,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/strings/str2num.m":{sha256:`faf811cceb7d855a930447c9165d2dfc9b1a433d62e5d4c8d4a7f1e2ccaf14bc`,bytes:2737,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/strings/strcat.m":{sha256:`7cf10fe786a09f45f79d0d02d8db91c62a96d3160e2650ab90ab204917d22adb`,bytes:5062,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/strings/strchr.m":{sha256:`52dcd7006fa7629a63dc676b8ce9068a7d9ea41470e9902974899b92726a5567`,bytes:3302,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/strings/strjoin.m":{sha256:`7bd21816224739739bba68f9f686b847c22150f0cd7d8084d62e4d169a46e778`,bytes:3264,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/strings/strjust.m":{sha256:`a95b358031b1cbcd6ec54f0dc412985a048a990293dbdf0b9d1a39651ad4bff4`,bytes:3929,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/strings/strsplit.m":{sha256:`823fb25bf659d7a8ac455f24b7b85be0afad5412c18719f6ea7a47b24930498f`,bytes:11643,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/strings/strtok.m":{sha256:`b196ba9699432e97f2adbe1cf2be1f50d9fd434835acf2ddc5b857d6e809ca70`,bytes:7494,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/strings/strtrim.m":{sha256:`ffe2434a72d27817eb63d1c598c9073b0c6f71fac6579f7c0dc1fbbd820cdda1`,bytes:2960,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/strings/strtrunc.m":{sha256:`e2a31cfe575683b2b5c9d7e3e9f9a28332f9a1b5847d63cf18fb221f33a2e6ed`,bytes:3073,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/strings/substr.m":{sha256:`1f518e3a9182fb2a5c3476ea68e7330d4bdde33e1bf626ac7a33ef79a9e93b24`,bytes:3589,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/strings/unicode2native.m":{sha256:`a4db302cfccc1cc27a010812ce852d4f6f6b52c89286dfe78a2aea3aa440e5c5`,bytes:6458,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/strings/untabify.m":{sha256:`ae95dc4a8a89c17cb261b6d35d6cf116b47fb83f275fe28b6ba82b5c6fab3b3a`,bytes:3571,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/strings/validatestring.m":{sha256:`5f091c10b63bd8e711b3fd8dd480d6dff04f42a92ae443fb886a0a196ffbf037`,bytes:7058,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/testfun/__debug_octave__.m":{sha256:`639d3ff67c0abb57f3cca3f7535737ad542a3bf044be4a990199fce65138a142`,bytes:2527,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/testfun/__have_feature__.m":{sha256:`c62d65beedd57ee421da0fad8b826eac6cef2a28d6a46debdb1126c02d33f05d`,bytes:1877,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/testfun/__printf_assert__.m":{sha256:`ba6e62a214a3b2eff3d1331ae8537fd2730264e6367af300a58c568f05fccf71`,bytes:1393,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/testfun/__prog_output_assert__.m":{sha256:`60f3f727ae8542f45c314711e5f35338437055e68569fe257d2682ad0e23e058`,bytes:1600,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/testfun/__run_test_suite__.m":{sha256:`9de32990649120ad73596436c524f63cbf7e291aaf0af239f5cb992e5dacd75f`,bytes:12584,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/testfun/assert.m":{sha256:`20a9734b95319ab81947ffade481717483ac2e400f612491fb466d5c1954e5a9`,bytes:29387,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/testfun/demo.m":{sha256:`992c94eddd90a151f33523c21a10442e066e39b2557f5f333032a3abf38d2af9`,bytes:6479,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/testfun/example.m":{sha256:`20b3cd9bc3e3f032dcea96eb494f2876e8501274368a61bf854dec2faf5cec90`,bytes:3750,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/testfun/fail.m":{sha256:`008fcf546acea91a93d70b6a5e5f87ae2d18a3b6e05d9545f7501420f1ec125c`,bytes:5166,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/testfun/oruntests.m":{sha256:`d53c348ef3f02d49c78a19594d3f152b658b6bdf82fb43b75c015f6b2cf66465`,bytes:5695,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/testfun/private/compare_plot_demos.m":{sha256:`2a5a1dfe5c4e3d2413bc760d413c889670c09e049fb3fcb4b2aff56dfbad1d0d`,bytes:4389,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/testfun/private/dump_demos.m":{sha256:`17af609c38059f8f4e8d79207943539e9ba338a374e71eb9cf56117d380156f5`,bytes:16636,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/testfun/private/html-plot-demos-template.html":{sha256:`fdd16c09980535a2b5d708aa172461fc68c26bd16fbf7b9ebf44cc9363df5e23`,bytes:304,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/testfun/private/html_compare_plot_demos.m":{sha256:`b9fd4a2047140bf309be04080681259eb9edae8cc5e294e862ebdfc8e56782ae`,bytes:5571,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/testfun/rundemos.m":{sha256:`350334c75d029af77a812f87771edbf0a44274199ad603890d4911504e4e130c`,bytes:3495,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/testfun/speed.m":{sha256:`5cef46ad6ed7203439901207c36a00a5afb9d45ac2729b8bfd86a8f3d771e300`,bytes:15428,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/testfun/test.m":{sha256:`027e46d16338a5b6f51cf0a03fc20b40151bdaea1a3ee12cbfb1ca0ca0a6d3c3`,bytes:37875,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/time/addtodate.m":{sha256:`4a9191f6c155c1048dcfe22a2294f33741801f4fffb47f7e9cc2777eedd5d224`,bytes:5626,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/time/asctime.m":{sha256:`09d461adb4d25f6d2f1b9c07ac4159f9eca183906b10c0ea6c9ee550364a4bec`,bytes:1819,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/time/calendar.m":{sha256:`c7610b43f178cabd9359a3028a79bce1bdcb2869ca0e17af098439a01a0fa5a5`,bytes:2909,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/time/clock.m":{sha256:`c66212a48ff7f711b95ffeb947d5d47f6ad51ec4ed867e6f61331cb8d735ae5d`,bytes:2293,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/time/ctime.m":{sha256:`63abc6d8f327c47237feaf2a6cfa334370c977a764fcb5cfe02eb4690fd86029`,bytes:1822,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/time/date.m":{sha256:`b4cfd0c1e6d75625f0d4770be359e783f6e9a71a34db0d130e12cea1fff39d42`,bytes:1492,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/time/datenum.m":{sha256:`937c5ac1d7b9250e6d3363892df7ef0ec20c01fea80e6e4acdf308047ab35f11`,bytes:11507,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/time/datestr.m":{sha256:`7171a592edc2d9cbe7fae9a6d2315b15e04b12fd830afc7b5dfd900935b3f1c3`,bytes:13081,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/time/datevec.m":{sha256:`950a35299e1738c76be4a63cb76b52d9de537ddc263b7d9b4a5673edf089775d`,bytes:33449,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/time/eomday.m":{sha256:`41c92e8009e4bb4123ac62784b169cf4f6e4d52c55bab55868af2d5abc271d1f`,bytes:2422,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/time/etime.m":{sha256:`d246cab21903b12e162bbb1dd5a39aa7545f617ef7195556fc6fcf828ab3b542`,bytes:2541,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/time/is_leap_year.m":{sha256:`6fc152682f9543e94c551fca3303144d019c55ff5fb4b57346ddcef8eb2e3289`,bytes:1833,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/time/now.m":{sha256:`3cca2a27b5176dbff14f614eecdab722a5ff15a0f53d257d61cf7c90abee6577`,bytes:2039,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/time/weekday.m":{sha256:`323d202aa917536805cbcea82e0f8c6a0d9d8338efa97033973b3d94417449f3`,bytes:4120,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/web/web.m":{sha256:`79d2213261f94200e2d00570523575bdb5c5b98ed512296075daa51dd0c95a18`,bytes:3574,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/web/weboptions.m":{sha256:`ec47a6df8011d7dd1033a11e182e4a40b021c8b4e27b8a3e59f559d7d0b14b89`,bytes:13097,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/web/webread.m":{sha256:`a28d5cc126bddd3df01d1d90d6bc4b589074654d0d23fab569181bbb27b7eca3`,bytes:3853,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/10.3.0/m/web/webwrite.m":{sha256:`6be157a5824e469e0b05660bfdf60a5625cd826e8cdb8bff63f6369cb20fa5d5`,bytes:4523,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/site/api-v60/octave_packages":{sha256:`3b0cc05cd481c734f3a5f76b4c648f36a9aa4c74bd160980ae04d15a49b1480e`,bytes:216,mediaType:`application/octet-stream`},"wasm-octave/runtime/share/octave/site/m/startup/octaverc":{sha256:`d19d22446a490f31482f659e3b14a324d9be38f9989a23c0644d3cfb28121c08`,bytes:1571,mediaType:`application/octet-stream`},"wasm-of-js-of-ocaml/browser-native-bundle/browser-native-manifest.v1.json":{sha256:`bb6ad7850ebed944b3a35fad1b71de82e8ef1256cb4600ebe6c6cfcf0f5497e3`,bytes:60076,mediaType:`application/json`},"wasm-of-js-of-ocaml/browser-native-bundle/browser-native-runtime-pack.v1.bin":{sha256:`760db8afcfdfd0e121120f29498efbbc99406e6ca6eb8c522d6e1d5d788e956b`,bytes:24453239,mediaType:`application/octet-stream`,deliveryPath:`wasm-of-js-of-ocaml/browser-native-bundle/browser-native-runtime-pack.v1.bin.gz`},"wasm-of-js-of-ocaml/browser-native-bundle/browser-native-runtime-pack.v1.bin.gz":{sha256:`3aaa3dec4bdce49f1786eb2373c782d0bf2803013ee105dc81791ef6b936f2da`,bytes:18132361,encoding:`gzip`,mediaType:`application/octet-stream`,uncompressedSha256:`760db8afcfdfd0e121120f29498efbbc99406e6ca6eb8c522d6e1d5d788e956b`,uncompressedBytes:24453239},"wasm-of-js-of-ocaml/browser-native-bundle/browser-native-runtime-pack.v1.index.json":{sha256:`ac426368561253a13f6b645e09d7278ffab2fc80816c6ad1096f9e9919050d59`,bytes:70441,mediaType:`application/json`},"wasm-of-js-of-ocaml/browser-native-bundle/findlib.conf":{sha256:`7a3f7339e24631f266e25a996a2001eca1633fcd4a66cc9b3074863ffee572b7`,bytes:181,mediaType:`application/octet-stream`},"wasm-of-js-of-ocaml/browser-native-bundle/tools/js_of_ocaml.bc.browser.js":{sha256:`f0db3bb33757eff619f3f6889ba88f72c2150a4972aedfd5373ae8ffe02b5a42`,bytes:4783689,mediaType:`text/javascript`,deliveryPath:`wasm-of-js-of-ocaml/browser-native-bundle/tools/js_of_ocaml.bc.browser.js.gz`},"wasm-of-js-of-ocaml/browser-native-bundle/tools/js_of_ocaml.bc.browser.js.gz":{sha256:`84187e16cf17380b09e4d77fd271d12f4fa20ae16026e5f300cf14ab71b50605`,bytes:912890,encoding:`gzip`,mediaType:`text/javascript`,uncompressedSha256:`f0db3bb33757eff619f3f6889ba88f72c2150a4972aedfd5373ae8ffe02b5a42`,uncompressedBytes:4783689},"wasm-of-js-of-ocaml/browser-native-bundle/tools/ocamlc.byte.browser.js":{sha256:`78796cf45398351cb42ea116c83639d577b310a6f13e9308403a90a8fbb51f14`,bytes:2328856,mediaType:`text/javascript`,deliveryPath:`wasm-of-js-of-ocaml/browser-native-bundle/tools/ocamlc.byte.browser.js.gz`},"wasm-of-js-of-ocaml/browser-native-bundle/tools/ocamlc.byte.browser.js.gz":{sha256:`6c5b08402094e1b9aff93fb84b000d92941dd1b55a89b936cf4723db541a42d9`,bytes:592521,encoding:`gzip`,mediaType:`text/javascript`,uncompressedSha256:`78796cf45398351cb42ea116c83639d577b310a6f13e9308403a90a8fbb51f14`,uncompressedBytes:2328856},"wasm-of-js-of-ocaml/browser-native-bundle/tools/wasm-merge.browser.js":{sha256:`28c285a03583af811d5acc6e912e2b5298953cb1fe38cbe79140b7e017cb9155`,bytes:10145874,mediaType:`text/javascript`,deliveryPath:`wasm-of-js-of-ocaml/browser-native-bundle/tools/wasm-merge.browser.js.gz`},"wasm-of-js-of-ocaml/browser-native-bundle/tools/wasm-merge.browser.js.gz":{sha256:`63286543870887744eb7cb0cc5020c6bfe569d26583f207beb51e41add831128`,bytes:2225185,encoding:`gzip`,mediaType:`text/javascript`,uncompressedSha256:`28c285a03583af811d5acc6e912e2b5298953cb1fe38cbe79140b7e017cb9155`,uncompressedBytes:10145874},"wasm-of-js-of-ocaml/browser-native-bundle/tools/wasm-metadce.browser.js":{sha256:`6130fc8ef8715e34625efb82b0f31c4c7ef1e6ea790e01c65a56ab44d294fee0`,bytes:10176326,mediaType:`text/javascript`,deliveryPath:`wasm-of-js-of-ocaml/browser-native-bundle/tools/wasm-metadce.browser.js.gz`},"wasm-of-js-of-ocaml/browser-native-bundle/tools/wasm-metadce.browser.js.gz":{sha256:`bbf23b5d597e9cbdaa6cfc1b44483343917c4a5d7000e852f6b4046eca22cd57`,bytes:2237479,encoding:`gzip`,mediaType:`text/javascript`,uncompressedSha256:`6130fc8ef8715e34625efb82b0f31c4c7ef1e6ea790e01c65a56ab44d294fee0`,uncompressedBytes:10176326},"wasm-of-js-of-ocaml/browser-native-bundle/tools/wasm-opt.browser.js":{sha256:`e04ed72e19aab4ab3cbbca152a95ed00d63d2d084be7d8dd07fc133c8d576196`,bytes:11279296,mediaType:`text/javascript`,deliveryPath:`wasm-of-js-of-ocaml/browser-native-bundle/tools/wasm-opt.browser.js.gz`},"wasm-of-js-of-ocaml/browser-native-bundle/tools/wasm-opt.browser.js.gz":{sha256:`3e1a6d2dd24fe4a45627068075dead99e4bf8d829347b346b6167b7d8f9b26a8`,bytes:2483619,encoding:`gzip`,mediaType:`text/javascript`,uncompressedSha256:`e04ed72e19aab4ab3cbbca152a95ed00d63d2d084be7d8dd07fc133c8d576196`,uncompressedBytes:11279296},"wasm-of-js-of-ocaml/browser-native-bundle/tools/wasm_of_ocaml.bc.browser.js":{sha256:`666b83417cdf9b0aab3b3933529e48432953763c0385a26605c84efbfaab2e76`,bytes:6250420,mediaType:`text/javascript`,deliveryPath:`wasm-of-js-of-ocaml/browser-native-bundle/tools/wasm_of_ocaml.bc.browser.js.gz`},"wasm-of-js-of-ocaml/browser-native-bundle/tools/wasm_of_ocaml.bc.browser.js.gz":{sha256:`dd886dbca4e07341f07ae29f2f338f58926576a868fda72ac4fc2f070424736b`,bytes:1162811,encoding:`gzip`,mediaType:`text/javascript`,uncompressedSha256:`666b83417cdf9b0aab3b3933529e48432953763c0385a26605c84efbfaab2e76`,uncompressedBytes:6250420},"wasm-of-js-of-ocaml/browser-native/browser-harness/main.js":{sha256:`f339e720e1b3e26c8e124f557c96669359cd3248b6371fa47a3328015f7ed731`,bytes:2442,mediaType:`text/javascript`},"wasm-of-js-of-ocaml/browser-native/browser-harness/native-compile.js":{sha256:`c3bf2bc4f4ef64c91749fcb795c5654a4b033726e98e1c9618fd957d1ab7f2fa`,bytes:11365,mediaType:`text/javascript`},"wasm-of-js-of-ocaml/browser-native/browser-harness/native-tool-worker.js":{sha256:`ed4e5423a79b46e67d60455e57d6a1b6595021b917b1dbeac63187c790f59e30`,bytes:43310,mediaType:`text/javascript`},"wasm-of-js-of-ocaml/browser-native/runtime/browser-native-asset-cache.js":{sha256:`643986ac8187348ccd0dc71964bf76b409e95b5453b96654d3b05363442ce745`,bytes:4882,mediaType:`text/javascript`},"wasm-of-js-of-ocaml/browser-native/runtime/browser-native-tool-assets.js":{sha256:`7e66fe28000e5921e82445e8dc6ecc09dbcd2d088608e7372e451012297e833d`,bytes:15018,mediaType:`text/javascript`},"wasm-of-js-of-ocaml/browser-native/runtime/fs/memory-fs.js":{sha256:`b1c44dbd8edbd92b27f66c1adcc62354622906196e601cadb0b87ca205855982`,bytes:4673,mediaType:`text/javascript`},"wasm-of-js-of-ocaml/browser-native/runtime/system-dispatch-browser-worker.js":{sha256:`5b04545b7dcb4e72cfefac2b162624fa98462907d829a716caf26318f456eca1`,bytes:40078,mediaType:`text/javascript`},"wasm-of-js-of-ocaml/browser-native/runtime/system-dispatch-node.js":{sha256:`eba03289849e7c3e63e061729996cfacd94c91d2c2f3ba3c3125fae4fa82897a`,bytes:4875,mediaType:`text/javascript`},"wasm-of-js-of-ocaml/browser-native/runtime/system-dispatch.js":{sha256:`5cc5b27c952875f370049633336584e2af16bd85e81705431b69c9eeadd48387`,bytes:1105,mediaType:`text/javascript`},"wasm-of-js-of-ocaml/browser-native/src/compiler-worker.js":{sha256:`d57997796a1a1c284c15ba1049f795addad24b02bc2e1ef1dee2cd1dcb1f6aae`,bytes:12331,mediaType:`text/javascript`},"wasm-of-js-of-ocaml/browser-native/src/index.js":{sha256:`17d80beb633799e9021dc1b851bc76283494d981ec20fc315462d740284fa13a`,bytes:1892,mediaType:`text/javascript`},"wasm-of-js-of-ocaml/browser-native/src/node.js":{sha256:`34afac088667b55a8fde8b8b5a95126b5bf2307f0c786875217cb294d497750d`,bytes:6026,mediaType:`text/javascript`},"wasm-of-js-of-ocaml/browser-native/src/types.js":{sha256:`8e609bb71c20b858c77f0e9f90bb1319db8477b13f9f965f1a1e18524bf50881`,bytes:11,mediaType:`text/javascript`},"wasm-of-js-of-ocaml/browser-native/src/worker-protocol.js":{sha256:`8e609bb71c20b858c77f0e9f90bb1319db8477b13f9f965f1a1e18524bf50881`,bytes:11,mediaType:`text/javascript`},"wasm-pascal/compiler.js":{sha256:`b35968e4acaff893ab9e712815cf83f4d9b3ae4ca23a307b83ec37c65c4a6756`,bytes:3332860,mediaType:`text/javascript`,deliveryPath:`wasm-pascal/compiler.js.gz`},"wasm-pascal/compiler.js.gz":{sha256:`603829fbb9b9663f243a9adb30a59a0c0d0251bae2a869dd4f2402ed7c554a2a`,bytes:495779,encoding:`gzip`,mediaType:`text/javascript`,uncompressedSha256:`b35968e4acaff893ab9e712815cf83f4d9b3ae4ca23a307b83ec37c65c4a6756`,uncompressedBytes:3332860},"wasm-pascal/compiler.js.gz.bin":{sha256:`603829fbb9b9663f243a9adb30a59a0c0d0251bae2a869dd4f2402ed7c554a2a`,bytes:495779,encoding:`gzip`,mediaType:`text/javascript`,uncompressedSha256:`b35968e4acaff893ab9e712815cf83f4d9b3ae4ca23a307b83ec37c65c4a6756`,uncompressedBytes:3332860},"wasm-pascal/rtl.js":{sha256:`26fb07d209ca42654ada5c13357abdd630a0693fbb5a7806d32fa089adab026c`,bytes:49020,mediaType:`text/javascript`},"wasm-pascal/rtl.js.bin":{sha256:`26fb07d209ca42654ada5c13357abdd630a0693fbb5a7806d32fa089adab026c`,bytes:49020,mediaType:`application/octet-stream`},"wasm-pascal/runner-worker.js":{sha256:`1067c3d36b7cf7d56b2679b43a18105dfac7c4a6f234f68e5bce11e15dc3ff12`,bytes:20309,mediaType:`text/javascript`},"wasm-pascal/runtime-build.json":{sha256:`bcf88f90a94181e4f1d183314500d1fce386933500b42d4ba176a337cdde80f5`,bytes:132,mediaType:`application/json`},"wasm-pascal/runtime-manifest.v1.json":{sha256:`a349bac69dac3b8765e65ff294aa06571e787ad767650e5a2a8ac49c1255e48f`,bytes:266,mediaType:`application/json`},"wasm-pascal/runtime-manifest.v2.json":{sha256:`e810c87b04c79b522b0433988e40bb5770dfd06d3d892416b333020b9d7ac7b3`,bytes:3252,mediaType:`application/json`},"wasm-pascal/system.pas":{sha256:`524c5cbd1b8c23c284943fa7c76e3cc42ac0be099072a6f0ea84418cfc08fb39`,bytes:31650,mediaType:`application/octet-stream`},"wasm-pascal/system.pas.bin":{sha256:`524c5cbd1b8c23c284943fa7c76e3cc42ac0be099072a6f0ea84418cfc08fb39`,bytes:31650,mediaType:`application/octet-stream`},"wasm-perl/emperl.data":{sha256:`9529019418cf766a42cf2d25bd3fc97b47c9e689f5666cfc32dc11338d1b1e66`,bytes:12021691,mediaType:`application/octet-stream`,deliveryPath:`wasm-perl/emperl.data.gz`},"wasm-perl/emperl.data.gz":{sha256:`22a01b26b41b515fd9be927e639dafa4846529c6e25fda2d74663a9b4f34ba2c`,bytes:2603581,encoding:`gzip`,mediaType:`application/octet-stream`,uncompressedSha256:`9529019418cf766a42cf2d25bd3fc97b47c9e689f5666cfc32dc11338d1b1e66`,uncompressedBytes:12021691},"wasm-perl/emperl.data.gz.bin":{sha256:`22a01b26b41b515fd9be927e639dafa4846529c6e25fda2d74663a9b4f34ba2c`,bytes:2603581,encoding:`gzip`,mediaType:`application/octet-stream`,uncompressedSha256:`9529019418cf766a42cf2d25bd3fc97b47c9e689f5666cfc32dc11338d1b1e66`,uncompressedBytes:12021691},"wasm-perl/emperl.js":{sha256:`b60e3c04874c6ef5278001257b4c8a9f4c7e69ca3d6b268d9639723234844784`,bytes:303013,mediaType:`text/javascript`,deliveryPath:`wasm-perl/emperl.js.gz`},"wasm-perl/emperl.js.gz":{sha256:`2a8b07227cb363ee57d8a5679c751044e191b4979862ff54709ea8773c236ce0`,bytes:61304,encoding:`gzip`,mediaType:`text/javascript`,uncompressedSha256:`b60e3c04874c6ef5278001257b4c8a9f4c7e69ca3d6b268d9639723234844784`,uncompressedBytes:303013},"wasm-perl/emperl.js.gz.bin":{sha256:`2a8b07227cb363ee57d8a5679c751044e191b4979862ff54709ea8773c236ce0`,bytes:61304,encoding:`gzip`,mediaType:`text/javascript`,uncompressedSha256:`b60e3c04874c6ef5278001257b4c8a9f4c7e69ca3d6b268d9639723234844784`,uncompressedBytes:303013},"wasm-perl/emperl.wasm":{sha256:`f1d49c4514c7332a57992c4a2444fd6a56ae3b5e6651b4fd484852a641e5e4ec`,bytes:3734063,mediaType:`application/wasm`,deliveryPath:`wasm-perl/emperl.wasm.gz`},"wasm-perl/emperl.wasm.gz":{sha256:`1375fdda3204cbcb9f21d182a0706bf8bac7acc1267366e87bccf9ac29310ca0`,bytes:1186908,encoding:`gzip`,mediaType:`application/wasm`,uncompressedSha256:`f1d49c4514c7332a57992c4a2444fd6a56ae3b5e6651b4fd484852a641e5e4ec`,uncompressedBytes:3734063},"wasm-perl/emperl.wasm.gz.bin":{sha256:`1375fdda3204cbcb9f21d182a0706bf8bac7acc1267366e87bccf9ac29310ca0`,bytes:1186908,encoding:`gzip`,mediaType:`application/wasm`,uncompressedSha256:`f1d49c4514c7332a57992c4a2444fd6a56ae3b5e6651b4fd484852a641e5e4ec`,uncompressedBytes:3734063},"wasm-perl/runner-worker.js":{sha256:`f5c4a623cae150451794db91643822bed017eb5fa5a8aab9ea3171250273aab3`,bytes:24597,mediaType:`text/javascript`},"wasm-perl/runtime-build.json":{sha256:`f26d6631375c2625ee73f5de94e304834957d409e9a00d4cc3c4b52ea4e02c39`,bytes:1796,mediaType:`application/json`},"wasm-perl/runtime-manifest.v1.json":{sha256:`7ac9d669345ae46aadfd922fc4acaaa743a59d6a89e493b11249f9cf77ca31ef`,bytes:384,mediaType:`application/json`},"wasm-perl/runtime-manifest.v2.json":{sha256:`0254578c97d1bfb58432f96161ef5758a3bfbfde89d6cb00f867c80c8099ba96`,bytes:3758,mediaType:`application/json`},"wasm-php/assets/intl-CUx5vSaa.so":{sha256:`15faf0692e6adb432ffa2182711723c3f2f9afc025f96afc0f04c3fd07d12709`,bytes:7915366,mediaType:`application/octet-stream`,deliveryPath:`wasm-php/assets/intl-CUx5vSaa.so.gz`},"wasm-php/assets/intl-CUx5vSaa.so.gz":{sha256:`b4c37b9ad5c4e495fc0e0d2bffebee845896d24e18bd6dd238ef9d9135c1626f`,bytes:1941651,encoding:`gzip`,mediaType:`application/octet-stream`,uncompressedSha256:`15faf0692e6adb432ffa2182711723c3f2f9afc025f96afc0f04c3fd07d12709`,uncompressedBytes:7915366},"wasm-php/assets/intl-ZuZnBC_c.so":{sha256:`baef85d1e59fcebd27194feb8538caf511aac0ba82c116cad8d403d9a40d1d43`,bytes:5583120,mediaType:`application/octet-stream`,deliveryPath:`wasm-php/assets/intl-ZuZnBC_c.so.gz`},"wasm-php/assets/intl-ZuZnBC_c.so.gz":{sha256:`71fcb65fe87f03229cde51b7342de5728172483da05d1df6971d15e7e94fabc5`,bytes:1549348,encoding:`gzip`,mediaType:`application/octet-stream`,uncompressedSha256:`baef85d1e59fcebd27194feb8538caf511aac0ba82c116cad8d403d9a40d1d43`,uncompressedBytes:5583120},"wasm-php/assets/php_8_4-B-lpXlcN.wasm":{sha256:`49a2801eafc48ec229a940020207c3f8ea6d0093a3e173c9d199389fa0b34adf`,bytes:19951607,mediaType:`application/wasm`,deliveryPath:`wasm-php/assets/php_8_4-B-lpXlcN.wasm.gz`},"wasm-php/assets/php_8_4-B-lpXlcN.wasm.gz":{sha256:`cc3e7d82c489f7e73f1a7cb37733f25d85c58846e5d6c29975dfa9477963555a`,bytes:7729514,encoding:`gzip`,mediaType:`application/wasm`,uncompressedSha256:`49a2801eafc48ec229a940020207c3f8ea6d0093a3e173c9d199389fa0b34adf`,uncompressedBytes:19951607},"wasm-php/assets/php_8_4-B9pF5N64.wasm":{sha256:`88e14ad0b66c7ea6860cab6ecbf24ca32a25967be96af56c2bdd17e62be4fe1c`,bytes:19924253,mediaType:`application/wasm`,deliveryPath:`wasm-php/assets/php_8_4-B9pF5N64.wasm.gz`},"wasm-php/assets/php_8_4-B9pF5N64.wasm.gz":{sha256:`6657330787090617054aa7c0c6f113d8fe8dced2c9816ecdba56d4aec477dace`,bytes:7753850,encoding:`gzip`,mediaType:`application/wasm`,uncompressedSha256:`88e14ad0b66c7ea6860cab6ecbf24ca32a25967be96af56c2bdd17e62be4fe1c`,uncompressedBytes:19924253},"wasm-php/chunks/__vite-browser-external-Bsloc-A9.mjs":{sha256:`5fab1c02b4e1be1ab9e33536275fd723e51315bee0573e062a4fc4bedcf4e8a1`,bytes:626,mediaType:`text/javascript`},"wasm-php/chunks/php_8_4-BZTUBSMV.mjs":{sha256:`b43d90eb320b851faa6f49cc15ccfdafd6f6ca88350d200cae4aca53aecfa4a1`,bytes:196813,mediaType:`text/javascript`},"wasm-php/chunks/php_8_4-HOoIUeaQ.mjs":{sha256:`d0d47718089130bf204d9d45c1689e3c6d1bff985577e1bb9fbe0392a53985d6`,bytes:151753,mediaType:`text/javascript`},"wasm-php/chunks/startup-runtime-api-eKcsJJIE.mjs":{sha256:`a754a1dee5bb0d5f07c1b3333fc57150bafedb3af3618034fb2e6397e8654ace`,bytes:90,mediaType:`text/javascript`},"wasm-php/chunks/universal-_N6DxJ-J.mjs":{sha256:`698ef411b67ff67f293f8ab461dcdc23990d4b06c4d13757e0117ebde47a5a33`,bytes:120573,mediaType:`text/javascript`},"wasm-php/chunks/web-8-4-2Jcoi3JW.mjs":{sha256:`5b8fc16bdf1248155869273cbc18de4ae6b310d318594a7492b3bae320849cff`,bytes:1799,mediaType:`text/javascript`},"wasm-php/runtime-manifest.v1.json":{sha256:`4934e188a8230db94b67f6520d502e1c87cffe29324a984548814f2a811d6409`,bytes:2267,mediaType:`application/json`},"wasm-php/runtime.mjs":{sha256:`f44db0308c6eb80e3846850f7057430be82a949496ff2ab3ed57a22ca9971d4d`,bytes:447,mediaType:`text/javascript`},"wasm-php/startup.mjs":{sha256:`cc5acc22f20dd1422a49e20cd5820b7f8b628d1342fc6a17252d27161364b922`,bytes:4474,mediaType:`text/javascript`},"wasm-postgresql/assets/initdb-DwLcS450.wasm":{sha256:`4c8988dca3b2f0bbfd23a0714023e4822a2909ead01804f37acffd9ff3ca9f8a`,bytes:395242,mediaType:`application/wasm`,deliveryPath:`wasm-postgresql/assets/initdb-DwLcS450.wasm.gz`},"wasm-postgresql/assets/initdb-DwLcS450.wasm.gz":{sha256:`abad40b58d0c416710ecce2e88598910a03eaef6c99e624182e184a0b61d90bf`,bytes:147404,encoding:`gzip`,mediaType:`application/wasm`,uncompressedSha256:`4c8988dca3b2f0bbfd23a0714023e4822a2909ead01804f37acffd9ff3ca9f8a`,uncompressedBytes:395242},"wasm-postgresql/assets/pglite-DgipwPsY.wasm":{sha256:`356b89f6fcb2ab3a397bec4128327b67b7137ec2a900b13251dade81bcbc0ef0`,bytes:10088161,mediaType:`application/wasm`,deliveryPath:`wasm-postgresql/assets/pglite-DgipwPsY.wasm.gz`},"wasm-postgresql/assets/pglite-DgipwPsY.wasm.gz":{sha256:`972cdea487c9e777033b7afd80a47742ce99ae54aae01b2a241eabca20be96ea`,bytes:3439803,encoding:`gzip`,mediaType:`application/wasm`,uncompressedSha256:`356b89f6fcb2ab3a397bec4128327b67b7137ec2a900b13251dade81bcbc0ef0`,uncompressedBytes:10088161},"wasm-postgresql/assets/pglite-n8RDJ3Sw.data":{sha256:`c574cc331d96e33311470ec57bf58c579d972c111dbd9c0ab54bb42d79ec4c0d`,bytes:6295316,mediaType:`application/octet-stream`,deliveryPath:`wasm-postgresql/assets/pglite-n8RDJ3Sw.data.gz`},"wasm-postgresql/assets/pglite-n8RDJ3Sw.data.gz":{sha256:`dbcfb3201e1800da9f7fb719ea8999f1dbcbb897aac05d2c40737c1e05d50a49`,bytes:2140187,encoding:`gzip`,mediaType:`application/octet-stream`,uncompressedSha256:`c574cc331d96e33311470ec57bf58c579d972c111dbd9c0ab54bb42d79ec4c0d`,uncompressedBytes:6295316},"wasm-postgresql/chunks/__vite-browser-external-BqTOPsad.mjs":{sha256:`96fc50b6105c0a7a1ea05492920e66bcf06fdadcd0cc1144822d3858b8f4051b`,bytes:115,mediaType:`text/javascript`},"wasm-postgresql/chunks/dist-CBe8LYV9.mjs":{sha256:`47e27a78d70015cacb686635f1c1028e70d7b488470d428132e88e44f494e45c`,bytes:606928,mediaType:`text/javascript`,deliveryPath:`wasm-postgresql/chunks/dist-CBe8LYV9.mjs.gz`},"wasm-postgresql/chunks/dist-CBe8LYV9.mjs.gz":{sha256:`3f00624b7eb45d25e0d70c8fab4469f7c631ed30941efea43d399e04a33bb7e9`,bytes:139717,encoding:`gzip`,mediaType:`text/javascript`,uncompressedSha256:`47e27a78d70015cacb686635f1c1028e70d7b488470d428132e88e44f494e45c`,uncompressedBytes:606928},"wasm-postgresql/chunks/nodefs-Lavu35aH.mjs":{sha256:`79858b804d87411352bd039da3e7cdb04a6ceac4de997b76ac841b56bc99bec3`,bytes:544,mediaType:`text/javascript`},"wasm-postgresql/chunks/opfs-ahp-CWXvZC5u.mjs":{sha256:`bb2724c9ef9265c4792d516cd2892746ac856e5c233ed89d67f0155e90613033`,bytes:10009,mediaType:`text/javascript`},"wasm-postgresql/chunks/preload-helper-CGPSMADP.mjs":{sha256:`619e20fe75396cf1771978ff186d0753bca8f42ec931be5128516c33046a0a09`,bytes:1573,mediaType:`text/javascript`},"wasm-postgresql/chunks/rolldown-runtime-Dik6OG8R.mjs":{sha256:`75903e56b9b39037c0a8714463bccf8995790fa58a8d02837fdddf783146e99f`,bytes:590,mediaType:`text/javascript`},"wasm-postgresql/runtime-manifest.v1.json":{sha256:`ead0bdd18eec72f62e19540e4b0bb5a0ea8311e820e781a5cc4d829210cde716`,bytes:2078,mediaType:`application/json`},"wasm-postgresql/runtime.mjs":{sha256:`5807d24d5e07cc79b96452f2cd31c8d787dca19491a9aec6af72b21febfe7a81`,bytes:583,mediaType:`text/javascript`},"wasm-prolog/runner-worker.js":{sha256:`b72014e85132b6ee6bfe3ec0e59ae6ba791f4c137caa1cb744d0a37bab9c60c4`,bytes:25342,mediaType:`text/javascript`},"wasm-prolog/runtime-build.json":{sha256:`bcb4f819cc2f272319b6ee33d591dd4b64b60b0659d967278ba7ebd45147e109`,bytes:853,mediaType:`application/json`},"wasm-prolog/runtime-manifest.v2.json":{sha256:`b67d6f6ff9115bd886d2992b0ad97e7d726aa66cc2a3e288ce7f99a3249d6d47`,bytes:2576,mediaType:`application/json`},"wasm-prolog/swipl-web.data":{sha256:`91e9d9c1d184f1a291c870e96bf6a1bc502ce8787946c966526a663a725ba932`,bytes:1659074,mediaType:`application/octet-stream`,deliveryPath:`wasm-prolog/swipl-web.data.gz`},"wasm-prolog/swipl-web.data.gz":{sha256:`ea735ff89940eaed405a4a9b2be8606141d821016f3fc7671983b2203e88e86f`,bytes:1192600,encoding:`gzip`,mediaType:`application/octet-stream`,uncompressedSha256:`91e9d9c1d184f1a291c870e96bf6a1bc502ce8787946c966526a663a725ba932`,uncompressedBytes:1659074},"wasm-prolog/swipl-web.data.gz.bin":{sha256:`ea735ff89940eaed405a4a9b2be8606141d821016f3fc7671983b2203e88e86f`,bytes:1192600,encoding:`gzip`,mediaType:`application/octet-stream`,uncompressedSha256:`91e9d9c1d184f1a291c870e96bf6a1bc502ce8787946c966526a663a725ba932`,uncompressedBytes:1659074},"wasm-prolog/swipl-web.js":{sha256:`635da02ac0eb18e51303e4a0398b220d17cabfc0e4b7a2acbc7af9e949e4a9c7`,bytes:193421,mediaType:`text/javascript`},"wasm-prolog/swipl-web.wasm":{sha256:`c8831c0ac6a021b6bc67fa1b86e8826d1ea92a1a81b932cfb88fea235361c355`,bytes:2275324,mediaType:`application/wasm`,deliveryPath:`wasm-prolog/swipl-web.wasm.gz`},"wasm-prolog/swipl-web.wasm.gz":{sha256:`da8461e22b4513c5020d7eef7f8e62b2086003125381d18fed08f3656eecd793`,bytes:820495,encoding:`gzip`,mediaType:`application/wasm`,uncompressedSha256:`c8831c0ac6a021b6bc67fa1b86e8826d1ea92a1a81b932cfb88fea235361c355`,uncompressedBytes:2275324},"wasm-prolog/swipl-web.wasm.gz.bin":{sha256:`da8461e22b4513c5020d7eef7f8e62b2086003125381d18fed08f3656eecd793`,bytes:820495,encoding:`gzip`,mediaType:`application/wasm`,uncompressedSha256:`c8831c0ac6a021b6bc67fa1b86e8826d1ea92a1a81b932cfb88fea235361c355`,uncompressedBytes:2275324},"wasm-rescript/compiler.js.gz.bin":{sha256:`9d6988eff528fb577c10aa76f720e59c8737dc91c5a4a2f17496930b848ff51d`,bytes:1245489,encoding:`gzip`,mediaType:`text/javascript`,uncompressedSha256:`17b16598b473bcd56367f29fb76d300ffe0073c814af68710d3b46964b200202`,uncompressedBytes:6496768},"wasm-rescript/runner-worker.js":{sha256:`9ed95127f988333a79c7591771c40f2d0fde07e5cb79da2543082582ffdd276d`,bytes:22497,mediaType:`text/javascript`},"wasm-rescript/runtime-build.json":{sha256:`2712153acbc9202f546ea60dd14c248127ceebb6bcb41336b760ea358f8a6ee0`,bytes:1418,mediaType:`application/json`},"wasm-rescript/runtime-manifest.v1.json":{sha256:`dddbbbdf2da0c91280267004875023ff9949c8815c6edff7057444cfcff25e61`,bytes:1406,mediaType:`application/json`},"wasm-ruby/assets/ruby_stdlib-D8-A_OuU.wasm":{sha256:`4b814fc9d13505ea5b4c1f3bd3a7cc7ccca137f551196b9b21f0a7caf9cc5878`,bytes:30635497,mediaType:`application/wasm`,deliveryPath:`wasm-ruby/assets/ruby_stdlib-D8-A_OuU.wasm.gz`},"wasm-ruby/assets/ruby_stdlib-D8-A_OuU.wasm.gz":{sha256:`7fd753e801bf2cc58111149d8c77539b941480e848274b51a39c4dcef2d2bb13`,bytes:9058728,encoding:`gzip`,mediaType:`application/wasm`,uncompressedSha256:`4b814fc9d13505ea5b4c1f3bd3a7cc7ccca137f551196b9b21f0a7caf9cc5878`,uncompressedBytes:30635497},"wasm-ruby/assets/ruby_stdlib-D8-A_OuU.wasm.gz.bin":{sha256:`7fd753e801bf2cc58111149d8c77539b941480e848274b51a39c4dcef2d2bb13`,bytes:9058728,encoding:`gzip`,mediaType:`application/wasm`,uncompressedSha256:`4b814fc9d13505ea5b4c1f3bd3a7cc7ccca137f551196b9b21f0a7caf9cc5878`,uncompressedBytes:30635497},"wasm-ruby/runtime-build.json":{sha256:`001d590b18cf039dccb2840c5e0955832068d7e354fc587989c70041797b9239`,bytes:7561,mediaType:`application/json`},"wasm-ruby/runtime-manifest.v1.json":{sha256:`cb5da1289ea19078e26fcfa1780d1dd03b213bf5cdeee5bffe119f8aa7c8942d`,bytes:526,mediaType:`application/json`},"wasm-ruby/runtime-manifest.v2.json":{sha256:`4e5f21e2835571078893032f47775460e74722994d906c2983f0621864b6a5e0`,bytes:7782,mediaType:`application/json`},"wasm-ruby/runtime.mjs":{sha256:`d1d33ccf090d3e99d8e3fd54a4e18c258d468e101711d0aee360e51dc2e26fd9`,bytes:54866,mediaType:`text/javascript`},"wasm-ruby/runtime.mjs.bin":{sha256:`d1d33ccf090d3e99d8e3fd54a4e18c258d468e101711d0aee360e51dc2e26fd9`,bytes:54866,mediaType:`application/octet-stream`},"wasm-ruby/split/ruby-core.wasm.gz.bin":{sha256:`d427b86c2bb221bd007731795d44212bd1d61a3bc58661ab78276906b30a491b`,bytes:5050303,encoding:`gzip`,mediaType:`application/wasm`,uncompressedSha256:`e64fa4c82cbbb62044648b0a15b96f3486ff3ecbab7bb7a3df11b4ee3e907ddc`,uncompressedBytes:16655034},"wasm-ruby/split/runtime-split.v1.json":{sha256:`57880188dbfe3299bc9932e1136e56cf9591ee07b1556dbcd85afd5fd8e80907`,bytes:4259,mediaType:`application/json`},"wasm-ruby/split/runtime.mjs.bin":{sha256:`d1d33ccf090d3e99d8e3fd54a4e18c258d468e101711d0aee360e51dc2e26fd9`,bytes:54866,mediaType:`application/octet-stream`},"wasm-ruby/split/stdlib.pack.gz.bin":{sha256:`49887b7d427526bd04045b2da56895c51c9824c1681bbdbd2bf4ca5cc2cbbf5b`,bytes:4016936,encoding:`gzip`,mediaType:`application/octet-stream`,uncompressedSha256:`db6419553b4e2773999d48d4e3a7d4b5f750faed01171f5ec72f4772bbb2f5d8`,uncompressedBytes:14791924},"wasm-rust/asset-url.js.bin":{sha256:`0cfc9638ca814251f9ddf117a5cef1832a1ee1c5035226f6538cdf739c55772a`,bytes:300,mediaType:`application/octet-stream`},"wasm-rust/browser-component-tools.js.bin":{sha256:`7860e2c261bb3d40daacc3c4dfefa18fb8e558ce56f4f0527b50f3134ce15be3`,bytes:12627,mediaType:`application/octet-stream`},"wasm-rust/browser-execution.js.bin":{sha256:`3a7d5ad84676ceabef0758be7230abb97ef496375b2d4838cc25d02371465f7b`,bytes:6936,mediaType:`application/octet-stream`},"wasm-rust/browser-linker.js.bin":{sha256:`e01a93da60e7901416a57dfdbd71b299f92aa42382ded5371bf1a9ff8a33d009`,bytes:13014,mediaType:`application/octet-stream`},"wasm-rust/browser-stdin.js.bin":{sha256:`52dba3d7edc435816adb4b795033000f3d5fee16bb265710b4361601f9a1eee5`,bytes:1482,mediaType:`application/octet-stream`},"wasm-rust/compiler-preload.js.bin":{sha256:`644aa8d25bd4adbb190d07a0bc23923149a912dee7b511e25809fb67312c89a9`,bytes:7403,mediaType:`application/octet-stream`},"wasm-rust/compiler-runtime.js.bin":{sha256:`86f2b34128ce97c050f8c9245781b211e229073cef6a3ed4c6cfef92652902c7`,bytes:3418,mediaType:`application/octet-stream`},"wasm-rust/compiler-support.js.bin":{sha256:`52164fb602e546e61e6a5a2e09ae3c61aba9377c1b9918b0a788d92e4c497a5b`,bytes:5220,mediaType:`application/octet-stream`},"wasm-rust/compiler-worker.js.bin":{sha256:`72cd8fe5c7999ffa6e144b3d6ea3691686843063dc8405274c2573f1ea8356a2`,bytes:22093,mediaType:`application/octet-stream`},"wasm-rust/compiler.js.bin":{sha256:`6fd676dfda595610d41e44e80f90f9330aee5326d5daf42cb935a28b48dffc2b`,bytes:35115,mediaType:`application/octet-stream`},"wasm-rust/debug-instrumenter.js":{sha256:`2a8913fc4f6d998910de3453e7d25720df75cda57ae5d959d19c8c74acfda919`,bytes:122770,mediaType:`text/javascript`},"wasm-rust/index.js.bin":{sha256:`cfbc70c3349b35c1f510ead79fdfb95bb29700f2566716b6b5fa0d1017cd00d7`,bytes:3686,mediaType:`application/octet-stream`},"wasm-rust/module-worker.js.bin":{sha256:`317eee43c55be3923ffc9630342deeac9ff1030abb2cb2d222e1036ca796b3fc`,bytes:104,mediaType:`application/octet-stream`},"wasm-rust/retryable-failure-kind.js.bin":{sha256:`32d49e791d1c35329e8aa8dc16cc372ee0c52ba8570c7488c7f7a5a99e1e003c`,bytes:1432,mediaType:`application/octet-stream`},"wasm-rust/runtime-asset-cache-service.js.bin":{sha256:`10b01ffd98193be3e7506586fc8886f881b7a3459cbbbc4311b51e1485f4f917`,bytes:7031,mediaType:`application/octet-stream`},"wasm-rust/runtime-asset-cache.js.bin":{sha256:`47d7369975b19ef51a0c85da30638b995c9c5ba40b6cabe2979ec2d2b7ba8fef`,bytes:997,mediaType:`application/octet-stream`},"wasm-rust/runtime-asset-store.js.bin":{sha256:`95278dcb0e836d460c657bffcd8ae429e7e8e0508e60665d377a69aaa27e10b4`,bytes:16751,mediaType:`application/octet-stream`},"wasm-rust/runtime-asset.js.bin":{sha256:`5f09c428431e3f3226673b537fc1277ba71dc42bdaf2937e18275a8844e044f8`,bytes:25746,mediaType:`application/octet-stream`},"wasm-rust/runtime-delivery-budget.js.bin":{sha256:`9340496c81f33b0780ac760d89939dfe22442df0318989b8edf1dc97d57f36e5`,bytes:9681,mediaType:`application/octet-stream`},"wasm-rust/runtime-executable-graph.v1.json":{sha256:`62349e16caf8d31ff7f1910575e1fae5299620a9297e9ed05a04ad05833df406`,bytes:44025,mediaType:`application/json`},"wasm-rust/runtime-manifest.js.bin":{sha256:`52939e1bb35c208ab7ad26000ea52e4a5ad9b724a35533f0b004f65212e22314`,bytes:49498,mediaType:`application/octet-stream`},"wasm-rust/runtime/packs/sysroot/wasm32-wasip1.index.json":{sha256:`2f05e809be7df5f92b91eb8493a63091574cecb249f3de376e4c8f3aea81b05c`,bytes:6986,mediaType:`application/json`,deliveryPath:`wasm-rust/runtime/packs/sysroot/wasm32-wasip1.index.json.gz`},"wasm-rust/runtime/packs/sysroot/wasm32-wasip1.index.json.gz":{sha256:`d3846ecae39b774300272f883e3d85a7e986214584a6ca23d15b9b55c6024cb4`,bytes:1126,encoding:`gzip`,mediaType:`application/json`,uncompressedSha256:`2f05e809be7df5f92b91eb8493a63091574cecb249f3de376e4c8f3aea81b05c`,uncompressedBytes:6986},"wasm-rust/runtime/packs/sysroot/wasm32-wasip1.pack.gz":{sha256:`c98393f3ab41a009fe6d36b9afacea7d47aa282b88c93c171b1d5a924ce18f96`,bytes:24626071,encoding:`gzip`,mediaType:`application/octet-stream`,uncompressedSha256:`c77bbafd0d7496731810296f91f34cf02be47f8708a6a669172c97963d12a5cb`,uncompressedBytes:75268153},"wasm-rust/runtime/packs/sysroot/wasm32-wasip2.index.json":{sha256:`780e0716fb5bddc9f142f4b2205b76d495593e6c34b7d654c034d0e4b7cea3b3`,bytes:12822,mediaType:`application/json`,deliveryPath:`wasm-rust/runtime/packs/sysroot/wasm32-wasip2.index.json.gz`},"wasm-rust/runtime/packs/sysroot/wasm32-wasip2.index.json.gz":{sha256:`5f3cc86d59e8f5388f072dc48a0951ddc616f18a4860c220afaff2a89199d4e0`,bytes:1811,encoding:`gzip`,mediaType:`application/json`,uncompressedSha256:`780e0716fb5bddc9f142f4b2205b76d495593e6c34b7d654c034d0e4b7cea3b3`,uncompressedBytes:12822},"wasm-rust/runtime/packs/sysroot/wasm32-wasip2.pack.gz":{sha256:`417a9316a2a6a7db5fab6adfa0a7e7e5958ed4591754562a66f6cdd96a68df6e`,bytes:7747620,encoding:`gzip`,mediaType:`application/octet-stream`,uncompressedSha256:`957dca062890c0550fe3bf8a5ce0e2fe69f6bd69d19a429f73ceec888f05be83`,uncompressedBytes:17558862},"wasm-rust/runtime/packs/sysroot/wasm32-wasip3.index.json":{sha256:`bc5e257d8560487902d4a023fed6c64faa90508cddac067db23a4eed9af50cb4`,bytes:12825,mediaType:`application/json`,deliveryPath:`wasm-rust/runtime/packs/sysroot/wasm32-wasip3.index.json.gz`},"wasm-rust/runtime/packs/sysroot/wasm32-wasip3.index.json.gz":{sha256:`14251cd39eb88dcfef74f0ed626994109a24f2b560910da453db8d24caf7bdb9`,bytes:1829,encoding:`gzip`,mediaType:`application/json`,uncompressedSha256:`bc5e257d8560487902d4a023fed6c64faa90508cddac067db23a4eed9af50cb4`,uncompressedBytes:12825},"wasm-rust/runtime/packs/sysroot/wasm32-wasip3.pack.gz":{sha256:`dbd22b4c728b0d8eb60ca8371bfd2a4de3cc309aec919ac21d4b2e9a5f687bf3`,bytes:7862375,encoding:`gzip`,mediaType:`application/octet-stream`,uncompressedSha256:`b6c9fb2dfb6fe7de6d21c23eb468b57d2629973e40fd63e0acf2324689592b70`,uncompressedBytes:18202672},"wasm-rust/runtime/runtime-manifest.v3.json":{sha256:`30b210003632395a1effd19f7a46565d5f8c52a9d3a28a310fa24219f97a5a9a`,bytes:6185,mediaType:`application/json`},"wasm-rust/runtime/rustc/rustc.wasm":{sha256:`b7b1dc0687115b3243e4e41b7dc24718178d4e75e1ccc975d4400a407627c493`,bytes:75367614,mediaType:`application/wasm`,deliveryPath:`wasm-rust/runtime/rustc/rustc.wasm.gz`},"wasm-rust/runtime/rustc/rustc.wasm.gz":{sha256:`3cbbf421f97460cd36c678509289976a8346fa4875009e064944024bc9c7e3da`,bytes:21103827,encoding:`gzip`,mediaType:`application/wasm`,uncompressedSha256:`b7b1dc0687115b3243e4e41b7dc24718178d4e75e1ccc975d4400a407627c493`,uncompressedBytes:75367614},"wasm-rust/rustc-module-service.js.bin":{sha256:`643e87810870eadb9489f4161f2132a158e37c1e343426c58e04e3482e1d7045`,bytes:4926,mediaType:`application/octet-stream`},"wasm-rust/rustc-module.js.bin":{sha256:`81dee74032dd10187e9b576f2d2fe9291cee1ea6a829d0db37429dabd06c0d1e`,bytes:711,mediaType:`application/octet-stream`},"wasm-rust/rustc-runtime.js.bin":{sha256:`f72739e496d8b9e012f323f30f5869f8fee2d444986494cfe08c378fc05e6913`,bytes:22766,mediaType:`application/octet-stream`},"wasm-rust/rustc-thread-worker.js.bin":{sha256:`0b41ccb2c0053b860ac4297545e5f3ffcbb4a11525dfca6f495bd43b7e2a7bb6`,bytes:12578,mediaType:`application/octet-stream`},"wasm-rust/shared-workspace.js.bin":{sha256:`a522f740cac9d237cedb54ad4aaeb68e595a08073259a1e603f5dec3d7274469`,bytes:16122,mediaType:`application/octet-stream`},"wasm-rust/thread-startup.js.bin":{sha256:`2c407a04ed387991ff4c770d3ba8af6f493217ba48c57df381ab13909799e258`,bytes:2096,mediaType:`application/octet-stream`},"wasm-rust/thread-worker-budget.js.bin":{sha256:`3e188eda32c36119716a85164da79451a3283574464db0bfbd8016363c5f5129`,bytes:3634,mediaType:`application/octet-stream`},"wasm-rust/vendor/browser_wasi_shim/debug.js.bin":{sha256:`a91848ee180529e2a60c05dfb9584cad19cd4e1c6f391fdb76a938bcae4c0328`,bytes:414,mediaType:`application/octet-stream`},"wasm-rust/vendor/browser_wasi_shim/fd.js.bin":{sha256:`9e82e1fc1bfd3e3573f64349dc42b4b624ed61d24e5c553f2bb4d041444f166c`,bytes:1906,mediaType:`application/octet-stream`},"wasm-rust/vendor/browser_wasi_shim/fs_mem.js.bin":{sha256:`85dbc9e0ee784d9ff8b55452644e00bf7058e32355aab974f8b71d7d85772324`,bytes:12206,mediaType:`application/octet-stream`},"wasm-rust/vendor/browser_wasi_shim/fs_opfs.js.bin":{sha256:`4b96aaeb5ac5986cf802cbf22b975c656682d22a38248160c96fc2ded5644869`,bytes:2280,mediaType:`application/octet-stream`},"wasm-rust/vendor/browser_wasi_shim/index.js.bin":{sha256:`7e2fd52ee3f728bb0b1d6e449724e0f13e3d586bb25bde6e02a66366175b5605`,bytes:316,mediaType:`application/octet-stream`},"wasm-rust/vendor/browser_wasi_shim/strace.js.bin":{sha256:`ece435d3784d928d02bff4d015b7cb686f8c06de8536ff9f8ebc38a8f403a3be`,bytes:318,mediaType:`application/octet-stream`},"wasm-rust/vendor/browser_wasi_shim/wasi.js.bin":{sha256:`168eb977a826f75ab0c39f9322f78cc58dbd5b233019ad1d6a7e940af8a7c4aa`,bytes:16429,mediaType:`application/octet-stream`},"wasm-rust/vendor/browser_wasi_shim/wasi_defs.js.bin":{sha256:`0db0f42ba330749a7b05095ea1fd0ff63fd2b30e84cead30fe4c28359d15f194`,bytes:9027,mediaType:`application/octet-stream`},"wasm-rust/vendor/jco/lib/wasi_snapshot_preview1.command.wasm":{sha256:`b391794bf40029766403da7353eb2e1da17067844b78e19eaf9d934c25c4055d`,bytes:57236,mediaType:`application/wasm`},"wasm-rust/vendor/jco/obj/js-component-bindgen-component.core.wasm":{sha256:`50d8ad4bf3f2d985f90b2571a8090d2075301adbaaf9fe21d4771c772477cc48`,bytes:7739762,mediaType:`application/wasm`,deliveryPath:`wasm-rust/vendor/jco/obj/js-component-bindgen-component.core.wasm.gz`},"wasm-rust/vendor/jco/obj/js-component-bindgen-component.core.wasm.gz":{sha256:`004a5f62b0514f78b645c0acc403f599c8706cb27f21a0ac9f96b119ea20fe0c`,bytes:2508654,encoding:`gzip`,mediaType:`application/wasm`,uncompressedSha256:`50d8ad4bf3f2d985f90b2571a8090d2075301adbaaf9fe21d4771c772477cc48`,uncompressedBytes:7739762},"wasm-rust/vendor/jco/obj/js-component-bindgen-component.core2.wasm":{sha256:`ae04633eab380bc18fbe3842a092eab4924688fcc93f04a2ac659add202ede5e`,bytes:16426,mediaType:`application/wasm`},"wasm-rust/vendor/jco/obj/js-component-bindgen-component.js.gz.bin":{sha256:`7b5f36771a9bbcb47576d45d00629c59e9046166e5c6b686a2e3b77f0058e612`,bytes:41401,encoding:`gzip`,mediaType:`text/javascript`,uncompressedSha256:`bf5ea764275866171fe564ea92a78f9289ef7ff47746534887b882235a6e780c`,uncompressedBytes:358340},"wasm-rust/vendor/jco/obj/wasm-tools.core.wasm":{sha256:`c58816cb0a4751250dc2aea56064e50730d8af7bafffa3ab7bc31d7bd56670e4`,bytes:2429240,mediaType:`application/wasm`,deliveryPath:`wasm-rust/vendor/jco/obj/wasm-tools.core.wasm.gz`},"wasm-rust/vendor/jco/obj/wasm-tools.core.wasm.gz":{sha256:`347ad6e84cb0904203f862bb1b8fa0cea49e9bc43e129918fd6d728aeab13730`,bytes:928763,encoding:`gzip`,mediaType:`application/wasm`,uncompressedSha256:`c58816cb0a4751250dc2aea56064e50730d8af7bafffa3ab7bc31d7bd56670e4`,uncompressedBytes:2429240},"wasm-rust/vendor/jco/obj/wasm-tools.core2.wasm":{sha256:`ae04633eab380bc18fbe3842a092eab4924688fcc93f04a2ac659add202ede5e`,bytes:16426,mediaType:`application/wasm`},"wasm-rust/vendor/jco/obj/wasm-tools.js.gz.bin":{sha256:`9bf222d2dfc2006ee0ffe2a79f5d0d15816f44938458e0e0f6eec4ba820b0ff0`,bytes:42464,encoding:`gzip`,mediaType:`text/javascript`,uncompressedSha256:`b34e3766db2e82991f9c531e8f7d30533f1907f6ddb3b873517100a2ce66bbfb`,uncompressedBytes:376425},"wasm-rust/vendor/jco/src/browser.js.bin":{sha256:`7d8d056dedc4327245520d7b3b2ce1930953f017fe0335902899e8aa5dbd3f8e`,bytes:404,mediaType:`application/octet-stream`},"wasm-rust/vendor/preview2-shim/lib/browser/cli.js.bin":{sha256:`fc73e8c872db6e100522ae1b41c1b7ae5160ac97629610cae53eb2bc2d320266`,bytes:2826,mediaType:`application/octet-stream`},"wasm-rust/vendor/preview2-shim/lib/browser/clocks.js.bin":{sha256:`3a44508f62ce3cd3fb2adbabf8cc70be0c3fd962bb0e77cbc8125b6d5bba3f35`,bytes:1170,mediaType:`application/octet-stream`},"wasm-rust/vendor/preview2-shim/lib/browser/config.js.bin":{sha256:`ef5271f78522c5ecb7fee3579f73f12a43e85874f6bfcb24d449d0d6e1c9e813`,bytes:110,mediaType:`application/octet-stream`},"wasm-rust/vendor/preview2-shim/lib/browser/environment.js.bin":{sha256:`6a755f21d705e98caede66bb86e5aa880deff71c1721c39a641a59d287123298`,bytes:434,mediaType:`application/octet-stream`},"wasm-rust/vendor/preview2-shim/lib/browser/filesystem.js.bin":{sha256:`083e8c1be5c4b11264c3be7e15477fc37894723a649445daeaabfb973460acc5`,bytes:11570,mediaType:`application/octet-stream`},"wasm-rust/vendor/preview2-shim/lib/browser/http.js.bin":{sha256:`270e10d75628add4d96878b705dbf0ce3121648540c2c8df331796f809c7d84a`,bytes:17055,mediaType:`application/octet-stream`},"wasm-rust/vendor/preview2-shim/lib/browser/io.js.bin":{sha256:`c2429defe2de286efe7579c76e17a627d68846fb9c100260b1f5ea4ddb370096`,bytes:6348,mediaType:`application/octet-stream`},"wasm-rust/vendor/preview2-shim/lib/browser/random.js.bin":{sha256:`10ca591c575a43051f205ef953861e2bcba3a917e1ffbb40d74c0bc6985c4eb2`,bytes:1531,mediaType:`application/octet-stream`},"wasm-rust/vendor/preview2-shim/lib/browser/sockets.js.bin":{sha256:`a9a6ba4c7847c8109924447d36ec3087d410237e0728832f1de14625d03969e3`,bytes:1370,mediaType:`application/octet-stream`},"wasm-rust/worker-status.js.bin":{sha256:`8c345945f87eb1305fca69d4b99cca7a3df90a8f5b4ac334cd04e5d5b5be7041`,bytes:3841,mediaType:`application/octet-stream`},"wasm-sqlite/assets/sql-wasm-DfANybxk.wasm":{sha256:`38c14f6e379210bc942bdc4ebca44e7bfdb4318ecc1c72ca666a28fdce96670a`,bytes:658410,mediaType:`application/wasm`,deliveryPath:`wasm-sqlite/assets/sql-wasm-DfANybxk.wasm.gz`},"wasm-sqlite/assets/sql-wasm-DfANybxk.wasm.gz":{sha256:`d6d8a85420ba17e8283bdde16d46f85953fdb7bb4e3d33d1819dafd9f412bd2d`,bytes:322928,encoding:`gzip`,mediaType:`application/wasm`,uncompressedSha256:`38c14f6e379210bc942bdc4ebca44e7bfdb4318ecc1c72ca666a28fdce96670a`,uncompressedBytes:658410},"wasm-sqlite/runtime-manifest.v1.json":{sha256:`7ac561564a4fa7bf43efab1f708422f5c03ae8aad6f05ecd0e993ace663380a8`,bytes:580,mediaType:`application/json`},"wasm-sqlite/runtime.mjs":{sha256:`3b2318870ea6cb5eef1613949b09476e1220723b278b460c9c16248d1a93fe61`,bytes:40832,mediaType:`text/javascript`},"wasm-tcl/require.js":{sha256:`0ca49b7de8f5e006ba5eb976937a3f9fb96b05ebfbb11d685c0b21ead94aacaf`,bytes:17831,mediaType:`text/javascript`},"wasm-tcl/runner-worker.js":{sha256:`f65d0ed41589fe280219948afe7b4bb5f07766faac66fd2b15b70c5c2c50c4f2`,bytes:31654,mediaType:`text/javascript`},"wasm-tcl/runtime-build.json":{sha256:`3b426e4332c3e89a80878d4cc1b159192de50e03185757420ceef3699c786834`,bytes:1972,mediaType:`application/json`},"wasm-tcl/runtime-manifest.v1.json":{sha256:`f144c8bd67f4ada5377740e3a4bf900624468ab5b92818361936e90c9c8fe536`,bytes:457,mediaType:`application/json`},"wasm-tcl/runtime-manifest.v2.json":{sha256:`df616e22d937820997f4263ad341082eb86e05f3891729fabd3e0892f7c5e1db`,bytes:4870,mediaType:`application/json`},"wasm-tcl/tcl/wacl-custom.data":{sha256:`46874b6dfe04b9c693815fe904a52e3583260323857dee46ac7373c484e3b2f8`,bytes:976,mediaType:`application/octet-stream`},"wasm-tcl/tcl/wacl-custom.data.bin":{sha256:`46874b6dfe04b9c693815fe904a52e3583260323857dee46ac7373c484e3b2f8`,bytes:976,mediaType:`application/octet-stream`},"wasm-tcl/tcl/wacl-library.data":{sha256:`3a8e166c2197920e36c874e2fefae4ca6e0c4a920a443b8e1d2282c344d485f0`,bytes:2307994,mediaType:`application/octet-stream`,deliveryPath:`wasm-tcl/tcl/wacl-library.data.gz`},"wasm-tcl/tcl/wacl-library.data.gz":{sha256:`909811fc942d947e1d5efb0ee425447dce9f267bfd6207c4d5af91dedca1ae8a`,bytes:593060,encoding:`gzip`,mediaType:`application/octet-stream`,uncompressedSha256:`3a8e166c2197920e36c874e2fefae4ca6e0c4a920a443b8e1d2282c344d485f0`,uncompressedBytes:2307994},"wasm-tcl/tcl/wacl-library.data.gz.bin":{sha256:`909811fc942d947e1d5efb0ee425447dce9f267bfd6207c4d5af91dedca1ae8a`,bytes:593060,encoding:`gzip`,mediaType:`application/octet-stream`,uncompressedSha256:`3a8e166c2197920e36c874e2fefae4ca6e0c4a920a443b8e1d2282c344d485f0`,uncompressedBytes:2307994},"wasm-tcl/tcl/wacl.js":{sha256:`c3377f974386190f1e465ffd66b528b0e33ea7a66bcde3b8c1695d4d720276af`,bytes:240157,mediaType:`text/javascript`},"wasm-tcl/tcl/wacl.wasm":{sha256:`9f55db5a617fd154882bb93bbf333dad5af1d0d697e8076ed05896fb91b22e99`,bytes:1884110,mediaType:`application/wasm`,deliveryPath:`wasm-tcl/tcl/wacl.wasm.gz`},"wasm-tcl/tcl/wacl.wasm.gz":{sha256:`35a913cb5400f1eaa350de61bf9b6276fb6114d2a6ac7d16e5ee58d5c8b83ac4`,bytes:640669,encoding:`gzip`,mediaType:`application/wasm`,uncompressedSha256:`9f55db5a617fd154882bb93bbf333dad5af1d0d697e8076ed05896fb91b22e99`,uncompressedBytes:1884110},"wasm-tcl/tcl/wacl.wasm.gz.bin":{sha256:`35a913cb5400f1eaa350de61bf9b6276fb6114d2a6ac7d16e5ee58d5c8b83ac4`,bytes:640669,encoding:`gzip`,mediaType:`application/wasm`,uncompressedSha256:`9f55db5a617fd154882bb93bbf333dad5af1d0d697e8076ed05896fb91b22e99`,uncompressedBytes:1884110},"wasm-tinygo/assets/upstream-binaryen-59aad93503b5fd53.wasm.gz.bin":{sha256:`e497b67a6bcbee29639792a3d58ecacb22781287f7fe155bfdf079e6ca159dff`,bytes:2366782,encoding:`gzip`,mediaType:`application/wasm`,uncompressedSha256:`59aad93503b5fd539993f2f5571c11dce9ddb4c5d10b681abc8e5dc124aed526`,uncompressedBytes:9282194},"wasm-tinygo/assets/upstream-compile-worker-CFw6Ych6.js":{sha256:`03a76345c69f8bd751dac18894f65c0918f1690fbbb661f38052819cd5ae8209`,bytes:558,mediaType:`text/javascript`},"wasm-tinygo/assets/upstream-compile-worker-CUrboB1_.js":{sha256:`42337c2f06d04b51d79f0ec66ae685f0cfb2a78718b0636df980dc92dd1db9d5`,bytes:103559,mediaType:`text/javascript`},"wasm-tinygo/assets/upstream-compile-worker-CeYS3ydo.js":{sha256:`faa2bf6a310cd23991babde1fb62cd34253d692fee03029fe3508eae4c24b1c0`,bytes:181175,mediaType:`text/javascript`},"wasm-tinygo/assets/upstream-compile-worker-NPJcbr3r.js":{sha256:`2ac9a6dff1bfd7198815ead612722d9b2ffbbc6c8a0e62958444ee84ff155b80`,bytes:110,mediaType:`text/javascript`},"wasm-tinygo/runtime-executable-graph.v1.json":{sha256:`2019e9f2980929a7eead0db858fd9a4b0a149075fa657bc0c4b815d916a5ac15`,bytes:2554,mediaType:`application/json`},"wasm-tinygo/tools/upstream/lld.wasm":{sha256:`14f08c475b24ef45313cab7a086693525955c2c000b833faaaf48ad35b2521f8`,bytes:20795796,mediaType:`application/wasm`,deliveryPath:`wasm-tinygo/tools/upstream/lld.wasm.gz`},"wasm-tinygo/tools/upstream/lld.wasm.gz":{sha256:`f842a9b5df3c6d326f0260bfd313c11c2e22bc8b8ae0387deede9a4af55779cd`,bytes:7837837,encoding:`gzip`,mediaType:`application/wasm`,uncompressedSha256:`14f08c475b24ef45313cab7a086693525955c2c000b833faaaf48ad35b2521f8`,uncompressedBytes:20795796},"wasm-tinygo/tools/upstream/package-graph-provider-receipt.json":{sha256:`b25c8ffd86af0e540cf058e38b273271100ff297316f30a38c8239c77d9357d1`,bytes:10368,mediaType:`application/json`},"wasm-tinygo/tools/upstream/producer-receipt.json":{sha256:`a400355ee1ca13c6a79bca0c7c2e8cf05ecf457fdc61c9fc69692bb17500842a`,bytes:10207,mediaType:`application/json`},"wasm-tinygo/tools/upstream/tinygo-compiler.wasm":{sha256:`a65f51c7d2845ea1469328705f2c9839f0151ee221e6a3efea851226e4e2d649`,bytes:54057556,mediaType:`application/wasm`,deliveryPath:`wasm-tinygo/tools/upstream/tinygo-compiler.wasm.gz`},"wasm-tinygo/tools/upstream/tinygo-compiler.wasm.gz":{sha256:`9700dd4403162a89cffa065011bb26c919b70a82b3e86d612ceb064a598111de`,bytes:17488480,encoding:`gzip`,mediaType:`application/wasm`,uncompressedSha256:`a65f51c7d2845ea1469328705f2c9839f0151ee221e6a3efea851226e4e2d649`,uncompressedBytes:54057556},"wasm-tinygo/tools/upstream/tinygo-package-graph.wasm":{sha256:`b7b28719bf97d5c5e140c3ec6f8f40a40fc7d02216e0160e460a34b79f61cb14`,bytes:25870831,mediaType:`application/wasm`,deliveryPath:`wasm-tinygo/tools/upstream/tinygo-package-graph.wasm.gz`},"wasm-tinygo/tools/upstream/tinygo-package-graph.wasm.gz":{sha256:`4ed8da31755a0b54ccfc1dafe39fcc124ed3525f3c843642179c08af18c76c58`,bytes:6058150,encoding:`gzip`,mediaType:`application/wasm`,uncompressedSha256:`b7b28719bf97d5c5e140c3ec6f8f40a40fc7d02216e0160e460a34b79f61cb14`,uncompressedBytes:25870831},"wasm-tinygo/tools/upstream/tinygoroot.tar.gz.bin":{sha256:`6c085f441ecc5990b71628f0b47b80e9e9810ae6384093e65723f795b4bd8688`,bytes:29058996,encoding:`gzip`,mediaType:`application/octet-stream`,uncompressedSha256:`559b9aca13977cd816f3b8afadfc12996f5b9ea8e113a3b249364be0f90f1cd3`,uncompressedBytes:133201920},"wasm-tinygo/tools/upstream/upstream-toolchain.v2.json":{sha256:`e53790b97125e48d77967bc87cc400fdfacfb678e6d847de372efa647cb4de4f`,bytes:1124,mediaType:`application/json`},"wasm-tinygo/upstream.js":{sha256:`136a957aa940c3e2b8c7a925eb538f3fce81f699aa9113e1fd93ce0b35c879aa`,bytes:126073,mediaType:`text/javascript`},"wasm-typescript/index.js":{sha256:`2c8942b6383d25d4582e9db0ee38d85b61eb8016f16e57c840f3c20af9ac848b`,bytes:3759064,mediaType:`text/javascript`,deliveryPath:`wasm-typescript/index.js.gz`},"wasm-typescript/index.js.gz":{sha256:`5bdc6a2df9798eac007098caa03bae44b0deb369ae8929ebdebd4f5eb8d54fac`,bytes:1383971,encoding:`gzip`,mediaType:`text/javascript`,uncompressedSha256:`2c8942b6383d25d4582e9db0ee38d85b61eb8016f16e57c840f3c20af9ac848b`,uncompressedBytes:3759064},"wasm-typescript/javascript.js":{sha256:`21b176cfe1ce4d39519979422bd1b3b598f183e9b3fe042ecc8cc37a535c3608`,bytes:35866,mediaType:`text/javascript`},"wasm-typescript/runtime-build.json":{sha256:`33978a1fcf84efa189e2b2b51accb42de854fcfce2965af5585808cfde69f8d6`,bytes:1960,mediaType:`application/json`},"wasm-uhmlang/runtime-build.json":{sha256:`5b78fc425d8e72b1298adc1de8bc3c32885df83e41aece5880d8335975ee2a89`,bytes:6986,mediaType:`application/json`},"wasm-uhmlang/uhmlang.wasm":{sha256:`f55e8a41f59654818af1d119d32d604165da369ce3aa269282b90fc319ed96dd`,bytes:3017206,mediaType:`application/wasm`,deliveryPath:`wasm-uhmlang/uhmlang.wasm.gz`},"wasm-uhmlang/uhmlang.wasm.gz":{sha256:`8e8347463e847ceed218763a24187512f6693c7da7a8b9e56261c75abf8c80ba`,bytes:859526,encoding:`gzip`,mediaType:`application/wasm`,uncompressedSha256:`f55e8a41f59654818af1d119d32d604165da369ce3aa269282b90fc319ed96dd`,uncompressedBytes:3017206},"wasm-v/c-sysroot.tar.gz":{sha256:`1bef0e55b104b039182659effe266234a87a977acb5b634643b4ee29b4b42bf2`,bytes:1291548,encoding:`gzip`,mediaType:`application/octet-stream`,uncompressedSha256:`87e44397b4dd68e02c3eb153219bd28bb6b39d658e23810c982b52c11a805fdf`,uncompressedBytes:4157440},"wasm-v/runtime-build.json":{sha256:`7bc782abc781a7d8195080026fd9efa8693d7422daf57428d2f6b851faf33aca`,bytes:3608,mediaType:`application/json`},"wasm-v/runtime-manifest.v1.json":{sha256:`f3d7cdaf97adfc0eb9a527c45ba01758facc50844f03cfcc85f338c768881044`,bytes:588,mediaType:`application/json`},"wasm-v/v.wasm":{sha256:`0eda26591eb6bafba7a2a7be4edf2433348849c1b8c2d47461335dbe22fd7077`,bytes:5490280,mediaType:`application/wasm`,deliveryPath:`wasm-v/v.wasm.gz`},"wasm-v/v.wasm.gz":{sha256:`fc9784e1142632f8c89cc723df9eb8b27ce877fc5ef68441d193658a71b50a3f`,bytes:2064564,encoding:`gzip`,mediaType:`application/wasm`,uncompressedSha256:`0eda26591eb6bafba7a2a7be4edf2433348849c1b8c2d47461335dbe22fd7077`,uncompressedBytes:5490280},"wasm-v/vroot.tar.gz":{sha256:`d98fc2f553c02c60f1e0426137019efb44252c80da8d1e40c4090c99e5c500c3`,bytes:858507,encoding:`gzip`,mediaType:`application/octet-stream`,uncompressedSha256:`c39b0961e1c8dc2961bae13f928915d64894942c561dfe44b1da721eb74fe4e0`,uncompressedBytes:4024320},"wasm-wat/index.js":{sha256:`76b7c67a84a69307c8f0164e5bb4d79fb1bccc6562294cbf3958673feed671f1`,bytes:920134,mediaType:`text/javascript`,deliveryPath:`wasm-wat/index.js.gz`},"wasm-wat/index.js.gz":{sha256:`5eac3243de41e66861d99eec318348148b16c5b74655cbd06400998b56d8b8bb`,bytes:230248,encoding:`gzip`,mediaType:`text/javascript`,uncompressedSha256:`76b7c67a84a69307c8f0164e5bb4d79fb1bccc6562294cbf3958673feed671f1`,uncompressedBytes:920134},"wasm-whitespace/runtime-build.json":{sha256:`2e6f7577b883b2fa8f249f85ff37aa2086f12f460b0aa1265b128d9681afeb31`,bytes:2367,mediaType:`application/json`},"wasm-whitespace/whitespace.wasm":{sha256:`de0846c43446d8dcb01e43324313bed565764b852b82b9885cd7d25e4f36b537`,bytes:59270,mediaType:`application/wasm`},"wasm-zig/runtime-build.json":{sha256:`30986d2feafd4953a12b75b4eb187c70fb936584cf4017755170480b77c39eba`,bytes:979,mediaType:`application/json`},"wasm-zig/std.tar.gz":{sha256:`03b09a29961853c11dbd3f8e7496f17df0a03a1e90d95932970e59730e958b62`,bytes:2575470,encoding:`gzip`,mediaType:`application/octet-stream`,uncompressedSha256:`ab9d792e3803dc66177ffe9ee715df2987d8348d7a808e2273229dd99d5fbfdd`,uncompressedBytes:12559872},"wasm-zig/zig_small.wasm":{sha256:`cbfc172100b07beee2710c837b7ed0fe2e456fb10c00aa7ff5e618db949adf61`,bytes:5018805,mediaType:`application/wasm`,deliveryPath:`wasm-zig/zig_small.wasm.gz`},"wasm-zig/zig_small.wasm.gz":{sha256:`7197ecf6024467003d96957c58f28a329b267a53abe93d8e476ef01603bf02c0`,bytes:1566206,encoding:`gzip`,mediaType:`application/wasm`,uncompressedSha256:`cbfc172100b07beee2710c837b7ed0fe2e456fb10c00aa7ff5e618db949adf61`,uncompressedBytes:5018805},"webr/000bd2c7d2f13441/R.js":{sha256:`162adb529111d739b37ef1b9f889eb7afbe4fb3288f8a58166cd6d0b04fd7376`,bytes:785875,mediaType:`text/javascript`,deliveryPath:`webr/000bd2c7d2f13441/R.js.gz`},"webr/000bd2c7d2f13441/R.js.gz":{sha256:`ab867cc499a388a49efd03609d2ff2bdafd9dd8898bb5aba168c6c1be7ad567c`,bytes:140094,encoding:`gzip`,mediaType:`text/javascript`,uncompressedSha256:`162adb529111d739b37ef1b9f889eb7afbe4fb3288f8a58166cd6d0b04fd7376`,uncompressedBytes:785875},"webr/000bd2c7d2f13441/R.wasm":{sha256:`5df459fb222d332e358cf08e4019c0e114398579ed8c62242bfcceeda81222ba`,bytes:18062845,mediaType:`application/wasm`,deliveryPath:`webr/000bd2c7d2f13441/R.wasm.gz`},"webr/000bd2c7d2f13441/R.wasm.gz":{sha256:`e0b6c9f4a6bf363a307c40bb6fd965c367b6e3b608429c89c9f70c64c41d65ec`,bytes:12333414,encoding:`gzip`,mediaType:`application/wasm`,uncompressedSha256:`5df459fb222d332e358cf08e4019c0e114398579ed8c62242bfcceeda81222ba`,uncompressedBytes:18062845},"webr/000bd2c7d2f13441/libRblas.so":{sha256:`d831496cc1d1e2748519439a0ea509ba966b56db10d13132db52331a270aac74`,bytes:198205,mediaType:`application/octet-stream`},"webr/000bd2c7d2f13441/libRlapack.so":{sha256:`df8ca333754f0dd95715df437f6e6d633e4ffbff0176bcb11c15fe3e5dd4e387`,bytes:1769888,mediaType:`application/octet-stream`,deliveryPath:`webr/000bd2c7d2f13441/libRlapack.so.gz`},"webr/000bd2c7d2f13441/libRlapack.so.gz":{sha256:`1f5ede363dee6c49f7f8fcf952e81f5e423b78936037d166faa1b74615028117`,bytes:708028,encoding:`gzip`,mediaType:`application/octet-stream`,uncompressedSha256:`df8ca333754f0dd95715df437f6e6d633e4ffbff0176bcb11c15fe3e5dd4e387`,uncompressedBytes:1769888},"webr/000bd2c7d2f13441/vfs/etc/fonts/fonts.conf":{sha256:`a93efbf9eec83d72a463f1d52f54043a8afa6ae7cc05609deda73232525e7bc0`,bytes:1089,mediaType:`application/octet-stream`},"webr/000bd2c7d2f13441/vfs/etc/ssl/cert.pem":{sha256:`86a1f3366afac7c6f8ae9f3c779ac221129328c43f0ab2b8817eb2f362a5025c`,bytes:189462,mediaType:`application/octet-stream`},"webr/000bd2c7d2f13441/vfs/usr/lib/R/doc.data":{sha256:`07e495986a70f6d94695fd0ffdafaf3f617f0ebd9a25fe0ddb01ea5cb6348284`,bytes:6835078,mediaType:`application/octet-stream`,deliveryPath:`webr/000bd2c7d2f13441/vfs/usr/lib/R/doc.data.gz`},"webr/000bd2c7d2f13441/vfs/usr/lib/R/doc.data.gz":{sha256:`03ad1b51acd51665a5ad8e4b1a3ffa570434ca0f2a51d432b294e4b5500ea90f`,bytes:4000106,encoding:`gzip`,mediaType:`application/octet-stream`,uncompressedSha256:`07e495986a70f6d94695fd0ffdafaf3f617f0ebd9a25fe0ddb01ea5cb6348284`,uncompressedBytes:6835078},"webr/000bd2c7d2f13441/vfs/usr/lib/R/doc.js.metadata":{sha256:`fa7537b51ccab64e17407933e926211d706f7e87ecc7db018e44e663c07d93a2`,bytes:8701,mediaType:`application/octet-stream`},"webr/000bd2c7d2f13441/vfs/usr/lib/R/library/base/demo.data":{sha256:`4e11f30054b30bb8746479b92bf5a34a6ce556e2f3b786a3bfd7f0169a3a6781`,bytes:11815,mediaType:`application/octet-stream`,deliveryPath:`webr/000bd2c7d2f13441/vfs/usr/lib/R/library/base/demo.data.gz`},"webr/000bd2c7d2f13441/vfs/usr/lib/R/library/base/demo.data.gz":{sha256:`5dc1fc84cb1d61e4d5311b8e01458014dab1c434c2b6d93deca3eaa9b50752e2`,bytes:4460,encoding:`gzip`,mediaType:`application/octet-stream`,uncompressedSha256:`4e11f30054b30bb8746479b92bf5a34a6ce556e2f3b786a3bfd7f0169a3a6781`,uncompressedBytes:11815},"webr/000bd2c7d2f13441/vfs/usr/lib/R/library/base/demo.js.metadata":{sha256:`bfc597e88f9b97b8eec9fd36227ef0d079fdf1c32e8bea84c3b1e77fb7a6b05c`,bytes:263,mediaType:`application/octet-stream`},"webr/000bd2c7d2f13441/vfs/usr/lib/R/library/base/help.data":{sha256:`597a8e549ce3484d27902419078827eefba4ce881303a01685e03e2fb7706dca`,bytes:2676181,mediaType:`application/octet-stream`,deliveryPath:`webr/000bd2c7d2f13441/vfs/usr/lib/R/library/base/help.data.gz`},"webr/000bd2c7d2f13441/vfs/usr/lib/R/library/base/help.data.gz":{sha256:`7c5dec2357f9e36fa4d348a8fef8477994cd56089009247e5908d918a6fb1a09`,bytes:2633853,encoding:`gzip`,mediaType:`application/octet-stream`,uncompressedSha256:`597a8e549ce3484d27902419078827eefba4ce881303a01685e03e2fb7706dca`,uncompressedBytes:2676181},"webr/000bd2c7d2f13441/vfs/usr/lib/R/library/base/help.js.metadata":{sha256:`a4cc3075fc1bd2bdd4826ee04efa616d569cd7e07886b8c98531a23406fc0a25`,bytes:318,mediaType:`application/octet-stream`},"webr/000bd2c7d2f13441/vfs/usr/lib/R/library/base/html.data":{sha256:`05347d90549b857eafbde191a28e2566bdb9b23887181b5af8417802a6c1a13a`,bytes:154498,mediaType:`application/octet-stream`,deliveryPath:`webr/000bd2c7d2f13441/vfs/usr/lib/R/library/base/html.data.gz`},"webr/000bd2c7d2f13441/vfs/usr/lib/R/library/base/html.data.gz":{sha256:`1f4e82a2633bf1cc134d3dbc6222003492de2fe207ddecccd6e3ab5d4f46f30c`,bytes:20906,encoding:`gzip`,mediaType:`application/octet-stream`,uncompressedSha256:`05347d90549b857eafbde191a28e2566bdb9b23887181b5af8417802a6c1a13a`,uncompressedBytes:154498},"webr/000bd2c7d2f13441/vfs/usr/lib/R/library/base/html.js.metadata":{sha256:`4826bdd7ba15568d7ab5226c92b1d742bcd3f4ce853300f55bf205a5f8e22d02`,bytes:155,mediaType:`application/octet-stream`},"webr/000bd2c7d2f13441/vfs/usr/lib/R/library/compiler/help.data":{sha256:`59f99e9f716faa2cc5d772f21158131a3d7ef15baefd34edfde1aa582936d6f6`,bytes:10241,mediaType:`application/octet-stream`,deliveryPath:`webr/000bd2c7d2f13441/vfs/usr/lib/R/library/compiler/help.data.gz`},"webr/000bd2c7d2f13441/vfs/usr/lib/R/library/compiler/help.data.gz":{sha256:`c8e850b5b5e1a04aaf29ef42d50f805473f56c988abcf60ffcb375195f7bcddc`,bytes:10128,encoding:`gzip`,mediaType:`application/octet-stream`,uncompressedSha256:`59f99e9f716faa2cc5d772f21158131a3d7ef15baefd34edfde1aa582936d6f6`,uncompressedBytes:10241},"webr/000bd2c7d2f13441/vfs/usr/lib/R/library/compiler/help.js.metadata":{sha256:`1afd086c4166f184ec0db0943352c4c5885a33e1b8fb70e537241da712288534`,bytes:304,mediaType:`application/octet-stream`},"webr/000bd2c7d2f13441/vfs/usr/lib/R/library/compiler/html.data":{sha256:`d4a2aa1436cb29138ff02ce61158a9edbf1e2938657dfff72a01e69a2ae3713f`,bytes:3994,mediaType:`application/octet-stream`,deliveryPath:`webr/000bd2c7d2f13441/vfs/usr/lib/R/library/compiler/html.data.gz`},"webr/000bd2c7d2f13441/vfs/usr/lib/R/library/compiler/html.data.gz":{sha256:`6d157ac6c76a2f2b15a989ffdbc8c1a465b91811a654aa6fb1573d783109e30c`,bytes:1227,encoding:`gzip`,mediaType:`application/octet-stream`,uncompressedSha256:`d4a2aa1436cb29138ff02ce61158a9edbf1e2938657dfff72a01e69a2ae3713f`,uncompressedBytes:3994},"webr/000bd2c7d2f13441/vfs/usr/lib/R/library/compiler/html.js.metadata":{sha256:`98d18997c393881d285172dcb2414da928192520af6aba215667f0a93b0da54d`,bytes:147,mediaType:`application/octet-stream`},"webr/000bd2c7d2f13441/vfs/usr/lib/R/library/datasets/help.data":{sha256:`5afe376cec2e59dac7d4cbff5423f100f6e43e017f7b77fe1d19dbabaf5e0b49`,bytes:283635,mediaType:`application/octet-stream`,deliveryPath:`webr/000bd2c7d2f13441/vfs/usr/lib/R/library/datasets/help.data.gz`},"webr/000bd2c7d2f13441/vfs/usr/lib/R/library/datasets/help.data.gz":{sha256:`de58c6303b01b5fe83fca73a5d205e7448ffa16a56cf0a1086d776fdc60bb4dd`,bytes:277806,encoding:`gzip`,mediaType:`application/octet-stream`,uncompressedSha256:`5afe376cec2e59dac7d4cbff5423f100f6e43e017f7b77fe1d19dbabaf5e0b49`,uncompressedBytes:283635},"webr/000bd2c7d2f13441/vfs/usr/lib/R/library/datasets/help.js.metadata":{sha256:`a5cb9f65838dad1ad72e662675d28dafb75b8769c02d9537fac7569a295b7c16`,bytes:316,mediaType:`application/octet-stream`},"webr/000bd2c7d2f13441/vfs/usr/lib/R/library/datasets/html.data":{sha256:`8fd3a5d474206474e66d046afda046b948ef85133e6d0eb95d04fcf849e46481`,bytes:18875,mediaType:`application/octet-stream`,deliveryPath:`webr/000bd2c7d2f13441/vfs/usr/lib/R/library/datasets/html.data.gz`},"webr/000bd2c7d2f13441/vfs/usr/lib/R/library/datasets/html.data.gz":{sha256:`6f1eb6811cd3432e9764e75b0d418e3ed2455835a58f725ba18d0b2b8e1ed94d`,bytes:4458,encoding:`gzip`,mediaType:`application/octet-stream`,uncompressedSha256:`8fd3a5d474206474e66d046afda046b948ef85133e6d0eb95d04fcf849e46481`,uncompressedBytes:18875},"webr/000bd2c7d2f13441/vfs/usr/lib/R/library/datasets/html.js.metadata":{sha256:`c9c5e5bafee1c03be04d2867f44923e0fa74791bbc51ccbb8d3ff5579bb5e211`,bytes:151,mediaType:`application/octet-stream`},"webr/000bd2c7d2f13441/vfs/usr/lib/R/library/grDevices/afm.data":{sha256:`6b9cb3e7c78b5d1d099fd07926e5510b25d3b6b271f35bd60ff70025c1b68d6b`,bytes:970340,mediaType:`application/octet-stream`,deliveryPath:`webr/000bd2c7d2f13441/vfs/usr/lib/R/library/grDevices/afm.data.gz`},"webr/000bd2c7d2f13441/vfs/usr/lib/R/library/grDevices/afm.data.gz":{sha256:`bb0d88c8492ba397470152d6d90d82e055092dad73e1e864fe6b2ebf0b2bd52a`,bytes:953823,encoding:`gzip`,mediaType:`application/octet-stream`,uncompressedSha256:`6b9cb3e7c78b5d1d099fd07926e5510b25d3b6b271f35bd60ff70025c1b68d6b`,uncompressedBytes:970340},"webr/000bd2c7d2f13441/vfs/usr/lib/R/library/grDevices/afm.js.metadata":{sha256:`3e88061dfecc14c6cd1386be85d4fef59fe1f964312db41903e471ed74e7cf02`,bytes:6816,mediaType:`application/octet-stream`},"webr/000bd2c7d2f13441/vfs/usr/lib/R/library/grDevices/demo.data":{sha256:`8202f1abe0c06e973ec7329c3191534f6c7e030d4064f67784c966f166ff4981`,bytes:6376,mediaType:`application/octet-stream`,deliveryPath:`webr/000bd2c7d2f13441/vfs/usr/lib/R/library/grDevices/demo.data.gz`},"webr/000bd2c7d2f13441/vfs/usr/lib/R/library/grDevices/demo.data.gz":{sha256:`89433796693b081e65e8ae3214f4b8823c564a2fe8bf0f900956adf55fb16f2c`,bytes:2513,encoding:`gzip`,mediaType:`application/octet-stream`,uncompressedSha256:`8202f1abe0c06e973ec7329c3191534f6c7e030d4064f67784c966f166ff4981`,uncompressedBytes:6376},"webr/000bd2c7d2f13441/vfs/usr/lib/R/library/grDevices/demo.js.metadata":{sha256:`2a51924eaee18cbe41bfe8f11ae70f083748d97ef5cbbb77bd3c3a133eaad471`,bytes:149,mediaType:`application/octet-stream`},"webr/000bd2c7d2f13441/vfs/usr/lib/R/library/grDevices/enc.data":{sha256:`42df7e5787df79c1a87485dce7baeee25059debd26630b3ced3a4e70956cbe42`,bytes:38259,mediaType:`application/octet-stream`,deliveryPath:`webr/000bd2c7d2f13441/vfs/usr/lib/R/library/grDevices/enc.data.gz`},"webr/000bd2c7d2f13441/vfs/usr/lib/R/library/grDevices/enc.data.gz":{sha256:`73fcd21310a54e033f151f6c887001c55d348ff26e2e4d32a0be0ad48c3a4fd7`,bytes:4263,encoding:`gzip`,mediaType:`application/octet-stream`,uncompressedSha256:`42df7e5787df79c1a87485dce7baeee25059debd26630b3ced3a4e70956cbe42`,uncompressedBytes:38259},"webr/000bd2c7d2f13441/vfs/usr/lib/R/library/grDevices/enc.js.metadata":{sha256:`fd6fb479b499da19fe442318ac147bdda2557a087ff19acda5a220fbe6686617`,bytes:960,mediaType:`application/octet-stream`},"webr/000bd2c7d2f13441/vfs/usr/lib/R/library/grDevices/fonts.data":{sha256:`126f3d0c906841784316c88dfb3799182532bdf0e4f298e6e0664ab21bacd4ea`,bytes:580800,mediaType:`application/octet-stream`,deliveryPath:`webr/000bd2c7d2f13441/vfs/usr/lib/R/library/grDevices/fonts.data.gz`},"webr/000bd2c7d2f13441/vfs/usr/lib/R/library/grDevices/fonts.data.gz":{sha256:`4dca57d1a4a8b8ab530fa67b019193e6b3457d4066506a67284179f58bb50a72`,bytes:273155,encoding:`gzip`,mediaType:`application/octet-stream`,uncompressedSha256:`126f3d0c906841784316c88dfb3799182532bdf0e4f298e6e0664ab21bacd4ea`,uncompressedBytes:580800},"webr/000bd2c7d2f13441/vfs/usr/lib/R/library/grDevices/fonts.js.metadata":{sha256:`a59f1e81fa5a21f6b6fb91b6a51ad9944cff3283d5891c9427a3702573b6d65c`,bytes:352,mediaType:`application/octet-stream`},"webr/000bd2c7d2f13441/vfs/usr/lib/R/library/grDevices/help.data":{sha256:`afba278623218dc9e7a4b04bd4d51a3e800cd913fb715cf5c8ee0a8a2191a726`,bytes:452008,mediaType:`application/octet-stream`,deliveryPath:`webr/000bd2c7d2f13441/vfs/usr/lib/R/library/grDevices/help.data.gz`},"webr/000bd2c7d2f13441/vfs/usr/lib/R/library/grDevices/help.data.gz":{sha256:`cd5bb1d9e3da614ecfd34d493b5370c98e3e3e93dd625fac1f753c6c6a67d3a0`,bytes:447385,encoding:`gzip`,mediaType:`application/octet-stream`,uncompressedSha256:`afba278623218dc9e7a4b04bd4d51a3e800cd913fb715cf5c8ee0a8a2191a726`,uncompressedBytes:452008},"webr/000bd2c7d2f13441/vfs/usr/lib/R/library/grDevices/help.js.metadata":{sha256:`c639cb7c72cac13497dc29f0147f311a5206c9dc249885b0e2d11daa44e00106`,bytes:318,mediaType:`application/octet-stream`},"webr/000bd2c7d2f13441/vfs/usr/lib/R/library/grDevices/html.data":{sha256:`5479e8cbc74ebb18cfad77d57592580d61f90bc6f67cae0e5bb0c908e5b390c1`,bytes:26347,mediaType:`application/octet-stream`,deliveryPath:`webr/000bd2c7d2f13441/vfs/usr/lib/R/library/grDevices/html.data.gz`},"webr/000bd2c7d2f13441/vfs/usr/lib/R/library/grDevices/html.data.gz":{sha256:`de1205804774e7d7db07966467a2d0ea66734550583ad4549935d4356cffd9bb`,bytes:4188,encoding:`gzip`,mediaType:`application/octet-stream`,uncompressedSha256:`5479e8cbc74ebb18cfad77d57592580d61f90bc6f67cae0e5bb0c908e5b390c1`,uncompressedBytes:26347},"webr/000bd2c7d2f13441/vfs/usr/lib/R/library/grDevices/html.js.metadata":{sha256:`3a2b36bad1509df1912e194322e133c7f362ae7cade8c178e9fbfe88da0a0c83`,bytes:151,mediaType:`application/octet-stream`},"webr/000bd2c7d2f13441/vfs/usr/lib/R/library/grDevices/libs.data":{sha256:`fed7ac92f66efa1f985c945013bedd9fe5e873680cd7ebd4b7fb5e26c5397713`,bytes:4577488,mediaType:`application/octet-stream`,deliveryPath:`webr/000bd2c7d2f13441/vfs/usr/lib/R/library/grDevices/libs.data.gz`},"webr/000bd2c7d2f13441/vfs/usr/lib/R/library/grDevices/libs.data.gz":{sha256:`558a09f14c830848510b6279c1141802d392fe2d0aaf66eca174faa03dc7bb1d`,bytes:1643930,encoding:`gzip`,mediaType:`application/octet-stream`,uncompressedSha256:`fed7ac92f66efa1f985c945013bedd9fe5e873680cd7ebd4b7fb5e26c5397713`,uncompressedBytes:4577488},"webr/000bd2c7d2f13441/vfs/usr/lib/R/library/grDevices/libs.js.metadata":{sha256:`f4b2da4dd2f93011eaa259f8dddc23c63dd144fecc8322fab7885341952e2b7b`,bytes:103,mediaType:`application/octet-stream`},"webr/000bd2c7d2f13441/vfs/usr/lib/R/library/graphics/demo.data":{sha256:`c9c9d00542a701a9636c69af4392824eb046e1b8ed3b7312a3150f092e9a5aba`,bytes:72138,mediaType:`application/octet-stream`,deliveryPath:`webr/000bd2c7d2f13441/vfs/usr/lib/R/library/graphics/demo.data.gz`},"webr/000bd2c7d2f13441/vfs/usr/lib/R/library/graphics/demo.data.gz":{sha256:`3e60f0210cb48d0c40a8c56436af980e2a71f0016ea66b7d95f1932ffea24762`,bytes:13086,encoding:`gzip`,mediaType:`application/octet-stream`,uncompressedSha256:`c9c9d00542a701a9636c69af4392824eb046e1b8ed3b7312a3150f092e9a5aba`,uncompressedBytes:72138},"webr/000bd2c7d2f13441/vfs/usr/lib/R/library/graphics/demo.js.metadata":{sha256:`1128fef779f40452d0dd2b27b3974175fb4a341c3418d953d8b33540575117fd`,bytes:359,mediaType:`application/octet-stream`},"webr/000bd2c7d2f13441/vfs/usr/lib/R/library/graphics/help.data":{sha256:`3a7a808476e9caf497eebad81c08f6b90bee15456b840b0342d64647163836e9`,bytes:593260,mediaType:`application/octet-stream`,deliveryPath:`webr/000bd2c7d2f13441/vfs/usr/lib/R/library/graphics/help.data.gz`},"webr/000bd2c7d2f13441/vfs/usr/lib/R/library/graphics/help.data.gz":{sha256:`8522582e2b3a3577c24f174bcccc7d75bebb9128131157d7b3712d28255baf71`,bytes:562908,encoding:`gzip`,mediaType:`application/octet-stream`,uncompressedSha256:`3a7a808476e9caf497eebad81c08f6b90bee15456b840b0342d64647163836e9`,uncompressedBytes:593260},"webr/000bd2c7d2f13441/vfs/usr/lib/R/library/graphics/help.js.metadata":{sha256:`f389834ad81b4db9bb4e8e89c254bb8c886da36b5c458cd661a1a4d5710809f1`,bytes:720,mediaType:`application/octet-stream`},"webr/000bd2c7d2f13441/vfs/usr/lib/R/library/graphics/html.data":{sha256:`6896690287a4eaea3d08cf4802b0f2e41b926e962de4cb216c914e202fa5f6ec`,bytes:14311,mediaType:`application/octet-stream`,deliveryPath:`webr/000bd2c7d2f13441/vfs/usr/lib/R/library/graphics/html.data.gz`},"webr/000bd2c7d2f13441/vfs/usr/lib/R/library/graphics/html.data.gz":{sha256:`99d1c6a3224b704237d427057549a1a9b863033bbf2e8c086fc6e200553621bb`,bytes:2982,encoding:`gzip`,mediaType:`application/octet-stream`,uncompressedSha256:`6896690287a4eaea3d08cf4802b0f2e41b926e962de4cb216c914e202fa5f6ec`,uncompressedBytes:14311},"webr/000bd2c7d2f13441/vfs/usr/lib/R/library/graphics/html.js.metadata":{sha256:`bb82dd2024e800abf3d390c3f21f44e189ebe3df567a0de974e95206f7edef7d`,bytes:151,mediaType:`application/octet-stream`},"webr/000bd2c7d2f13441/vfs/usr/lib/R/library/grid/doc.data":{sha256:`5b80d22f927521345fd6480ea1e11aac77819d528da4e39fc9ebf7b1ceaadbbc`,bytes:671625,mediaType:`application/octet-stream`,deliveryPath:`webr/000bd2c7d2f13441/vfs/usr/lib/R/library/grid/doc.data.gz`},"webr/000bd2c7d2f13441/vfs/usr/lib/R/library/grid/doc.data.gz":{sha256:`c40b85e70ad49170e7aca3041bd518a1f7ce5c5510f5f46b49807a4c4715d869`,bytes:584214,encoding:`gzip`,mediaType:`application/octet-stream`,uncompressedSha256:`5b80d22f927521345fd6480ea1e11aac77819d528da4e39fc9ebf7b1ceaadbbc`,uncompressedBytes:671625},"webr/000bd2c7d2f13441/vfs/usr/lib/R/library/grid/doc.js.metadata":{sha256:`14924ac9389ed973b16d0f3e5cb30e49b6629db3f2f4c8e0ab36908bec1bac0b`,bytes:896,mediaType:`application/octet-stream`},"webr/000bd2c7d2f13441/vfs/usr/lib/R/library/grid/help.data":{sha256:`386619bc3cbbbe55964e6867934de92584acd014dee1e7ab03a7d707662ef7bb`,bytes:350823,mediaType:`application/octet-stream`,deliveryPath:`webr/000bd2c7d2f13441/vfs/usr/lib/R/library/grid/help.data.gz`},"webr/000bd2c7d2f13441/vfs/usr/lib/R/library/grid/help.data.gz":{sha256:`3d8a87877c069f47a6ffc590043975e26d26b112addd7bcabdcab576f7a9c74e`,bytes:341560,encoding:`gzip`,mediaType:`application/octet-stream`,uncompressedSha256:`386619bc3cbbbe55964e6867934de92584acd014dee1e7ab03a7d707662ef7bb`,uncompressedBytes:350823},"webr/000bd2c7d2f13441/vfs/usr/lib/R/library/grid/help.js.metadata":{sha256:`66a56f27efa45f11c3fe20b63215761527a18014531159bc7d1af159d9bf0a87`,bytes:308,mediaType:`application/octet-stream`},"webr/000bd2c7d2f13441/vfs/usr/lib/R/library/grid/html.data":{sha256:`c1ac78a310a90fd010b115084591cc770bc66d7a385dd80a4435655a82e377d5`,bytes:34936,mediaType:`application/octet-stream`,deliveryPath:`webr/000bd2c7d2f13441/vfs/usr/lib/R/library/grid/html.data.gz`},"webr/000bd2c7d2f13441/vfs/usr/lib/R/library/grid/html.data.gz":{sha256:`8ab236a697ca624dd74b1fce1eab0852e8d6fcab4e441ec09fe57e56849b77d1`,bytes:4928,encoding:`gzip`,mediaType:`application/octet-stream`,uncompressedSha256:`c1ac78a310a90fd010b115084591cc770bc66d7a385dd80a4435655a82e377d5`,uncompressedBytes:34936},"webr/000bd2c7d2f13441/vfs/usr/lib/R/library/grid/html.js.metadata":{sha256:`3d28487a22ea049d3c6329a9cebb0d310e3d4206647a517cb40ab21bc5662e1d`,bytes:151,mediaType:`application/octet-stream`},"webr/000bd2c7d2f13441/vfs/usr/lib/R/library/methods/help.data":{sha256:`7a28598ce94623a9b0ab73410561c3902180c4eeb29f7f5d42d8ff3f54550f84`,bytes:571949,mediaType:`application/octet-stream`,deliveryPath:`webr/000bd2c7d2f13441/vfs/usr/lib/R/library/methods/help.data.gz`},"webr/000bd2c7d2f13441/vfs/usr/lib/R/library/methods/help.data.gz":{sha256:`d727dc6b7422dedf18caf153144c78b6e2966d7a5a42c4c9f6f6cf16a8a0683e`,bytes:559755,encoding:`gzip`,mediaType:`application/octet-stream`,uncompressedSha256:`7a28598ce94623a9b0ab73410561c3902180c4eeb29f7f5d42d8ff3f54550f84`,uncompressedBytes:571949},"webr/000bd2c7d2f13441/vfs/usr/lib/R/library/methods/help.js.metadata":{sha256:`f8803bd5a9ceffbdf2857cba27d965f380a97801f97b51d300ac39ee239c5056`,bytes:318,mediaType:`application/octet-stream`},"webr/000bd2c7d2f13441/vfs/usr/lib/R/library/methods/html.data":{sha256:`f8deef64c5bd3e95486e4c557f676c167914de8988974eecdfdb9e1112245d1c`,bytes:43542,mediaType:`application/octet-stream`,deliveryPath:`webr/000bd2c7d2f13441/vfs/usr/lib/R/library/methods/html.data.gz`},"webr/000bd2c7d2f13441/vfs/usr/lib/R/library/methods/html.data.gz":{sha256:`12cbbb4eb9d878d130a0713e1ad24a4a5a1dbe5b623347a838c4d9d7f334b0bd`,bytes:5267,encoding:`gzip`,mediaType:`application/octet-stream`,uncompressedSha256:`f8deef64c5bd3e95486e4c557f676c167914de8988974eecdfdb9e1112245d1c`,uncompressedBytes:43542},"webr/000bd2c7d2f13441/vfs/usr/lib/R/library/methods/html.js.metadata":{sha256:`a63e96038c66042226f488d3ac8f54cbea74bda22febf593965e2bede552c73a`,bytes:151,mediaType:`application/octet-stream`},"webr/000bd2c7d2f13441/vfs/usr/lib/R/library/parallel.data":{sha256:`4d18ffdfd9097ca5db680becc7edd0552b6896924f5d168b7558b837f9d1bf6b`,bytes:369335,mediaType:`application/octet-stream`,deliveryPath:`webr/000bd2c7d2f13441/vfs/usr/lib/R/library/parallel.data.gz`},"webr/000bd2c7d2f13441/vfs/usr/lib/R/library/parallel.data.gz":{sha256:`25256757440bb6dd77b2cbdd5668b85aed5d2b8ebae58d039408f1d8b4fe5b95`,bytes:349042,encoding:`gzip`,mediaType:`application/octet-stream`,uncompressedSha256:`4d18ffdfd9097ca5db680becc7edd0552b6896924f5d168b7558b837f9d1bf6b`,uncompressedBytes:369335},"webr/000bd2c7d2f13441/vfs/usr/lib/R/library/parallel.js.metadata":{sha256:`82f79a072159d48f4c9d2b984ee7660c7c15327d14534d9e89b3271268b0a768`,bytes:1238,mediaType:`application/octet-stream`},"webr/000bd2c7d2f13441/vfs/usr/lib/R/library/splines/help.data":{sha256:`7b5067a625565bf2b527f9fb7c56286bbce4bb23c8d37f6b22037877af74b922`,bytes:45146,mediaType:`application/octet-stream`,deliveryPath:`webr/000bd2c7d2f13441/vfs/usr/lib/R/library/splines/help.data.gz`},"webr/000bd2c7d2f13441/vfs/usr/lib/R/library/splines/help.data.gz":{sha256:`019301cba92c42cb85448f37a081e09f13684a2d62bc28122b6d2832a8666da5`,bytes:44264,encoding:`gzip`,mediaType:`application/octet-stream`,uncompressedSha256:`7b5067a625565bf2b527f9fb7c56286bbce4bb23c8d37f6b22037877af74b922`,uncompressedBytes:45146},"webr/000bd2c7d2f13441/vfs/usr/lib/R/library/splines/help.js.metadata":{sha256:`6c6e828305347cb9bc7c1cba42a2d4a60509f95f4375919b8d7143b602b4e862`,bytes:302,mediaType:`application/octet-stream`},"webr/000bd2c7d2f13441/vfs/usr/lib/R/library/splines/html.data":{sha256:`2030f21e34a02452501be60f3ca70adc0b03222ac05729f1440f3d73d67f06af`,bytes:5851,mediaType:`application/octet-stream`,deliveryPath:`webr/000bd2c7d2f13441/vfs/usr/lib/R/library/splines/html.data.gz`},"webr/000bd2c7d2f13441/vfs/usr/lib/R/library/splines/html.data.gz":{sha256:`1f35815050129826f06bb9c71377ef98745648e028702ed326d56dee2288c2df`,bytes:1550,encoding:`gzip`,mediaType:`application/octet-stream`,uncompressedSha256:`2030f21e34a02452501be60f3ca70adc0b03222ac05729f1440f3d73d67f06af`,uncompressedBytes:5851},"webr/000bd2c7d2f13441/vfs/usr/lib/R/library/splines/html.js.metadata":{sha256:`55921a910bdb3d7cb2d2db24dff9e57ddbe4d5670fc54c3ce0c70da6112d6cef`,bytes:147,mediaType:`application/octet-stream`},"webr/000bd2c7d2f13441/vfs/usr/lib/R/library/stats/demo.data":{sha256:`c7b7e88d3cb1afaf4caa1010ed1e2a6e0dc568f87f3af18ebdd316ba4de60bb0`,bytes:10281,mediaType:`application/octet-stream`,deliveryPath:`webr/000bd2c7d2f13441/vfs/usr/lib/R/library/stats/demo.data.gz`},"webr/000bd2c7d2f13441/vfs/usr/lib/R/library/stats/demo.data.gz":{sha256:`761adcd4b49ca859057e1a96774308a5fd3b6f35e00d2dac6d17731ee91f5050`,bytes:4061,encoding:`gzip`,mediaType:`application/octet-stream`,uncompressedSha256:`c7b7e88d3cb1afaf4caa1010ed1e2a6e0dc568f87f3af18ebdd316ba4de60bb0`,uncompressedBytes:10281},"webr/000bd2c7d2f13441/vfs/usr/lib/R/library/stats/demo.js.metadata":{sha256:`7e537450a6855a02f5491cf22f48abed526bb1d4d2fd15d3e34725ab3667db5f`,bytes:241,mediaType:`application/octet-stream`},"webr/000bd2c7d2f13441/vfs/usr/lib/R/library/stats/doc.data":{sha256:`dbd0e8366e7f30856ff75dbbe6133b2d50ccc04e207880fc69a709c41f983316`,bytes:51903,mediaType:`application/octet-stream`,deliveryPath:`webr/000bd2c7d2f13441/vfs/usr/lib/R/library/stats/doc.data.gz`},"webr/000bd2c7d2f13441/vfs/usr/lib/R/library/stats/doc.data.gz":{sha256:`d24e1da1a4da7cf531f9d963a5fbfb42fab39270ef182283c23d88d666a607cf`,bytes:50057,encoding:`gzip`,mediaType:`application/octet-stream`,uncompressedSha256:`dbd0e8366e7f30856ff75dbbe6133b2d50ccc04e207880fc69a709c41f983316`,uncompressedBytes:51903},"webr/000bd2c7d2f13441/vfs/usr/lib/R/library/stats/doc.js.metadata":{sha256:`671b514c960e5f91023a8003a690918ae84ac97a4c3bc123f391e51b582c0c66`,bytes:102,mediaType:`application/octet-stream`},"webr/000bd2c7d2f13441/vfs/usr/lib/R/library/stats/help.data":{sha256:`bd76a351b702fc8ce244ee03957b854883fc12ea508651e75fe9eb870d585e19`,bytes:1868752,mediaType:`application/octet-stream`,deliveryPath:`webr/000bd2c7d2f13441/vfs/usr/lib/R/library/stats/help.data.gz`},"webr/000bd2c7d2f13441/vfs/usr/lib/R/library/stats/help.data.gz":{sha256:`8fa48d1e3803dd508e24bde959313a24fa91ebe73f779272c6aca31ed6134a33`,bytes:1843548,encoding:`gzip`,mediaType:`application/octet-stream`,uncompressedSha256:`bd76a351b702fc8ce244ee03957b854883fc12ea508651e75fe9eb870d585e19`,uncompressedBytes:1868752},"webr/000bd2c7d2f13441/vfs/usr/lib/R/library/stats/help.js.metadata":{sha256:`84619108c7ab023343c1e5e95d5979fccf426e43080c7fd90672f44ab3653ea0`,bytes:316,mediaType:`application/octet-stream`},"webr/000bd2c7d2f13441/vfs/usr/lib/R/library/stats/html.data":{sha256:`220e31954e30307a9814b762d6e40433b666f99b696571321bee3d58fda02706`,bytes:78207,mediaType:`application/octet-stream`,deliveryPath:`webr/000bd2c7d2f13441/vfs/usr/lib/R/library/stats/html.data.gz`},"webr/000bd2c7d2f13441/vfs/usr/lib/R/library/stats/html.data.gz":{sha256:`4e14ef0067001e22cb25167c7f51cf665ce89f16fe6d80c1c4121075bff5520a`,bytes:11358,encoding:`gzip`,mediaType:`application/octet-stream`,uncompressedSha256:`220e31954e30307a9814b762d6e40433b666f99b696571321bee3d58fda02706`,uncompressedBytes:78207},"webr/000bd2c7d2f13441/vfs/usr/lib/R/library/stats/html.js.metadata":{sha256:`9ea60d805483f4ebfb197957da1c7c360a00c92d4b33fcc7fda42f9ee626cd7d`,bytes:151,mediaType:`application/octet-stream`},"webr/000bd2c7d2f13441/vfs/usr/lib/R/library/stats4/help.data":{sha256:`e95dad0102a1d860ddb773d3497b3ad56668c4a9c1808073152a2cb7e5a412cc`,bytes:38896,mediaType:`application/octet-stream`,deliveryPath:`webr/000bd2c7d2f13441/vfs/usr/lib/R/library/stats4/help.data.gz`},"webr/000bd2c7d2f13441/vfs/usr/lib/R/library/stats4/help.data.gz":{sha256:`8a18b51cbfe3991f3f33be831bc7a7b2676f62c4a012bff73450afde182b159f`,bytes:37560,encoding:`gzip`,mediaType:`application/octet-stream`,uncompressedSha256:`e95dad0102a1d860ddb773d3497b3ad56668c4a9c1808073152a2cb7e5a412cc`,uncompressedBytes:38896},"webr/000bd2c7d2f13441/vfs/usr/lib/R/library/stats4/help.js.metadata":{sha256:`a03f6116d3f6703f88f9209864709946362e51cbf328c14d3c9c7e3d39a40d4e`,bytes:304,mediaType:`application/octet-stream`},"webr/000bd2c7d2f13441/vfs/usr/lib/R/library/stats4/html.data":{sha256:`9e7a47a4308033eeb76c21cc6b14477a1c698c5d99e97a5a0d262dfa752e18ec`,bytes:6650,mediaType:`application/octet-stream`,deliveryPath:`webr/000bd2c7d2f13441/vfs/usr/lib/R/library/stats4/html.data.gz`},"webr/000bd2c7d2f13441/vfs/usr/lib/R/library/stats4/html.data.gz":{sha256:`eab7a939a8d57c5792e98a13b94222d29b43f2fbc4e0b4d449e6fad96f401da5`,bytes:1522,encoding:`gzip`,mediaType:`application/octet-stream`,uncompressedSha256:`9e7a47a4308033eeb76c21cc6b14477a1c698c5d99e97a5a0d262dfa752e18ec`,uncompressedBytes:6650},"webr/000bd2c7d2f13441/vfs/usr/lib/R/library/stats4/html.js.metadata":{sha256:`c34ccf9f0de1ad19d6aea15b3f56e6f65c8967bd8c9a9e39461788daa5c1d15e`,bytes:147,mediaType:`application/octet-stream`},"webr/000bd2c7d2f13441/vfs/usr/lib/R/library/tcltk.data":{sha256:`ec610c365f66198c4ab11962c58d10be47a1183c6ec25681236d4beebafa66b1`,bytes:341942,mediaType:`application/octet-stream`,deliveryPath:`webr/000bd2c7d2f13441/vfs/usr/lib/R/library/tcltk.data.gz`},"webr/000bd2c7d2f13441/vfs/usr/lib/R/library/tcltk.data.gz":{sha256:`fd62d4cf44534ca784cbc0ab26e65eb1c6f882269709fced5a1ac459f8550026`,bytes:132160,encoding:`gzip`,mediaType:`application/octet-stream`,uncompressedSha256:`ec610c365f66198c4ab11962c58d10be47a1183c6ec25681236d4beebafa66b1`,uncompressedBytes:341942},"webr/000bd2c7d2f13441/vfs/usr/lib/R/library/tcltk.js.metadata":{sha256:`785dc003a43233094a6845f5804fa097fb680ccae0c0aad6fd0784e9582f0ab9`,bytes:2019,mediaType:`application/octet-stream`},"webr/000bd2c7d2f13441/vfs/usr/lib/R/library/tools/help.data":{sha256:`78a6c72183a879188468a27f63ddf68cf50ae7b4a27ff01838523fc3a2a7b1c4`,bytes:328529,mediaType:`application/octet-stream`,deliveryPath:`webr/000bd2c7d2f13441/vfs/usr/lib/R/library/tools/help.data.gz`},"webr/000bd2c7d2f13441/vfs/usr/lib/R/library/tools/help.data.gz":{sha256:`4ad0e607507c22a91860857865192a7b560270168f3be8c75d9394c5689364d8`,bytes:324132,encoding:`gzip`,mediaType:`application/octet-stream`,uncompressedSha256:`78a6c72183a879188468a27f63ddf68cf50ae7b4a27ff01838523fc3a2a7b1c4`,uncompressedBytes:328529},"webr/000bd2c7d2f13441/vfs/usr/lib/R/library/tools/help.js.metadata":{sha256:`761f3e2cd8ecc194410a039da7fa7565a68b17c8b271306e927c0f8b4d0eef27`,bytes:306,mediaType:`application/octet-stream`},"webr/000bd2c7d2f13441/vfs/usr/lib/R/library/tools/html.data":{sha256:`e99606eafc79a196a1c3797a65709a3be16ac9ccbf0be9f96f1d3c4d9fda7823`,bytes:25733,mediaType:`application/octet-stream`,deliveryPath:`webr/000bd2c7d2f13441/vfs/usr/lib/R/library/tools/html.data.gz`},"webr/000bd2c7d2f13441/vfs/usr/lib/R/library/tools/html.data.gz":{sha256:`13242d7e18ab7412609925428c651e07615146a78137e1bc7f117d1add62e47f`,bytes:4307,encoding:`gzip`,mediaType:`application/octet-stream`,uncompressedSha256:`e99606eafc79a196a1c3797a65709a3be16ac9ccbf0be9f96f1d3c4d9fda7823`,uncompressedBytes:25733},"webr/000bd2c7d2f13441/vfs/usr/lib/R/library/tools/html.js.metadata":{sha256:`d93471df33f8c83582f3c217fdaad9c0947996bc87c19e2261828e01bcb668c3`,bytes:151,mediaType:`application/octet-stream`},"webr/000bd2c7d2f13441/vfs/usr/lib/R/library/tools/misc.data":{sha256:`a6860a2a2c52668549f3752078f60ca722a3010594bdb7320e804d4d251d6b36`,bytes:14193,mediaType:`application/octet-stream`,deliveryPath:`webr/000bd2c7d2f13441/vfs/usr/lib/R/library/tools/misc.data.gz`},"webr/000bd2c7d2f13441/vfs/usr/lib/R/library/tools/misc.data.gz":{sha256:`7042f04844026fbc281f4789abf8ac5bf0751d1ce70bb602a8db8d60f2ac68cf`,bytes:3724,encoding:`gzip`,mediaType:`application/octet-stream`,uncompressedSha256:`a6860a2a2c52668549f3752078f60ca722a3010594bdb7320e804d4d251d6b36`,uncompressedBytes:14193},"webr/000bd2c7d2f13441/vfs/usr/lib/R/library/tools/misc.js.metadata":{sha256:`5c6bd36201d2f620052f3ba437224496ea98919a8a05dcee6b44aa99547eb5a6`,bytes:142,mediaType:`application/octet-stream`},"webr/000bd2c7d2f13441/vfs/usr/lib/R/library/translations.data":{sha256:`43b08d30caeaf5c6a4e0237bda5bb374f7232cbd3af4cf0ae7938d2444700d8d`,bytes:9314909,mediaType:`application/octet-stream`,deliveryPath:`webr/000bd2c7d2f13441/vfs/usr/lib/R/library/translations.data.gz`},"webr/000bd2c7d2f13441/vfs/usr/lib/R/library/translations.data.gz":{sha256:`c8cac5071b8691cb1c960389b370b5007c5b8df752d98a5860bce505c234b9c2`,bytes:3061528,encoding:`gzip`,mediaType:`application/octet-stream`,uncompressedSha256:`43b08d30caeaf5c6a4e0237bda5bb374f7232cbd3af4cf0ae7938d2444700d8d`,uncompressedBytes:9314909},"webr/000bd2c7d2f13441/vfs/usr/lib/R/library/translations.js.metadata":{sha256:`f62b1fa37f7cdff9aa0c9b7046366254411b7df6bb35d2017cbb531fd6ee3d4a`,bytes:35184,mediaType:`application/octet-stream`},"webr/000bd2c7d2f13441/vfs/usr/lib/R/library/translations/DESCRIPTION":{sha256:`ba7da3ac60466f5f466c4f706f50bcafbb924f94b0888d333bb410451b41afd2`,bytes:238,mediaType:`application/octet-stream`},"webr/000bd2c7d2f13441/vfs/usr/lib/R/library/utils/doc.data":{sha256:`08054e63f9720a6354f42731402b1dd6c3e47613d12c4416adfc53990970d68a`,bytes:228244,mediaType:`application/octet-stream`,deliveryPath:`webr/000bd2c7d2f13441/vfs/usr/lib/R/library/utils/doc.data.gz`},"webr/000bd2c7d2f13441/vfs/usr/lib/R/library/utils/doc.data.gz":{sha256:`4018e722537fa83c70d5f031d4aa391ed68dc00b63a9888aef565899c789caf9`,bytes:216941,encoding:`gzip`,mediaType:`application/octet-stream`,uncompressedSha256:`08054e63f9720a6354f42731402b1dd6c3e47613d12c4416adfc53990970d68a`,uncompressedBytes:228244},"webr/000bd2c7d2f13441/vfs/usr/lib/R/library/utils/doc.js.metadata":{sha256:`189fd98b3cda5d4a11c7da6780649ddecce9a5fd5b9d472a075f49909a6956c3`,bytes:103,mediaType:`application/octet-stream`},"webr/000bd2c7d2f13441/vfs/usr/lib/R/library/utils/help.data":{sha256:`070b604c116c6c28a163467547245da3baa57f5770fe76cd6171efc68fe5d326`,bytes:904746,mediaType:`application/octet-stream`,deliveryPath:`webr/000bd2c7d2f13441/vfs/usr/lib/R/library/utils/help.data.gz`},"webr/000bd2c7d2f13441/vfs/usr/lib/R/library/utils/help.data.gz":{sha256:`be06c8a1d69d4b0b82b09afc24ade14fe0afd68053c19f87af1f6d17d9842cbf`,bytes:894372,encoding:`gzip`,mediaType:`application/octet-stream`,uncompressedSha256:`070b604c116c6c28a163467547245da3baa57f5770fe76cd6171efc68fe5d326`,uncompressedBytes:904746},"webr/000bd2c7d2f13441/vfs/usr/lib/R/library/utils/help.js.metadata":{sha256:`7bbdaa8dd24135fa73ec05ef1120e94f50bca25fcef31244a3ba3d51dd0c4478`,bytes:310,mediaType:`application/octet-stream`},"webr/000bd2c7d2f13441/vfs/usr/lib/R/library/utils/html.data":{sha256:`389f3050a6536e4624dcc3207c21a2578c51aae85178049bb620a9755718cbe6`,bytes:45082,mediaType:`application/octet-stream`,deliveryPath:`webr/000bd2c7d2f13441/vfs/usr/lib/R/library/utils/html.data.gz`},"webr/000bd2c7d2f13441/vfs/usr/lib/R/library/utils/html.data.gz":{sha256:`33f6fe57dad92319af190f3ea06ee79104e850c86043cc45c11c7513de9cc066`,bytes:7240,encoding:`gzip`,mediaType:`application/octet-stream`,uncompressedSha256:`389f3050a6536e4624dcc3207c21a2578c51aae85178049bb620a9755718cbe6`,uncompressedBytes:45082},"webr/000bd2c7d2f13441/vfs/usr/lib/R/library/utils/html.js.metadata":{sha256:`9237b38d0bb9cd04c6f305f9b69b7d06b2dcaf982050e3d3e374e6cdfe0706a1`,bytes:151,mediaType:`application/octet-stream`},"webr/000bd2c7d2f13441/vfs/usr/lib/R/library/utils/misc.data":{sha256:`be079b9f18e6823c09ef4d560d5541541110acd4bff696662c2ec9f3e3ae4192`,bytes:280,mediaType:`application/octet-stream`,deliveryPath:`webr/000bd2c7d2f13441/vfs/usr/lib/R/library/utils/misc.data.gz`},"webr/000bd2c7d2f13441/vfs/usr/lib/R/library/utils/misc.data.gz":{sha256:`33ddc6d1a7b594c7d0824dc12aa15cfce859b66b9d7134c228ee349b48027b56`,bytes:161,encoding:`gzip`,mediaType:`application/octet-stream`,uncompressedSha256:`be079b9f18e6823c09ef4d560d5541541110acd4bff696662c2ec9f3e3ae4192`,uncompressedBytes:280},"webr/000bd2c7d2f13441/vfs/usr/lib/R/library/utils/misc.js.metadata":{sha256:`7e248a6c0ce276772fe22eb83d49128393be9e674e322ab0ce57905e83e6709b`,bytes:142,mediaType:`application/octet-stream`},"webr/000bd2c7d2f13441/vfs/usr/lib/R/library/webr/help.data":{sha256:`7366a3ad0388fcdd089f045e0d2632254b724b7b084397e21c9ae9eb9343c4c7`,bytes:58512,mediaType:`application/octet-stream`,deliveryPath:`webr/000bd2c7d2f13441/vfs/usr/lib/R/library/webr/help.data.gz`},"webr/000bd2c7d2f13441/vfs/usr/lib/R/library/webr/help.data.gz":{sha256:`13f814b4ca4b8ad4ae07f43a5e09ed90274233d8758a3c5ec0e6dac3ba56799c`,bytes:57381,encoding:`gzip`,mediaType:`application/octet-stream`,uncompressedSha256:`7366a3ad0388fcdd089f045e0d2632254b724b7b084397e21c9ae9eb9343c4c7`,uncompressedBytes:58512},"webr/000bd2c7d2f13441/vfs/usr/lib/R/library/webr/help.js.metadata":{sha256:`bbec147dbb13908d360940507e158e7507cda52f169f365821dcdc3414513794`,bytes:357,mediaType:`application/octet-stream`},"webr/000bd2c7d2f13441/vfs/usr/lib/R/library/webr/html.data":{sha256:`6810f190834307ec40f1412ca6a7794ccafce2b2f0c89cef24809492b5bd3ed9`,bytes:5748,mediaType:`application/octet-stream`,deliveryPath:`webr/000bd2c7d2f13441/vfs/usr/lib/R/library/webr/html.data.gz`},"webr/000bd2c7d2f13441/vfs/usr/lib/R/library/webr/html.data.gz":{sha256:`e16b557a8417ec2bfb11c3a03ab8b28638464217877ad6bdd26f45263a14cb79`,bytes:1696,encoding:`gzip`,mediaType:`application/octet-stream`,uncompressedSha256:`6810f190834307ec40f1412ca6a7794ccafce2b2f0c89cef24809492b5bd3ed9`,uncompressedBytes:5748},"webr/000bd2c7d2f13441/vfs/usr/lib/R/library/webr/html.js.metadata":{sha256:`820fc44428d2f719881725341ba13650436e989c53191e2d6da1f2493f7ea131`,bytes:147,mediaType:`application/octet-stream`},"webr/000bd2c7d2f13441/vfs/usr/lib/R/share.data":{sha256:`2126490556e21b2c21eb6c3abdd5821a1d43367ef65ed2978e4a742359a90d22`,bytes:1549357,mediaType:`application/octet-stream`,deliveryPath:`webr/000bd2c7d2f13441/vfs/usr/lib/R/share.data.gz`},"webr/000bd2c7d2f13441/vfs/usr/lib/R/share.data.gz":{sha256:`79258e504395be06aefa3d9ed482bcd9c26efb27791a243f851ead183ac28d41`,bytes:380353,encoding:`gzip`,mediaType:`application/octet-stream`,uncompressedSha256:`2126490556e21b2c21eb6c3abdd5821a1d43367ef65ed2978e4a742359a90d22`,uncompressedBytes:1549357},"webr/000bd2c7d2f13441/vfs/usr/lib/R/share.js.metadata":{sha256:`3ccaab3b787ae8e377bb56fad19764772e6f1ddf90d47f10fbaef58921c7e9e2`,bytes:46073,mediaType:`application/octet-stream`},"webr/000bd2c7d2f13441/vfs/usr/share/fonts/NotoSans-Bold.ttf":{sha256:`87cb2d84472a7d66da659ee47b6cdb9552326e8c128245231f191b6ac72529d9`,bytes:432376,mediaType:`application/octet-stream`},"webr/000bd2c7d2f13441/vfs/usr/share/fonts/NotoSans-BoldItalic.ttf":{sha256:`3d367743f371f28671d2764e911a53d7c20ec9b6aa8791d059e7090389fc52a5`,bytes:441936,mediaType:`application/octet-stream`},"webr/000bd2c7d2f13441/vfs/usr/share/fonts/NotoSans-Italic.ttf":{sha256:`678288f868807d4d64a6f3b51466871d117d915780381ce9d0ed4b3bcbd06d37`,bytes:446880,mediaType:`application/octet-stream`},"webr/000bd2c7d2f13441/vfs/usr/share/fonts/NotoSans-Regular.ttf":{sha256:`f3961a9cde016d41a4879aecda1474d3a36d6bf54fa0e4643de029cc2248b0e8`,bytes:431364,mediaType:`application/octet-stream`},"webr/000bd2c7d2f13441/vfs/usr/share/fonts/NotoSansMono-Bold.ttf":{sha256:`1100772b2f79c102402a1011df5e2226517d0f40ac553a25fb12fdbad8c11b85`,bytes:387484,mediaType:`application/octet-stream`},"webr/000bd2c7d2f13441/vfs/usr/share/fonts/NotoSansMono-Regular.ttf":{sha256:`87f8ce0522a6c99b743ee5fc75b4073cfdd575639119672828b7b9944b65b4f4`,bytes:388660,mediaType:`application/octet-stream`},"webr/000bd2c7d2f13441/vfs/usr/share/fonts/NotoSerif-Bold.ttf":{sha256:`24ad531e6b05ddad8c3d89572d2c93eb86a6b74e652ce7ee3c3e171de68e84c3`,bytes:481892,mediaType:`application/octet-stream`},"webr/000bd2c7d2f13441/vfs/usr/share/fonts/NotoSerif-BoldItalic.ttf":{sha256:`1bc4f86502eaa368718f6192bee022ea9a703d5af1c18b7d291212657b63074a`,bytes:513280,mediaType:`application/octet-stream`},"webr/000bd2c7d2f13441/vfs/usr/share/fonts/NotoSerif-Italic.ttf":{sha256:`c4b3c971741ecdb40f5a443bce754e8fe91efe761b6ea10c92be7c3597cdadc4`,bytes:513428,mediaType:`application/octet-stream`},"webr/000bd2c7d2f13441/vfs/usr/share/fonts/NotoSerif-Regular.ttf":{sha256:`a15cfbbc1539d707115111d672d590a3d70d4f74b4c0a315956da20ae19a14e1`,bytes:482540,mediaType:`application/octet-stream`},"webr/000bd2c7d2f13441/vfs/usr/share/gdal.data":{sha256:`b9a70a27cce3d423546684a56b9e625262f6d339e192a978fcb732075e7d3aa3`,bytes:2749858,mediaType:`application/octet-stream`,deliveryPath:`webr/000bd2c7d2f13441/vfs/usr/share/gdal.data.gz`},"webr/000bd2c7d2f13441/vfs/usr/share/gdal.data.gz":{sha256:`8adcaf12f15dabb964cb3363defa02bdc9e730a17b10460946944885bcf699af`,bytes:348461,encoding:`gzip`,mediaType:`application/octet-stream`,uncompressedSha256:`b9a70a27cce3d423546684a56b9e625262f6d339e192a978fcb732075e7d3aa3`,uncompressedBytes:2749858},"webr/000bd2c7d2f13441/vfs/usr/share/gdal.js.metadata":{sha256:`de403ded38013ab57931a862d14bcdc33b09997c70de1587ec6719f94360ab25`,bytes:10206,mediaType:`application/octet-stream`},"webr/000bd2c7d2f13441/vfs/usr/share/proj.data":{sha256:`8559d094cb4de20c5029a47e2354a409c00cca088ec0968aae53d83be6740358`,bytes:8627619,mediaType:`application/octet-stream`,deliveryPath:`webr/000bd2c7d2f13441/vfs/usr/share/proj.data.gz`},"webr/000bd2c7d2f13441/vfs/usr/share/proj.data.gz":{sha256:`14e3893991c408324d43605abbe6c4cae18607fe27655e78654bec4565799e13`,bytes:1705325,encoding:`gzip`,mediaType:`application/octet-stream`,uncompressedSha256:`8559d094cb4de20c5029a47e2354a409c00cca088ec0968aae53d83be6740358`,uncompressedBytes:8627619},"webr/000bd2c7d2f13441/vfs/usr/share/proj.js.metadata":{sha256:`adc4c33a8c963b5059402a2132c59811016cc9c48286b6bd43e68b347a5f4c0c`,bytes:857,mediaType:`application/octet-stream`},"webr/000bd2c7d2f13441/vfs/usr/share/udunits.data":{sha256:`abd70ce7e01f6d58c13bcaf61eeae89b9ee5890e2684cbcaa3859eb97692e52f`,bytes:111579,mediaType:`application/octet-stream`,deliveryPath:`webr/000bd2c7d2f13441/vfs/usr/share/udunits.data.gz`},"webr/000bd2c7d2f13441/vfs/usr/share/udunits.data.gz":{sha256:`fc1de0c9cb5c827fef22ed148ffc28eab70a99d3cc9aa9990e37aaf38e5c1757`,bytes:16775,encoding:`gzip`,mediaType:`application/octet-stream`,uncompressedSha256:`abd70ce7e01f6d58c13bcaf61eeae89b9ee5890e2684cbcaa3859eb97692e52f`,uncompressedBytes:111579},"webr/000bd2c7d2f13441/vfs/usr/share/udunits.js.metadata":{sha256:`9f8ac349f1d68c23e4d2a4790e328ab3ecc38cd84ef993592170b7d19ef1b6a6`,bytes:424,mediaType:`application/octet-stream`},"webr/000bd2c7d2f13441/vfs/var/cache/fontconfig/3830d5c3ddfd5cd38a049b759396e72e-le32d8.cache-9":{sha256:`48cd35d8c3d7a4456f05bbf3c10bac83de082d354b2ec02c8a80e325ac3f0839`,bytes:16008,mediaType:`application/octet-stream`},"webr/000bd2c7d2f13441/vfs/var/cache/fontconfig/CACHEDIR.TAG":{sha256:`05e7633fb31bf1f6f8d89020c16b9f24587fdf7638e951c9745b192f5fc3b682`,bytes:200,mediaType:`application/octet-stream`},"webr/000bd2c7d2f13441/webr-worker.js":{sha256:`c64282f5e15b51ef473e26548203313f868208c8988b2c7bdfc22c5730de418b`,bytes:134029,mediaType:`text/javascript`},"webr/000bd2c7d2f13441/webr.js":{sha256:`4c04d3240de6cd3e7f59e081756168faa8566f8a8b97251400770939815c344a`,bytes:66672,mediaType:`text/javascript`}}};for(let e of Object.values(he.assets))e.layer&&Object.freeze(e.layer),Object.freeze(e);Object.freeze(he.assets),Object.freeze(he);const ge=67108864;function _e(e){let t=Object.freeze(xe(e)),n=async e=>{if(!(!t.enabled||typeof e!=`string`||!e||e.length>65536))try{let n=await crypto.subtle.digest(`SHA-256`,new TextEncoder().encode(e)),r=Array.from(new Uint8Array(n),e=>e.toString(16).padStart(2,`0`)).join(``);return{url:`https://wasm-idle.invalid/.generated-assets/${t.namespace}/${r}`,validationKey:`generated-v1:${r}`}}catch{return}},r=(e,t)=>e.references.some(e=>e.url===t.url&&e.validationKey===t.validationKey);return Object.freeze({async read(e,i){N(i);let a=await n(e);if(a)return De(t,i,async(e,n)=>{let o=(await Ae(n)).find(e=>r(e,a));if(!o||o.bytes>Math.min(t.maxEntryBytes,t.maxBytes,ge))return;let s=await e.match(we(t,o.sha256));try{if(!s)throw Error(`Generated artifact body is missing`);let e=await Ne(s,o.bytes);await me({asset:a.url,bytes:e,expected:o}),N(i);try{o.lastUsed=Date.now(),await P(n,`readwrite`,e=>e.put(o))}catch{}return e}catch{N(i),await je(e,n,t,o);return}})},async write(e,i,a){if(N(a),!Te(t)||!i.byteLength||i.byteLength>Math.min(t.maxBytes,t.maxEntryBytes,ge))return!1;let o=await n(e);if(!o)return!1;let s=Uint8Array.from(i),c;try{c=Array.from(new Uint8Array(await crypto.subtle.digest(`SHA-256`,s)),e=>e.toString(16).padStart(2,`0`)).join(``)}catch{return!1}return await De(t,a,async(e,n)=>{let i=await Ae(n),l=new Set(i.map(e=>we(t,e.sha256)));for(let t of await e.keys())l.has(t.url)||await e.delete(t);for(let a of i)a.sha256!==c&&r(a,o)&&(a.references=a.references.filter(e=>e.url!==o.url||e.validationKey!==o.validationKey),a.references.length?await P(n,`readwrite`,e=>e.put(a)):await je(e,n,t,a));i=await Ae(n);let u=i.find(e=>e.sha256===c),d=u??{sha256:c,bytes:s.byteLength,lastUsed:0,references:[]};if(d.bytes!==s.byteLength||(Oe(d,{...o,sha256:c,bytes:s.byteLength},t),!await Fe(e,n,t,i,u?0:s.byteLength,+!u,c)))return!1;N(a),await e.put(we(t,c),new Response(s,{headers:{"Content-Type":`application/octet-stream`,"Content-Length":String(s.byteLength)}}));try{await P(n,`readwrite`,e=>e.put(d))}catch(n){throw u||await e.delete(we(t,c)),n}return!0})??!1},async remove(e,i){let a=await n(e);a&&await De(t,i,async(e,n)=>{for(let i of await Ae(n))r(i,a)&&(i.references=i.references.filter(e=>e.url!==a.url||e.validationKey!==a.validationKey),i.references.length?await P(n,`readwrite`,e=>e.put(i)):await je(e,n,t,i))})}})}const ve=Object.freeze({enabled:!0,maxBytes:536870912,maxEntryBytes:536870912,maxEntries:4096,storageReserveBytes:67108864,eviction:`lru`,namespace:`wasm-idle`,version:`1.0.11`}),ye=3e3;let be={};function xe(...e){return Se([be,...e])}function Se(e){let t={...ve};for(let n of e)if(n===!1)t.enabled=!1;else if(n)for(let[e,r]of Object.entries(n))r!==void 0&&Object.hasOwn(ve,e)&&(t[e]=r);for(let e of[`maxBytes`,`maxEntryBytes`,`maxEntries`,`storageReserveBytes`])if(!Number.isSafeInteger(t[e])||t[e]<0)throw TypeError(`Invalid asset cache ${e}`);if(typeof t.enabled!=`boolean`||![`lru`,`none`].includes(t.eviction))throw TypeError(`Invalid asset cache policy`);if(typeof t.namespace!=`string`||!/^[a-zA-Z0-9._-]{1,100}$/u.test(t.namespace))throw TypeError(`Invalid asset cache namespace`);if(typeof t.version!=`string`||!t.version||t.version.length>256)throw TypeError(`Invalid asset cache version`);return t}function N(e){if(e?.aborted)throw e.reason===void 0?new DOMException(`Aborted`,`AbortError`):e.reason}function Ce(e){return`wasm-idle-assets-v1:${e.namespace}`}function we(e,t){return`https://wasm-idle.invalid/.runtime-assets/${e.namespace}/${t}`}function Te(e){try{return e.enabled&&e.maxBytes>0&&e.maxEntryBytes>0&&e.maxEntries>0&&globalThis.caches!==void 0&&globalThis.indexedDB!==void 0&&typeof globalThis.navigator?.locks?.request==`function`}catch{return!1}}function Ee(e){return new Promise((t,n)=>{let r=!1,i=indexedDB.open(e,1),a=setTimeout(()=>{r=!0,n(/* @__PURE__ */ Error(`Asset cache database open timed out`))},ye);i.onupgradeneeded=()=>i.result.createObjectStore(`assets`,{keyPath:`sha256`}),i.onsuccess=()=>{clearTimeout(a),r?i.result.close():(r=!0,t(i.result))},i.onerror=()=>{clearTimeout(a),r=!0,n(i.error)}})}function P(e,t,n){return new Promise((r,i)=>{let a=e.transaction(`assets`,t),o=setTimeout(()=>{try{a.abort()}catch{}},ye),s;try{s=n(a.objectStore(`assets`))}catch(e){clearTimeout(o);try{a.abort()}catch{}i(e);return}a.oncomplete=()=>{clearTimeout(o),r(s.result)},a.onabort=a.onerror=()=>{clearTimeout(o),i(a.error??/* @__PURE__ */ Error(`Asset cache database transaction failed`))}})}async function De(e,t,n){if(N(t),!Te(e))return;let r=new AbortController,i=()=>r.abort(t?.reason);t?.addEventListener(`abort`,i,{once:!0});let a=setTimeout(()=>r.abort(),ye);try{return await navigator.locks.request(Ce(e),{signal:r.signal},async()=>{clearTimeout(a),N(t);let r=await Ee(Ce(e));try{let i=await caches.open(Ce(e));N(t);let a=await n(i,r);return N(t),a}finally{r.close()}})}catch{N(t);return}finally{clearTimeout(a),t?.removeEventListener(`abort`,i)}}function Oe(e,t,n){let r=t.version??n.version;if(!e.references.some(e=>e.version===r&&e.url===t.url&&e.validationKey===t.validationKey)){if(e.references.length>=4096)throw Error(`Asset cache reference limit reached`);e.references.push({version:r,url:t.url,validationKey:t.validationKey})}e.lastUsed=Date.now()}function ke(e){return!!e&&/^[a-f0-9]{64}$/u.test(e.sha256)&&Number.isSafeInteger(e.bytes)&&e.bytes>=0&&Number.isFinite(e.lastUsed)&&Array.isArray(e.references)&&e.references.length<=4096&&e.references.every(e=>typeof e?.version==`string`&&typeof e.url==`string`&&(e.validationKey===void 0||typeof e.validationKey==`string`))}async function Ae(e){let t=await P(e,`readonly`,e=>e.getAll());if(!t.every(ke))throw Error(`Invalid asset cache metadata`);return t}async function je(e,t,n,r){await e.delete(we(n,r.sha256)),await P(t,`readwrite`,e=>e.delete(r.sha256))}async function Me(){try{return await navigator.storage?.estimate?.()}catch{return}}async function Ne(e,t){let n=e.body?.getReader();if(!n)return/* @__PURE__ */ new Uint8Array;let r=[],i=0;try{for(;;){let{done:e,value:a}=await n.read();if(e)break;if(i+=a.byteLength,i>t)throw Error(`Cached asset exceeds expected size`);r.push(a)}}catch(e){throw await n.cancel().catch(()=>{}),e}finally{n.releaseLock()}let a=new Uint8Array(i),o=0;for(let e of r)a.set(e,o),o+=e.byteLength;return a}async function Pe(e,t){let n=await Me();return typeof n?.quota!=`number`||typeof n.usage!=`number`||!Number.isFinite(n.quota)||!Number.isFinite(n.usage)?e.maxBytes:Math.max(0,Math.min(e.maxBytes,n.quota-n.usage+t-e.storageReserveBytes))}async function Fe(e,t,n,r,i,a,o){let s=r.reduce((e,t)=>e+t.bytes,0),c=r.length,l=await Pe(n,s);if(i>l||a>n.maxEntries)return!1;let u=()=>s+i<=l&&c+a<=n.maxEntries;if(u())return!0;if(n.eviction===`none`)return!1;for(let i of[...r].sort((e,t)=>e.lastUsed-t.lastUsed||e.sha256.localeCompare(t.sha256)))if(i.sha256!==o&&(await je(e,t,n,i),s-=i.bytes,c--,u()))return!0;return u()}function Ie(e){if(e.schemaVersion!==1)throw TypeError(`Unsupported runtime trust profile schema: ${String(e.schemaVersion)}`);if(!/^[a-z0-9](?:[a-z0-9._-]*[a-z0-9])?$/u.test(e.profileId))throw TypeError(`Runtime trust profile ID must be a non-empty stable identifier`);if(![`none`,`allowlist`,`unrestricted`].includes(e.network.mode))throw TypeError(`Unsupported runtime network mode: ${String(e.network.mode)}`);let t=e.network.allowedOrigins.map(e=>{let t;try{t=new URL(e)}catch{throw TypeError(`Runtime network allowlist contains an invalid origin: ${e}`)}if(t.protocol!==`https:`&&t.protocol!==`http:`||t.pathname!==`/`||t.search||t.hash||t.username||t.password)throw TypeError(`Runtime network allowlist requires HTTP(S) origins: ${e}`);return t.origin}),n=[...new Set(t)].sort();if(e.network.mode===`allowlist`&&n.length===0)throw TypeError(`Runtime network allowlist mode requires at least one origin`);if(e.network.mode!==`allowlist`&&n.length>0)throw TypeError(`Runtime network mode ${e.network.mode} cannot declare allowed origins`);if(![`none`,`ephemeral`,`persistent`].includes(e.storage.mode))throw TypeError(`Unsupported runtime storage mode: ${String(e.storage.mode)}`);if(![`none`,`allowlist`].includes(e.environment.mode))throw TypeError(`Unsupported runtime environment mode: ${String(e.environment.mode)}`);for(let t of e.environment.allowedNames)if(!/^[A-Za-z_][A-Za-z0-9_]*$/u.test(t))throw TypeError(`Runtime environment allowlist contains an invalid name: ${t}`);let r=[...new Set(e.environment.allowedNames)].sort();if(e.environment.mode===`allowlist`&&r.length===0)throw TypeError(`Runtime environment allowlist mode requires at least one name`);if(e.environment.mode===`none`&&r.length>0)throw TypeError(`Runtime environment mode none cannot declare allowed names`);if(!Number.isSafeInteger(e.threads.maxThreads)||e.threads.maxThreads<0)throw TypeError(`Runtime maxThreads must be a non-negative safe integer`);if(!Number.isSafeInteger(e.workers.maxNestedWorkers)||e.workers.maxNestedWorkers<0)throw TypeError(`Runtime maxNestedWorkers must be a non-negative safe integer`);if(typeof e.sharedArrayBuffer!=`boolean`)throw TypeError(`Runtime sharedArrayBuffer capability must be boolean`);if(!e.sharedArrayBuffer&&e.threads.maxThreads>0)throw TypeError(`Runtime threads require SharedArrayBuffer capability`);if(![`none`,`wasm-only`,`javascript-and-wasm`].includes(e.dynamicCode))throw TypeError(`Unsupported runtime dynamic-code mode: ${String(e.dynamicCode)}`);if(typeof e.sameOriginAccess!=`boolean`)throw TypeError(`Runtime sameOriginAccess capability must be boolean`);return Object.freeze({schemaVersion:1,profileId:e.profileId,network:Object.freeze({mode:e.network.mode,allowedOrigins:Object.freeze(n)}),storage:Object.freeze({mode:e.storage.mode}),environment:Object.freeze({mode:e.environment.mode,allowedNames:Object.freeze(r)}),threads:Object.freeze({maxThreads:e.threads.maxThreads}),workers:Object.freeze({maxNestedWorkers:e.workers.maxNestedWorkers}),sharedArrayBuffer:e.sharedArrayBuffer,dynamicCode:e.dynamicCode,sameOriginAccess:e.sameOriginAccess})}Ie({schemaVersion:1,profileId:`restricted-browser-worker-v1`,network:{mode:`none`,allowedOrigins:[]},storage:{mode:`ephemeral`},environment:{mode:`none`,allowedNames:[]},threads:{maxThreads:0},workers:{maxNestedWorkers:0},sharedArrayBuffer:!1,dynamicCode:`wasm-only`,sameOriginAccess:!1}),5*BigInt64Array.BYTES_PER_ELEMENT,BigInt(2**53-1),typeof SharedArrayBuffer==`function`&&Object.getOwnPropertyDescriptor(SharedArrayBuffer.prototype,`byteLength`)?.get;const Le=Object.freeze(/* @__PURE__ */ `C.C3.CPP.OBJC.OBJECTIVECXX.PYTHON3.JAVA.RUST.GO.D.CSHARP.FSHARP.VBNET.ELIXIR.ERLANG.PROLOG.GLEAM.GRAIN.PERL.TCL.AWK.PASCAL.FORTH.J.BQN.JANET.JULIA.NIM.BASH.CLOJURESCRIPT.RESCRIPT.HY.FORTRAN.LFORTRAN.LEAN4.COBOL.V.TINYGO.OCAML.JAVASCRIPT.TYPESCRIPT.ASSEMBLYSCRIPT.WAT.WASM.WHITESPACE.MALBOLGE.AHEUI.UHMLANG.LOLCODE.APECODE.GOLFSCRIPT.BRAINFUCK.BEFUNGE93.LUA.FENNEL.ZIG.LISP.COMMONLISP.RUBY.HASKELL.R.OCTAVE.DUCKDB.SQLITE.POSTGRESQL.PHP`.split(`.`)),Re=/* @__PURE__ */ new Set([`C`,`CPP`,`PYTHON3`,`JAVA`]);new Set(Le.filter(e=>!Re.has(e)));const ze={BEFUNGE:{canonicalId:`BEFUNGE93`,kind:`dialect`},"BEFUNGE-93":{canonicalId:`BEFUNGE93`,kind:`spelling`},BF:{canonicalId:`BRAINFUCK`,kind:`spelling`},"C#":{canonicalId:`CSHARP`,kind:`spelling`},"F#":{canonicalId:`FSHARP`,kind:`spelling`},VB:{canonicalId:`VBNET`,kind:`spelling`},VISUALBASIC:{canonicalId:`VBNET`,kind:`spelling`},OBJECTIVEC:{canonicalId:`OBJC`,kind:`spelling`},OBJECTIVE_C:{canonicalId:`OBJC`,kind:`spelling`},"OBJECTIVE-C":{canonicalId:`OBJC`,kind:`spelling`},OBJCXX:{canonicalId:`OBJECTIVECXX`,kind:`spelling`},OBJCPP:{canonicalId:`OBJECTIVECXX`,kind:`spelling`},OBJECTIVE_CXX:{canonicalId:`OBJECTIVECXX`,kind:`spelling`},"OBJECTIVE-C++":{canonicalId:`OBJECTIVECXX`,kind:`spelling`},ERL:{canonicalId:`ERLANG`,kind:`spelling`},LEAN:{canonicalId:`LEAN4`,kind:`spelling`},SWIPL:{canonicalId:`PROLOG`,kind:`implementation`},SWI:{canonicalId:`PROLOG`,kind:`implementation`},TCLSH:{canonicalId:`TCL`,kind:`implementation`},GAWK:{canonicalId:`AWK`,kind:`implementation`},PAS:{canonicalId:`PASCAL`,kind:`spelling`},FPC:{canonicalId:`PASCAL`,kind:`implementation`},GFORTH:{canonicalId:`FORTH`,kind:`implementation`},JL:{canonicalId:`JULIA`,kind:`spelling`},NIMROD:{canonicalId:`NIM`,kind:`spelling`},SH:{canonicalId:`BASH`,kind:`compatibility`},SHELL:{canonicalId:`BASH`,kind:`compatibility`},CLJS:{canonicalId:`CLOJURESCRIPT`,kind:`spelling`},RES:{canonicalId:`RESCRIPT`,kind:`spelling`},HYLANG:{canonicalId:`HY`,kind:`spelling`},F77:{canonicalId:`FORTRAN`,kind:`dialect`},COB:{canonicalId:`COBOL`,kind:`spelling`},CBL:{canonicalId:`COBOL`,kind:`spelling`},GNUCOBOL:{canonicalId:`COBOL`,kind:`implementation`},VLANG:{canonicalId:`V`,kind:`spelling`},DLANG:{canonicalId:`D`,kind:`spelling`},JS:{canonicalId:`JAVASCRIPT`,kind:`spelling`},AS:{canonicalId:`ASSEMBLYSCRIPT`,kind:`spelling`},PYTHON:{canonicalId:`PYTHON3`,kind:`spelling`},PYPY3:{canonicalId:`PYTHON3`,kind:`implementation`,deprecated:!0,message:`PYPY3 runs the Pyodide implementation; use PYTHON3 instead.`},FNL:{canonicalId:`FENNEL`,kind:`spelling`},HS:{canonicalId:`HASKELL`,kind:`spelling`},RB:{canonicalId:`RUBY`,kind:`spelling`},SCHEME:{canonicalId:`LISP`,kind:`compatibility`,message:`SCHEME selects the bundled Puppy Scheme-compatible runtime.`},SCM:{canonicalId:`LISP`,kind:`compatibility`,message:`SCM selects the bundled Puppy Scheme-compatible runtime.`},CL:{canonicalId:`COMMONLISP`,kind:`spelling`},COMMON_LISP:{canonicalId:`COMMONLISP`,kind:`spelling`},"COMMON-LISP":{canonicalId:`COMMONLISP`,kind:`spelling`},ECL:{canonicalId:`COMMONLISP`,kind:`implementation`},TS:{canonicalId:`TYPESCRIPT`,kind:`spelling`},MATLAB:{canonicalId:`OCTAVE`,kind:`compatibility`,message:`MATLAB selects GNU Octave compatibility, not MATLAB.`},SQL:{canonicalId:`SQLITE`,kind:`dialect`,message:`SQL selects the SQLite dialect and engine.`},POSTGRES:{canonicalId:`POSTGRESQL`,kind:`spelling`},PGSQL:{canonicalId:`POSTGRESQL`,kind:`spelling`},PGLITE:{canonicalId:`POSTGRESQL`,kind:`implementation`,message:`PGLITE selects PostgreSQL running through the PGlite WebAssembly build.`},WASM32:{canonicalId:`WASM`,kind:`spelling`}};Object.freeze(Object.keys(ze)),Object.freeze(Object.fromEntries(Object.entries(ze).map(([e,t])=>[e,Object.freeze({alias:e,deprecated:!1,...t})]))),Object.freeze({maxFiles:256,maxFileBytes:2097152,maxTotalBytes:8388608,maxPathBytes:1024,caseSensitive:!1}),new TextEncoder,Object.freeze({assetTimeoutMs:6e4,startupTimeoutMs:6e4,compileTimeoutMs:12e4,runTimeoutMs:3e4,maxOutputBytes:1048576,maxDiagnostics:1e3,maxWorkspaceBytes:8388608,maxAssetBytes:134217728,maxWasmMemoryBytes:536870912,maxWorkers:1,maxThreads:1}),Object.freeze({stdin:`streaming`,workspace:!1,abort:!0,artifacts:!1,streamingOutput:!0}),new TextEncoder,new TextDecoder(`utf-8`,{fatal:!0}),Object.getOwnPropertyDescriptor(Object.getPrototypeOf(Uint8Array.prototype),Symbol.toStringTag)?.get,Object.getOwnPropertyDescriptor(ArrayBuffer.prototype,`byteLength`)?.get;const Be=Object.freeze({profileId:`ruby-3.4.1-ruby-wasm-2.10.1`,artifactRevision:`c7151435f55e1f078ca823231593f56e6a855873`,rubyVersion:`3.4.1`,rubyRevision:`48d4efcb85000e1ebae42004e963b5d0cedddcf2`,rubyWasmVersion:`2.10.1`,rubyWasmRevision:`c7151435f55e1f078ca823231593f56e6a855873`,wasiSdkVersion:`22.0`,manifestFingerprint:`45146a821c16192efe93ed2b16ce30e73716fc83d2e437d2fdb9dd6dac78b37b`,manifestReceipt:Object.freeze({bytes:7782,sha256:`4e5f21e2835571078893032f47775460e74722994d906c2983f0621864b6a5e0`}),moduleJavaScriptReceipt:Object.freeze({bytes:54866,sha256:`d1d33ccf090d3e99d8e3fd54a4e18c258d468e101711d0aee360e51dc2e26fd9`}),wasmReceipt:Object.freeze({bytes:9058728,sha256:`7fd753e801bf2cc58111149d8c77539b941480e848274b51a39c4dcef2d2bb13`,uncompressedBytes:30635497,uncompressedSha256:`4b814fc9d13505ea5b4c1f3bd3a7cc7ccca137f551196b9b21f0a7caf9cc5878`})});Object.freeze({profile:Be});const Ve=`assets/ruby_stdlib-D8-A_OuU.wasm`;Be.manifestFingerprint,Object.freeze({"runtime.mjs":Be.moduleJavaScriptReceipt,[Ve]:Object.freeze({bytes:Be.wasmReceipt.uncompressedBytes,sha256:Be.wasmReceipt.uncompressedSha256})});const He=Ve,Ue=`${He}.gz.bin`;Object.freeze([Object.freeze({name:`@bjorn3/browser_wasi_shim`,version:`0.4.2`,requestedRange:`^0.4.2`,tarballUrl:`https://registry.npmjs.org/@bjorn3/browser_wasi_shim/-/browser_wasi_shim-0.4.2.tgz`,tarballBytes:31373,tarballSha256:`9c0281520d0e99f027ec7c1c79b4036c0f8168ed9bf98aba19db4737a1333782`,integrity:`sha512-/iHkCVUG3VbcbmEHn5iIUpIrh7a7WPiwZ3sHy4HZKZzBdSadwdddYDZAII2zBvQYV0Lfi8naZngPCN7WPHI/hA==`,attestationUrl:null,repository:`https://github.com/bjorn3/browser_wasi_shim`,revision:`4a55f2a519d0ddfa7e4609c42e0c9769c37c9ae8`,license:`MIT OR Apache-2.0`,files:26,bytes:114555,treeSha256:`4454a5e0d68941440b947fdb705f8aa8fca789c5a3d040902bfe2cda8ffde248`}),Object.freeze({name:`@ruby/3.4-wasm-wasi`,version:`2.10.1`,requestedRange:`2.10.1`,tarballUrl:`https://registry.npmjs.org/@ruby/3.4-wasm-wasi/-/3.4-wasm-wasi-2.10.1.tgz`,tarballBytes:29979485,tarballSha256:`2e709bd9eddefe1c5d63e9fc0391a35cce4754e936d8a2f24b8582f6d5c2ea88`,integrity:`sha512-qrzIJ/7TGSpsZpFyLJb9OXO6TYAq18XoLd11We17Sr78hWpb5IGGFgMQ9A2Y8Ww5n0k8uKA/I8/P8MJdzlJX0Q==`,attestationUrl:`https://registry.npmjs.org/-/npm/v1/attestations/@ruby%2f3.4-wasm-wasi@2.10.1`,repository:`https://github.com/ruby/ruby.wasm`,revision:`c7151435f55e1f078ca823231593f56e6a855873`,license:`MIT`,files:20,bytes:97240399,treeSha256:`3f1fe2083438ed312b2ea2890036b4fd2ab603568f4ff8ccb94b20dfd4c53a80`}),Object.freeze({name:`@ruby/wasm-wasi`,version:`2.10.1`,requestedRange:`2.10.1`,tarballUrl:`https://registry.npmjs.org/@ruby/wasm-wasi/-/wasm-wasi-2.10.1.tgz`,tarballBytes:86655,tarballSha256:`1a4f58a452688b3d53d291539d35ea780cf10a40657694501b7169959512b265`,integrity:`sha512-OGSxxDraRq8alWQsWqDJQsaAavQwhwIVRkDozpPucjD1tUofMF6n99Y8Ia1bpDhOAXCwiNIHqhumfqFw0H0DZw==`,attestationUrl:`https://registry.npmjs.org/-/npm/v1/attestations/@ruby%2fwasm-wasi@2.10.1`,repository:`https://github.com/ruby/ruby.wasm`,revision:`c7151435f55e1f078ca823231593f56e6a855873`,license:`MIT`,files:50,bytes:481676,treeSha256:`a179307cb70dd75fd83fb017c9b05d66ad28e6281909d1f124de30e8371eb01d`})]),Object.freeze({entry:Object.freeze({path:`scripts/runtime-modules/ruby.ts`,bytes:257,sha256:`501625656ed69b9876ddd6320e08f45bf8e0c236d791ba04458c64f3864d9812`}),script:Object.freeze({path:`scripts/sync-wasm-ruby.mjs`,bytes:46815,sha256:`d2c7defde8ad5c9c813edcba9f37fe4f3fd2ebb4c5b7ecf1bf81a41936036bc9`}),tool:Object.freeze({name:`vite`,version:`8.3.3`,requestedRange:`^8.3.3`,tarballUrl:`https://registry.npmjs.org/vite/-/vite-8.3.3.tgz`,integrity:`sha512-cTAldKPImjg6c+gk48U19POPn3GCBzZwpdsN8ZMEEcbpes+6/wvfqUd0C2y3qYY4wsj8PwgFwrZ/1jBPVttMSg==`,license:`MIT`,files:37,bytes:2374102,treeSha256:`a050948cad1f02d83465c98f4954ab3fbcbe4c67d0eafae60e70e7f79ff4eb09`}),packageTreeReceiptFormat:`sha256-json-sorted-path-bytes-sha256-v2-excludes-package-manager-bin`}),Object.freeze([Object.freeze({id:`vite-8-es2022-single-module-bundle`,input:`scripts/runtime-modules/ruby.ts`,output:`runtime.mjs`}),Object.freeze({id:`node-zlib-gzip-level-9`,input:He,output:Ue})]),Object.freeze([Object.freeze({targetPath:`LICENSE`,mediaType:`text/plain`,spdx:`MIT`,size:1067,sha256:`90357d3794c968704914d42a52354a83f2d8b10cb43df3b63ef1ca0e5bbc0bf2`}),Object.freeze({targetPath:`NOTICE`,mediaType:`text/markdown`,spdx:`LicenseRef-Ruby-Wasm-Third-Party-Notices`,size:51134,sha256:`343c246a6e1f1234e29e51707a54799ea82b50d3a2a41c5221fa12058b2395b2`}),Object.freeze({targetPath:`THIRD_PARTY_NOTICES.md`,mediaType:`text/markdown`,spdx:`LicenseRef-Provenance-Notice`,size:1238,sha256:`bffe7fd8ce26c3bb2fa604b451d88770d6887891abfaf0d06e29f1742a166fb5`}),Object.freeze({targetPath:`licenses/browser-wasi-shim/LICENSE-MIT`,mediaType:`text/plain`,spdx:`MIT`,size:1023,sha256:`23f18e03dc49df91622fe2a76176497404e46ced8a715d9d2b67a7446571cca3`}),Object.freeze({targetPath:`licenses/browser-wasi-shim/LICENSE-APACHE`,mediaType:`text/plain`,spdx:`Apache-2.0`,size:11357,sha256:`c71d239df91726fc519c6eb72d318ec65820627232b2f796219e87dcf35d0ab4`})]),new TextEncoder,new TextDecoder(`utf-8`,{fatal:!0}),Object.freeze({"dyld.mjs":Object.freeze({bytes:83177,sha256:`d2260e7669868741fde2f1ba8cd38a9d63bff532c8ccb53d18b210b60af915d9`}),"rootfs.tar.zst":Object.freeze({bytes:49091550,sha256:`35f68f56fdb72111f150ba05ad31efed2f6fc77ee7026fb4b197ae7901a67adf`}),"bsdtar.wasm":Object.freeze({bytes:1240004,sha256:`e13ebb15ca0971f6629a6313bc043c532dd9be3a0e6bb0b7f8a395de835ad0c0`})}),Object.freeze({"compiler.wasm-runtime.js":Object.freeze({bytes:13936,sha256:`bd103f277be99fd2f3ffc0248b3558e6c2c85a44902bfeef042c6bedcf0b2c63`}),"compiler.wasm":Object.freeze({bytes:4299273,sha256:`9eb047426613c3ed3006838daae49e29929ad0d560ec6b1f8b50e15e2c3865d6`}),"compile-classlib-teavm.bin":Object.freeze({bytes:200621,sha256:`71746dc82ddad5ad8be829f461c235a747bdaf121d1b7abd16dbbbbe6a17f53d`}),"runtime-classlib-teavm.bin":Object.freeze({bytes:2394175,sha256:`f0c9c8c0426e310d08751e57cc88fdfd63ea2f428e4d6cb1b7e59a3dc20844ad`})}),new TextEncoder,new TextDecoder(`utf-8`,{fatal:!0});const We=`emperl.js`,Ge=`emperl.wasm`,Ke=`emperl.data`;new TextEncoder,new TextDecoder(`utf-8`,{fatal:!0}),Object.freeze({"licenses/LICENSE_artistic.txt":`Artistic-1.0-Perl`,"licenses/LICENSE_gpl.txt":`GPL-1.0-or-later`}),Object.freeze({[We]:`text/javascript`,[Ge]:`application/wasm`,[Ke]:`application/octet-stream`}),Object.freeze({"emperl.js.gz.bin":Object.freeze({logicalPath:We,encoding:`gzip`}),"emperl.wasm.gz.bin":Object.freeze({logicalPath:Ge,encoding:`gzip`}),"emperl.data.gz.bin":Object.freeze({logicalPath:Ke,encoding:`gzip`})});const qe=`janet.js`,Je=`janet.wasm`;new TextEncoder,new TextDecoder(`utf-8`,{fatal:!0}),Object.freeze({[qe]:`text/javascript`,[Je]:`application/wasm`}),Object.freeze({[qe]:Object.freeze({logicalPath:qe,encoding:`identity`}),"janet.wasm.gz.bin":Object.freeze({logicalPath:Je,encoding:`gzip`})});const Ye=Object.freeze([`ENVIRONMENT=worker`,`MODULARIZE=1`,`EXPORT_ES6=1`,`FORCE_FILESYSTEM=1`,`INVOKE_RUN=0`,`EXIT_RUNTIME=1`,`JANET_REDUCED_OS`]);Object.freeze({options:Ye,runner:Object.freeze({path:`scripts/runtime-build/wasm-janet-runner.c`,verifiedBuildInput:!1,bytes:1378,sha256:`1a2f357f16e250ed64260a77bd11435837ae033647fb23166eb924a42b4036ee`})}),Object.freeze({stdin:`streaming`,workspace:!1,abort:!0,artifacts:!1,streamingOutput:!0}),new TextEncoder,new TextDecoder(`utf-8`,{fatal:!0}),Object.freeze({"julia.data":`application/octet-stream`,"julia.js":`text/javascript`,"julia.wasm":`application/wasm`}),Object.freeze({"julia.data.gz.bin":Object.freeze({logicalPath:`julia.data`,encoding:`gzip`}),"julia.js.gz.bin":Object.freeze({logicalPath:`julia.js`,encoding:`gzip`}),"julia.wasm.gz.bin":Object.freeze({logicalPath:`julia.wasm`,encoding:`gzip`})}),Object.freeze({stdin:`streaming`,workspace:!1,abort:!0,artifacts:!1,streamingOutput:!0}),Object.freeze({"clang/clang.js":`text/javascript`,"clang/clang.wasm":`application/wasm`,"clang/lld.wasm":`application/wasm`,"clang/memfs.wasm":`application/wasm`,"clang/sysroot.tar":`application/x-tar`,"nim/nim-bundle.js":`text/javascript`,"nim/nim.wasm":`application/wasm`,"nim/nimbase.h":`text/x-c-header`}),Object.freeze({"clang/clang.js.bin":Object.freeze({logicalPath:`clang/clang.js`,encoding:`identity`}),"clang/clang.wasm.gz.bin":Object.freeze({logicalPath:`clang/clang.wasm`,encoding:`gzip`}),"clang/lld.wasm.gz.bin":Object.freeze({logicalPath:`clang/lld.wasm`,encoding:`gzip`}),"clang/memfs.wasm.gz.bin":Object.freeze({logicalPath:`clang/memfs.wasm`,encoding:`gzip`}),"clang/sysroot.tar.gz.bin":Object.freeze({logicalPath:`clang/sysroot.tar`,encoding:`gzip`}),"nim/nim-bundle.js.gz.bin":Object.freeze({logicalPath:`nim/nim-bundle.js`,encoding:`gzip`}),"nim/nim.wasm.gz.bin":Object.freeze({logicalPath:`nim/nim.wasm`,encoding:`gzip`}),"nim/nimbase.h.bin":Object.freeze({logicalPath:`nim/nimbase.h`,encoding:`identity`})}),Object.freeze({"clang/clang.js.bin":`clangJavaScript`,"clang/clang.wasm.gz.bin":`clangWasm`,"clang/lld.wasm.gz.bin":`lldWasm`,"clang/memfs.wasm.gz.bin":`memfsWasm`,"clang/sysroot.tar.gz.bin":`sysroot`,"nim/nim-bundle.js.gz.bin":`nimJavaScript`,"nim/nim.wasm.gz.bin":`nimWasm`,"nim/nimbase.h.bin":`nimbase`}),new TextEncoder,new TextDecoder(`utf-8`,{fatal:!0});const Xe=`sdk/index.mjs`,Ze=`sdk/wasmer_js_bg.wasm`,Qe=`bash.webc`;Object.freeze({[Xe]:`text/javascript`,[Ze]:`application/wasm`,[Qe]:`application/octet-stream`}),Object.freeze({"sdk/index.mjs.bin":Object.freeze({logicalPath:Xe,encoding:`identity`}),"sdk/wasmer_js_bg.wasm.gz.bin":Object.freeze({logicalPath:Ze,encoding:`gzip`}),"bash.webc.gz.bin":Object.freeze({logicalPath:Qe,encoding:`gzip`})}),new TextEncoder,new TextDecoder(`utf-8`,{fatal:!0});const $e=`compiler.js`,et=`rtl.js`,tt=`system.pas`;Object.freeze({[$e]:`text/javascript`,[et]:`text/javascript`,[tt]:`text/plain`}),Object.freeze({"compiler.js.gz.bin":Object.freeze({logicalPath:$e,encoding:`gzip`}),"rtl.js.bin":Object.freeze({logicalPath:et,encoding:`identity`}),"system.pas.bin":Object.freeze({logicalPath:tt,encoding:`identity`})}),Object.freeze({kind:`opaque-vendored`,repository:`https://github.com/seo-rii/wasm-idle.git`,path:`static/wasm-pascal`,provenance:`legacy-import`,verifiedBuildInput:!1}),Object.freeze({target:`browser`,compiler:`native pas2js`,entrypoint:`runtimes/wasm-pascal/src/wasm_idle_pascal_compiler.pas`,integrationSources:Object.freeze([`runtimes/wasm-pascal/src/system.pas`,`runtimes/wasm-pascal/src/wasm_idle_pascal_compiler.pas`,`runtimes/wasm-pascal/src/webfilecache.pp`]),transformations:Object.freeze([`strip trailing horizontal whitespace and normalize final newline`,`gzip compiler.js with Node zlib level 9`]),verifiedBuildInput:!1}),Object.freeze({spdx:`LGPL-2.1-only WITH Independent-modules-exception`,sourceUrl:`https://gitlab.com/freepascal.org/fpc/pas2js/-/raw/release_3_2_0/COPYING.txt`,exceptionSourceUrl:`https://gitlab.com/freepascal.org/fpc/pas2js/-/raw/release_3_2_0/LICENSE`,verifiedBuildInput:!1,evidence:`upstream license URLs recorded; texts were not vendored with the legacy generation`}),new TextEncoder,new TextDecoder(`utf-8`,{fatal:!0});const nt=`require.js`,rt=`tcl/wacl-custom.data`,it=`tcl/wacl-library.data`,at=`tcl/wacl.js`,ot=`tcl/wacl.wasm`;new TextEncoder,new TextDecoder(`utf-8`,{fatal:!0}),Object.freeze({"licenses/REQUIREJS.txt":`MIT`,"licenses/TCL.txt":`TCL`,"licenses/WACL.txt":`BSD-3-Clause`}),Object.freeze({[nt]:`text/javascript`,[rt]:`application/octet-stream`,[it]:`application/octet-stream`,[at]:`text/javascript`,[ot]:`application/wasm`}),Object.freeze({[nt]:Object.freeze({logicalPath:nt,encoding:`identity`}),"tcl/wacl-custom.data.bin":Object.freeze({logicalPath:rt,encoding:`identity`}),"tcl/wacl-library.data.gz.bin":Object.freeze({logicalPath:it,encoding:`gzip`}),[at]:Object.freeze({logicalPath:at,encoding:`identity`}),"tcl/wacl.wasm.gz.bin":Object.freeze({logicalPath:ot,encoding:`gzip`})}),new TextDecoder(`utf-8`,{fatal:!0});const st=Object.freeze({"index.js":Object.freeze({mediaType:`text/javascript`,role:`runtime`}),"puppyc.core.wasm":Object.freeze({mediaType:`application/wasm`,role:`runtime`}),"puppyc.core2.wasm":Object.freeze({mediaType:`application/wasm`,role:`runtime`}),"puppyc.js":Object.freeze({mediaType:`text/javascript`,role:`runtime`})}),ct=Object.freeze(Object.keys(st).sort());Object.freeze(ct.filter(e=>st[e].role===`runtime`)),[`artifact`,`assets`,`components`,`fingerprint`,`format`,`license`,`licenseExpression`,`metadata`,`notices`,`profileId`,`provenanceLevel`,`runtime`,`storage`,`transformations`].sort(),[`mediaType`,`path`,`role`,`sha256`,`size`].sort(),[`encoding`,`logicalPath`,`path`,`sha256`,`size`].sort(),[`path`,`sha256`,`size`,`spdx`].sort(),[`mediaType`,`path`,`sha256`,`size`].sort(),new TextDecoder(`utf-8`,{fatal:!0}),Object.freeze({wasmMemoryBytes:0,nestedWorkers:0,threads:0}),new TextEncoder;const lt=e=>{if(e&&typeof e==`object`){for(let t of Object.values(e))lt(t);Object.freeze(e)}return e};lt({profileId:`ruby-3.4.1-ruby-wasm-2.10.1-split-stdlib-v1`,version:`57880188dbfe3299bc9932e1136e56cf9591ee07b1556dbcd85afd5fd8e80907`,manifest:{path:`runtime-split.v1.json`,bytes:4259,sha256:`57880188dbfe3299bc9932e1136e56cf9591ee07b1556dbcd85afd5fd8e80907`},mountPaths:[`/usr`,`/usr/local`,`/usr/local/lib`,`/usr/local/lib/ruby`,`/usr/local/lib/ruby/3.4.0`,`/usr/local/lib/ruby/gems`,`/usr/local/lib/ruby/gems/3.4.0`,`/bundle`],assets:{module:{path:`runtime.mjs.bin`,encoding:`identity`,bytes:54866,sha256:`d1d33ccf090d3e99d8e3fd54a4e18c258d468e101711d0aee360e51dc2e26fd9`,logicalBytes:54866,logicalSha256:`d1d33ccf090d3e99d8e3fd54a4e18c258d468e101711d0aee360e51dc2e26fd9`},wasm:{path:`ruby-core.wasm.gz.bin`,encoding:`gzip`,bytes:5050303,sha256:`d427b86c2bb221bd007731795d44212bd1d61a3bc58661ab78276906b30a491b`,logicalBytes:16655034,logicalSha256:`e64fa4c82cbbb62044648b0a15b96f3486ff3ecbab7bb7a3df11b4ee3e907ddc`},stdlib:{path:`stdlib.pack.gz.bin`,encoding:`gzip`,bytes:4016936,sha256:`49887b7d427526bd04045b2da56895c51c9824c1681bbdbd2bf4ca5cc2cbbf5b`,logicalBytes:14791924,logicalSha256:`db6419553b4e2773999d48d4e3a7d4b5f750faed01171f5ec72f4772bbb2f5d8`}}}),new TextDecoder(`utf-8`,{fatal:!0});function F(e){if(e.debugMode!==void 0){if(e.debugMode===`none`||e.debugMode===`trace`||e.debugMode===`lldb`)return e.debugMode;throw Error(`unsupported wasm-clang debug mode: ${String(e.debugMode)}`)}return e.debug?`trace`:`none`}function ut(e,...t){let n={};for(let r of t)n[r]=(e[r]||(()=>0)).bind(e);return n}function dt(e,t,n=-1){let r=n===-1?e.length:t+n,i=``;for(let n=t;n<r&&e[n];++n)i+=String.fromCharCode(e[n]);return i}function ft(e,t,n=-1){let r=n===-1?e.length:t+n,i=[];for(let n=t;n<r&&e[n];++n)i.push(e[n]);return new TextDecoder().decode(Uint8Array.from(i))}function pt(e,t,n){return parseInt(dt(e,t,n),8)}var mt=class{memory;view;buffer;u8;u32;constructor(e){this.memory=e,this.buffer=e.buffer,this.view=new DataView(this.buffer),this.u8=new Uint8Array(this.buffer),this.u32=new Uint32Array(this.buffer)}check(){this.buffer.byteLength===0&&(this.buffer=this.memory.buffer,this.view=new DataView(this.buffer),this.u8=new Uint8Array(this.buffer),this.u32=new Uint32Array(this.buffer))}read8(e){return this.u8[e]}read32(e){return this.u32[e>>2]}readInt32(e){return this.view.getInt32(e,!0)}readFloat32(e){return this.view.getFloat32(e,!0)}readFloat64(e){return this.view.getFloat64(e,!0)}readStr(e,t){return dt(this.u8,e,t)}readStrR(e,t){return ft(this.u8,e,t)}write8(e,t){this.u8[e]=t}write32(e,t){this.u32[e>>2]=t}write64(e,t,n=0){this.write32(e,t),this.write32(e+4,n)}writeStr(e,t){return e+=this.write(e,t),this.write8(e,0),t.length+1}writeUint8(e,t){return new Uint8Array(this.buffer,e,t.length).set(t),t.length}write(e,t){return t instanceof ArrayBuffer||t instanceof SharedArrayBuffer?this.writeUint8(e,new Uint8Array(t)):typeof t==`string`?this.writeUint8(e,t.split(``).map(e=>e.charCodeAt(0))):this.writeUint8(e,t)}};const ht=/* @__PURE__ */ new Map,gt=/* @__PURE__ */ new Map,_t=/* @__PURE__ */ new WeakMap;function vt(e){return _t.get(e)??Promise.resolve(void 0)}async function yt(e){try{return Array.from(new Uint8Array(await crypto.subtle.digest(`SHA-256`,e)),e=>e.toString(16).padStart(2,`0`)).join(``)}catch{return}}const bt=e=>e.byteLength>=2&&e[0]===31&&e[1]===139,xt=134217728,St=4194304,Ct=65536;async function wt(e,t,n,r){let i=e.getReader(),a=r,o=!1;if(a?.aborted){o=!0;let e=I(a);try{Promise.resolve(i.cancel(e)).catch(()=>{})}catch{}try{i.releaseLock()}catch{}throw e}let s,c=a?new Promise((e,t)=>{s=()=>{if(o)return;o=!0;let e=I(a);try{Promise.resolve(i.cancel(e)).catch(()=>{})}catch{}t(e)},a.addEventListener(`abort`,s,{once:!0})}):void 0,l=new Uint8Array(Math.min(Ct,n)),u=0,d=!1,f,p;try{for(L(a);;){let e=i.read(),{done:r,value:o}=c?await Promise.race([e,c]):await e;if(L(a),r)break;if(!o)continue;let s=u+o.byteLength;if(s>n)throw Error(`Runtime asset ${t} decompressed size exceeds the ${n} byte limit`);if(s>l.byteLength){let e=Math.min(n,Math.max(s,Math.max(l.byteLength*2,1))),t=new Uint8Array(e);t.set(l.subarray(0,u)),l=t}l.set(o,u),u=s}L(a),f=l.subarray(0,u),d=!0}catch(e){if(a?.aborted)throw I(a);if(!o){o=!0;try{Promise.resolve(i.cancel(e)).catch(()=>{})}catch{}}throw e}finally{s&&a?.removeEventListener(`abort`,s);try{i.releaseLock()}catch(e){d&&(p={error:e})}}if(p)throw p.error;return f}function Tt(e){let t;try{t=new URL(e,typeof location<`u`?location.href:void 0)}catch{throw Error(`Runtime asset URL must be absolute outside a browser document`)}if(t.protocol!==`http:`&&t.protocol!==`https:`)throw Error(`Runtime assets must use HTTP(S)`);if(t.username||t.password)throw Error(`Runtime asset URLs must not include credentials`);if(t.hash)throw Error(`Runtime asset URLs must not include fragments`);return t}function Et(e){let t=e.headers.get(`Content-Length`);if(t===null)return 0;let n=Number(t);if(!/^\d+$/u.test(t)||!Number.isSafeInteger(n))throw Error(`Runtime asset has an invalid Content-Length`);return n}function I(e){return e.reason??new DOMException(`Runtime asset load aborted`,`AbortError`)}function Dt(e,t,n){return t?new Promise((r,i)=>{let a=!1,o=()=>{a||(a=!0,t.removeEventListener(`abort`,o),i(I(t)))};t.addEventListener(`abort`,o,{once:!0}),e.then(e=>{if(a){n&&Promise.resolve().then(()=>n(e,t.reason)).catch(()=>{});return}a=!0,t.removeEventListener(`abort`,o),r(e)},e=>{a||(a=!0,t.removeEventListener(`abort`,o),i(e))}),t.aborted&&o()}):e}function L(e){if(e?.aborted)throw I(e)}function R(e,t){try{e.body?.cancel(t).catch(()=>{})}catch{}}async function Ot(e,t,n,r,i){if(i?.aborted){let t=I(i);throw R(e,t),t}let a;try{a=Et(e)}catch(t){throw R(e,t),t}if(a>n)throw R(e),Error(`Runtime asset ${t} size exceeds the ${n} byte limit`);if(!e.body){let a=new Uint8Array(await Dt(e.arrayBuffer(),i));if(i?.aborted)throw I(i);if(a.byteLength>n)throw Error(`Runtime asset ${t} size exceeds the ${n} byte limit`);return r?.set?.(1),a}let o=i,s=e.body.getReader(),c=!1,l=e=>{if(!c){c=!0;try{Promise.resolve(s.cancel(e)).catch(()=>{})}catch{}}};if(o?.aborted){let e=I(o);l(e);try{s.releaseLock()}catch{}throw e}let u,d=o?new Promise((e,t)=>{u=()=>{let e=I(o);l(e),t(e)},o.addEventListener(`abort`,u,{once:!0})}):void 0,f,p=0,m,h;try{for(f=new Uint8Array(Math.min(n,a||Ct));;){L(o);let e=s.read(),{done:i,value:c}=d?await Promise.race([e,d]):await e;if(L(o),i)break;if(!c)continue;let u=p+c.byteLength;if(u>n){let e=/* @__PURE__ */ Error(`Runtime asset ${t} size exceeds the ${n} byte limit`);throw l(e),e}if(u>f.byteLength){let e=Math.min(n,Math.max(u,Math.max(f.byteLength*2,1))),t=new Uint8Array(e);t.set(f.subarray(0,p)),f=t}f.set(c,p),p=u,a>0&&r?.set?.(p/a)}L(o),m=f.subarray(0,p)}catch(e){if(o?.aborted){let e=I(o);throw l(e),e}throw l(e),e}finally{u&&o?.removeEventListener(`abort`,u);try{s.releaseLock()}catch(e){o?.aborted||(h={error:e})}}if(o?.aborted){let e=I(o);throw l(e),e}if(h)throw h.error;return m}async function kt(e,t={}){let n=t.maxBytes??4194304;if(!Number.isSafeInteger(n)||n<=0)throw Error(`Runtime JSON byte limit must be a positive safe integer`);let r=Tt(e.toString()),i=t.label?.trim()||`runtime JSON`,a=t.fetchImpl??globalThis.fetch?.bind(globalThis);if(!a)throw Error(`Fetch is unavailable while loading ${i}`);if(t.signal?.aborted)throw I(t.signal);let o={cache:`no-store`,credentials:`omit`,redirect:`error`,referrerPolicy:`no-referrer`};t.signal&&(o.signal=t.signal);let s=await Dt(Promise.resolve(a(r.toString(),o)),t.signal,(e,t)=>{R(e,t)});if(t.signal?.aborted){let e=I(t.signal);throw R(s,e),e}if(s.url){let e;try{e=new URL(s.url)}catch{throw R(s),Error(`${i} returned an invalid final URL`)}if(e.href!==r.href)throw R(s),Error(`${i} returned an unexpected final URL`)}if(!s.ok)throw R(s),Error(`Failed to load ${i} from ${r}: ${s.status}`);let c=await Ot(s,r,n,void 0,t.signal),l;try{l=new TextDecoder(`utf-8`,{fatal:!0}).decode(c)}catch(e){throw Error(`${i} is not valid UTF-8`,{cause:e})}try{return JSON.parse(l)}catch(e){throw Error(`${i} is not valid JSON`,{cause:e})}}async function At(e,t=`runtime asset`,n=xt,r){if(!Number.isSafeInteger(n)||n<0)throw Error(`Runtime asset decompression limit must be a non-negative safe integer`);if(L(r),!bt(e)){if(e.byteLength>n)throw Error(`Runtime asset ${t} decompressed size exceeds the ${n} byte limit`);return e}if(typeof DecompressionStream!=`function`)throw Error(`Failed to decompress runtime asset ${t}: DecompressionStream('gzip') is unavailable`);try{let i=Uint8Array.from(e),a=new ReadableStream({start(e){e.enqueue(i),e.close()}}),o=new DecompressionStream(`gzip`);return await wt(a.pipeThrough({readable:o.readable,writable:o.writable}),t,n,r)}catch(e){throw r?.aborted?I(r):Error(`Failed to decompress runtime asset ${t}: ${e instanceof Error?e.message:String(e)}`)}}async function jt(e,t,n,r,i){if(i?.aborted){let t=I(i);throw R(e,t),t}let a;try{a=Et(e)}catch(t){throw R(e,t),t}if(a>n)throw R(e),Error(`Runtime asset ${t} download size exceeds the ${n} byte limit`);if(!e.body){let a=new Uint8Array(await Dt(e.arrayBuffer(),i));if(L(i),a.byteLength>n)throw Error(`Runtime asset ${t} download size exceeds the ${n} byte limit`);let o=await At(a,t,n,i);return L(i),r?.set?.(1),o}let o=e.body.getReader(),s=[],c=0,l=0,u=!1,d=!1,f=!1,p=()=>{d||(d=!0,o.releaseLock())},m=e=>{if(!(d||f)){f=!0;try{Promise.resolve(o.cancel(e)).catch(()=>{})}catch{}try{p()}catch{}}};if(i?.aborted){let e=I(i);throw m(e),e}let h,g=i?new Promise((e,t)=>{h=()=>{let e=I(i);m(e),t(e)},i.addEventListener(`abort`,h,{once:!0})}):void 0;try{for(L(i);c<2;){let e=o.read(),{done:d,value:f}=g?await Promise.race([e,g]):await e;if(L(i),d){u=!0,p();break}if(!f)continue;let h=l+f.byteLength;if(h>n){let e=/* @__PURE__ */ Error(`Runtime asset ${t} download size exceeds the ${n} byte limit`);throw m(e),e}s.push(f),c+=f.byteLength,l=h,a>0&&r?.set?.(Math.min(l/a,1))}L(i)}catch(e){throw m(e),i?.aborted?I(i):e}finally{h&&i?.removeEventListener(`abort`,h)}let _,v;for(let e of s){for(let t of e)if(_===void 0?_=t:v===void 0&&(v=t),v!==void 0)break;if(v!==void 0)break}let y=0,b=new ReadableStream({async pull(e){if(y<s.length){e.enqueue(s[y++]);return}if(u){e.close();return}try{let{done:s,value:c}=await o.read();if(L(i),s){u=!0,p(),e.close();return}if(!c)return;let d=l+c.byteLength;if(d>n){let r=/* @__PURE__ */ Error(`Runtime asset ${t} download size exceeds the ${n} byte limit`);m(r),e.error(r);return}l=d,a>0&&r?.set?.(Math.min(l/a,1)),e.enqueue(c)}catch(t){m(t),e.error(t)}},cancel(e){m(e)}}),x=b;if(_===31&&v===139){if(typeof DecompressionStream!=`function`){let e=/* @__PURE__ */ Error(`Failed to decompress runtime asset ${t}: DecompressionStream('gzip') is unavailable`);throw m(e),e}let e=new DecompressionStream(`gzip`);x=b.pipeThrough({readable:e.readable,writable:e.writable})}try{let e=await wt(x,t,n,i);return r?.set?.(1),e}catch(e){throw m(e),i?.aborted?I(i):Error(`Failed to decompress runtime asset ${t}: ${e instanceof Error?e.message:String(e)}`)}}async function Mt(e,t,n,r){L(r);let{unzipSync:i}=await import(`./chunks/UgmTalj_.js`);L(r);let a,o=i(e,{filter(e){if(e.name.endsWith(`/`)||a!==void 0)return!1;if(e.originalSize>n)throw Error(`Runtime asset ${t} extracted size exceeds the ${n} byte limit`);return a=e.name,!0}});L(r);for(let[e,t]of Object.entries(o))if(!e.endsWith(`/`))return t;throw Error(`No entry found`)}const Nt=async(e,t,n=xt,r)=>{if(!Number.isSafeInteger(n)||n<0)throw Error(`Runtime asset byte limit must be a non-negative safe integer`);L(r);let i=`${e}\0${n}`,a=r?void 0:gt.get(i);a||(a=(async()=>{let i=Tt(e),a={credentials:`omit`,redirect:`error`,referrerPolicy:`no-referrer`};r&&(a.signal=r);let o;try{o=await Dt(Promise.resolve(fetch(i,a)),r,(e,t)=>{R(e,t)})}catch(e){throw r?.aborted?I(r):e}if(r?.aborted){let e=I(r);throw R(o,e),e}if(o.url){let e;try{e=new URL(o.url)}catch{throw R(o),Error(`Runtime asset returned an invalid final URL`)}if(e.href!==i.href)throw R(o),Error(`Runtime asset returned an unexpected final URL`)}if(!o.ok)throw R(o),Error(`Failed to load runtime asset ${i}: ${o.status}`);if(i.pathname.endsWith(`.gz`))return await jt(o,i,n,t,r);let s=await Ot(o,i,n,t,r);return i.pathname.endsWith(`.zip`)?await Mt(s,i,n,r):s})(),r||(a=a.catch(e=>{throw gt.get(i)===a&&gt.delete(i),e}),gt.set(i,a)));let o=await a;return L(r),t?.set?.(1),o},z=async(e,t,n=xt,r)=>{let i=await Nt(e,t,n,r);return L(r),Uint8Array.from(i)};async function Pt(e,t,n,r=xt){L(n);let i=`${e}\0${r}`,a=n?void 0:ht.get(i);if(a)return a;let o=(async()=>{let i=await Nt(e,t,r,n);L(n);let a=i.buffer;if(!(a instanceof ArrayBuffer))throw TypeError(`Runtime asset compilation requires an ArrayBuffer`);let o=new Uint8Array(a,i.byteOffset,i.byteLength),s=await Dt(WebAssembly.compile(o),n);return L(n),_t.set(s,yt(o)),s})();return n||(o=o.catch(e=>{throw ht.get(i)===o&&ht.delete(i),e}),ht.set(i,o)),o}function Ft(e,t){return WebAssembly.instantiate(e,t)}var It=class extends Error{code;constructor(e){super(`process exited with code ${e}.`),this.code=e}},Lt=class extends Error{constructor(e,t){super(`${e}.${t} not implemented.`)}},Rt=class extends Error{constructor(e=`abort`){super(e)}},zt=class extends Error{constructor(e){super(e)}};function Bt(e){if(!e)throw new zt(`assertion failed.`)}const Vt=[`&&`,`||`,`==`,`!=`,`<=`,`>=`,`+`,`-`,`*`,`/`,`%`,`<`,`>`,`!`],Ht=e=>!!e&&typeof e==`object`&&!Array.isArray(e)&&e.__debugExpressionKind===`array`,Ut=e=>!!e&&typeof e==`object`&&!Array.isArray(e)&&e.__debugExpressionKind===`object`,Wt=(e,t)=>{let n=e[t];if(n!==`'`&&n!==`"`)throw Error(`expected quoted string`);let r=t+1,i=``;for(;r<e.length;){let t=e[r];if(!t)break;if(t===`\\`){let t=e[r+1];if(!t)throw Error(`unterminated string literal`);i+=t===`n`?`
`:t===`r`?`\r`:t===`t`?`	`:t,r+=2;continue}if(t===n)return{value:i,next:r+1};i+=t,r+=1}throw Error(`unterminated string literal`)},Gt=e=>{let t=[];for(let n=0;n<e.length;){let r=e[n];if(!r)break;if(/\s/.test(r)){n+=1;continue}if(r===`(`||r===`)`){t.push({type:`paren`,value:r}),n+=1;continue}if(r===`[`||r===`]`){t.push({type:`bracket`,value:r}),n+=1;continue}if(r===`.`){t.push({type:`dot`}),n+=1;continue}let i=Vt.find(t=>e.startsWith(t,n));if(i){t.push({type:`operator`,value:i}),n+=i.length;continue}if(r===`'`||r===`"`){let r=Wt(e,n);t.push({type:`string`,value:r.value}),n=r.next;continue}let a=e.slice(n).match(/^\d+(?:\.\d+)?/);if(a?.[0]){t.push({type:`number`,value:a[0]}),n+=a[0].length;continue}let o=e.slice(n).match(/^[A-Za-z_]\w*/);if(o?.[0]){o[0]===`true`||o[0]===`false`||o[0]===`True`||o[0]===`False`?t.push({type:`boolean`,value:o[0]===`true`||o[0]===`True`}):o[0]===`null`||o[0]===`None`?t.push({type:`null`}):o[0]===`and`?t.push({type:`operator`,value:`&&`}):o[0]===`or`?t.push({type:`operator`,value:`||`}):o[0]===`not`?t.push({type:`operator`,value:`!`}):t.push({type:`identifier`,value:o[0]}),n+=o[0].length;continue}throw Error(`unsupported token near "${e.slice(n)}"`)}return t},Kt=(e,t=0)=>{let n=t;for(;/\s/.test(e[n]||``);)n+=1;let r=e[n];if(r===`[`){n+=1;let t=[];for(;;){for(;/\s/.test(e[n]||``);)n+=1;if(e[n]===`]`)return{value:t,next:n+1};if(e.startsWith(`...`,n)){for(t.truncated=!0,n+=3;/\s/.test(e[n]||``);)n+=1;if(e[n]===`]`)return{value:t,next:n+1};throw Error(`unsupported array preview`)}let r=Kt(e,n);for(t.push(r.value),n=r.next;/\s/.test(e[n]||``);)n+=1;if(e[n]===`,`){n+=1;continue}if(e[n]===`]`)return{value:t,next:n+1};throw Error(`unsupported array preview`)}}if(r===`(`){n+=1;let t=[];for(;;){for(;/\s/.test(e[n]||``);)n+=1;if(e[n]===`)`)return{value:t,next:n+1};if(e.startsWith(`...`,n)){for(t.truncated=!0,n+=3;/\s/.test(e[n]||``);)n+=1;if(e[n]===`)`)return{value:t,next:n+1};throw Error(`unsupported tuple preview`)}let r=Kt(e,n);for(t.push(r.value),n=r.next;/\s/.test(e[n]||``);)n+=1;if(e[n]===`,`){n+=1;continue}if(e[n]===`)`)return{value:t,next:n+1};throw Error(`unsupported tuple preview`)}}if(r===`{`){n+=1;let t={};for(;;){for(;/\s/.test(e[n]||``);)n+=1;if(e[n]===`}`)return{value:t,next:n+1};if(e.startsWith(`...`,n))throw Error(`unavailable`);let r=``;if(e[n]===`'`||e[n]===`"`){let t=Wt(e,n);r=t.value,n=t.next}else{let t=e.slice(n).match(/^[A-Za-z_]\w*/)?.[0];if(!t)throw Error(`unsupported object preview`);r=t,n+=t.length}for(;/\s/.test(e[n]||``);)n+=1;if(e[n]!==`:`)throw Error(`unsupported object preview`);n+=1;let i=Kt(e,n);for(t[r]=i.value,n=i.next;/\s/.test(e[n]||``);)n+=1;if(e[n]===`,`){n+=1;continue}if(e[n]===`}`)return{value:t,next:n+1};throw Error(`unsupported object preview`)}}if(r===`'`||r===`"`)return Wt(e,n);if(e.startsWith(`true`,n))return{value:!0,next:n+4};if(e.startsWith(`false`,n))return{value:!1,next:n+5};if(e.startsWith(`True`,n))return{value:!0,next:n+4};if(e.startsWith(`False`,n))return{value:!1,next:n+5};if(e.startsWith(`null`,n)||e.startsWith(`None`,n))return{value:null,next:n+4};let i=e.slice(n).match(/^-?\d+(?:\.\d+)?/);if(i?.[0])return{value:Number(i[0]),next:n+i[0].length};throw Error(`unsupported preview`)},qt=e=>{let t=e.trim();if(!t||t===`?`)throw Error(`unavailable`);if(t===`true`||t===`false`||t===`True`||t===`False`)return t===`true`||t===`True`;if(t===`null`||t===`None`)return null;let n=Number(t);if(!Number.isNaN(n))return n;if(t.startsWith(`[`)||t.startsWith(`(`)||t.startsWith(`{`)||t.startsWith(`'`)||t.startsWith(`"`)){let e=Kt(t);if(t.slice(e.next).trim())throw Error(`unsupported preview`);return e.value}throw Error(`unsupported preview`)},Jt=e=>`'${e.replaceAll(`\\`,`\\\\`).replaceAll(`'`,`\\'`).replaceAll(`
`,`\\n`).replaceAll(`\r`,`\\r`).replaceAll(`	`,`\\t`)}'`,Yt=(e,t,n)=>{if(e===null)return`null`;if(typeof e==`number`||typeof e==`boolean`)return`${e}`;if(typeof e==`string`)return t?Jt(e):e;if(n>=4)return`...`;if(Array.isArray(e)){let t=Math.min(e.length,8);return`[${e.slice(0,t).map(e=>Yt(e,!0,n+1)).join(`, `)}${e.truncated||e.length>t?`, ...`:``}]`}if(Ht(e)){let t=e.keys?.()||[],r=Math.min(t.length||e.length||0,8),i=[];for(let a=0;a<r;a+=1){let r=t[a]??a;i.push(Yt(e.get(r),!0,n+1))}let a=e.truncated||e.length!=null&&e.length>r;return`[${i.join(`, `)}${a?`, ...`:``}]`}if(Ut(e)){let t=e.keys?.()||[],r=Math.min(t.length,8);return`{${t.slice(0,r).map(t=>`${t}: ${Yt(e.get(t),!0,n+1)}`).join(`, `)}${t.length>r?`, ...`:``}}`}let r=Object.keys(e),i=Math.min(r.length,8);return`{${r.slice(0,i).map(t=>`${t}: ${Yt(e[t],!0,n+1)}`).join(`, `)}${r.length>i?`, ...`:``}}`},Xt=e=>Yt(e,!1,0),Zt=(e,t)=>{let n=e.trim();if(!n)throw Error(`empty expression`);let r=Gt(n),i=/* @__PURE__ */ new Map,a=e=>{if(i.has(e))return i.get(e);let n=t(e);return i.set(e,n),n},o=(e,t)=>{if(!Number.isInteger(t))throw Error(`unsupported index access`);if(Array.isArray(e)){if(t<0||t>=e.length)throw Error(`unavailable`);return e[t]}if(Ht(e)){if(e.length!=null&&(t<0||t>=e.length))throw Error(`unavailable`);return e.get(t)}throw Error(`unsupported index access`)},s=(e,t)=>{if(Array.isArray(e)||Ht(e)||!e)throw Error(`unsupported member access`);if(Ut(e)){if(!e.has(t))throw Error(`unavailable`);return e.get(t)}if(typeof e!=`object`||!Object.hasOwn(e,t))throw Error(`unavailable`);return e[t]},c=0,l=!0,u=e=>{let t=l;l=!1;try{return e()}finally{l=t}},d=()=>{let e=r[c];if(!e)throw Error(`unexpected end of expression`);if(e.type===`number`)return c+=1,Number(e.value);if(e.type===`boolean`)return c+=1,e.value;if(e.type===`null`)return c+=1,null;if(e.type===`string`)return c+=1,e.value;if(e.type===`identifier`){c+=1;let t=l?a(e.value):null;for(;;){let e=r[c];if(e?.type===`bracket`&&e.value===`[`){c+=1;let e=Number(v()),n=r[c];if(!n||n.type!==`bracket`||n.value!==`]`)throw Error(`missing closing bracket`);c+=1,t=l?o(t,e):null;continue}if(e?.type===`dot`){c+=1;let e=r[c];if(!e||e.type!==`identifier`)throw Error(`missing property name`);c+=1,t=l?s(t,e.value):null;continue}break}return t}if(e.type===`paren`&&e.value===`(`){c+=1;let e=v(),t=r[c];if(!t||t.type!==`paren`||t.value!==`)`)throw Error(`missing closing parenthesis`);return c+=1,e}throw Error(`expected value`)},f=()=>{let e=r[c];return e?.type===`operator`&&e.value===`!`?(c+=1,!f()):e?.type===`operator`&&e.value===`-`?(c+=1,-Number(f())):e?.type===`operator`&&e.value===`+`?(c+=1,Number(f())):d()},p=()=>{let e=f();for(;;){let t=r[c];if(t?.type!==`operator`||![`*`,`/`,`%`].includes(t.value))return e;c+=1;let n=f();t.value===`*`&&(e=Number(e)*Number(n)),t.value===`/`&&(e=Number(e)/Number(n)),t.value===`%`&&(e=Number(e)%Number(n))}},m=()=>{let e=p();for(;;){let t=r[c];if(t?.type!==`operator`||![`+`,`-`].includes(t.value))return e;c+=1;let n=p();t.value===`+`&&(e=typeof e==`string`||typeof n==`string`?`${e??`null`}${n??`null`}`:Number(e)+Number(n)),t.value===`-`&&(e=Number(e)-Number(n))}},h=()=>{let e=m();for(;;){let t=r[c];if(t?.type!==`operator`||![`<`,`<=`,`>`,`>=`].includes(t.value))return e;c+=1;let n=m(),i=typeof e==`string`&&typeof n==`string`?e:Number(e),a=typeof e==`string`&&typeof n==`string`?n:Number(n);t.value===`<`&&(e=i<a),t.value===`<=`&&(e=i<=a),t.value===`>`&&(e=i>a),t.value===`>=`&&(e=i>=a)}},g=()=>{let e=h();for(;;){let t=r[c];if(t?.type!==`operator`||![`==`,`!=`].includes(t.value))return e;c+=1;let n=h();t.value===`==`&&(e=e===n),t.value===`!=`&&(e=e!==n)}},_=()=>{let e=g();for(;;){let t=r[c];if(!t||t.type!==`operator`||t.value!==`&&`)break;c+=1;let n=l&&e?g():u(g);l&&(e=!!e&&!!n)}return e},v=()=>{let e=_();for(;;){let t=r[c];if(!t||t.type!==`operator`||t.value!==`||`)break;c+=1;let n=l&&!e?_():u(_);l&&(e=!!e||!!n)}return e},y=v();if(c!==r.length)throw Error(`unexpected trailing tokens`);return Xt(y)},Qt=Int32Array.BYTES_PER_ELEMENT*2,$t=new TextEncoder,en=new TextDecoder,tn=e=>e instanceof Int32Array?e:new Int32Array(e),nn=e=>new Uint8Array(e.buffer,e.byteOffset+Qt,e.byteLength-Qt),rn=(e,t)=>{let n=$t.encode(e);if(n.length<=t)return{bytes:n,rest:``};let r=0,i=e.length;for(;r<i;){let n=Math.ceil((r+i)/2);$t.encode(e.slice(0,n)).length<=t?r=n:i=n-1}let a=e.slice(0,r);return{bytes:$t.encode(a),rest:e.slice(r)}},an=(e,t)=>{if(!e.length)return!1;let n=tn(t),r=nn(n),i=e[0]||``,{bytes:a,rest:o}=rn(i,r.length);return r.fill(0),r.set(a),Atomics.store(n,1,a.length),Atomics.add(n,0,1),Atomics.notify(n,0),o?e[0]=o:e.shift(),!0},on=e=>{let t=tn(e),n=Atomics.load(t,1);if(n===-1)return null;let r=nn(t);return en.decode(r.slice(0,n))};var sn=class{ready;mem=null;memfs;instance=null;exports;trace=()=>{};debugSession;useJsReadOverlay=!1;useJsSourceReadOverlay=!1;argv;environ;handles=/* @__PURE__ */ new Map;nextHandle=1024;syntheticFileHandles=/* @__PURE__ */ new Set;nextSyntheticInode=1;syntheticInodes=/* @__PURE__ */ new Map;readFileHandles=/* @__PURE__ */ new Map;writeFileHandles=/* @__PURE__ */ new Map;constructor(e,t,n,...r){let i=r.at(-1),a=i&&typeof i==`object`?r.pop():{},o=r;this.argv=[n,...o],this.environ={USER:`wasm-clang`},this.memfs=t,this.useJsReadOverlay=n===`wasm-ld`||n===`ld.lld`||n===`lld`,this.useJsSourceReadOverlay=n===`clang`||n===`clang++`||n===`cobc`;let s=ut(this,`__wasm_idle_debug_enter`,`__wasm_idle_debug_leave`,`__wasm_idle_debug_line`,`__wasm_idle_debug_value_num`,`__wasm_idle_debug_value_bool`,`__wasm_idle_debug_value_addr`,`__wasm_idle_debug_value_text`),c={...ut(this,`proc_exit`,`environ_sizes_get`,`environ_get`,`args_sizes_get`,`args_get`,`random_get`,`clock_time_get`,`poll_oneoff`,`fd_filestat_set_times`,`path_filestat_set_times`,`sock_accept`,`sock_recv`,`sock_send`,`sock_shutdown`,`path_link`,`path_rename`),...this.memfs.exports,...ut(this,`path_open`,`path_filestat_get`,`path_readlink`,`path_unlink_file`,`fd_fdstat_get`,`fd_fdstat_set_flags`,`fd_filestat_get`,`fd_filestat_set_size`,`fd_datasync`,`fd_read`,`fd_pread`,`fd_seek`,`fd_tell`,`fd_write`,`fd_close`)},l=a.extraImports?.env||{};this.ready=Ft(e,{...a.extraImports,wasi_unstable:c,wasi_snapshot_preview1:c,env:{...l,...s}}).then(e=>{this.instance=e,a.instanceRef&&(a.instanceRef.current=e),this.exports=this.instance.exports,this.mem=new mt(this.exports.memory),this.memfs.hostMem=this.mem})}async run(){await this.ready,this.trace(`start(argv=${JSON.stringify(this.argv)}, exports=${JSON.stringify(Object.keys(this.exports||{}))})`);try{this.exports._start()}catch(e){let t=!0;if(e instanceof It){if(this.trace(`proc_exit(code=${e.code})`),e.code===789514)return this.trace(`allow_rAF_after_exit`),!0;if(this.trace(`disallow_rAF_after_exit(code=${e.code})`),e.code==0)return!1;t=!1}e instanceof Lt&&this.trace(`not_implemented(${e.message})`);let n=`\x1b[91mError: ${e.message}`;throw t&&(n+=`\n${e.stack}`),n+=`\x1B[0m
`,this.memfs.stdout(n),e}this.trace(`start() returned without proc_exit`)}proc_exit(e){throw this.trace(`proc_exit_throw(code=${e})`),new It(e)}toNumber(e){return typeof e==`bigint`?Number(e):e}writeU32(e,t){this.mem.view.setUint32(e,t>>>0,!0)}writeU64(e,t){let n=BigInt(t);this.mem.view.setUint32(e,Number(n&4294967295n),!0),this.mem.view.setUint32(e+4,Number(n>>32n&4294967295n),!0)}readMemfsFile(e){let t=[e,e.replace(/^\/+/,``),e.replace(/^\.\//,``),e.replace(/^\/+/,``).replace(/^\.\//,``)];for(let e of t)if(this.memfs.hasFile(e))try{return Uint8Array.from(this.memfs.getFileContents(e))}catch{}return null}shouldUseJsReadForPath(e){return this.useJsReadOverlay?!0:this.useJsSourceReadOverlay}syntheticInodeForPath(e){let t=e.replace(/^\/+/,``).replace(/^\.\//,``)||e,n=this.syntheticInodes.get(t);return n||(n=this.nextSyntheticInode++,this.syntheticInodes.set(t,n)),n}copyFileToIovs(e,t,n,r,i){this.mem.check();let a=0;for(let i=0;i<r;i+=1){let r=this.mem.read32(n);n+=4;let i=this.mem.read32(n);if(n+=4,i<=0)continue;let o=Math.max(0,e.length-t),s=Math.min(i,o);if(s>0&&(this.mem.write(r,e.subarray(t,t+s)),t+=s,a+=s),s<i)break}return this.writeU32(i,a),{copied:a,position:t}}writeRegularFileStat(e,t,n){this.mem.check(),this.writeU64(e,1),this.writeU64(e+8,this.syntheticInodeForPath(n)),this.mem.write8(e+16,4),this.writeU64(e+24,1),this.writeU64(e+32,t),this.writeU64(e+40,0),this.writeU64(e+48,0),this.writeU64(e+56,0)}seekPosition(e,t,n,r){let i=this.toNumber(n);return r===0?Math.max(0,i):r===1?Math.max(0,e+i):r===2?Math.max(0,t+i):null}ensureWriteCapacity(e,t){if(e.contents.length>=t)return;let n=Math.max(1024,e.contents.length);for(;n<t;)n*=2;let r=new Uint8Array(n);r.set(e.contents.subarray(0,e.size)),e.contents=r}atomicOutputTarget(e){let t=e.match(/^(.+)-[0-9a-f]+(\.[^.]+)\.tmp$/);return t?`${t[1]}${t[2]}`:null}storeFileContents(e,t){if(this.useJsReadOverlay||this.useJsSourceReadOverlay){this.memfs.setFile(e,t);return}this.memfs.addFile(e,t)}path_open(e,t,n,r,i,a,o,s,c){this.mem.check();let l=this.mem.readStr(n,r),u=this.toNumber(a),d=!!(u&64)||!!(i&9);this.trace(`path_open_request(path=${JSON.stringify(l)}, rights=${u}, oflags=${i}, write=${d})`);let f=!d&&this.shouldUseJsReadForPath(l)&&u&2?this.readMemfsFile(l):null;if(!d&&this.shouldUseJsReadForPath(l)&&u&2&&!f)return this.trace(`path_open_read_missing(path=${JSON.stringify(l)})`),44;let p=0,m;if(this.useJsReadOverlay&&(d||f))m=this.nextHandle++,this.syntheticFileHandles.add(m),this.writeU32(c,m),this.trace(`path_open_overlay(fd=${m}, path=${JSON.stringify(l)})`);else{if(p=this.memfs.exports.path_open(e,t,n,r,i,a,o,s,c),p!==0)return p;m=this.mem.read32(c)}if(d){let e=i&8?null:this.readMemfsFile(l),t=e?Uint8Array.from(e):/* @__PURE__ */ new Uint8Array;return this.writeFileHandles.set(m,{path:l,contents:t,position:0,size:t.length}),this.readFileHandles.delete(m),this.trace(`path_open_write(fd=${m}, path=${JSON.stringify(l)}, size=${t.length})`),p}if(!this.shouldUseJsReadForPath(l)||!(u&2))return p;let h=f||this.readMemfsFile(l);return h?(this.readFileHandles.set(m,{path:l,contents:h,position:0}),this.trace(`path_open_read(fd=${m}, path=${JSON.stringify(l)}, size=${h.length})`),p):p}path_filestat_get(e,t,n,r,i){this.mem.check();let a=this.mem.readStr(n,r);if(!this.shouldUseJsReadForPath(a))return this.memfs.exports.path_filestat_get(e,t,n,r,i);let o=this.readMemfsFile(a);return o?(this.writeRegularFileStat(i,o.length,a),this.trace(`path_filestat_get(path=${JSON.stringify(a)}, size=${o.length})`),0):this.memfs.exports.path_filestat_get(e,t,n,r,i)}fd_fdstat_get(e,t){let n=this.readFileHandles.get(e)||this.writeFileHandles.get(e);if(!n)return this.memfs.exports.fd_fdstat_get(e,t);let r=this.writeFileHandles.has(e)?6291572:2097190;return this.mem.check(),this.mem.write8(t,4),this.mem.write8(t+1,0),this.mem.write8(t+2,0),this.mem.write8(t+3,0),this.writeU64(t+8,r),this.writeU64(t+16,0),this.trace(`fd_fdstat_get(fd=${e}, path=${JSON.stringify(n.path)})`),0}fd_filestat_get(e,t){let n=this.writeFileHandles.get(e),r=this.readFileHandles.get(e),i=n||r;if(!i)return this.memfs.exports.fd_filestat_get(e,t);let a=n?n.size:r?.contents.length||0;return this.writeRegularFileStat(t,a,i.path),this.trace(`fd_filestat_get(fd=${e}, path=${JSON.stringify(i.path)}, size=${a})`),0}fd_filestat_set_size(e,t){let n=this.writeFileHandles.get(e);if(!n)return this.memfs.exports.fd_filestat_set_size(e,t);let r=this.toNumber(t);return this.ensureWriteCapacity(n,r),r>n.size&&n.contents.fill(0,n.size,r),n.size=r,n.position>r&&(n.position=r),this.trace(`fd_filestat_set_size(fd=${e}, size=${r})`),0}fd_read(e,t,n,r){let i=this.readFileHandles.get(e);if(!i)return this.memfs.exports.fd_read(e,t,n,r);let a=this.copyFileToIovs(i.contents,i.position,t,n,r);return i.position=a.position,this.trace(`fd_read(fd=${e}, bytes=${a.copied})`),0}fd_pread(e,t,n,r,i){let a=this.readFileHandles.get(e);if(!a)return this.memfs.exports.fd_pread(e,t,n,r,i);let o=this.copyFileToIovs(a.contents,this.toNumber(r),t,n,i);return this.trace(`fd_pread(fd=${e}, offset=${this.toNumber(r)}, bytes=${o.copied})`),0}fd_seek(e,t,n,r){let i=this.writeFileHandles.get(e);if(i){let a=this.seekPosition(i.position,i.size,t,n);return a==null?this.memfs.exports.fd_seek(e,t,n,r):(i.position=a,this.mem.check(),this.writeU64(r,i.position),this.trace(`fd_seek_write(fd=${e}, offset=${this.toNumber(t)}, whence=${n})`),0)}let a=this.readFileHandles.get(e);if(!a)return this.memfs.exports.fd_seek(e,t,n,r);let o=this.seekPosition(a.position,a.contents.length,t,n);return o==null?this.memfs.exports.fd_seek(e,t,n,r):(a.position=o,this.mem.check(),this.writeU64(r,a.position),this.trace(`fd_seek(fd=${e}, offset=${this.toNumber(t)}, whence=${n})`),0)}fd_tell(e,t){let n=this.writeFileHandles.get(e)?.position??this.readFileHandles.get(e)?.position;if(n==null){let n=this.memfs.exports.fd_tell;return typeof n==`function`?n(e,t):44}return this.mem.check(),this.writeU64(t,n),this.trace(`fd_tell(fd=${e}, offset=${n})`),0}fd_datasync(e){if(this.writeFileHandles.has(e)||this.readFileHandles.has(e))return 0;let t=this.memfs.exports.fd_datasync;return typeof t==`function`?t(e):0}fd_fdstat_set_flags(e,t){if(this.writeFileHandles.has(e)||this.readFileHandles.has(e))return 0;let n=this.memfs.exports.fd_fdstat_set_flags;return typeof n==`function`?n(e,t):0}path_readlink(e,t,n,r,i,a){return this.mem.check(),this.writeU32(a,0),this.trace(`path_readlink(path=${JSON.stringify(this.mem.readStr(t,n))})`),44}path_unlink_file(e,t,n){this.mem.check();let r=this.mem.readStr(t,n);return this.trace(`path_unlink_file(path=${JSON.stringify(r)})`),0}fd_write(e,t,n,r){let i=this.writeFileHandles.get(e);if(!i)return this.memfs.exports.fd_write(e,t,n,r);this.mem.check();let a=0;for(let e=0;e<n;e+=1){let e=this.mem.read32(t);t+=4;let n=this.mem.read32(t);t+=4,!(n<=0)&&(this.ensureWriteCapacity(i,i.position+n),i.contents.set(new Uint8Array(this.mem.buffer,e,n),i.position),i.position+=n,i.size=Math.max(i.size,i.position),a+=n)}return this.writeU32(r,a),this.trace(`fd_write(fd=${e}, bytes=${a})`),0}fd_close(e){let t=this.syntheticFileHandles.delete(e);if(this.readFileHandles.has(e)){this.readFileHandles.delete(e);let n=t?0:this.memfs.exports.fd_close(e);return this.trace(`fd_close_read(fd=${e}, close=${n})`),n}let n=this.writeFileHandles.get(e);if(n){this.writeFileHandles.delete(e);let r=t?0:this.memfs.exports.fd_close(e),i=n.contents.subarray(0,n.size);this.storeFileContents(n.path,i);let a=this.atomicOutputTarget(n.path);return a&&this.storeFileContents(a,i),this.trace(`fd_close_write(fd=${e}, path=${JSON.stringify(n.path)}, size=${n.size}, close=${r}, target=${JSON.stringify(a)})`),0}return t?0:this.memfs.exports.fd_close(e)}debugEvaluate(e){let t=this.debugSession;if(!t)throw Error(`unavailable`);let n=[...t.frames].reverse().find(e=>e.functionId===t.currentFunctionId),r=t.currentLine,i=[...t.variableMetadata[t.currentFunctionId]||[]].reverse().filter(e=>r>=e.fromLine&&r<=e.toLine),a=[...t.globalVariableMetadata||[]].reverse().filter(e=>r>=e.fromLine&&r<=e.toLine);return Zt(e,e=>{let r=(e,t)=>{let n=e.dimensions?.length?e.dimensions:e.length?[e.length]:[],r=Number(t);if(!Number.isFinite(r)||r<=0||!n.length||!e.elementKind&&!e.structFields?.length)throw Error(`unavailable`);this.mem?.check?.();let i=e.structFields?.length&&e.structSize?e.structSize:e.elementKind===`double`?8:e.elementKind===`bool`||e.elementKind===`char`?1:4,a=(e,t)=>{if(e===`bool`)return!!this.mem.read8(t);if(e===`char`){let e=this.mem.read8(t);return e>=32&&e<=126?String.fromCharCode(e):e}return e===`float`?this.mem.readFloat32(t):e===`double`?this.mem.readFloat64(t):this.mem.readInt32(t)},o=t=>({__debugExpressionKind:`object`,has:t=>!!e.structFields?.some(e=>e.name===t),get:n=>{let r=e.structFields?.find(e=>e.name===n);if(!r)throw Error(`unavailable`);return a(r.kind,t+r.offset)},keys:()=>e.structFields?.map(e=>e.name)||[]}),s=(t,n)=>({__debugExpressionKind:`array`,length:n[0],truncated:n[0]>8,get:r=>{if(!Number.isInteger(r)||r<0||r>=n[0])throw Error(`unavailable`);if(n.length>1){let e=n.slice(1).reduce((e,t)=>e*t,1)*i;return s(t+r*e,n.slice(1))}if(e.structFields?.length&&e.structSize)return o(t+r*e.structSize);if(!e.elementKind)throw Error(`unavailable`);return a(e.elementKind,t+r*i)},keys:()=>Array.from({length:Math.min(n[0],8)},(e,t)=>t)});return s(r,n)},o=(e,t)=>{if(t==null||t===`?`)throw Error(`unavailable`);return e.kind===`array`?r(e,t):qt(t)},s=i.find(t=>t.name===e);if(s)return o(s,n?.values.get(s.slot));let c=a.find(t=>t.name===e);if(c)return o(c,t.globalValues.get(c.slot));throw Error(`unavailable`)})}pauseDebugSession(e,t,n,r){let i=e.buffer;if(!i)return 0;e.currentFunctionId=t,e.currentLine=n;let a=[...e.frames].reverse().find(e=>e.functionId===t);a&&(a.line=n),e.pauseOnEntry=!1,e.stepArmed=!1,e.nextLineArmed=!1,e.nextLineDepth=0,e.stepOutArmed=!1,this.trace(`pause(function=${t}, line=${n}, reason=${r})`);let o=e.variableMetadata[t]?.flatMap(e=>{if(n<e.fromLine||n>e.toLine)return[];if(e.kind===`array`){this.mem?.check?.();let t=Number(a?.values.get(e.slot)??NaN),n=e.dimensions?.length?e.dimensions:e.length?[e.length]:[];if(!Number.isFinite(t)||t<=0||!n.length||!e.elementKind&&!e.structFields?.length)return[{name:e.name,value:`?`}];if(e.structFields?.length&&e.structSize){let r=Math.min(n[0],8),i=[];for(let n=0;n<r;n+=1){let r=[];for(let i of e.structFields){let a=t+n*e.structSize+i.offset;if(i.kind===`bool`){r.push(`${i.name}: ${this.mem.read8(a)?`true`:`false`}`);continue}if(i.kind===`char`){let e=this.mem.read8(a);r.push(`${i.name}: ${e>=32&&e<=126?`'${String.fromCharCode(e)}'`:`${e}`}`);continue}if(i.kind===`float`){r.push(`${i.name}: ${this.mem.readFloat32(a)}`);continue}if(i.kind===`double`){r.push(`${i.name}: ${this.mem.readFloat64(a)}`);continue}r.push(`${i.name}: ${this.mem.readInt32(a)}`)}i.push(`{${r.join(`, `)}}`)}return[{name:e.name,value:`[${i.join(`, `)}${n[0]>r?`, ...`:``}]`}]}if(!e.elementKind)return[{name:e.name,value:`?`}];let r=e.elementKind===`double`?8:e.elementKind===`bool`||e.elementKind===`char`?1:4;if(n.length===2){let i=Math.min(n[0],4),a=Math.min(n[1],8),o=[];for(let s=0;s<i;s+=1){let i=[];for(let o=0;o<a;o+=1){let a=t+(s*n[1]+o)*r;if(e.elementKind===`bool`){i.push(this.mem.read8(a)?`true`:`false`);continue}if(e.elementKind===`char`){let e=this.mem.read8(a);i.push(e>=32&&e<=126?`'${String.fromCharCode(e)}'`:`${e}`);continue}if(e.elementKind===`float`){i.push(`${this.mem.readFloat32(a)}`);continue}if(e.elementKind===`double`){i.push(`${this.mem.readFloat64(a)}`);continue}i.push(`${this.mem.readInt32(a)}`)}o.push(`[${i.join(`, `)}${n[1]>a?`, ...`:``}]`)}return[{name:e.name,value:`[${o.join(`, `)}${n[0]>i?`, ...`:``}]`}]}let i=Math.min(n[0],8),o=[];for(let n=0;n<i;n+=1){let i=t+n*r;if(e.elementKind===`bool`){o.push(this.mem.read8(i)?`true`:`false`);continue}if(e.elementKind===`char`){let e=this.mem.read8(i);o.push(e>=32&&e<=126?`'${String.fromCharCode(e)}'`:`${e}`);continue}if(e.elementKind===`float`){o.push(`${this.mem.readFloat32(i)}`);continue}if(e.elementKind===`double`){o.push(`${this.mem.readFloat64(i)}`);continue}o.push(`${this.mem.readInt32(i)}`)}return[{name:e.name,value:`[${o.join(`, `)}${n[0]>i?`, ...`:``}]`}]}let t=a?.values.get(e.slot)??`?`;return[{name:e.name,value:t}]})||[],s=new Set(o.map(e=>e.name)),c=(e.globalVariableMetadata||[]).flatMap(t=>{if(s.has(t.name)||n<t.fromLine||n>t.toLine)return[];if(t.kind===`array`){this.mem?.check?.();let n=Number(e.globalValues?.get(t.slot)??NaN),r=t.dimensions?.length?t.dimensions:t.length?[t.length]:[];if(!Number.isFinite(n)||n<=0||!r.length||!t.elementKind&&!t.structFields?.length)return[{name:t.name,value:`?`}];if(t.structFields?.length&&t.structSize){let e=Math.min(r[0],8),i=[];for(let r=0;r<e;r+=1){let e=[];for(let i of t.structFields){let a=n+r*t.structSize+i.offset;if(i.kind===`bool`){e.push(`${i.name}: ${this.mem.read8(a)?`true`:`false`}`);continue}if(i.kind===`char`){let t=this.mem.read8(a);e.push(`${i.name}: ${t>=32&&t<=126?`'${String.fromCharCode(t)}'`:`${t}`}`);continue}if(i.kind===`float`){e.push(`${i.name}: ${this.mem.readFloat32(a)}`);continue}if(i.kind===`double`){e.push(`${i.name}: ${this.mem.readFloat64(a)}`);continue}e.push(`${i.name}: ${this.mem.readInt32(a)}`)}i.push(`{${e.join(`, `)}}`)}return[{name:t.name,value:`[${i.join(`, `)}${r[0]>e?`, ...`:``}]`}]}if(!t.elementKind)return[{name:t.name,value:`?`}];let i=t.elementKind===`double`?8:t.elementKind===`bool`||t.elementKind===`char`?1:4;if(r.length===2){let e=Math.min(r[0],4),a=Math.min(r[1],8),o=[];for(let s=0;s<e;s+=1){let e=[];for(let o=0;o<a;o+=1){let a=n+(s*r[1]+o)*i;if(t.elementKind===`bool`){e.push(this.mem.read8(a)?`true`:`false`);continue}if(t.elementKind===`char`){let t=this.mem.read8(a);e.push(t>=32&&t<=126?`'${String.fromCharCode(t)}'`:`${t}`);continue}if(t.elementKind===`float`){e.push(`${this.mem.readFloat32(a)}`);continue}if(t.elementKind===`double`){e.push(`${this.mem.readFloat64(a)}`);continue}e.push(`${this.mem.readInt32(a)}`)}o.push(`[${e.join(`, `)}${r[1]>a?`, ...`:``}]`)}return[{name:t.name,value:`[${o.join(`, `)}${r[0]>e?`, ...`:``}]`}]}let a=Math.min(r[0],8),o=[];for(let e=0;e<a;e+=1){let r=n+e*i;if(t.elementKind===`bool`){o.push(this.mem.read8(r)?`true`:`false`);continue}if(t.elementKind===`char`){let e=this.mem.read8(r);o.push(e>=32&&e<=126?`'${String.fromCharCode(e)}'`:`${e}`);continue}if(t.elementKind===`float`){o.push(`${this.mem.readFloat32(r)}`);continue}if(t.elementKind===`double`){o.push(`${this.mem.readFloat64(r)}`);continue}o.push(`${this.mem.readInt32(r)}`)}return[{name:t.name,value:`[${o.join(`, `)}${r[0]>a?`, ...`:``}]`}]}let r=e.globalValues?.get(t.slot)??`?`;return[{name:t.name,value:r}]})||[],l=new Map(o.map(e=>[e.name,e])),u=new Map(c.map(e=>[e.name,e]));for(let e of l.keys())u.delete(e);e.onPause?.({type:`pause`,line:n,reason:r,locals:[...l.values(),...u.values()],callStack:[...e.frames].reverse().map(e=>({functionName:e.functionName,line:e.line}))});let d=Atomics.load(i,0);for(;;){if(e.interruptBuffer?.[0]===2||(Atomics.wait(i,0,d,100),e.interruptBuffer?.[0]===2))throw new Rt;let t=Atomics.exchange(i,1,0);if(t===1)return e.resumeSkipActive=!0,e.resumeSkipFunctionId=e.currentFunctionId,e.resumeSkipLine=e.currentLine,0;if(t===2)return e.stepArmed=!0,e.resumeSkipActive=!0,e.resumeSkipFunctionId=e.currentFunctionId,e.resumeSkipLine=e.currentLine,0;if(t===3)return e.nextLineArmed=!0,e.nextLineFunctionId=e.currentFunctionId,e.nextLineLine=e.currentLine,e.nextLineDepth=e.callDepth,e.resumeSkipActive=!0,e.resumeSkipFunctionId=e.currentFunctionId,e.resumeSkipLine=e.currentLine,0;if(t===4)return e.stepOutArmed=!0,e.stepOutDepth=Math.max(0,e.callDepth-1),e.resumeSkipActive=!0,e.resumeSkipFunctionId=e.currentFunctionId,e.resumeSkipLine=e.currentLine,0;if(t===5){let t=e.watchBuffer?on(e.watchBuffer):``,n=`?`;try{n=t?this.debugEvaluate(t):`?`}catch(e){n=e instanceof Error&&e.message===`unavailable`?`?`:`error`}e.watchResultBuffer&&an([n],e.watchResultBuffer)}}}__wasm_idle_debug_enter(e,t){let n=this.debugSession;return n?.buffer?(n.callDepth+=1,n.currentFunctionId=e,n.currentLine=t,n.frames.push({functionId:e,functionName:n.functionMetadata[e]||`fn_${e}`,line:t,values:/* @__PURE__ */ new Map}),this.trace(`enter(function=${e}, line=${t}, depth=${n.callDepth})`),n.pauseOnEntry?this.pauseDebugSession(n,e,t,`entry`):n.stepArmed?this.pauseDebugSession(n,e,t,`step`):0):0}__wasm_idle_debug_leave(e){let t=this.debugSession;if(!t?.buffer)return 0;this.trace(`leave(function=${e}, depth=${t.callDepth})`),t.nextLineArmed&&e===t.nextLineFunctionId&&t.callDepth<=(t.nextLineDepth??t.callDepth)&&(t.nextLineArmed=!1,t.nextLineDepth=0,t.stepArmed=!0),t.callDepth=Math.max(0,t.callDepth-1),t.currentFunctionId===e&&(t.currentFunctionId=0);for(let n=t.frames.length-1;n>=0;--n)if(t.frames[n]?.functionId===e){t.frames.splice(n,1);break}return 0}__wasm_idle_debug_value_num(e,t,n){let r=this.debugSession;if(!r?.buffer)return 0;if(e===0)return r.globalValues.set(t,Number.isInteger(n)?String(n):`${n}`),0;for(let i=r.frames.length-1;i>=0;--i){let a=r.frames[i];if(a?.functionId===e){a.values.set(t,Number.isInteger(n)?String(n):`${n}`);break}}return 0}__wasm_idle_debug_value_bool(e,t,n){let r=this.debugSession;if(!r?.buffer)return 0;if(e===0)return r.globalValues.set(t,n?`true`:`false`),0;for(let i=r.frames.length-1;i>=0;--i){let a=r.frames[i];if(a?.functionId===e){a.values.set(t,n?`true`:`false`);break}}return 0}__wasm_idle_debug_value_addr(e,t,n){let r=this.debugSession;if(!r?.buffer)return 0;if(e===0)return r.globalValues.set(t,String(n>>>0)),0;for(let i=r.frames.length-1;i>=0;--i){let a=r.frames[i];if(a?.functionId===e){a.values.set(t,String(n>>>0));break}}return 0}__wasm_idle_debug_value_text(e,t,n,r){let i=this.debugSession;if(!i?.buffer)return 0;this.mem?.check?.();let a=this.mem?.readStr?this.mem.readStr(n,r):`?`;if(e===0)return i.globalValues.set(t,a),0;for(let n=i.frames.length-1;n>=0;--n){let r=i.frames[n];if(r?.functionId===e){r.values.set(t,a);break}}return 0}__wasm_idle_debug_line(e,t){let n=this.debugSession;if(!n?.buffer)return 0;let r=Atomics.load(n.buffer,2);if(r!==n.breakpointVersion){let e=Math.max(0,Atomics.load(n.buffer,3)),t=/* @__PURE__ */ new Set;for(let r=0;r<e&&r+4<n.buffer.length;r+=1){let e=Atomics.load(n.buffer,r+4);e>0&&t.add(e)}n.breakpoints=t,n.breakpointVersion=r}if(n.resumeSkipActive){if(e===n.resumeSkipFunctionId&&t===n.resumeSkipLine)return 0;n.resumeSkipActive=!1,n.resumeSkipFunctionId=0,n.resumeSkipLine=0}let i=``;return n.pauseOnEntry?i=`entry`:n.breakpoints.has(t)?i=`breakpoint`:n.stepArmed?i=`step`:n.nextLineArmed&&n.callDepth<=(n.nextLineDepth??n.callDepth)&&e===n.nextLineFunctionId&&t!==n.nextLineLine?i=`nextLine`:n.stepOutArmed&&n.callDepth<=n.stepOutDepth&&(i=`stepOut`),i?this.pauseDebugSession(n,e,t,i):0}environ_sizes_get(e,t){this.mem.check();let n=0,r=Object.getOwnPropertyNames(this.environ);for(let e of r){let t=this.environ[e];n+=e.length+t.length+2}return this.mem.write32(e,r.length),this.mem.write32(t,n),this.trace(`environ_sizes_get(count=${r.length}, bytes=${n})`),0}environ_get(e,t){this.mem.check();let n=Object.getOwnPropertyNames(this.environ);this.trace(`environ_get(entries=${JSON.stringify(n)})`);for(let r of n)this.mem.write32(e,t),e+=4,t+=this.mem.writeStr(t,`${r}=${this.environ[r]}`);return 0}args_sizes_get(e,t){this.mem.check();let n=0;for(let e of this.argv)n+=e.length+1;return this.mem.write32(e,this.argv.length),this.mem.write32(t,n),this.trace(`args_sizes_get(count=${this.argv.length}, bytes=${n})`),0}args_get(e,t){this.mem.check(),this.trace(`args_get(argv=${JSON.stringify(this.argv)})`);for(let n of this.argv)this.mem.write32(e,t),e+=4,t+=this.mem.writeStr(t,n);return 0}random_get(e,t){let n=new Uint8Array(this.mem.buffer,e,t);for(let e=0;e<t;++e)n[e]=Math.random()*256|0}clock_time_get(e,t,n){this.mem.check();let r=e===1&&typeof performance<`u`?performance.now():Date.now(),i=BigInt(Math.floor(r*1e6));return this.mem.view.setBigUint64(n,i,!0),this.trace(`clock_time_get(clock=${e}, ns=${i})`),0}poll_oneoff(){throw new Lt(`wasi_unstable`,`poll_oneoff`)}fd_filestat_set_times(){return this.trace(`fd_filestat_set_times()`),0}path_filestat_set_times(){return this.trace(`path_filestat_set_times()`),0}sock_accept(){return this.trace(`sock_accept() unsupported`),58}sock_recv(){return this.trace(`sock_recv() unsupported`),58}sock_send(){return this.trace(`sock_send() unsupported`),58}sock_shutdown(){return this.trace(`sock_shutdown() unsupported`),58}path_link(e,t,n,r,i,a,o){this.mem.check();let s=this.mem.readStr(n,r).replace(/^\/+/,``),c=this.mem.readStr(a,o).replace(/^\/+/,``);return this.trace(`path_link(source=${JSON.stringify(s)}, target=${JSON.stringify(c)})`),this.storeFileContents(c,new Uint8Array(this.memfs.getFileContents(s))),0}path_rename(e,t,n,r,i,a){this.mem.check();let o=this.mem.readStr(t,n).replace(/^\/+/,``),s=this.mem.readStr(i,a).replace(/^\/+/,``);return this.trace(`path_rename(source=${JSON.stringify(o)}, target=${JSON.stringify(s)})`),this.storeFileContents(s,new Uint8Array(this.memfs.getFileContents(o))),0}};const cn=String.raw`#ifndef WASM_CLANG_EXT_PB_DS_TREE_POLICY_HPP
#define WASM_CLANG_EXT_PB_DS_TREE_POLICY_HPP

#include <cstddef>

namespace __gnu_pbds {

struct null_type {};
struct rb_tree_tag {};
struct splay_tree_tag {};
struct ov_tree_tag {};

template <typename Node_CItr, typename Node_Itr, typename Cmp_Fn, typename Allocator>
class null_node_update {
public:
	typedef Node_CItr node_const_iterator;
	typedef Node_Itr node_iterator;
	typedef Cmp_Fn cmp_fn;
	typedef Allocator allocator_type;
};

template <typename Node_CItr, typename Node_Itr, typename Cmp_Fn, typename Allocator>
class tree_order_statistics_node_update {
public:
	typedef Node_CItr node_const_iterator;
	typedef Node_Itr node_iterator;
	typedef Cmp_Fn cmp_fn;
	typedef Allocator allocator_type;
};

} // namespace __gnu_pbds

#endif
`,ln=String.raw`#ifndef WASM_CLANG_EXT_PB_DS_ASSOC_CONTAINER_HPP
#define WASM_CLANG_EXT_PB_DS_ASSOC_CONTAINER_HPP

#include <algorithm>
#include <cstddef>
#include <functional>
#include <iterator>
#include <map>
#include <memory>
#include <set>
#include <type_traits>
#include <unordered_map>
#include <unordered_set>
#include <utility>
#include <ext/pb_ds/tree_policy.hpp>

namespace __gnu_pbds {

namespace detail {

template <typename Allocator, typename Value>
struct rebind_allocator {
	typedef typename std::allocator_traits<Allocator>::template rebind_alloc<Value> type;
};

template <typename Iterator>
Iterator advance_to_order(Iterator first, Iterator last, std::size_t order) {
	if (order >= static_cast<std::size_t>(std::distance(first, last))) return last;
	std::advance(
		first,
		static_cast<typename std::iterator_traits<Iterator>::difference_type>(order)
	);
	return first;
}

template <
	typename Key,
	typename Mapped,
	typename Hash_Fn,
	typename Eq_Fn,
	typename Allocator
>
struct hash_table_selector {
	typedef std::pair<const Key, Mapped> value_type;
	typedef typename rebind_allocator<Allocator, value_type>::type allocator_type;
	typedef std::unordered_map<Key, Mapped, Hash_Fn, Eq_Fn, allocator_type> type;
};

template <typename Key, typename Hash_Fn, typename Eq_Fn, typename Allocator>
struct hash_table_selector<Key, null_type, Hash_Fn, Eq_Fn, Allocator> {
	typedef typename rebind_allocator<Allocator, Key>::type allocator_type;
	typedef std::unordered_set<Key, Hash_Fn, Eq_Fn, allocator_type> type;
};

} // namespace detail

template <
	typename Key,
	typename Mapped,
	typename Cmp_Fn = std::less<Key>,
	typename Tag = rb_tree_tag,
	template <typename Node_CItr, typename Node_Itr, typename Cmp_Fn_, typename Allocator_>
	class Node_Update = null_node_update,
	typename Allocator = std::allocator<char>
>
class tree {
public:
	typedef Key key_type;
	typedef Mapped mapped_type;
	typedef std::pair<const Key, Mapped> value_type;
	typedef Cmp_Fn cmp_fn;
	typedef Tag container_category;
	typedef Allocator allocator_type;
	typedef std::size_t size_type;

private:
	typedef typename detail::rebind_allocator<Allocator, value_type>::type value_allocator_type;
	typedef std::map<Key, Mapped, Cmp_Fn, value_allocator_type> container_type;

public:
	typedef typename container_type::iterator iterator;
	typedef typename container_type::const_iterator const_iterator;
	typedef typename container_type::iterator point_iterator;
	typedef typename container_type::const_iterator const_point_iterator;
	typedef typename container_type::reverse_iterator reverse_iterator;
	typedef typename container_type::const_reverse_iterator const_reverse_iterator;

	tree() = default;
	explicit tree(const Cmp_Fn& compare) : values_(compare) {}

	template <typename InputIt>
	tree(InputIt first, InputIt last) : values_(first, last) {}

	bool empty() const { return values_.empty(); }
	size_type size() const { return values_.size(); }
	size_type max_size() const { return values_.max_size(); }

	iterator begin() { return values_.begin(); }
	const_iterator begin() const { return values_.begin(); }
	const_iterator cbegin() const { return values_.cbegin(); }
	iterator end() { return values_.end(); }
	const_iterator end() const { return values_.end(); }
	const_iterator cend() const { return values_.cend(); }
	reverse_iterator rbegin() { return values_.rbegin(); }
	const_reverse_iterator rbegin() const { return values_.rbegin(); }
	reverse_iterator rend() { return values_.rend(); }
	const_reverse_iterator rend() const { return values_.rend(); }

	std::pair<iterator, bool> insert(const value_type& value) { return values_.insert(value); }
	std::pair<iterator, bool> insert(value_type&& value) { return values_.insert(std::move(value)); }

	template <typename InputIt>
	void insert(InputIt first, InputIt last) {
		values_.insert(first, last);
	}

	mapped_type& operator[](const key_type& key) { return values_[key]; }
	mapped_type& at(const key_type& key) { return values_.at(key); }
	const mapped_type& at(const key_type& key) const { return values_.at(key); }

	iterator find(const key_type& key) { return values_.find(key); }
	const_iterator find(const key_type& key) const { return values_.find(key); }
	bool contains(const key_type& key) const { return values_.find(key) != values_.end(); }
	size_type count(const key_type& key) const { return values_.count(key); }

	iterator lower_bound(const key_type& key) { return values_.lower_bound(key); }
	const_iterator lower_bound(const key_type& key) const { return values_.lower_bound(key); }
	iterator upper_bound(const key_type& key) { return values_.upper_bound(key); }
	const_iterator upper_bound(const key_type& key) const { return values_.upper_bound(key); }

	size_type erase(const key_type& key) { return values_.erase(key); }
	iterator erase(const_iterator position) { return values_.erase(position); }
	iterator erase(const_iterator first, const_iterator last) { return values_.erase(first, last); }
	void clear() { values_.clear(); }
	void swap(tree& other) { values_.swap(other.values_); }

	iterator find_by_order(size_type order) {
		return detail::advance_to_order(values_.begin(), values_.end(), order);
	}

	const_iterator find_by_order(size_type order) const {
		return detail::advance_to_order(values_.begin(), values_.end(), order);
	}

	size_type order_of_key(const key_type& key) const {
		return static_cast<size_type>(std::distance(values_.begin(), values_.lower_bound(key)));
	}

	void join(tree& other) {
		values_.insert(other.values_.begin(), other.values_.end());
		other.values_.clear();
	}

	void split(const key_type& key, tree& other) {
		iterator first = values_.upper_bound(key);
		other.values_.insert(first, values_.end());
		values_.erase(first, values_.end());
	}

private:
	container_type values_;
};

template <
	typename Key,
	typename Cmp_Fn,
	typename Tag,
	template <typename Node_CItr, typename Node_Itr, typename Cmp_Fn_, typename Allocator_>
	class Node_Update,
	typename Allocator
>
class tree<Key, null_type, Cmp_Fn, Tag, Node_Update, Allocator> {
public:
	typedef Key key_type;
	typedef null_type mapped_type;
	typedef Key value_type;
	typedef Cmp_Fn cmp_fn;
	typedef Tag container_category;
	typedef Allocator allocator_type;
	typedef std::size_t size_type;

private:
	typedef typename detail::rebind_allocator<Allocator, value_type>::type value_allocator_type;
	typedef std::set<Key, Cmp_Fn, value_allocator_type> container_type;

public:
	typedef typename container_type::iterator iterator;
	typedef typename container_type::const_iterator const_iterator;
	typedef typename container_type::iterator point_iterator;
	typedef typename container_type::const_iterator const_point_iterator;
	typedef typename container_type::reverse_iterator reverse_iterator;
	typedef typename container_type::const_reverse_iterator const_reverse_iterator;

	tree() = default;
	explicit tree(const Cmp_Fn& compare) : values_(compare) {}

	template <typename InputIt>
	tree(InputIt first, InputIt last) : values_(first, last) {}

	bool empty() const { return values_.empty(); }
	size_type size() const { return values_.size(); }
	size_type max_size() const { return values_.max_size(); }

	iterator begin() { return values_.begin(); }
	const_iterator begin() const { return values_.begin(); }
	const_iterator cbegin() const { return values_.cbegin(); }
	iterator end() { return values_.end(); }
	const_iterator end() const { return values_.end(); }
	const_iterator cend() const { return values_.cend(); }
	reverse_iterator rbegin() { return values_.rbegin(); }
	const_reverse_iterator rbegin() const { return values_.rbegin(); }
	reverse_iterator rend() { return values_.rend(); }
	const_reverse_iterator rend() const { return values_.rend(); }

	std::pair<iterator, bool> insert(const value_type& value) { return values_.insert(value); }
	std::pair<iterator, bool> insert(value_type&& value) { return values_.insert(std::move(value)); }

	template <typename InputIt>
	void insert(InputIt first, InputIt last) {
		values_.insert(first, last);
	}

	iterator find(const key_type& key) { return values_.find(key); }
	const_iterator find(const key_type& key) const { return values_.find(key); }
	bool contains(const key_type& key) const { return values_.find(key) != values_.end(); }
	size_type count(const key_type& key) const { return values_.count(key); }

	iterator lower_bound(const key_type& key) { return values_.lower_bound(key); }
	const_iterator lower_bound(const key_type& key) const { return values_.lower_bound(key); }
	iterator upper_bound(const key_type& key) { return values_.upper_bound(key); }
	const_iterator upper_bound(const key_type& key) const { return values_.upper_bound(key); }

	size_type erase(const key_type& key) { return values_.erase(key); }
	iterator erase(const_iterator position) { return values_.erase(position); }
	iterator erase(const_iterator first, const_iterator last) { return values_.erase(first, last); }
	void clear() { values_.clear(); }
	void swap(tree& other) { values_.swap(other.values_); }

	iterator find_by_order(size_type order) {
		return detail::advance_to_order(values_.begin(), values_.end(), order);
	}

	const_iterator find_by_order(size_type order) const {
		return detail::advance_to_order(values_.begin(), values_.end(), order);
	}

	size_type order_of_key(const key_type& key) const {
		return static_cast<size_type>(std::distance(values_.begin(), values_.lower_bound(key)));
	}

	void join(tree& other) {
		values_.insert(other.values_.begin(), other.values_.end());
		other.values_.clear();
	}

	void split(const key_type& key, tree& other) {
		iterator first = values_.upper_bound(key);
		other.values_.insert(first, values_.end());
		values_.erase(first, values_.end());
	}

private:
	container_type values_;
};

template <
	typename Key,
	typename Mapped,
	typename Hash_Fn = std::hash<Key>,
	typename Eq_Fn = std::equal_to<Key>,
	typename Comb_Hash_Fn = void,
	typename Resize_Policy = void,
	bool Store_Hash = false,
	typename Allocator = std::allocator<char>
>
using gp_hash_table = typename detail::hash_table_selector<
	Key,
	Mapped,
	Hash_Fn,
	Eq_Fn,
	Allocator
>::type;

template <
	typename Key,
	typename Mapped,
	typename Hash_Fn = std::hash<Key>,
	typename Eq_Fn = std::equal_to<Key>,
	typename Comb_Hash_Fn = void,
	typename Resize_Policy = void,
	bool Store_Hash = false,
	typename Allocator = std::allocator<char>
>
using cc_hash_table = typename detail::hash_table_selector<
	Key,
	Mapped,
	Hash_Fn,
	Eq_Fn,
	Allocator
>::type;

} // namespace __gnu_pbds

#endif
`,un=String.raw`#ifndef WASM_CLANG_EXT_PB_DS_HASH_POLICY_HPP
#define WASM_CLANG_EXT_PB_DS_HASH_POLICY_HPP

#include <cstddef>

namespace __gnu_pbds {

template <typename Size_Type = std::size_t>
class direct_mask_range_hashing {
public:
	typedef Size_Type size_type;
};

template <typename Size_Type = std::size_t>
class direct_mod_range_hashing {
public:
	typedef Size_Type size_type;
};

template <typename Size_Type = std::size_t>
class linear_probe_fn {
public:
	typedef Size_Type size_type;
};

template <typename Size_Type = std::size_t>
class quadratic_probe_fn {
public:
	typedef Size_Type size_type;
};

class hash_exponential_size_policy {};
class hash_prime_size_policy {};

template <bool External_Load_Access = false, typename Size_Type = std::size_t>
class hash_load_check_resize_trigger {
public:
	typedef Size_Type size_type;
	explicit hash_load_check_resize_trigger(float = 0.125, float = 0.5) {}
};

template <bool External_Load_Access = false, typename Size_Type = std::size_t>
class cc_hash_max_collision_check_resize_trigger {
public:
	typedef Size_Type size_type;
	explicit cc_hash_max_collision_check_resize_trigger(float = 0.5) {}
};

template <
	typename Size_Policy = hash_exponential_size_policy,
	typename Trigger_Policy = hash_load_check_resize_trigger<>,
	bool External_Size_Access = false,
	typename Size_Type = std::size_t
>
class hash_standard_resize_policy {
public:
	typedef Size_Type size_type;
	hash_standard_resize_policy() = default;
	explicit hash_standard_resize_policy(const Size_Policy&) {}
	hash_standard_resize_policy(const Size_Policy&, const Trigger_Policy&) {}
};

} // namespace __gnu_pbds

#endif
`,dn=String.raw`#ifndef WASM_CLANG_EXT_PB_DS_PRIORITY_QUEUE_HPP
#define WASM_CLANG_EXT_PB_DS_PRIORITY_QUEUE_HPP

#include <algorithm>
#include <cstddef>
#include <functional>
#include <memory>
#include <queue>
#include <utility>
#include <vector>

namespace __gnu_pbds {

struct pairing_heap_tag {};
struct binary_heap_tag {};
struct binomial_heap_tag {};
struct rc_binomial_heap_tag {};
struct thin_heap_tag {};

namespace detail {

template <typename Allocator, typename Value>
struct priority_queue_rebind_allocator {
	typedef typename std::allocator_traits<Allocator>::template rebind_alloc<Value> type;
};

} // namespace detail

template <
	typename Value_Type,
	typename Cmp_Fn = std::less<Value_Type>,
	typename Tag = pairing_heap_tag,
	typename Allocator = std::allocator<char>
>
class priority_queue {
public:
	typedef Value_Type value_type;
	typedef Cmp_Fn cmp_fn;
	typedef Tag container_category;
	typedef Allocator allocator_type;
	typedef std::size_t size_type;
	typedef value_type& reference;
	typedef const value_type& const_reference;

private:
	typedef typename detail::priority_queue_rebind_allocator<Allocator, value_type>::type value_allocator_type;
	typedef std::vector<value_type, value_allocator_type> container_type;

public:
	typedef typename container_type::iterator point_iterator;
	typedef typename container_type::const_iterator const_point_iterator;

	priority_queue() : values_(), compare_() {
		std::make_heap(values_.begin(), values_.end(), compare_);
	}

	explicit priority_queue(const Cmp_Fn& compare) : values_(), compare_(compare) {
		std::make_heap(values_.begin(), values_.end(), compare_);
	}

	template <typename InputIt>
	priority_queue(InputIt first, InputIt last) : values_(first, last), compare_() {
		std::make_heap(values_.begin(), values_.end(), compare_);
	}

	bool empty() const { return values_.empty(); }
	size_type size() const { return values_.size(); }
	const_reference top() const { return values_.front(); }
	void clear() { values_.clear(); }
	void swap(priority_queue& other) {
		values_.swap(other.values_);
		std::swap(compare_, other.compare_);
	}

	point_iterator push(const_reference value) {
		values_.push_back(value);
		std::push_heap(values_.begin(), values_.end(), compare_);
		return values_.empty() ? values_.end() : values_.begin();
	}

	void pop() {
		std::pop_heap(values_.begin(), values_.end(), compare_);
		values_.pop_back();
	}

	void modify(point_iterator position, const_reference value) {
		if (position == values_.end()) return;
		*position = value;
		std::make_heap(values_.begin(), values_.end(), compare_);
	}

	void erase(point_iterator position) {
		if (position == values_.end()) return;
		values_.erase(position);
		std::make_heap(values_.begin(), values_.end(), compare_);
	}

	void join(priority_queue& other) {
		values_.insert(values_.end(), other.values_.begin(), other.values_.end());
		other.values_.clear();
		std::make_heap(values_.begin(), values_.end(), compare_);
	}

private:
	container_type values_;
	Cmp_Fn compare_;
};

} // namespace __gnu_pbds

#endif
`,fn=String.raw`#ifndef WASM_CLANG_EXT_ROPE
#define WASM_CLANG_EXT_ROPE

#include <algorithm>
#include <cstddef>
#include <iosfwd>
#include <iterator>
#include <memory>
#include <ostream>
#include <string>
#include <utility>

namespace __gnu_cxx {

template <typename CharT, typename Alloc = std::allocator<CharT>>
class rope {
public:
	typedef CharT value_type;
	typedef Alloc allocator_type;
	typedef std::basic_string<CharT, std::char_traits<CharT>, Alloc> string_type;
	typedef typename string_type::traits_type traits_type;
	typedef typename string_type::size_type size_type;
	typedef typename string_type::difference_type difference_type;
	typedef typename string_type::reference reference;
	typedef typename string_type::const_reference const_reference;
	typedef typename string_type::iterator iterator;
	typedef typename string_type::const_iterator const_iterator;

	static const size_type npos = string_type::npos;

	rope() = default;
	rope(const rope&) = default;
	rope(rope&&) = default;
	rope& operator=(const rope&) = default;
	rope& operator=(rope&&) = default;

	rope(const CharT* value) : data_(value ? value : empty_c_str()) {}
	rope(const CharT* value, size_type count) : data_(value, count) {}
	rope(size_type count, CharT value) : data_(count, value) {}
	rope(const string_type& value) : data_(value) {}
	rope(string_type&& value) : data_(std::move(value)) {}

	template <typename InputIt>
	rope(InputIt first, InputIt last) : data_(first, last) {}

	bool empty() const { return data_.empty(); }
	size_type size() const { return data_.size(); }
	size_type length() const { return data_.length(); }
	size_type max_size() const { return data_.max_size(); }
	void clear() { data_.clear(); }

	const CharT* c_str() const { return data_.c_str(); }
	const string_type& str() const { return data_; }

	iterator begin() { return data_.begin(); }
	const_iterator begin() const { return data_.begin(); }
	const_iterator cbegin() const { return data_.cbegin(); }
	iterator end() { return data_.end(); }
	const_iterator end() const { return data_.end(); }
	const_iterator cend() const { return data_.cend(); }

	reference operator[](size_type index) { return data_[index]; }
	const_reference operator[](size_type index) const { return data_[index]; }
	reference at(size_type index) { return data_.at(index); }
	const_reference at(size_type index) const { return data_.at(index); }
	reference mutable_reference_at(size_type index) { return data_.at(index); }

	void push_back(CharT value) { data_.push_back(value); }
	void pop_back() { data_.pop_back(); }

	rope& append(const rope& value) {
		data_.append(value.data_);
		return *this;
	}

	rope& append(const CharT* value) {
		data_.append(value ? value : empty_c_str());
		return *this;
	}

	rope& append(const CharT* value, size_type count) {
		data_.append(value, count);
		return *this;
	}

	rope& append(size_type count, CharT value) {
		data_.append(count, value);
		return *this;
	}

	rope& insert(size_type position, const rope& value) {
		data_.insert(position, value.data_);
		return *this;
	}

	rope& insert(size_type position, const CharT* value) {
		data_.insert(position, value ? value : empty_c_str());
		return *this;
	}

	rope& insert(size_type position, const CharT* value, size_type count) {
		data_.insert(position, value, count);
		return *this;
	}

	rope& insert(size_type position, size_type count, CharT value) {
		data_.insert(position, count, value);
		return *this;
	}

	rope& erase(size_type position = 0, size_type count = npos) {
		data_.erase(position, count);
		return *this;
	}

	rope& replace(size_type position, size_type count, const rope& value) {
		data_.replace(position, count, value.data_);
		return *this;
	}

	rope& replace(size_type position, size_type count, const CharT* value) {
		data_.replace(position, count, value ? value : empty_c_str());
		return *this;
	}

	rope substr(size_type position = 0, size_type count = npos) const {
		return rope(data_.substr(position, count));
	}

	size_type copy(size_type position, size_type count, CharT* target) const {
		if (position > data_.size()) return 0;
		const size_type copied = std::min(count, data_.size() - position);
		traits_type::copy(target, data_.data() + position, copied);
		return copied;
	}

	int compare(const rope& value) const { return data_.compare(value.data_); }

	rope& operator+=(const rope& value) { return append(value); }
	rope& operator+=(const CharT* value) { return append(value); }
	rope& operator+=(CharT value) {
		push_back(value);
		return *this;
	}

private:
	static const CharT* empty_c_str() {
		static const CharT empty[1] = {};
		return empty;
	}

	string_type data_;
};

template <typename CharT, typename Alloc>
rope<CharT, Alloc> operator+(rope<CharT, Alloc> left, const rope<CharT, Alloc>& right) {
	left += right;
	return left;
}

template <typename CharT, typename Alloc>
bool operator==(const rope<CharT, Alloc>& left, const rope<CharT, Alloc>& right) {
	return left.compare(right) == 0;
}

template <typename CharT, typename Alloc>
bool operator!=(const rope<CharT, Alloc>& left, const rope<CharT, Alloc>& right) {
	return !(left == right);
}

template <typename CharT, typename Alloc>
bool operator<(const rope<CharT, Alloc>& left, const rope<CharT, Alloc>& right) {
	return left.compare(right) < 0;
}

template <typename CharT, typename Alloc>
std::basic_ostream<CharT>& operator<<(
	std::basic_ostream<CharT>& output,
	const rope<CharT, Alloc>& value
) {
	return output << value.str();
}

typedef rope<char> crope;
typedef rope<wchar_t> wrope;

} // namespace __gnu_cxx

#endif
`,pn=String.raw`#ifndef WASM_CLANG_SETJMP_H
#define WASM_CLANG_SETJMP_H

#ifdef __cplusplus
extern "C" {
#endif

typedef long jmp_buf[32];
int setjmp(jmp_buf);
__attribute__((noreturn)) void longjmp(jmp_buf, int);

#ifdef __cplusplus
}
#endif

#endif
`,mn=String.raw`#ifndef WASM_CLANG_BITS_STDCPP_H
#define WASM_CLANG_BITS_STDCPP_H

#include <algorithm>
#include <array>
#include <bitset>
#include <cassert>
#include <cctype>
#include <cerrno>
#include <cfloat>
#include <climits>
#include <cmath>
#include <cstddef>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <deque>
#include <functional>
#include <iomanip>
#include <iostream>
#include <iterator>
#include <limits>
#include <list>
#include <map>
#include <memory>
#include <numeric>
#include <queue>
#include <set>
#include <sstream>
#include <stack>
#include <string>
#include <string_view>
#include <tuple>
#include <type_traits>
#include <unordered_map>
#include <unordered_set>
#include <utility>
#include <vector>

#endif
`,hn=String.raw`#ifndef WASM_CLANG_BITS_EXTCXX_H
#define WASM_CLANG_BITS_EXTCXX_H

#include <bits/stdc++.h>
#include <ext/hash_map>
#include <ext/hash_set>
#include <ext/rope>
#include <ext/pb_ds/assoc_container.hpp>
#include <ext/pb_ds/hash_policy.hpp>
#include <ext/pb_ds/priority_queue.hpp>
#include <ext/pb_ds/tree_policy.hpp>

#endif
`,gn=[{path:`include/setjmp.h`,contents:pn},{path:`include/bits/stdc++.h`,contents:mn},{path:`include/bits/extc++.h`,contents:hn},{path:`include/c++/v1/ext/rope`,contents:fn},{path:`include/c++/v1/ext/pb_ds/tree_policy.hpp`,contents:cn},{path:`include/c++/v1/ext/pb_ds/assoc_container.hpp`,contents:ln},{path:`include/c++/v1/ext/pb_ds/hash_policy.hpp`,contents:un},{path:`include/c++/v1/ext/pb_ds/priority_queue.hpp`,contents:dn}];function _n(e){e.addDirectory(`include/c++/v1/ext/pb_ds`),e.addDirectory(`include/bits`);for(let t of gn)e.addFile(t.path,t.contents)}const vn=Object.freeze({"builtins.h":`/*===---- builtins.h - Standard header for extra builtins -----------------===*\\
 *
 * Part of the LLVM Project, under the Apache License v2.0 with LLVM Exceptions.
 * See https://llvm.org/LICENSE.txt for license information.
 * SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception
 *
\\*===----------------------------------------------------------------------===*/

/// Some legacy compilers have builtin definitions in a file named builtins.h.
/// This header file has been added to allow compatibility with code that was
/// written for those compilers. Code may have an include line for this file
/// and to avoid an error an empty file with this name is provided.
#ifndef __BUILTINS_H
#define __BUILTINS_H

#if defined(__MVS__) && __has_include_next(<builtins.h>)
#include_next <builtins.h>
#endif /* __MVS__ */
#endif /* __BUILTINS_H */
`,"float.h":`/*===---- float.h - Characteristics of floating point types ----------------===
 *
 * Part of the LLVM Project, under the Apache License v2.0 with LLVM Exceptions.
 * See https://llvm.org/LICENSE.txt for license information.
 * SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception
 *
 *===-----------------------------------------------------------------------===
 */

#if defined(__MVS__) && __has_include_next(<float.h>)
#include <__float_header_macro.h>
#include_next <float.h>
#else

#if !defined(__need_infinity_nan)
#define __need_float_float
#if (defined(__STDC_VERSION__) && __STDC_VERSION__ >= 202311L) ||              \\
    !defined(__STRICT_ANSI__)
#define __need_infinity_nan
#endif
#include <__float_header_macro.h>
#endif

#ifdef __need_float_float
/* If we're on MinGW, fall back to the system's float.h, which might have
 * additional definitions provided for Windows.
 * For more details see http://msdn.microsoft.com/en-us/library/y0ybw9fy.aspx
 *
 * Also fall back on AIX to allow additional definitions and
 * implementation-defined values.
 */
#if (defined(__MINGW32__) || defined(_MSC_VER) || defined(_AIX)) &&            \\
    __STDC_HOSTED__ && __has_include_next(<float.h>)

#  include_next <float.h>

#endif

#include <__float_float.h>
#undef __need_float_float
#endif

#ifdef __need_infinity_nan
#include <__float_infinity_nan.h>
#undef __need_infinity_nan
#endif

#endif /* __MVS__ */
`,"__float_float.h":`/*===---- __float_float.h --------------------------------------------------===
 *
 * Part of the LLVM Project, under the Apache License v2.0 with LLVM Exceptions.
 * See https://llvm.org/LICENSE.txt for license information.
 * SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception
 *
 *===-----------------------------------------------------------------------===
 */

#ifndef __CLANG_FLOAT_FLOAT_H
#define __CLANG_FLOAT_FLOAT_H

#if (defined(__MINGW32__) || defined(_MSC_VER) || defined(_AIX)) &&            \\
    __STDC_HOSTED__

/* Undefine anything that we'll be redefining below. */
#  undef FLT_EVAL_METHOD
#  undef FLT_ROUNDS
#  undef FLT_RADIX
#  undef FLT_MANT_DIG
#  undef DBL_MANT_DIG
#  undef LDBL_MANT_DIG
#if (defined(__STDC_VERSION__) && __STDC_VERSION__ >= 199901L) ||              \\
    !defined(__STRICT_ANSI__) ||                                               \\
    (defined(__cplusplus) && __cplusplus >= 201103L) ||                        \\
    (__STDC_HOSTED__ && defined(_AIX) && defined(_ALL_SOURCE))
#    undef DECIMAL_DIG
#  endif
#  undef FLT_DIG
#  undef DBL_DIG
#  undef LDBL_DIG
#  undef FLT_MIN_EXP
#  undef DBL_MIN_EXP
#  undef LDBL_MIN_EXP
#  undef FLT_MIN_10_EXP
#  undef DBL_MIN_10_EXP
#  undef LDBL_MIN_10_EXP
#  undef FLT_MAX_EXP
#  undef DBL_MAX_EXP
#  undef LDBL_MAX_EXP
#  undef FLT_MAX_10_EXP
#  undef DBL_MAX_10_EXP
#  undef LDBL_MAX_10_EXP
#  undef FLT_MAX
#  undef DBL_MAX
#  undef LDBL_MAX
#  undef FLT_EPSILON
#  undef DBL_EPSILON
#  undef LDBL_EPSILON
#  undef FLT_MIN
#  undef DBL_MIN
#  undef LDBL_MIN
#if (defined(__STDC_VERSION__) && __STDC_VERSION__ >= 201112L) ||              \\
    !defined(__STRICT_ANSI__) ||                                               \\
    (defined(__cplusplus) && __cplusplus >= 201703L) ||                        \\
    (__STDC_HOSTED__ && defined(_AIX) && defined(_ALL_SOURCE))
#    undef FLT_TRUE_MIN
#    undef DBL_TRUE_MIN
#    undef LDBL_TRUE_MIN
#    undef FLT_DECIMAL_DIG
#    undef DBL_DECIMAL_DIG
#    undef LDBL_DECIMAL_DIG
#    undef FLT_HAS_SUBNORM
#    undef DBL_HAS_SUBNORM
#    undef LDBL_HAS_SUBNORM
#  endif
#if (defined(__STDC_VERSION__) && __STDC_VERSION__ >= 202311L) ||              \\
    !defined(__STRICT_ANSI__)
#    undef FLT_NORM_MAX
#    undef DBL_NORM_MAX
#    undef LDBL_NORM_MAX
#endif
#endif

#if (defined(__STDC_VERSION__) && __STDC_VERSION__ >= 202311L) ||              \\
    !defined(__STRICT_ANSI__)
#  undef FLT_SNAN
#  undef DBL_SNAN
#  undef LDBL_SNAN
#endif

/* Characteristics of floating point types, C99 5.2.4.2.2 */

#if (defined(__STDC_VERSION__) && __STDC_VERSION__ >= 199901L) ||              \\
    (defined(__cplusplus) && __cplusplus >= 201103L)
#define FLT_EVAL_METHOD __FLT_EVAL_METHOD__
#endif
#define FLT_ROUNDS (__builtin_flt_rounds())
#define FLT_RADIX __FLT_RADIX__

#define FLT_MANT_DIG __FLT_MANT_DIG__
#define DBL_MANT_DIG __DBL_MANT_DIG__
#define LDBL_MANT_DIG __LDBL_MANT_DIG__

#if (defined(__STDC_VERSION__) && __STDC_VERSION__ >= 199901L) ||              \\
    !defined(__STRICT_ANSI__) ||                                               \\
    (defined(__cplusplus) && __cplusplus >= 201103L) ||                        \\
    (__STDC_HOSTED__ && defined(_AIX) && defined(_ALL_SOURCE))
#  define DECIMAL_DIG __DECIMAL_DIG__
#endif

#define FLT_DIG __FLT_DIG__
#define DBL_DIG __DBL_DIG__
#define LDBL_DIG __LDBL_DIG__

#define FLT_MIN_EXP __FLT_MIN_EXP__
#define DBL_MIN_EXP __DBL_MIN_EXP__
#define LDBL_MIN_EXP __LDBL_MIN_EXP__

#define FLT_MIN_10_EXP __FLT_MIN_10_EXP__
#define DBL_MIN_10_EXP __DBL_MIN_10_EXP__
#define LDBL_MIN_10_EXP __LDBL_MIN_10_EXP__

#define FLT_MAX_EXP __FLT_MAX_EXP__
#define DBL_MAX_EXP __DBL_MAX_EXP__
#define LDBL_MAX_EXP __LDBL_MAX_EXP__

#define FLT_MAX_10_EXP __FLT_MAX_10_EXP__
#define DBL_MAX_10_EXP __DBL_MAX_10_EXP__
#define LDBL_MAX_10_EXP __LDBL_MAX_10_EXP__

#define FLT_MAX __FLT_MAX__
#define DBL_MAX __DBL_MAX__
#define LDBL_MAX __LDBL_MAX__

#define FLT_EPSILON __FLT_EPSILON__
#define DBL_EPSILON __DBL_EPSILON__
#define LDBL_EPSILON __LDBL_EPSILON__

#define FLT_MIN __FLT_MIN__
#define DBL_MIN __DBL_MIN__
#define LDBL_MIN __LDBL_MIN__

#if (defined(__STDC_VERSION__) && __STDC_VERSION__ >= 201112L) ||              \\
    !defined(__STRICT_ANSI__) ||                                               \\
    (defined(__cplusplus) && __cplusplus >= 201703L) ||                        \\
    (__STDC_HOSTED__ && defined(_AIX) && defined(_ALL_SOURCE))
#  define FLT_TRUE_MIN __FLT_DENORM_MIN__
#  define DBL_TRUE_MIN __DBL_DENORM_MIN__
#  define LDBL_TRUE_MIN __LDBL_DENORM_MIN__
#  define FLT_DECIMAL_DIG __FLT_DECIMAL_DIG__
#  define DBL_DECIMAL_DIG __DBL_DECIMAL_DIG__
#  define LDBL_DECIMAL_DIG __LDBL_DECIMAL_DIG__
#  define FLT_HAS_SUBNORM __FLT_HAS_DENORM__
#  define DBL_HAS_SUBNORM __DBL_HAS_DENORM__
#  define LDBL_HAS_SUBNORM __LDBL_HAS_DENORM__
#endif

#if (defined(__STDC_VERSION__) && __STDC_VERSION__ >= 202311L) ||              \\
    !defined(__STRICT_ANSI__)
   /* C23 5.2.5.3.2p28 */
#  define FLT_SNAN (__builtin_nansf(""))
#  define DBL_SNAN (__builtin_nans(""))
#  define LDBL_SNAN (__builtin_nansl(""))

   /* C23 5.2.5.3.3p32 */
#  define FLT_NORM_MAX __FLT_NORM_MAX__
#  define DBL_NORM_MAX __DBL_NORM_MAX__
#  define LDBL_NORM_MAX __LDBL_NORM_MAX__
#endif

#ifdef __STDC_WANT_IEC_60559_TYPES_EXT__
#  define FLT16_MANT_DIG    __FLT16_MANT_DIG__
#  define FLT16_DECIMAL_DIG __FLT16_DECIMAL_DIG__
#  define FLT16_DIG         __FLT16_DIG__
#  define FLT16_MIN_EXP     __FLT16_MIN_EXP__
#  define FLT16_MIN_10_EXP  __FLT16_MIN_10_EXP__
#  define FLT16_MAX_EXP     __FLT16_MAX_EXP__
#  define FLT16_MAX_10_EXP  __FLT16_MAX_10_EXP__
#  define FLT16_MAX         __FLT16_MAX__
#  define FLT16_EPSILON     __FLT16_EPSILON__
#  define FLT16_MIN         __FLT16_MIN__
#  define FLT16_TRUE_MIN    __FLT16_TRUE_MIN__
#endif /* __STDC_WANT_IEC_60559_TYPES_EXT__ */

#endif /* __CLANG_FLOAT_FLOAT_H */
`,"__float_header_macro.h":`/*===---- __float_header_macro.h -------------------------------------------===
 *
 * Part of the LLVM Project, under the Apache License v2.0 with LLVM Exceptions.
 * See https://llvm.org/LICENSE.txt for license information.
 * SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception
 *
 *===-----------------------------------------------------------------------===
 */

#ifndef __CLANG_FLOAT_H
#define __CLANG_FLOAT_H
#endif /* __CLANG_FLOAT_H */
`,"__float_infinity_nan.h":`/*===---- __float_infinity_nan.h -------------------------------------------===
 *
 * Part of the LLVM Project, under the Apache License v2.0 with LLVM Exceptions.
 * See https://llvm.org/LICENSE.txt for license information.
 * SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception
 *
 *===-----------------------------------------------------------------------===
 */

#ifndef __CLANG_FLOAT_INFINITY_NAN_H
#define __CLANG_FLOAT_INFINITY_NAN_H

/* C23 5.2.5.3.3p29-30 */
#undef INFINITY
#undef NAN

#define INFINITY (__builtin_inff())
#define NAN (__builtin_nanf(""))

#endif /* __CLANG_FLOAT_INFINITY_NAN_H */
`,"inttypes.h":`/*===---- inttypes.h - Standard header for integer printf macros ----------===*\\
 *
 * Part of the LLVM Project, under the Apache License v2.0 with LLVM Exceptions.
 * See https://llvm.org/LICENSE.txt for license information.
 * SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception
 *
\\*===----------------------------------------------------------------------===*/

#ifndef __CLANG_INTTYPES_H
// AIX system headers need inttypes.h to be re-enterable while _STD_TYPES_T
// is defined until an inclusion of it without _STD_TYPES_T occurs, in which
// case the header guard macro is defined.
#if !defined(_AIX) || !defined(_STD_TYPES_T)
#define __CLANG_INTTYPES_H
#endif
#if defined(__MVS__) && __has_include_next(<inttypes.h>)
#include_next <inttypes.h>
#else

#if defined(_MSC_VER) && _MSC_VER < 1800
#error MSVC does not have inttypes.h prior to Visual Studio 2013
#endif

#include_next <inttypes.h>

#if defined(_MSC_VER) && _MSC_VER < 1900
/* MSVC headers define int32_t as int, but PRIx32 as "lx" instead of "x".
 * This triggers format warnings, so fix it up here. */
#undef PRId32
#undef PRIdLEAST32
#undef PRIdFAST32
#undef PRIi32
#undef PRIiLEAST32
#undef PRIiFAST32
#undef PRIo32
#undef PRIoLEAST32
#undef PRIoFAST32
#undef PRIu32
#undef PRIuLEAST32
#undef PRIuFAST32
#undef PRIx32
#undef PRIxLEAST32
#undef PRIxFAST32
#undef PRIX32
#undef PRIXLEAST32
#undef PRIXFAST32

#undef SCNd32
#undef SCNdLEAST32
#undef SCNdFAST32
#undef SCNi32
#undef SCNiLEAST32
#undef SCNiFAST32
#undef SCNo32
#undef SCNoLEAST32
#undef SCNoFAST32
#undef SCNu32
#undef SCNuLEAST32
#undef SCNuFAST32
#undef SCNx32
#undef SCNxLEAST32
#undef SCNxFAST32

#define PRId32 "d"
#define PRIdLEAST32 "d"
#define PRIdFAST32 "d"
#define PRIi32 "i"
#define PRIiLEAST32 "i"
#define PRIiFAST32 "i"
#define PRIo32 "o"
#define PRIoLEAST32 "o"
#define PRIoFAST32 "o"
#define PRIu32 "u"
#define PRIuLEAST32 "u"
#define PRIuFAST32 "u"
#define PRIx32 "x"
#define PRIxLEAST32 "x"
#define PRIxFAST32 "x"
#define PRIX32 "X"
#define PRIXLEAST32 "X"
#define PRIXFAST32 "X"

#define SCNd32 "d"
#define SCNdLEAST32 "d"
#define SCNdFAST32 "d"
#define SCNi32 "i"
#define SCNiLEAST32 "i"
#define SCNiFAST32 "i"
#define SCNo32 "o"
#define SCNoLEAST32 "o"
#define SCNoFAST32 "o"
#define SCNu32 "u"
#define SCNuLEAST32 "u"
#define SCNuFAST32 "u"
#define SCNx32 "x"
#define SCNxLEAST32 "x"
#define SCNxFAST32 "x"
#endif

#endif /* __MVS__ */
#endif /* __CLANG_INTTYPES_H */
`,"iso646.h":`/*===---- iso646.h - Standard header for alternate spellings of operators---===
 *
 * Part of the LLVM Project, under the Apache License v2.0 with LLVM Exceptions.
 * See https://llvm.org/LICENSE.txt for license information.
 * SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception
 *
 *===-----------------------------------------------------------------------===
 */

#ifndef __ISO646_H
#define __ISO646_H
#if defined(__MVS__) && __has_include_next(<iso646.h>)
#include_next <iso646.h>
#else

#ifndef __cplusplus
#define and    &&
#define and_eq &=
#define bitand &
#define bitor  |
#define compl  ~
#define not    !
#define not_eq !=
#define or     ||
#define or_eq  |=
#define xor    ^
#define xor_eq ^=
#endif

#endif /* __MVS__ */
#endif /* __ISO646_H */
`,"limits.h":`/*===---- limits.h - Standard header for integer sizes --------------------===*\\
 *
 * Part of the LLVM Project, under the Apache License v2.0 with LLVM Exceptions.
 * See https://llvm.org/LICENSE.txt for license information.
 * SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception
 *
\\*===----------------------------------------------------------------------===*/

#ifndef __CLANG_LIMITS_H
#define __CLANG_LIMITS_H

#if defined(__MVS__) && __has_include_next(<limits.h>)
#include_next <limits.h>
#else

/* The system's limits.h may, in turn, try to #include_next GCC's limits.h.
   Avert this #include_next madness. */
#if defined __GNUC__ && !defined _GCC_LIMITS_H_
#define _GCC_LIMITS_H_
#endif

/* System headers include a number of constants from POSIX in <limits.h>.
   Include it if we're hosted. */
#if __STDC_HOSTED__ && __has_include_next(<limits.h>)
#include_next <limits.h>
#endif

/* Many system headers try to "help us out" by defining these.  No really, we
   know how big each datatype is. */
#undef  SCHAR_MIN
#undef  SCHAR_MAX
#undef  UCHAR_MAX
#undef  SHRT_MIN
#undef  SHRT_MAX
#undef  USHRT_MAX
#undef  INT_MIN
#undef  INT_MAX
#undef  UINT_MAX
#undef  LONG_MIN
#undef  LONG_MAX
#undef  ULONG_MAX

#undef  CHAR_BIT
#undef  CHAR_MIN
#undef  CHAR_MAX

/* C90/99 5.2.4.2.1 */
#define SCHAR_MAX __SCHAR_MAX__
#define SHRT_MAX  __SHRT_MAX__
#define INT_MAX   __INT_MAX__
#define LONG_MAX  __LONG_MAX__

#define SCHAR_MIN (-__SCHAR_MAX__-1)
#define SHRT_MIN  (-__SHRT_MAX__ -1)
#define INT_MIN   (-__INT_MAX__  -1)
#define LONG_MIN  (-__LONG_MAX__ -1L)

#define UCHAR_MAX (__SCHAR_MAX__*2  +1)
#if __SHRT_WIDTH__ < __INT_WIDTH__
#define USHRT_MAX (__SHRT_MAX__ * 2 + 1)
#else
#define USHRT_MAX (__SHRT_MAX__ * 2U + 1U)
#endif
#define UINT_MAX  (__INT_MAX__  *2U +1U)
#define ULONG_MAX (__LONG_MAX__ *2UL+1UL)

#ifndef MB_LEN_MAX
#define MB_LEN_MAX 1
#endif

#define CHAR_BIT  __CHAR_BIT__

/* C23 5.2.4.2.1 */
#if defined(__STDC_VERSION__) && __STDC_VERSION__ >= 202311L
#define BOOL_WIDTH   __BOOL_WIDTH__
#define CHAR_WIDTH   CHAR_BIT
#define SCHAR_WIDTH  CHAR_BIT
#define UCHAR_WIDTH  CHAR_BIT
#define USHRT_WIDTH  __SHRT_WIDTH__
#define SHRT_WIDTH   __SHRT_WIDTH__
#define UINT_WIDTH   __INT_WIDTH__
#define INT_WIDTH    __INT_WIDTH__
#define ULONG_WIDTH  __LONG_WIDTH__
#define LONG_WIDTH   __LONG_WIDTH__
#define ULLONG_WIDTH __LLONG_WIDTH__
#define LLONG_WIDTH  __LLONG_WIDTH__

#define BITINT_MAXWIDTH __BITINT_MAXWIDTH__
#endif

#ifdef __CHAR_UNSIGNED__  /* -funsigned-char */
#define CHAR_MIN 0
#define CHAR_MAX UCHAR_MAX
#else
#define CHAR_MIN SCHAR_MIN
#define CHAR_MAX __SCHAR_MAX__
#endif

/* C99 5.2.4.2.1: Added long long.
   C++11 18.3.3.2: same contents as the Standard C Library header <limits.h>.
 */
#if (defined(__STDC_VERSION__) && __STDC_VERSION__ >= 199901L) ||              \\
    (defined(__cplusplus) && __cplusplus >= 201103L)

#undef  LLONG_MIN
#undef  LLONG_MAX
#undef  ULLONG_MAX

#define LLONG_MAX  __LONG_LONG_MAX__
#define LLONG_MIN  (-__LONG_LONG_MAX__-1LL)
#define ULLONG_MAX (__LONG_LONG_MAX__*2ULL+1ULL)
#endif

/* LONG_LONG_MIN/LONG_LONG_MAX/ULONG_LONG_MAX are a GNU extension. Android's
   bionic also defines them. It's too bad that we don't have something like
   #pragma poison that could be used to deprecate a macro - the code should just
   use LLONG_MAX and friends.
 */
#if (defined(__GNU_LIBRARY__) ? defined(__USE_GNU)                             \\
                              : !defined(__STRICT_ANSI__)) ||                  \\
    defined(__BIONIC__)

#undef   LONG_LONG_MIN
#undef   LONG_LONG_MAX
#undef   ULONG_LONG_MAX

#define LONG_LONG_MAX  __LONG_LONG_MAX__
#define LONG_LONG_MIN  (-__LONG_LONG_MAX__-1LL)
#define ULONG_LONG_MAX (__LONG_LONG_MAX__*2ULL+1ULL)
#endif

#endif /* __MVS__ */
#endif /* __CLANG_LIMITS_H */
`,"stdalign.h":`/*===---- stdalign.h - Standard header for alignment ------------------------===
 *
 * Part of the LLVM Project, under the Apache License v2.0 with LLVM Exceptions.
 * See https://llvm.org/LICENSE.txt for license information.
 * SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception
 *
 *===-----------------------------------------------------------------------===
 */

#ifndef __STDALIGN_H
#define __STDALIGN_H

#if defined(__cplusplus) ||                                                    \\
    (defined(__STDC_VERSION__) && __STDC_VERSION__ < 202311L)
#ifndef __cplusplus
#define alignas _Alignas
#define alignof _Alignof
#endif

#define __alignas_is_defined 1
#define __alignof_is_defined 1
#endif /* __STDC_VERSION__ */

#endif /* __STDALIGN_H */
`,"stdarg.h":`/*===---- stdarg.h - Variable argument handling ----------------------------===
 *
 * Part of the LLVM Project, under the Apache License v2.0 with LLVM Exceptions.
 * See https://llvm.org/LICENSE.txt for license information.
 * SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception
 *
 *===-----------------------------------------------------------------------===
 */

/*
 * This header is designed to be included multiple times. If any of the __need_
 * macros are defined, then only that subset of interfaces are provided. This
 * can be useful for POSIX headers that need to not expose all of stdarg.h, but
 * need to use some of its interfaces. Otherwise this header provides all of
 * the expected interfaces.
 *
 * When clang modules are enabled, this header is a textual header to support
 * the multiple include behavior. As such, it doesn't directly declare anything
 * so that it doesn't add duplicate declarations to all of its includers'
 * modules.
 */
#if defined(__MVS__) && __has_include_next(<stdarg.h>)
#undef __need___va_list
#undef __need_va_list
#undef __need_va_arg
#undef __need___va_copy
#undef __need_va_copy
#include <__stdarg_header_macro.h>
#include_next <stdarg.h>

#else
#if !defined(__need___va_list) && !defined(__need_va_list) &&                  \\
    !defined(__need_va_arg) && !defined(__need___va_copy) &&                   \\
    !defined(__need_va_copy)
#define __need___va_list
#define __need_va_list
#define __need_va_arg
#define __need___va_copy
/* GCC always defines __va_copy, but does not define va_copy unless in c99 mode
 * or -ansi is not specified, since it was not part of C90.
 */
#if (defined(__STDC_VERSION__) && __STDC_VERSION__ >= 199901L) ||              \\
    (defined(__cplusplus) && __cplusplus >= 201103L) ||                        \\
    !defined(__STRICT_ANSI__)
#define __need_va_copy
#endif
#include <__stdarg_header_macro.h>
#endif

#ifdef __need___va_list
#include <__stdarg___gnuc_va_list.h>
#undef __need___va_list
#endif /* defined(__need___va_list) */

#ifdef __need_va_list
#include <__stdarg_va_list.h>
#undef __need_va_list
#endif /* defined(__need_va_list) */

#ifdef __need_va_arg
#include <__stdarg_va_arg.h>
#undef __need_va_arg
#endif /* defined(__need_va_arg) */

#ifdef __need___va_copy
#include <__stdarg___va_copy.h>
#undef __need___va_copy
#endif /* defined(__need___va_copy) */

#ifdef __need_va_copy
#include <__stdarg_va_copy.h>
#undef __need_va_copy
#endif /* defined(__need_va_copy) */

#endif /* __MVS__ */
`,"__stdarg___gnuc_va_list.h":`/*===---- __stdarg___gnuc_va_list.h - Definition of __gnuc_va_list ---------===
 *
 * Part of the LLVM Project, under the Apache License v2.0 with LLVM Exceptions.
 * See https://llvm.org/LICENSE.txt for license information.
 * SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception
 *
 *===-----------------------------------------------------------------------===
 */

#ifndef __GNUC_VA_LIST
#define __GNUC_VA_LIST
typedef __builtin_va_list __gnuc_va_list;
#endif
`,"__stdarg___va_copy.h":`/*===---- __stdarg___va_copy.h - Definition of __va_copy -------------------===
 *
 * Part of the LLVM Project, under the Apache License v2.0 with LLVM Exceptions.
 * See https://llvm.org/LICENSE.txt for license information.
 * SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception
 *
 *===-----------------------------------------------------------------------===
 */

#ifndef __va_copy
#define __va_copy(d, s) __builtin_va_copy(d, s)
#endif
`,"__stdarg_header_macro.h":`/*===---- __stdarg_header_macro.h ------------------------------------------===
 *
 * Part of the LLVM Project, under the Apache License v2.0 with LLVM Exceptions.
 * See https://llvm.org/LICENSE.txt for license information.
 * SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception
 *
 *===-----------------------------------------------------------------------===
 */

#ifndef __STDARG_H
#define __STDARG_H
#endif
`,"__stdarg_va_arg.h":`/*===---- __stdarg_va_arg.h - Definitions of va_start, va_arg, va_end-------===
 *
 * Part of the LLVM Project, under the Apache License v2.0 with LLVM Exceptions.
 * See https://llvm.org/LICENSE.txt for license information.
 * SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception
 *
 *===-----------------------------------------------------------------------===
 */

#ifndef va_arg

#if defined(__STDC_VERSION__) && __STDC_VERSION__ >= 202311L
/* C23 uses a special builtin. */
#define va_start(...) __builtin_c23_va_start(__VA_ARGS__)
#else
/* Versions before C23 do require the second parameter. */
#define va_start(ap, param) __builtin_va_start(ap, param)
#endif
#define va_end(ap) __builtin_va_end(ap)
#define va_arg(ap, type) __builtin_va_arg(ap, type)

#endif
`,"__stdarg_va_copy.h":`/*===---- __stdarg_va_copy.h - Definition of va_copy------------------------===
 *
 * Part of the LLVM Project, under the Apache License v2.0 with LLVM Exceptions.
 * See https://llvm.org/LICENSE.txt for license information.
 * SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception
 *
 *===-----------------------------------------------------------------------===
 */

#ifndef va_copy
#define va_copy(dest, src) __builtin_va_copy(dest, src)
#endif
`,"__stdarg_va_list.h":`/*===---- __stdarg_va_list.h - Definition of va_list -----------------------===
 *
 * Part of the LLVM Project, under the Apache License v2.0 with LLVM Exceptions.
 * See https://llvm.org/LICENSE.txt for license information.
 * SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception
 *
 *===-----------------------------------------------------------------------===
 */

#ifndef _VA_LIST
#define _VA_LIST
typedef __builtin_va_list va_list;
#endif
`,"stdatomic.h":`/*===---- stdatomic.h - Standard header for atomic types and operations -----===
 *
 * Part of the LLVM Project, under the Apache License v2.0 with LLVM Exceptions.
 * See https://llvm.org/LICENSE.txt for license information.
 * SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception
 *
 *===-----------------------------------------------------------------------===
 */

#ifndef __CLANG_STDATOMIC_H
#define __CLANG_STDATOMIC_H

/* If we're hosted, fall back to the system's stdatomic.h. FreeBSD, for
 * example, already has a Clang-compatible stdatomic.h header.
 *
 * Exclude the MSVC path as well as the MSVC header as of the 14.31.30818
 * explicitly disallows \`stdatomic.h\` in the C mode via an \`#error\`.  Fallback
 * to the clang resource header until that is fully supported.  The
 * \`stdatomic.h\` header requires C++23 or newer.
 */
#if __STDC_HOSTED__ &&                                                         \\
    __has_include_next(<stdatomic.h>) &&                                       \\
    (!defined(_MSC_VER) || (defined(__cplusplus) && __cplusplus >= 202002L))
# include_next <stdatomic.h>
#else

#include <stddef.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

/* 7.17.1 Introduction */

#define ATOMIC_BOOL_LOCK_FREE       __CLANG_ATOMIC_BOOL_LOCK_FREE
#define ATOMIC_CHAR_LOCK_FREE       __CLANG_ATOMIC_CHAR_LOCK_FREE
#if defined(__STDC_VERSION__) && __STDC_VERSION__ >= 202311L
#define ATOMIC_CHAR8_T_LOCK_FREE    __CLANG_ATOMIC_CHAR8_T_LOCK_FREE
#endif
#define ATOMIC_CHAR16_T_LOCK_FREE   __CLANG_ATOMIC_CHAR16_T_LOCK_FREE
#define ATOMIC_CHAR32_T_LOCK_FREE   __CLANG_ATOMIC_CHAR32_T_LOCK_FREE
#define ATOMIC_WCHAR_T_LOCK_FREE    __CLANG_ATOMIC_WCHAR_T_LOCK_FREE
#define ATOMIC_SHORT_LOCK_FREE      __CLANG_ATOMIC_SHORT_LOCK_FREE
#define ATOMIC_INT_LOCK_FREE        __CLANG_ATOMIC_INT_LOCK_FREE
#define ATOMIC_LONG_LOCK_FREE       __CLANG_ATOMIC_LONG_LOCK_FREE
#define ATOMIC_LLONG_LOCK_FREE      __CLANG_ATOMIC_LLONG_LOCK_FREE
#define ATOMIC_POINTER_LOCK_FREE    __CLANG_ATOMIC_POINTER_LOCK_FREE

/* 7.17.2 Initialization */
#if (defined(__STDC_VERSION__) && __STDC_VERSION__ < 202311L) ||               \\
    defined(__cplusplus)
/* ATOMIC_VAR_INIT was removed in C23, but still remains in C++23. */
#define ATOMIC_VAR_INIT(value) (value)
#endif

#if ((defined(__STDC_VERSION__) && __STDC_VERSION__ >= 201710L &&              \\
      __STDC_VERSION__ < 202311L) ||                                           \\
     (defined(__cplusplus) && __cplusplus >= 202002L)) &&                      \\
    !defined(_CLANG_DISABLE_CRT_DEPRECATION_WARNINGS)
/* ATOMIC_VAR_INIT was deprecated in C17 and C++20. */
#pragma clang deprecated(ATOMIC_VAR_INIT)
#endif
#define atomic_init __c11_atomic_init

/* 7.17.3 Order and consistency */

typedef enum memory_order {
  memory_order_relaxed = __ATOMIC_RELAXED,
  memory_order_consume = __ATOMIC_CONSUME,
  memory_order_acquire = __ATOMIC_ACQUIRE,
  memory_order_release = __ATOMIC_RELEASE,
  memory_order_acq_rel = __ATOMIC_ACQ_REL,
  memory_order_seq_cst = __ATOMIC_SEQ_CST
} memory_order;

#define kill_dependency(y) (y)

/* 7.17.4 Fences */

/* These should be provided by the libc implementation. */
void atomic_thread_fence(memory_order);
void atomic_signal_fence(memory_order);

#define atomic_thread_fence(order) __c11_atomic_thread_fence(order)
#define atomic_signal_fence(order) __c11_atomic_signal_fence(order)

/* 7.17.5 Lock-free property */

#define atomic_is_lock_free(obj) __c11_atomic_is_lock_free(sizeof(*(obj)))

/* 7.17.6 Atomic integer types */

#ifdef __cplusplus
typedef _Atomic(bool)               atomic_bool;
#else
typedef _Atomic(_Bool)              atomic_bool;
#endif
typedef _Atomic(char)               atomic_char;
typedef _Atomic(signed char)        atomic_schar;
typedef _Atomic(unsigned char)      atomic_uchar;
typedef _Atomic(short)              atomic_short;
typedef _Atomic(unsigned short)     atomic_ushort;
typedef _Atomic(int)                atomic_int;
typedef _Atomic(unsigned int)       atomic_uint;
typedef _Atomic(long)               atomic_long;
typedef _Atomic(unsigned long)      atomic_ulong;
typedef _Atomic(long long)          atomic_llong;
typedef _Atomic(unsigned long long) atomic_ullong;
#if defined(__STDC_VERSION__) && __STDC_VERSION__ >= 202311L
typedef _Atomic(unsigned char)      atomic_char8_t;
#endif
typedef _Atomic(uint_least16_t)     atomic_char16_t;
typedef _Atomic(uint_least32_t)     atomic_char32_t;
typedef _Atomic(wchar_t)            atomic_wchar_t;
typedef _Atomic(int_least8_t)       atomic_int_least8_t;
typedef _Atomic(uint_least8_t)      atomic_uint_least8_t;
typedef _Atomic(int_least16_t)      atomic_int_least16_t;
typedef _Atomic(uint_least16_t)     atomic_uint_least16_t;
typedef _Atomic(int_least32_t)      atomic_int_least32_t;
typedef _Atomic(uint_least32_t)     atomic_uint_least32_t;
typedef _Atomic(int_least64_t)      atomic_int_least64_t;
typedef _Atomic(uint_least64_t)     atomic_uint_least64_t;
typedef _Atomic(int_fast8_t)        atomic_int_fast8_t;
typedef _Atomic(uint_fast8_t)       atomic_uint_fast8_t;
typedef _Atomic(int_fast16_t)       atomic_int_fast16_t;
typedef _Atomic(uint_fast16_t)      atomic_uint_fast16_t;
typedef _Atomic(int_fast32_t)       atomic_int_fast32_t;
typedef _Atomic(uint_fast32_t)      atomic_uint_fast32_t;
typedef _Atomic(int_fast64_t)       atomic_int_fast64_t;
typedef _Atomic(uint_fast64_t)      atomic_uint_fast64_t;
typedef _Atomic(intptr_t)           atomic_intptr_t;
typedef _Atomic(uintptr_t)          atomic_uintptr_t;
typedef _Atomic(size_t)             atomic_size_t;
typedef _Atomic(ptrdiff_t)          atomic_ptrdiff_t;
typedef _Atomic(intmax_t)           atomic_intmax_t;
typedef _Atomic(uintmax_t)          atomic_uintmax_t;

/* 7.17.7 Operations on atomic types */

#define atomic_store(object, desired) __c11_atomic_store(object, desired, __ATOMIC_SEQ_CST)
#define atomic_store_explicit __c11_atomic_store

#define atomic_load(object) __c11_atomic_load(object, __ATOMIC_SEQ_CST)
#define atomic_load_explicit __c11_atomic_load

#define atomic_exchange(object, desired) __c11_atomic_exchange(object, desired, __ATOMIC_SEQ_CST)
#define atomic_exchange_explicit __c11_atomic_exchange

#define atomic_compare_exchange_strong(object, expected, desired) __c11_atomic_compare_exchange_strong(object, expected, desired, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST)
#define atomic_compare_exchange_strong_explicit __c11_atomic_compare_exchange_strong

#define atomic_compare_exchange_weak(object, expected, desired) __c11_atomic_compare_exchange_weak(object, expected, desired, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST)
#define atomic_compare_exchange_weak_explicit __c11_atomic_compare_exchange_weak

#define atomic_fetch_add(object, operand) __c11_atomic_fetch_add(object, operand, __ATOMIC_SEQ_CST)
#define atomic_fetch_add_explicit __c11_atomic_fetch_add

#define atomic_fetch_sub(object, operand) __c11_atomic_fetch_sub(object, operand, __ATOMIC_SEQ_CST)
#define atomic_fetch_sub_explicit __c11_atomic_fetch_sub

#define atomic_fetch_or(object, operand) __c11_atomic_fetch_or(object, operand, __ATOMIC_SEQ_CST)
#define atomic_fetch_or_explicit __c11_atomic_fetch_or

#define atomic_fetch_xor(object, operand) __c11_atomic_fetch_xor(object, operand, __ATOMIC_SEQ_CST)
#define atomic_fetch_xor_explicit __c11_atomic_fetch_xor

#define atomic_fetch_and(object, operand) __c11_atomic_fetch_and(object, operand, __ATOMIC_SEQ_CST)
#define atomic_fetch_and_explicit __c11_atomic_fetch_and

/* 7.17.8 Atomic flag type and operations */

typedef struct atomic_flag { atomic_bool _Value; } atomic_flag;

#ifdef __cplusplus
#define ATOMIC_FLAG_INIT {false}
#else
#define ATOMIC_FLAG_INIT { 0 }
#endif

/* These should be provided by the libc implementation. */
#ifdef __cplusplus
bool atomic_flag_test_and_set(volatile atomic_flag *);
bool atomic_flag_test_and_set_explicit(volatile atomic_flag *, memory_order);
#else
_Bool atomic_flag_test_and_set(volatile atomic_flag *);
_Bool atomic_flag_test_and_set_explicit(volatile atomic_flag *, memory_order);
#endif
void atomic_flag_clear(volatile atomic_flag *);
void atomic_flag_clear_explicit(volatile atomic_flag *, memory_order);

#define atomic_flag_test_and_set(object) __c11_atomic_exchange(&(object)->_Value, 1, __ATOMIC_SEQ_CST)
#define atomic_flag_test_and_set_explicit(object, order) __c11_atomic_exchange(&(object)->_Value, 1, order)

#define atomic_flag_clear(object) __c11_atomic_store(&(object)->_Value, 0, __ATOMIC_SEQ_CST)
#define atomic_flag_clear_explicit(object, order) __c11_atomic_store(&(object)->_Value, 0, order)

#ifdef __cplusplus
}
#endif

#endif /* __STDC_HOSTED__ */
#endif /* __CLANG_STDATOMIC_H */

`,"stdbool.h":`/*===---- stdbool.h - Standard header for booleans -------------------------===
 *
 * Part of the LLVM Project, under the Apache License v2.0 with LLVM Exceptions.
 * See https://llvm.org/LICENSE.txt for license information.
 * SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception
 *
 *===-----------------------------------------------------------------------===
 */

#ifndef __STDBOOL_H
#define __STDBOOL_H

#define __bool_true_false_are_defined 1

#if defined(__MVS__) && __has_include_next(<stdbool.h>)
#include_next <stdbool.h>
#else

#if defined(__STDC_VERSION__) && __STDC_VERSION__ > 201710L
/* FIXME: We should be issuing a deprecation warning here, but cannot yet due
 * to system headers which include this header file unconditionally.
 */
#elif !defined(__cplusplus)
#define bool _Bool
#define true 1
#define false 0
#elif defined(__GNUC__) && !defined(__STRICT_ANSI__)
/* Define _Bool as a GNU extension. */
#define _Bool bool
#if defined(__cplusplus) && __cplusplus < 201103L
/* For C++98, define bool, false, true as a GNU extension. */
#define bool bool
#define false false
#define true true
#endif
#endif

#endif /* __MVS__ */
#endif /* __STDBOOL_H */
`,"stdcountof.h":`/*===---- stdcountof.h - Standard header for countof -----------------------===
 *
 * Part of the LLVM Project, under the Apache License v2.0 with LLVM Exceptions.
 * See https://llvm.org/LICENSE.txt for license information.
 * SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception
 *
 *===-----------------------------------------------------------------------===
 */

#ifndef __STDCOUNTOF_H
#define __STDCOUNTOF_H

#define countof _Countof

#endif /* __STDCOUNTOF_H */
`,"stdckdint.h":`/*===---- stdckdint.h - Standard header for checking integer----------------===
 *
 * Part of the LLVM Project, under the Apache License v2.0 with LLVM Exceptions.
 * See https://llvm.org/LICENSE.txt for license information.
 * SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception
 *
 *===-----------------------------------------------------------------------===
 */

#ifndef __STDCKDINT_H
#define __STDCKDINT_H

/* If we're hosted, fall back to the system's stdckdint.h. FreeBSD, for
 * example, already has a Clang-compatible stdckdint.h header.
 *
 * The \`stdckdint.h\` header requires C 23 or newer.
 */
#if __STDC_HOSTED__ && __has_include_next(<stdckdint.h>)
#include_next <stdckdint.h>
#else

/* C23 7.20.1 Defines several macros for performing checked integer arithmetic*/

#define __STDC_VERSION_STDCKDINT_H__ 202311L

// Both A and B shall be any integer type other than "plain" char, bool, a bit-
// precise integer type, or an enumerated type, and they need not be the same.

// R shall be a modifiable lvalue of any integer type other than "plain" char,
// bool, a bit-precise integer type, or an enumerated type. It shouldn't be
// short type, either. Otherwise, it may be unable to hold two the result of
// operating two 'int's.

// A diagnostic message will be produced if A or B are not suitable integer
// types, or if R is not a modifiable lvalue of a suitable integer type or R
// is short type.
#define ckd_add(R, A, B) __builtin_add_overflow((A), (B), (R))
#define ckd_sub(R, A, B) __builtin_sub_overflow((A), (B), (R))
#define ckd_mul(R, A, B) __builtin_mul_overflow((A), (B), (R))

#endif /* __STDC_HOSTED__ */
#endif /* __STDCKDINT_H */
`,"stddef.h":`/*===---- stddef.h - Basic type definitions --------------------------------===
 *
 * Part of the LLVM Project, under the Apache License v2.0 with LLVM Exceptions.
 * See https://llvm.org/LICENSE.txt for license information.
 * SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception
 *
 *===-----------------------------------------------------------------------===
 */

/*
 * This header is designed to be included multiple times. If any of the __need_
 * macros are defined, then only that subset of interfaces are provided. This
 * can be useful for POSIX headers that need to not expose all of stddef.h, but
 * need to use some of its interfaces. Otherwise this header provides all of
 * the expected interfaces.
 *
 * When clang modules are enabled, this header is a textual header to support
 * the multiple include behavior. As such, it doesn't directly declare anything
 * so that it doesn't add duplicate declarations to all of its includers'
 * modules.
 */
#if defined(__MVS__) && __has_include_next(<stddef.h>)
#undef __need_ptrdiff_t
#undef __need_size_t
#undef __need_rsize_t
#undef __need_wchar_t
#undef __need_NULL
#undef __need_nullptr_t
#undef __need_unreachable
#undef __need_max_align_t
#undef __need_offsetof
#undef __need_wint_t
#include <__stddef_header_macro.h>
#include_next <stddef.h>

#else

#if !defined(__need_ptrdiff_t) && !defined(__need_size_t) &&                   \\
    !defined(__need_rsize_t) && !defined(__need_wchar_t) &&                    \\
    !defined(__need_NULL) && !defined(__need_nullptr_t) &&                     \\
    !defined(__need_unreachable) && !defined(__need_max_align_t) &&            \\
    !defined(__need_offsetof) && !defined(__need_wint_t)
#define __need_ptrdiff_t
#define __need_size_t
/* ISO9899:2011 7.20 (C11 Annex K): Define rsize_t if __STDC_WANT_LIB_EXT1__ is
 * enabled. */
#if defined(__STDC_WANT_LIB_EXT1__) && __STDC_WANT_LIB_EXT1__ >= 1
#define __need_rsize_t
#endif
#define __need_wchar_t
#if !defined(__STDDEF_H) || __has_feature(modules)
/*
 * __stddef_null.h is special when building without modules: if __need_NULL is
 * set, then it will unconditionally redefine NULL. To avoid stepping on client
 * definitions of NULL, __need_NULL should only be set the first time this
 * header is included, that is when __STDDEF_H is not defined. However, when
 * building with modules, this header is a textual header and needs to
 * unconditionally include __stdef_null.h to support multiple submodules
 * exporting _Builtin_stddef.null. Take module SM with submodules A and B, whose
 * headers both include stddef.h When SM.A builds, __STDDEF_H will be defined.
 * When SM.B builds, the definition from SM.A will leak when building without
 * local submodule visibility. stddef.h wouldn't include __stddef_null.h, and
 * SM.B wouldn't import _Builtin_stddef.null, and SM.B's \`export *\` wouldn't
 * export NULL as expected. When building with modules, always include
 * __stddef_null.h so that everything works as expected.
 */
#define __need_NULL
#endif
#if (defined(__STDC_VERSION__) && __STDC_VERSION__ >= 202311L) ||              \\
    defined(__cplusplus)
#define __need_nullptr_t
#endif
#if defined(__STDC_VERSION__) && __STDC_VERSION__ >= 202311L
#define __need_unreachable
#endif
#if (defined(__STDC_VERSION__) && __STDC_VERSION__ >= 201112L) ||              \\
    (defined(__cplusplus) && __cplusplus >= 201103L)
#define __need_max_align_t
#endif
#define __need_offsetof
/* wint_t is provided by <wchar.h> and not <stddef.h>. It's here
 * for compatibility, but must be explicitly requested. Therefore
 * __need_wint_t is intentionally not defined here. */
#include <__stddef_header_macro.h>
#endif

#if defined(__need_ptrdiff_t)
#include <__stddef_ptrdiff_t.h>
#undef __need_ptrdiff_t
#endif /* defined(__need_ptrdiff_t) */

#if defined(__need_size_t)
#include <__stddef_size_t.h>
#undef __need_size_t
#endif /*defined(__need_size_t) */

#if defined(__need_rsize_t)
#include <__stddef_rsize_t.h>
#undef __need_rsize_t
#endif /* defined(__need_rsize_t) */

#if defined(__need_wchar_t)
#include <__stddef_wchar_t.h>
#undef __need_wchar_t
#endif /* defined(__need_wchar_t) */

#if defined(__need_NULL)
#include <__stddef_null.h>
#undef __need_NULL
#endif /* defined(__need_NULL) */

#if defined(__need_nullptr_t)
#include <__stddef_nullptr_t.h>
#undef __need_nullptr_t
#endif /* defined(__need_nullptr_t) */

#if defined(__need_unreachable)
#include <__stddef_unreachable.h>
#undef __need_unreachable
#endif /* defined(__need_unreachable) */

#if defined(__need_max_align_t)
#include <__stddef_max_align_t.h>
#undef __need_max_align_t
#endif /* defined(__need_max_align_t) */

#if defined(__need_offsetof)
#include <__stddef_offsetof.h>
#undef __need_offsetof
#endif /* defined(__need_offsetof) */

/* Some C libraries expect to see a wint_t here. Others (notably MinGW) will use
__WINT_TYPE__ directly; accommodate both by requiring __need_wint_t */
#if defined(__need_wint_t)
#include <__stddef_wint_t.h>
#undef __need_wint_t
#endif /* __need_wint_t */

#endif /* __MVS__ */
`,"stddefer.h":`/*===---- stddefer.h - Standard header for 'defer' -------------------------===
 *
 * Part of the LLVM Project, under the Apache License v2.0 with LLVM Exceptions.
 * See https://llvm.org/LICENSE.txt for license information.
 * SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception
 *
 *===-----------------------------------------------------------------------===
 */

#ifndef __CLANG_STDDEFER_H
#define __CLANG_STDDEFER_H

/* Provide 'defer' if '_Defer' is supported. */
#ifdef __STDC_DEFER_TS25755__
#define __STDC_VERSION_STDDEFER_H__ 202602L
#define defer _Defer
#endif

#endif /* __CLANG_STDDEFER_H */
`,"__stddef_header_macro.h":`/*===---- __stddef_header_macro.h ------------------------------------------===
 *
 * Part of the LLVM Project, under the Apache License v2.0 with LLVM Exceptions.
 * See https://llvm.org/LICENSE.txt for license information.
 * SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception
 *
 *===-----------------------------------------------------------------------===
 */

#ifndef __STDDEF_H
#define __STDDEF_H
#endif
`,"__stddef_max_align_t.h":`/*===---- __stddef_max_align_t.h - Definition of max_align_t ---------------===
 *
 * Part of the LLVM Project, under the Apache License v2.0 with LLVM Exceptions.
 * See https://llvm.org/LICENSE.txt for license information.
 * SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception
 *
 *===-----------------------------------------------------------------------===
 */

#ifndef __CLANG_MAX_ALIGN_T_DEFINED
#define __CLANG_MAX_ALIGN_T_DEFINED

#if defined(_MSC_VER)
typedef double max_align_t;
#elif defined(__APPLE__)
typedef long double max_align_t;
#else
// Define 'max_align_t' to match the GCC definition.
typedef struct {
  long long __clang_max_align_nonce1
      __attribute__((__aligned__(__alignof__(long long))));
  long double __clang_max_align_nonce2
      __attribute__((__aligned__(__alignof__(long double))));
} max_align_t;
#endif

#endif
`,"__stddef_null.h":`/*===---- __stddef_null.h - Definition of NULL -----------------------------===
 *
 * Part of the LLVM Project, under the Apache License v2.0 with LLVM Exceptions.
 * See https://llvm.org/LICENSE.txt for license information.
 * SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception
 *
 *===-----------------------------------------------------------------------===
 */

#if !defined(NULL) || !__building_module(_Builtin_stddef)

/* linux/stddef.h will define NULL to 0. glibc (and other) headers then define
 * __need_NULL and rely on stddef.h to redefine NULL to the correct value again.
 * Modules don't support redefining macros like that, but support that pattern
 * in the non-modules case.
 */
#undef NULL

#ifdef __cplusplus
#if !defined(__MINGW32__) && !defined(_MSC_VER)
#define NULL __null
#else
#define NULL 0
#endif
#else
#define NULL ((void*)0)
#endif

#endif
`,"__stddef_nullptr_t.h":`/*===---- __stddef_nullptr_t.h - Definition of nullptr_t -------------------===
 *
 * Part of the LLVM Project, under the Apache License v2.0 with LLVM Exceptions.
 * See https://llvm.org/LICENSE.txt for license information.
 * SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception
 *
 *===-----------------------------------------------------------------------===
 */

/*
 * When -fbuiltin-headers-in-system-modules is set this is a non-modular header
 * and needs to behave as if it was textual.
 */
#if !defined(_NULLPTR_T) ||                                                    \\
    (__has_feature(modules) && !__building_module(_Builtin_stddef))
#define _NULLPTR_T

#ifdef __cplusplus
#if defined(_MSC_EXTENSIONS) && defined(_NATIVE_NULLPTR_SUPPORTED)
namespace std {
typedef decltype(nullptr) nullptr_t;
}
using ::std::nullptr_t;
#endif
#elif defined(__STDC_VERSION__) && __STDC_VERSION__ >= 202311L
typedef typeof(nullptr) nullptr_t;
#endif

#endif
`,"__stddef_offsetof.h":`/*===---- __stddef_offsetof.h - Definition of offsetof ---------------------===
 *
 * Part of the LLVM Project, under the Apache License v2.0 with LLVM Exceptions.
 * See https://llvm.org/LICENSE.txt for license information.
 * SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception
 *
 *===-----------------------------------------------------------------------===
 */

/*
 * When -fbuiltin-headers-in-system-modules is set this is a non-modular header
 * and needs to behave as if it was textual.
 */
#if !defined(offsetof) ||                                                      \\
    (__has_feature(modules) && !__building_module(_Builtin_stddef))
#define offsetof(t, d) __builtin_offsetof(t, d)
#endif
`,"__stddef_ptrdiff_t.h":`/*===---- __stddef_ptrdiff_t.h - Definition of ptrdiff_t -------------------===
 *
 * Part of the LLVM Project, under the Apache License v2.0 with LLVM Exceptions.
 * See https://llvm.org/LICENSE.txt for license information.
 * SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception
 *
 *===-----------------------------------------------------------------------===
 */

/*
 * When -fbuiltin-headers-in-system-modules is set this is a non-modular header
 * and needs to behave as if it was textual.
 */
#if !defined(_PTRDIFF_T) ||                                                    \\
    (__has_feature(modules) && !__building_module(_Builtin_stddef))
#define _PTRDIFF_T

typedef __PTRDIFF_TYPE__ ptrdiff_t;

#endif
`,"__stddef_rsize_t.h":`/*===---- __stddef_rsize_t.h - Definition of rsize_t -----------------------===
 *
 * Part of the LLVM Project, under the Apache License v2.0 with LLVM Exceptions.
 * See https://llvm.org/LICENSE.txt for license information.
 * SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception
 *
 *===-----------------------------------------------------------------------===
 */

/*
 * When -fbuiltin-headers-in-system-modules is set this is a non-modular header
 * and needs to behave as if it was textual.
 */
#if !defined(_RSIZE_T) ||                                                      \\
    (__has_feature(modules) && !__building_module(_Builtin_stddef))
#define _RSIZE_T

typedef __SIZE_TYPE__ rsize_t;

#endif
`,"__stddef_size_t.h":`/*===---- __stddef_size_t.h - Definition of size_t -------------------------===
 *
 * Part of the LLVM Project, under the Apache License v2.0 with LLVM Exceptions.
 * See https://llvm.org/LICENSE.txt for license information.
 * SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception
 *
 *===-----------------------------------------------------------------------===
 */

/*
 * When -fbuiltin-headers-in-system-modules is set this is a non-modular header
 * and needs to behave as if it was textual.
 */
#if !defined(_SIZE_T) ||                                                       \\
    (__has_feature(modules) && !__building_module(_Builtin_stddef))
#define _SIZE_T

typedef __SIZE_TYPE__ size_t;

#endif
`,"__stddef_unreachable.h":`/*===---- __stddef_unreachable.h - Definition of unreachable ---------------===
 *
 * Part of the LLVM Project, under the Apache License v2.0 with LLVM Exceptions.
 * See https://llvm.org/LICENSE.txt for license information.
 * SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception
 *
 *===-----------------------------------------------------------------------===
 */

#ifndef __cplusplus

/*
 * When -fbuiltin-headers-in-system-modules is set this is a non-modular header
 * and needs to behave as if it was textual.
 */
#if !defined(unreachable) ||                                                   \\
    (__has_feature(modules) && !__building_module(_Builtin_stddef))
#define unreachable() __builtin_unreachable()
#endif

#endif
`,"__stddef_wchar_t.h":`/*===---- __stddef_wchar.h - Definition of wchar_t -------------------------===
 *
 * Part of the LLVM Project, under the Apache License v2.0 with LLVM Exceptions.
 * See https://llvm.org/LICENSE.txt for license information.
 * SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception
 *
 *===-----------------------------------------------------------------------===
 */

#if !defined(__cplusplus) || (defined(_MSC_VER) && !_NATIVE_WCHAR_T_DEFINED)

/*
 * When -fbuiltin-headers-in-system-modules is set this is a non-modular header
 * and needs to behave as if it was textual.
 */
#if !defined(_WCHAR_T) ||                                                      \\
    (__has_feature(modules) && !__building_module(_Builtin_stddef))
#define _WCHAR_T

#ifdef _MSC_EXTENSIONS
#define _WCHAR_T_DEFINED
#endif

typedef __WCHAR_TYPE__ wchar_t;

#endif

#endif
`,"__stddef_wint_t.h":`/*===---- __stddef_wint.h - Definition of wint_t ---------------------------===
 *
 * Part of the LLVM Project, under the Apache License v2.0 with LLVM Exceptions.
 * See https://llvm.org/LICENSE.txt for license information.
 * SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception
 *
 *===-----------------------------------------------------------------------===
 */

#ifndef _WINT_T
#define _WINT_T

typedef __WINT_TYPE__ wint_t;

#endif
`,"stdint.h":`/*===---- stdint.h - Standard header for sized integer types --------------===*\\
 *
 * Part of the LLVM Project, under the Apache License v2.0 with LLVM Exceptions.
 * See https://llvm.org/LICENSE.txt for license information.
 * SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception
 *
\\*===----------------------------------------------------------------------===*/

#ifndef __CLANG_STDINT_H
// AIX system headers need stdint.h to be re-enterable while _STD_TYPES_T
// is defined until an inclusion of it without _STD_TYPES_T occurs, in which
// case the header guard macro is defined.
#if !defined(_AIX) || !defined(_STD_TYPES_T) || !defined(__STDC_HOSTED__)
#define __CLANG_STDINT_H
#endif

#if defined(__MVS__) && __has_include_next(<stdint.h>)
#include_next <stdint.h>
#else

/* If we're hosted, fall back to the system's stdint.h, which might have
 * additional definitions.
 */
#if __STDC_HOSTED__ && __has_include_next(<stdint.h>)

// C99 7.18.3 Limits of other integer types
//
//  Footnote 219, 220: C++ implementations should define these macros only when
//  __STDC_LIMIT_MACROS is defined before <stdint.h> is included.
//
//  Footnote 222: C++ implementations should define these macros only when
//  __STDC_CONSTANT_MACROS is defined before <stdint.h> is included.
//
// C++11 [cstdint.syn]p2:
//
//  The macros defined by <cstdint> are provided unconditionally. In particular,
//  the symbols __STDC_LIMIT_MACROS and __STDC_CONSTANT_MACROS (mentioned in
//  footnotes 219, 220, and 222 in the C standard) play no role in C++.
//
// C11 removed the problematic footnotes.
//
// Work around this inconsistency by always defining those macros in C++ mode,
// so that a C library implementation which follows the C99 standard can be
// used in C++.
# ifdef __cplusplus
#  if !defined(__STDC_LIMIT_MACROS)
#   define __STDC_LIMIT_MACROS
#   define __STDC_LIMIT_MACROS_DEFINED_BY_CLANG
#  endif
#  if !defined(__STDC_CONSTANT_MACROS)
#   define __STDC_CONSTANT_MACROS
#   define __STDC_CONSTANT_MACROS_DEFINED_BY_CLANG
#  endif
# endif

# include_next <stdint.h>

# ifdef __STDC_LIMIT_MACROS_DEFINED_BY_CLANG
#  undef __STDC_LIMIT_MACROS
#  undef __STDC_LIMIT_MACROS_DEFINED_BY_CLANG
# endif
# ifdef __STDC_CONSTANT_MACROS_DEFINED_BY_CLANG
#  undef __STDC_CONSTANT_MACROS
#  undef __STDC_CONSTANT_MACROS_DEFINED_BY_CLANG
# endif

#else

/* C99 7.18.1.1 Exact-width integer types.
 * C99 7.18.1.2 Minimum-width integer types.
 * C99 7.18.1.3 Fastest minimum-width integer types.
 *
 * The standard requires that exact-width type be defined for 8-, 16-, 32-, and
 * 64-bit types if they are implemented. Other exact width types are optional.
 * This implementation defines an exact-width types for every integer width
 * that is represented in the standard integer types.
 *
 * The standard also requires minimum-width types be defined for 8-, 16-, 32-,
 * and 64-bit widths regardless of whether there are corresponding exact-width
 * types.
 *
 * To accommodate targets that are missing types that are exactly 8, 16, 32, or
 * 64 bits wide, this implementation takes an approach of cascading
 * redefinitions, redefining __int_leastN_t to successively smaller exact-width
 * types. It is therefore important that the types are defined in order of
 * descending widths.
 *
 * We currently assume that the minimum-width types and the fastest
 * minimum-width types are the same. This is allowed by the standard, but is
 * suboptimal.
 *
 * In violation of the standard, some targets do not implement a type that is
 * wide enough to represent all of the required widths (8-, 16-, 32-, 64-bit).
 * To accommodate these targets, a required minimum-width type is only
 * defined if there exists an exact-width type of equal or greater width.
 */

#ifdef __INT64_TYPE__
# ifndef __int8_t_defined /* glibc sys/types.h also defines int64_t*/
typedef __INT64_TYPE__ int64_t;
# endif /* __int8_t_defined */
typedef __UINT64_TYPE__ uint64_t;
# undef __int_least64_t
# define __int_least64_t int64_t
# undef __uint_least64_t
# define __uint_least64_t uint64_t
# undef __int_least32_t
# define __int_least32_t int64_t
# undef __uint_least32_t
# define __uint_least32_t uint64_t
# undef __int_least16_t
# define __int_least16_t int64_t
# undef __uint_least16_t
# define __uint_least16_t uint64_t
# undef __int_least8_t
# define __int_least8_t int64_t
# undef __uint_least8_t
# define __uint_least8_t uint64_t
#endif /* __INT64_TYPE__ */

#ifdef __int_least64_t
typedef __int_least64_t int_least64_t;
typedef __uint_least64_t uint_least64_t;
typedef __int_least64_t int_fast64_t;
typedef __uint_least64_t uint_fast64_t;
#endif /* __int_least64_t */

#ifdef __INT56_TYPE__
typedef __INT56_TYPE__ int56_t;
typedef __UINT56_TYPE__ uint56_t;
typedef int56_t int_least56_t;
typedef uint56_t uint_least56_t;
typedef int56_t int_fast56_t;
typedef uint56_t uint_fast56_t;
# undef __int_least32_t
# define __int_least32_t int56_t
# undef __uint_least32_t
# define __uint_least32_t uint56_t
# undef __int_least16_t
# define __int_least16_t int56_t
# undef __uint_least16_t
# define __uint_least16_t uint56_t
# undef __int_least8_t
# define __int_least8_t int56_t
# undef __uint_least8_t
# define __uint_least8_t uint56_t
#endif /* __INT56_TYPE__ */


#ifdef __INT48_TYPE__
typedef __INT48_TYPE__ int48_t;
typedef __UINT48_TYPE__ uint48_t;
typedef int48_t int_least48_t;
typedef uint48_t uint_least48_t;
typedef int48_t int_fast48_t;
typedef uint48_t uint_fast48_t;
# undef __int_least32_t
# define __int_least32_t int48_t
# undef __uint_least32_t
# define __uint_least32_t uint48_t
# undef __int_least16_t
# define __int_least16_t int48_t
# undef __uint_least16_t
# define __uint_least16_t uint48_t
# undef __int_least8_t
# define __int_least8_t int48_t
# undef __uint_least8_t
# define __uint_least8_t uint48_t
#endif /* __INT48_TYPE__ */


#ifdef __INT40_TYPE__
typedef __INT40_TYPE__ int40_t;
typedef __UINT40_TYPE__ uint40_t;
typedef int40_t int_least40_t;
typedef uint40_t uint_least40_t;
typedef int40_t int_fast40_t;
typedef uint40_t uint_fast40_t;
# undef __int_least32_t
# define __int_least32_t int40_t
# undef __uint_least32_t
# define __uint_least32_t uint40_t
# undef __int_least16_t
# define __int_least16_t int40_t
# undef __uint_least16_t
# define __uint_least16_t uint40_t
# undef __int_least8_t
# define __int_least8_t int40_t
# undef __uint_least8_t
# define __uint_least8_t uint40_t
#endif /* __INT40_TYPE__ */


#ifdef __INT32_TYPE__

# ifndef __int8_t_defined /* glibc sys/types.h also defines int32_t*/
typedef __INT32_TYPE__ int32_t;
# endif /* __int8_t_defined */

# ifndef __uint32_t_defined  /* more glibc compatibility */
# define __uint32_t_defined
typedef __UINT32_TYPE__ uint32_t;
# endif /* __uint32_t_defined */

# undef __int_least32_t
# define __int_least32_t int32_t
# undef __uint_least32_t
# define __uint_least32_t uint32_t
# undef __int_least16_t
# define __int_least16_t int32_t
# undef __uint_least16_t
# define __uint_least16_t uint32_t
# undef __int_least8_t
# define __int_least8_t int32_t
# undef __uint_least8_t
# define __uint_least8_t uint32_t
#endif /* __INT32_TYPE__ */

#ifdef __int_least32_t
typedef __int_least32_t int_least32_t;
typedef __uint_least32_t uint_least32_t;
typedef __int_least32_t int_fast32_t;
typedef __uint_least32_t uint_fast32_t;
#endif /* __int_least32_t */

#ifdef __INT24_TYPE__
typedef __INT24_TYPE__ int24_t;
typedef __UINT24_TYPE__ uint24_t;
typedef int24_t int_least24_t;
typedef uint24_t uint_least24_t;
typedef int24_t int_fast24_t;
typedef uint24_t uint_fast24_t;
# undef __int_least16_t
# define __int_least16_t int24_t
# undef __uint_least16_t
# define __uint_least16_t uint24_t
# undef __int_least8_t
# define __int_least8_t int24_t
# undef __uint_least8_t
# define __uint_least8_t uint24_t
#endif /* __INT24_TYPE__ */

#ifdef __INT16_TYPE__
#ifndef __int8_t_defined /* glibc sys/types.h also defines int16_t*/
typedef __INT16_TYPE__ int16_t;
#endif /* __int8_t_defined */
typedef __UINT16_TYPE__ uint16_t;
# undef __int_least16_t
# define __int_least16_t int16_t
# undef __uint_least16_t
# define __uint_least16_t uint16_t
# undef __int_least8_t
# define __int_least8_t int16_t
# undef __uint_least8_t
# define __uint_least8_t uint16_t
#endif /* __INT16_TYPE__ */

#ifdef __int_least16_t
typedef __int_least16_t int_least16_t;
typedef __uint_least16_t uint_least16_t;
typedef __int_least16_t int_fast16_t;
typedef __uint_least16_t uint_fast16_t;
#endif /* __int_least16_t */


#ifdef __INT8_TYPE__
#ifndef __int8_t_defined  /* glibc sys/types.h also defines int8_t*/
typedef __INT8_TYPE__ int8_t;
#endif /* __int8_t_defined */
typedef __UINT8_TYPE__ uint8_t;
# undef __int_least8_t
# define __int_least8_t int8_t
# undef __uint_least8_t
# define __uint_least8_t uint8_t
#endif /* __INT8_TYPE__ */

#ifdef __int_least8_t
typedef __int_least8_t int_least8_t;
typedef __uint_least8_t uint_least8_t;
typedef __int_least8_t int_fast8_t;
typedef __uint_least8_t uint_fast8_t;
#endif /* __int_least8_t */

/* prevent glibc sys/types.h from defining conflicting types */
#ifndef __int8_t_defined
# define __int8_t_defined
#endif /* __int8_t_defined */

/* C99 7.18.1.4 Integer types capable of holding object pointers.
 */
#define __stdint_join3(a,b,c) a ## b ## c

#ifndef _INTPTR_T
#ifndef __intptr_t_defined
typedef __INTPTR_TYPE__ intptr_t;
#define __intptr_t_defined
#define _INTPTR_T
#endif
#endif

#ifndef _UINTPTR_T
typedef __UINTPTR_TYPE__ uintptr_t;
#define _UINTPTR_T
#endif

/* C99 7.18.1.5 Greatest-width integer types.
 */
typedef __INTMAX_TYPE__  intmax_t;
typedef __UINTMAX_TYPE__ uintmax_t;

/* C99 7.18.4 Macros for minimum-width integer constants.
 *
 * The standard requires that integer constant macros be defined for all the
 * minimum-width types defined above. As 8-, 16-, 32-, and 64-bit minimum-width
 * types are required, the corresponding integer constant macros are defined
 * here. This implementation also defines minimum-width types for every other
 * integer width that the target implements, so corresponding macros are
 * defined below, too.
 *
 * Note that C++ should not check __STDC_CONSTANT_MACROS here, contrary to the
 * claims of the C standard (see C++ 18.3.1p2, [cstdint.syn]).
 */

#ifdef __int_least64_t
#define INT64_C(v) __INT64_C(v)
#define UINT64_C(v) __UINT64_C(v)
#endif /* __int_least64_t */


#ifdef __INT56_TYPE__
#define INT56_C(v) __INT56_C(v)
#define UINT56_C(v) __UINT56_C(v)
#endif /* __INT56_TYPE__ */


#ifdef __INT48_TYPE__
#define INT48_C(v) __INT48_C(v)
#define UINT48_C(v) __UINT48_C(v)
#endif /* __INT48_TYPE__ */


#ifdef __INT40_TYPE__
#define INT40_C(v) __INT40_C(v)
#define UINT40_C(v) __UINT40_C(v)
#endif /* __INT40_TYPE__ */


#ifdef __int_least32_t
#define INT32_C(v) __INT32_C(v)
#define UINT32_C(v) __UINT32_C(v)
#endif /* __int_least32_t */


#ifdef __INT24_TYPE__
#define INT24_C(v) __INT24_C(v)
#define UINT24_C(v) __UINT24_C(v)
#endif /* __INT24_TYPE__ */


#ifdef __int_least16_t
#define INT16_C(v) __INT16_C(v)
#define UINT16_C(v) __UINT16_C(v)
#endif /* __int_least16_t */


#ifdef __int_least8_t
#define INT8_C(v) __INT8_C(v)
#define UINT8_C(v) __UINT8_C(v)
#endif /* __int_least8_t */


/* C99 7.18.2.1 Limits of exact-width integer types.
 * C99 7.18.2.2 Limits of minimum-width integer types.
 * C99 7.18.2.3 Limits of fastest minimum-width integer types.
 *
 * The presence of limit macros are completely optional in C99.  This
 * implementation defines limits for all of the types (exact- and
 * minimum-width) that it defines above, using the limits of the minimum-width
 * type for any types that do not have exact-width representations.
 *
 * As in the type definitions, this section takes an approach of
 * successive-shrinking to determine which limits to use for the standard (8,
 * 16, 32, 64) bit widths when they don't have exact representations. It is
 * therefore important that the definitions be kept in order of decending
 * widths.
 *
 * Note that C++ should not check __STDC_LIMIT_MACROS here, contrary to the
 * claims of the C standard (see C++ 18.3.1p2, [cstdint.syn]).
 */

#ifdef __INT64_TYPE__
# define INT64_MAX           INT64_C( 9223372036854775807)
# define INT64_MIN         (-INT64_C( 9223372036854775807)-1)
# define UINT64_MAX         UINT64_C(18446744073709551615)

#if defined(__STDC_VERSION__) && __STDC_VERSION__ >= 202311L
# define UINT64_WIDTH         64
# define INT64_WIDTH          UINT64_WIDTH

# define __UINT_LEAST64_WIDTH UINT64_WIDTH
# undef __UINT_LEAST32_WIDTH
# define __UINT_LEAST32_WIDTH UINT64_WIDTH
# undef __UINT_LEAST16_WIDTH
# define __UINT_LEAST16_WIDTH UINT64_WIDTH
# undef __UINT_LEAST8_MAX
# define __UINT_LEAST8_MAX UINT64_MAX
#endif /* __STDC_VERSION__ */

# define __INT_LEAST64_MIN   INT64_MIN
# define __INT_LEAST64_MAX   INT64_MAX
# define __UINT_LEAST64_MAX UINT64_MAX
# undef __INT_LEAST32_MIN
# define __INT_LEAST32_MIN   INT64_MIN
# undef __INT_LEAST32_MAX
# define __INT_LEAST32_MAX   INT64_MAX
# undef __UINT_LEAST32_MAX
# define __UINT_LEAST32_MAX UINT64_MAX
# undef __INT_LEAST16_MIN
# define __INT_LEAST16_MIN   INT64_MIN
# undef __INT_LEAST16_MAX
# define __INT_LEAST16_MAX   INT64_MAX
# undef __UINT_LEAST16_MAX
# define __UINT_LEAST16_MAX UINT64_MAX
# undef __INT_LEAST8_MIN
# define __INT_LEAST8_MIN    INT64_MIN
# undef __INT_LEAST8_MAX
# define __INT_LEAST8_MAX    INT64_MAX
# undef __UINT_LEAST8_MAX
# define __UINT_LEAST8_MAX  UINT64_MAX
#endif /* __INT64_TYPE__ */

#ifdef __INT_LEAST64_MIN
# define INT_LEAST64_MIN   __INT_LEAST64_MIN
# define INT_LEAST64_MAX   __INT_LEAST64_MAX
# define UINT_LEAST64_MAX __UINT_LEAST64_MAX
# define INT_FAST64_MIN    __INT_LEAST64_MIN
# define INT_FAST64_MAX    __INT_LEAST64_MAX
# define UINT_FAST64_MAX  __UINT_LEAST64_MAX

#if defined(__STDC_VERSION__) &&  __STDC_VERSION__ >= 202311L
# define UINT_LEAST64_WIDTH __UINT_LEAST64_WIDTH
# define INT_LEAST64_WIDTH  UINT_LEAST64_WIDTH
# define UINT_FAST64_WIDTH  __UINT_LEAST64_WIDTH
# define INT_FAST64_WIDTH   UINT_FAST64_WIDTH
#endif /* __STDC_VERSION__ */
#endif /* __INT_LEAST64_MIN */


#ifdef __INT56_TYPE__
# define INT56_MAX           INT56_C(36028797018963967)
# define INT56_MIN         (-INT56_C(36028797018963967)-1)
# define UINT56_MAX         UINT56_C(72057594037927935)
# define INT_LEAST56_MIN     INT56_MIN
# define INT_LEAST56_MAX     INT56_MAX
# define UINT_LEAST56_MAX   UINT56_MAX
# define INT_FAST56_MIN      INT56_MIN
# define INT_FAST56_MAX      INT56_MAX
# define UINT_FAST56_MAX    UINT56_MAX

# undef __INT_LEAST32_MIN
# define __INT_LEAST32_MIN   INT56_MIN
# undef __INT_LEAST32_MAX
# define __INT_LEAST32_MAX   INT56_MAX
# undef __UINT_LEAST32_MAX
# define __UINT_LEAST32_MAX UINT56_MAX
# undef __INT_LEAST16_MIN
# define __INT_LEAST16_MIN   INT56_MIN
# undef __INT_LEAST16_MAX
# define __INT_LEAST16_MAX   INT56_MAX
# undef __UINT_LEAST16_MAX
# define __UINT_LEAST16_MAX UINT56_MAX
# undef __INT_LEAST8_MIN
# define __INT_LEAST8_MIN    INT56_MIN
# undef __INT_LEAST8_MAX
# define __INT_LEAST8_MAX    INT56_MAX
# undef __UINT_LEAST8_MAX
# define __UINT_LEAST8_MAX  UINT56_MAX

#if defined(__STDC_VERSION__) && __STDC_VERSION__ >= 202311L
# define UINT56_WIDTH         56
# define INT56_WIDTH          UINT56_WIDTH
# define UINT_LEAST56_WIDTH   UINT56_WIDTH
# define INT_LEAST56_WIDTH    UINT_LEAST56_WIDTH
# define UINT_FAST56_WIDTH    UINT56_WIDTH
# define INT_FAST56_WIDTH     UINT_FAST56_WIDTH
# undef __UINT_LEAST32_WIDTH
# define __UINT_LEAST32_WIDTH UINT56_WIDTH
# undef __UINT_LEAST16_WIDTH
# define __UINT_LEAST16_WIDTH UINT56_WIDTH
# undef __UINT_LEAST8_WIDTH
# define __UINT_LEAST8_WIDTH  UINT56_WIDTH
#endif /* __STDC_VERSION__ */
#endif /* __INT56_TYPE__ */


#ifdef __INT48_TYPE__
# define INT48_MAX           INT48_C(140737488355327)
# define INT48_MIN         (-INT48_C(140737488355327)-1)
# define UINT48_MAX         UINT48_C(281474976710655)
# define INT_LEAST48_MIN     INT48_MIN
# define INT_LEAST48_MAX     INT48_MAX
# define UINT_LEAST48_MAX   UINT48_MAX
# define INT_FAST48_MIN      INT48_MIN
# define INT_FAST48_MAX      INT48_MAX
# define UINT_FAST48_MAX    UINT48_MAX

# undef __INT_LEAST32_MIN
# define __INT_LEAST32_MIN   INT48_MIN
# undef __INT_LEAST32_MAX
# define __INT_LEAST32_MAX   INT48_MAX
# undef __UINT_LEAST32_MAX
# define __UINT_LEAST32_MAX UINT48_MAX
# undef __INT_LEAST16_MIN
# define __INT_LEAST16_MIN   INT48_MIN
# undef __INT_LEAST16_MAX
# define __INT_LEAST16_MAX   INT48_MAX
# undef __UINT_LEAST16_MAX
# define __UINT_LEAST16_MAX UINT48_MAX
# undef __INT_LEAST8_MIN
# define __INT_LEAST8_MIN    INT48_MIN
# undef __INT_LEAST8_MAX
# define __INT_LEAST8_MAX    INT48_MAX
# undef __UINT_LEAST8_MAX
# define __UINT_LEAST8_MAX  UINT48_MAX

#if defined(__STDC_VERSION__) && __STDC_VERSION__ >= 202311L
#define UINT48_WIDTH         48
#define INT48_WIDTH          UINT48_WIDTH
#define UINT_LEAST48_WIDTH   UINT48_WIDTH
#define INT_LEAST48_WIDTH    UINT_LEAST48_WIDTH
#define UINT_FAST48_WIDTH    UINT48_WIDTH
#define INT_FAST48_WIDTH     UINT_FAST48_WIDTH
#undef __UINT_LEAST32_WIDTH
#define __UINT_LEAST32_WIDTH UINT48_WIDTH
# undef __UINT_LEAST16_WIDTH
#define __UINT_LEAST16_WIDTH UINT48_WIDTH
# undef __UINT_LEAST8_WIDTH
#define __UINT_LEAST8_WIDTH  UINT48_WIDTH
#endif /* __STDC_VERSION__ */
#endif /* __INT48_TYPE__ */


#ifdef __INT40_TYPE__
# define INT40_MAX           INT40_C(549755813887)
# define INT40_MIN         (-INT40_C(549755813887)-1)
# define UINT40_MAX         UINT40_C(1099511627775)
# define INT_LEAST40_MIN     INT40_MIN
# define INT_LEAST40_MAX     INT40_MAX
# define UINT_LEAST40_MAX   UINT40_MAX
# define INT_FAST40_MIN      INT40_MIN
# define INT_FAST40_MAX      INT40_MAX
# define UINT_FAST40_MAX    UINT40_MAX

# undef __INT_LEAST32_MIN
# define __INT_LEAST32_MIN   INT40_MIN
# undef __INT_LEAST32_MAX
# define __INT_LEAST32_MAX   INT40_MAX
# undef __UINT_LEAST32_MAX
# define __UINT_LEAST32_MAX UINT40_MAX
# undef __INT_LEAST16_MIN
# define __INT_LEAST16_MIN   INT40_MIN
# undef __INT_LEAST16_MAX
# define __INT_LEAST16_MAX   INT40_MAX
# undef __UINT_LEAST16_MAX
# define __UINT_LEAST16_MAX UINT40_MAX
# undef __INT_LEAST8_MIN
# define __INT_LEAST8_MIN    INT40_MIN
# undef __INT_LEAST8_MAX
# define __INT_LEAST8_MAX    INT40_MAX
# undef __UINT_LEAST8_MAX
# define __UINT_LEAST8_MAX  UINT40_MAX

#if defined(__STDC_VERSION__) && __STDC_VERSION__ >= 202311L
# define UINT40_WIDTH         40
# define INT40_WIDTH          UINT40_WIDTH
# define UINT_LEAST40_WIDTH   UINT40_WIDTH
# define INT_LEAST40_WIDTH    UINT_LEAST40_WIDTH
# define UINT_FAST40_WIDTH    UINT40_WIDTH
# define INT_FAST40_WIDTH     UINT_FAST40_WIDTH
# undef __UINT_LEAST32_WIDTH
# define __UINT_LEAST32_WIDTH UINT40_WIDTH
# undef __UINT_LEAST16_WIDTH
# define __UINT_LEAST16_WIDTH UINT40_WIDTH
# undef __UINT_LEAST8_WIDTH
# define __UINT_LEAST8_WIDTH  UINT40_WIDTH
#endif /* __STDC_VERSION__ */
#endif /* __INT40_TYPE__ */


#ifdef __INT32_TYPE__
# define INT32_MAX           INT32_C(2147483647)
# define INT32_MIN         (-INT32_C(2147483647)-1)
# define UINT32_MAX         UINT32_C(4294967295)

# undef __INT_LEAST32_MIN
# define __INT_LEAST32_MIN   INT32_MIN
# undef __INT_LEAST32_MAX
# define __INT_LEAST32_MAX   INT32_MAX
# undef __UINT_LEAST32_MAX
# define __UINT_LEAST32_MAX UINT32_MAX
# undef __INT_LEAST16_MIN
# define __INT_LEAST16_MIN   INT32_MIN
# undef __INT_LEAST16_MAX
# define __INT_LEAST16_MAX   INT32_MAX
# undef __UINT_LEAST16_MAX
# define __UINT_LEAST16_MAX UINT32_MAX
# undef __INT_LEAST8_MIN
# define __INT_LEAST8_MIN    INT32_MIN
# undef __INT_LEAST8_MAX
# define __INT_LEAST8_MAX    INT32_MAX
# undef __UINT_LEAST8_MAX
# define __UINT_LEAST8_MAX  UINT32_MAX

#if defined(__STDC_VERSION__) && __STDC_VERSION__ >= 202311L
# define UINT32_WIDTH         32
# define INT32_WIDTH          UINT32_WIDTH
# undef __UINT_LEAST32_WIDTH
# define __UINT_LEAST32_WIDTH UINT32_WIDTH
# undef __UINT_LEAST16_WIDTH
# define __UINT_LEAST16_WIDTH UINT32_WIDTH
# undef __UINT_LEAST8_WIDTH
# define __UINT_LEAST8_WIDTH  UINT32_WIDTH
#endif /* __STDC_VERSION__ */
#endif /* __INT32_TYPE__ */

#ifdef __INT_LEAST32_MIN
# define INT_LEAST32_MIN   __INT_LEAST32_MIN
# define INT_LEAST32_MAX   __INT_LEAST32_MAX
# define UINT_LEAST32_MAX __UINT_LEAST32_MAX
# define INT_FAST32_MIN    __INT_LEAST32_MIN
# define INT_FAST32_MAX    __INT_LEAST32_MAX
# define UINT_FAST32_MAX  __UINT_LEAST32_MAX

#if defined(__STDC_VERSION__) && __STDC_VERSION__ >= 202311L
# define UINT_LEAST32_WIDTH __UINT_LEAST32_WIDTH
# define INT_LEAST32_WIDTH  UINT_LEAST32_WIDTH
# define UINT_FAST32_WIDTH  __UINT_LEAST32_WIDTH
# define INT_FAST32_WIDTH   UINT_FAST32_WIDTH
#endif /* __STDC_VERSION__ */
#endif /* __INT_LEAST32_MIN */


#ifdef __INT24_TYPE__
# define INT24_MAX           INT24_C(8388607)
# define INT24_MIN         (-INT24_C(8388607)-1)
# define UINT24_MAX         UINT24_C(16777215)
# define INT_LEAST24_MIN     INT24_MIN
# define INT_LEAST24_MAX     INT24_MAX
# define UINT_LEAST24_MAX   UINT24_MAX
# define INT_FAST24_MIN      INT24_MIN
# define INT_FAST24_MAX      INT24_MAX
# define UINT_FAST24_MAX    UINT24_MAX

# undef __INT_LEAST16_MIN
# define __INT_LEAST16_MIN   INT24_MIN
# undef __INT_LEAST16_MAX
# define __INT_LEAST16_MAX   INT24_MAX
# undef __UINT_LEAST16_MAX
# define __UINT_LEAST16_MAX UINT24_MAX
# undef __INT_LEAST8_MIN
# define __INT_LEAST8_MIN    INT24_MIN
# undef __INT_LEAST8_MAX
# define __INT_LEAST8_MAX    INT24_MAX
# undef __UINT_LEAST8_MAX
# define __UINT_LEAST8_MAX  UINT24_MAX

#if defined(__STDC_VERSION__) && __STDC_VERSION__ >= 202311L
# define UINT24_WIDTH         24
# define INT24_WIDTH          UINT24_WIDTH
# define UINT_LEAST24_WIDTH   UINT24_WIDTH
# define INT_LEAST24_WIDTH    UINT_LEAST24_WIDTH
# define UINT_FAST24_WIDTH    UINT24_WIDTH
# define INT_FAST24_WIDTH     UINT_FAST24_WIDTH
# undef __UINT_LEAST16_WIDTH
# define __UINT_LEAST16_WIDTH UINT24_WIDTH
# undef __UINT_LEAST8_WIDTH
# define __UINT_LEAST8_WIDTH  UINT24_WIDTH
#endif /* __STDC_VERSION__ */
#endif /* __INT24_TYPE__ */


#ifdef __INT16_TYPE__
#define INT16_MAX            INT16_C(32767)
#define INT16_MIN          (-INT16_C(32767)-1)
#define UINT16_MAX          UINT16_C(65535)

# undef __INT_LEAST16_MIN
# define __INT_LEAST16_MIN   INT16_MIN
# undef __INT_LEAST16_MAX
# define __INT_LEAST16_MAX   INT16_MAX
# undef __UINT_LEAST16_MAX
# define __UINT_LEAST16_MAX UINT16_MAX
# undef __INT_LEAST8_MIN
# define __INT_LEAST8_MIN    INT16_MIN
# undef __INT_LEAST8_MAX
# define __INT_LEAST8_MAX    INT16_MAX
# undef __UINT_LEAST8_MAX
# define __UINT_LEAST8_MAX  UINT16_MAX

#if defined(__STDC_VERSION__) && __STDC_VERSION__ >= 202311L
# define UINT16_WIDTH         16
# define INT16_WIDTH          UINT16_WIDTH
# undef __UINT_LEAST16_WIDTH
# define __UINT_LEAST16_WIDTH UINT16_WIDTH
# undef __UINT_LEAST8_WIDTH
# define __UINT_LEAST8_WIDTH  UINT16_WIDTH
#endif /* __STDC_VERSION__ */
#endif /* __INT16_TYPE__ */

#ifdef __INT_LEAST16_MIN
# define INT_LEAST16_MIN   __INT_LEAST16_MIN
# define INT_LEAST16_MAX   __INT_LEAST16_MAX
# define UINT_LEAST16_MAX __UINT_LEAST16_MAX
# define INT_FAST16_MIN    __INT_LEAST16_MIN
# define INT_FAST16_MAX    __INT_LEAST16_MAX
# define UINT_FAST16_MAX  __UINT_LEAST16_MAX

#if defined(__STDC_VERSION__) && __STDC_VERSION__ >= 202311L
# define UINT_LEAST16_WIDTH __UINT_LEAST16_WIDTH
# define INT_LEAST16_WIDTH  UINT_LEAST16_WIDTH
# define UINT_FAST16_WIDTH  __UINT_LEAST16_WIDTH
# define INT_FAST16_WIDTH   UINT_FAST16_WIDTH
#endif /* __STDC_VERSION__ */
#endif /* __INT_LEAST16_MIN */


#ifdef __INT8_TYPE__
# define INT8_MAX            INT8_C(127)
# define INT8_MIN          (-INT8_C(127)-1)
# define UINT8_MAX          UINT8_C(255)

# undef __INT_LEAST8_MIN
# define __INT_LEAST8_MIN    INT8_MIN
# undef __INT_LEAST8_MAX
# define __INT_LEAST8_MAX    INT8_MAX
# undef __UINT_LEAST8_MAX
# define __UINT_LEAST8_MAX  UINT8_MAX

#if defined(__STDC_VERSION__) && __STDC_VERSION__ >= 202311L
# define UINT8_WIDTH         8
# define INT8_WIDTH          UINT8_WIDTH
# undef __UINT_LEAST8_WIDTH
# define __UINT_LEAST8_WIDTH UINT8_WIDTH
#endif /* __STDC_VERSION__ */
#endif /* __INT8_TYPE__ */

#ifdef __INT_LEAST8_MIN
# define INT_LEAST8_MIN   __INT_LEAST8_MIN
# define INT_LEAST8_MAX   __INT_LEAST8_MAX
# define UINT_LEAST8_MAX __UINT_LEAST8_MAX
# define INT_FAST8_MIN    __INT_LEAST8_MIN
# define INT_FAST8_MAX    __INT_LEAST8_MAX
# define UINT_FAST8_MAX  __UINT_LEAST8_MAX

#if defined(__STDC_VERSION__) && __STDC_VERSION__ >= 202311L
# define UINT_LEAST8_WIDTH __UINT_LEAST8_WIDTH
# define INT_LEAST8_WIDTH  UINT_LEAST8_WIDTH
# define UINT_FAST8_WIDTH  __UINT_LEAST8_WIDTH
# define INT_FAST8_WIDTH   UINT_FAST8_WIDTH
#endif /* __STDC_VERSION__ */
#endif /* __INT_LEAST8_MIN */

/* Some utility macros */
#define  __INTN_MIN(n)  __stdint_join3( INT, n, _MIN)
#define  __INTN_MAX(n)  __stdint_join3( INT, n, _MAX)
#define __UINTN_MAX(n)  __stdint_join3(UINT, n, _MAX)
#define  __INTN_C(n, v) __stdint_join3( INT, n, _C(v))
#define __UINTN_C(n, v) __stdint_join3(UINT, n, _C(v))

/* C99 7.18.2.4 Limits of integer types capable of holding object pointers. */
/* C99 7.18.3 Limits of other integer types. */

#define  INTPTR_MIN  (-__INTPTR_MAX__-1)
#define  INTPTR_MAX    __INTPTR_MAX__
#define UINTPTR_MAX   __UINTPTR_MAX__
#define PTRDIFF_MIN (-__PTRDIFF_MAX__-1)
#define PTRDIFF_MAX   __PTRDIFF_MAX__
#define    SIZE_MAX      __SIZE_MAX__

/* C23 7.22.2.4 Width of integer types capable of holding object pointers. */
#if defined(__STDC_VERSION__) && __STDC_VERSION__ >= 202311L
/* NB: The C standard requires that these be the same value, but the compiler
   exposes separate internal width macros. */
#define INTPTR_WIDTH  __INTPTR_WIDTH__
#define UINTPTR_WIDTH __UINTPTR_WIDTH__
#endif

/* ISO9899:2011 7.20 (C11 Annex K): Define RSIZE_MAX if __STDC_WANT_LIB_EXT1__
 * is enabled. */
#if defined(__STDC_WANT_LIB_EXT1__) && __STDC_WANT_LIB_EXT1__ >= 1
#define   RSIZE_MAX            (SIZE_MAX >> 1)
#endif

/* C99 7.18.2.5 Limits of greatest-width integer types. */
#define  INTMAX_MIN (-__INTMAX_MAX__-1)
#define  INTMAX_MAX   __INTMAX_MAX__
#define UINTMAX_MAX  __UINTMAX_MAX__

/* C23 7.22.2.5 Width of greatest-width integer types. */
#if defined(__STDC_VERSION__) && __STDC_VERSION__ >= 202311L
/* NB: The C standard requires that these be the same value, but the compiler
   exposes separate internal width macros. */
#define INTMAX_WIDTH __INTMAX_WIDTH__
#define UINTMAX_WIDTH __UINTMAX_WIDTH__
#endif

/* C99 7.18.3 Limits of other integer types. */
#define SIG_ATOMIC_MIN __INTN_MIN(__SIG_ATOMIC_WIDTH__)
#define SIG_ATOMIC_MAX __INTN_MAX(__SIG_ATOMIC_WIDTH__)
#ifdef __WINT_UNSIGNED__
# define WINT_MIN       __UINTN_C(__WINT_WIDTH__, 0)
# define WINT_MAX       __UINTN_MAX(__WINT_WIDTH__)
#else
# define WINT_MIN       __INTN_MIN(__WINT_WIDTH__)
# define WINT_MAX       __INTN_MAX(__WINT_WIDTH__)
#endif

#ifndef WCHAR_MAX
# define WCHAR_MAX __WCHAR_MAX__
#endif
#ifndef WCHAR_MIN
# if __WCHAR_MAX__ == __INTN_MAX(__WCHAR_WIDTH__)
#  define WCHAR_MIN __INTN_MIN(__WCHAR_WIDTH__)
# else
#  define WCHAR_MIN __UINTN_C(__WCHAR_WIDTH__, 0)
# endif
#endif

/* 7.18.4.2 Macros for greatest-width integer constants. */
#define  INTMAX_C(v) __INTMAX_C(v)
#define UINTMAX_C(v) __UINTMAX_C(v)

/* C23 7.22.3.x Width of other integer types. */
#if defined(__STDC_VERSION__) && __STDC_VERSION__ >= 202311L
#define PTRDIFF_WIDTH    __PTRDIFF_WIDTH__
#define SIG_ATOMIC_WIDTH __SIG_ATOMIC_WIDTH__
#define SIZE_WIDTH       __SIZE_WIDTH__
#define WCHAR_WIDTH      __WCHAR_WIDTH__
#define WINT_WIDTH       __WINT_WIDTH__
#endif

#endif /* __STDC_HOSTED__ */
#endif /* __MVS__ */
#endif /* __CLANG_STDINT_H */
`,"stdnoreturn.h":`/*===---- stdnoreturn.h - Standard header for noreturn macro ---------------===
 *
 * Part of the LLVM Project, under the Apache License v2.0 with LLVM Exceptions.
 * See https://llvm.org/LICENSE.txt for license information.
 * SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception
 *
 *===-----------------------------------------------------------------------===
 */

#ifndef __STDNORETURN_H
#define __STDNORETURN_H

#if defined(__MVS__) && __has_include_next(<stdnoreturn.h>)
#include_next <stdnoreturn.h>
#else

#define noreturn _Noreturn
#define __noreturn_is_defined 1

#endif /* __MVS__ */

#if (defined(__STDC_VERSION__) && __STDC_VERSION__ > 201710L) &&               \\
    !defined(_CLANG_DISABLE_CRT_DEPRECATION_WARNINGS)
/* The noreturn macro is deprecated in C23. We do not mark it as such because
   including the header file in C23 is also deprecated and we do not want to
   issue a confusing diagnostic for code which includes <stdnoreturn.h>
   followed by code that writes [[noreturn]]. The issue with such code is not
   with the attribute, or the use of 'noreturn', but the inclusion of the
   header. */
/* FIXME: We should be issuing a deprecation warning here, but cannot yet due
 * to system headers which include this header file unconditionally.
 */
#endif

#endif /* __STDNORETURN_H */
`,"tgmath.h":`/*===---- tgmath.h - Standard header for type generic math ----------------===*\\
 *
 * Part of the LLVM Project, under the Apache License v2.0 with LLVM Exceptions.
 * See https://llvm.org/LICENSE.txt for license information.
 * SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception
 *
\\*===----------------------------------------------------------------------===*/

#ifndef __CLANG_TGMATH_H
#define __CLANG_TGMATH_H

/* C99 7.22 Type-generic math <tgmath.h>. */
#include <math.h>

/*
 * Allow additional definitions and implementation-defined values on Apple
 * platforms. This is done after #include <math.h> to avoid depcycle conflicts
 * between libcxx and darwin in C++ modules builds.
 */
#if defined(__APPLE__) && __STDC_HOSTED__ && __has_include_next(<tgmath.h>)
#  include_next <tgmath.h>
#else

/* C++ handles type genericity with overloading in math.h. */
#ifndef __cplusplus
#include <complex.h>

#define _TG_ATTRSp __attribute__((__overloadable__))
#define _TG_ATTRS __attribute__((__overloadable__, __always_inline__))

// promotion

typedef void _Argument_type_is_not_arithmetic;
static _Argument_type_is_not_arithmetic __tg_promote(...)
  __attribute__((__unavailable__,__overloadable__));
static double               _TG_ATTRSp __tg_promote(int);
static double               _TG_ATTRSp __tg_promote(unsigned int);
static double               _TG_ATTRSp __tg_promote(long);
static double               _TG_ATTRSp __tg_promote(unsigned long);
static double               _TG_ATTRSp __tg_promote(long long);
static double               _TG_ATTRSp __tg_promote(unsigned long long);
static float                _TG_ATTRSp __tg_promote(float);
static double               _TG_ATTRSp __tg_promote(double);
static long double          _TG_ATTRSp __tg_promote(long double);
static float _Complex       _TG_ATTRSp __tg_promote(float _Complex);
static double _Complex      _TG_ATTRSp __tg_promote(double _Complex);
static long double _Complex _TG_ATTRSp __tg_promote(long double _Complex);

#define __tg_promote1(__x)           (__typeof__(__tg_promote(__x)))
#define __tg_promote2(__x, __y)      (__typeof__(__tg_promote(__x) + \\
                                                 __tg_promote(__y)))
#define __tg_promote3(__x, __y, __z) (__typeof__(__tg_promote(__x) + \\
                                                 __tg_promote(__y) + \\
                                                 __tg_promote(__z)))

// acos

static float
    _TG_ATTRS
    __tg_acos(float __x) {return acosf(__x);}

static double
    _TG_ATTRS
    __tg_acos(double __x) {return acos(__x);}

static long double
    _TG_ATTRS
    __tg_acos(long double __x) {return acosl(__x);}

static float _Complex
    _TG_ATTRS
    __tg_acos(float _Complex __x) {return cacosf(__x);}

static double _Complex
    _TG_ATTRS
    __tg_acos(double _Complex __x) {return cacos(__x);}

static long double _Complex
    _TG_ATTRS
    __tg_acos(long double _Complex __x) {return cacosl(__x);}

#undef acos
#define acos(__x) __tg_acos(__tg_promote1((__x))(__x))

// asin

static float
    _TG_ATTRS
    __tg_asin(float __x) {return asinf(__x);}

static double
    _TG_ATTRS
    __tg_asin(double __x) {return asin(__x);}

static long double
    _TG_ATTRS
    __tg_asin(long double __x) {return asinl(__x);}

static float _Complex
    _TG_ATTRS
    __tg_asin(float _Complex __x) {return casinf(__x);}

static double _Complex
    _TG_ATTRS
    __tg_asin(double _Complex __x) {return casin(__x);}

static long double _Complex
    _TG_ATTRS
    __tg_asin(long double _Complex __x) {return casinl(__x);}

#undef asin
#define asin(__x) __tg_asin(__tg_promote1((__x))(__x))

// atan

static float
    _TG_ATTRS
    __tg_atan(float __x) {return atanf(__x);}

static double
    _TG_ATTRS
    __tg_atan(double __x) {return atan(__x);}

static long double
    _TG_ATTRS
    __tg_atan(long double __x) {return atanl(__x);}

static float _Complex
    _TG_ATTRS
    __tg_atan(float _Complex __x) {return catanf(__x);}

static double _Complex
    _TG_ATTRS
    __tg_atan(double _Complex __x) {return catan(__x);}

static long double _Complex
    _TG_ATTRS
    __tg_atan(long double _Complex __x) {return catanl(__x);}

#undef atan
#define atan(__x) __tg_atan(__tg_promote1((__x))(__x))

// acosh

static float
    _TG_ATTRS
    __tg_acosh(float __x) {return acoshf(__x);}

static double
    _TG_ATTRS
    __tg_acosh(double __x) {return acosh(__x);}

static long double
    _TG_ATTRS
    __tg_acosh(long double __x) {return acoshl(__x);}

static float _Complex
    _TG_ATTRS
    __tg_acosh(float _Complex __x) {return cacoshf(__x);}

static double _Complex
    _TG_ATTRS
    __tg_acosh(double _Complex __x) {return cacosh(__x);}

static long double _Complex
    _TG_ATTRS
    __tg_acosh(long double _Complex __x) {return cacoshl(__x);}

#undef acosh
#define acosh(__x) __tg_acosh(__tg_promote1((__x))(__x))

// asinh

static float
    _TG_ATTRS
    __tg_asinh(float __x) {return asinhf(__x);}

static double
    _TG_ATTRS
    __tg_asinh(double __x) {return asinh(__x);}

static long double
    _TG_ATTRS
    __tg_asinh(long double __x) {return asinhl(__x);}

static float _Complex
    _TG_ATTRS
    __tg_asinh(float _Complex __x) {return casinhf(__x);}

static double _Complex
    _TG_ATTRS
    __tg_asinh(double _Complex __x) {return casinh(__x);}

static long double _Complex
    _TG_ATTRS
    __tg_asinh(long double _Complex __x) {return casinhl(__x);}

#undef asinh
#define asinh(__x) __tg_asinh(__tg_promote1((__x))(__x))

// atanh

static float
    _TG_ATTRS
    __tg_atanh(float __x) {return atanhf(__x);}

static double
    _TG_ATTRS
    __tg_atanh(double __x) {return atanh(__x);}

static long double
    _TG_ATTRS
    __tg_atanh(long double __x) {return atanhl(__x);}

static float _Complex
    _TG_ATTRS
    __tg_atanh(float _Complex __x) {return catanhf(__x);}

static double _Complex
    _TG_ATTRS
    __tg_atanh(double _Complex __x) {return catanh(__x);}

static long double _Complex
    _TG_ATTRS
    __tg_atanh(long double _Complex __x) {return catanhl(__x);}

#undef atanh
#define atanh(__x) __tg_atanh(__tg_promote1((__x))(__x))

// cos

static float
    _TG_ATTRS
    __tg_cos(float __x) {return cosf(__x);}

static double
    _TG_ATTRS
    __tg_cos(double __x) {return cos(__x);}

static long double
    _TG_ATTRS
    __tg_cos(long double __x) {return cosl(__x);}

static float _Complex
    _TG_ATTRS
    __tg_cos(float _Complex __x) {return ccosf(__x);}

static double _Complex
    _TG_ATTRS
    __tg_cos(double _Complex __x) {return ccos(__x);}

static long double _Complex
    _TG_ATTRS
    __tg_cos(long double _Complex __x) {return ccosl(__x);}

#undef cos
#define cos(__x) __tg_cos(__tg_promote1((__x))(__x))

// sin

static float
    _TG_ATTRS
    __tg_sin(float __x) {return sinf(__x);}

static double
    _TG_ATTRS
    __tg_sin(double __x) {return sin(__x);}

static long double
    _TG_ATTRS
    __tg_sin(long double __x) {return sinl(__x);}

static float _Complex
    _TG_ATTRS
    __tg_sin(float _Complex __x) {return csinf(__x);}

static double _Complex
    _TG_ATTRS
    __tg_sin(double _Complex __x) {return csin(__x);}

static long double _Complex
    _TG_ATTRS
    __tg_sin(long double _Complex __x) {return csinl(__x);}

#undef sin
#define sin(__x) __tg_sin(__tg_promote1((__x))(__x))

// tan

static float
    _TG_ATTRS
    __tg_tan(float __x) {return tanf(__x);}

static double
    _TG_ATTRS
    __tg_tan(double __x) {return tan(__x);}

static long double
    _TG_ATTRS
    __tg_tan(long double __x) {return tanl(__x);}

static float _Complex
    _TG_ATTRS
    __tg_tan(float _Complex __x) {return ctanf(__x);}

static double _Complex
    _TG_ATTRS
    __tg_tan(double _Complex __x) {return ctan(__x);}

static long double _Complex
    _TG_ATTRS
    __tg_tan(long double _Complex __x) {return ctanl(__x);}

#undef tan
#define tan(__x) __tg_tan(__tg_promote1((__x))(__x))

// cosh

static float
    _TG_ATTRS
    __tg_cosh(float __x) {return coshf(__x);}

static double
    _TG_ATTRS
    __tg_cosh(double __x) {return cosh(__x);}

static long double
    _TG_ATTRS
    __tg_cosh(long double __x) {return coshl(__x);}

static float _Complex
    _TG_ATTRS
    __tg_cosh(float _Complex __x) {return ccoshf(__x);}

static double _Complex
    _TG_ATTRS
    __tg_cosh(double _Complex __x) {return ccosh(__x);}

static long double _Complex
    _TG_ATTRS
    __tg_cosh(long double _Complex __x) {return ccoshl(__x);}

#undef cosh
#define cosh(__x) __tg_cosh(__tg_promote1((__x))(__x))

// sinh

static float
    _TG_ATTRS
    __tg_sinh(float __x) {return sinhf(__x);}

static double
    _TG_ATTRS
    __tg_sinh(double __x) {return sinh(__x);}

static long double
    _TG_ATTRS
    __tg_sinh(long double __x) {return sinhl(__x);}

static float _Complex
    _TG_ATTRS
    __tg_sinh(float _Complex __x) {return csinhf(__x);}

static double _Complex
    _TG_ATTRS
    __tg_sinh(double _Complex __x) {return csinh(__x);}

static long double _Complex
    _TG_ATTRS
    __tg_sinh(long double _Complex __x) {return csinhl(__x);}

#undef sinh
#define sinh(__x) __tg_sinh(__tg_promote1((__x))(__x))

// tanh

static float
    _TG_ATTRS
    __tg_tanh(float __x) {return tanhf(__x);}

static double
    _TG_ATTRS
    __tg_tanh(double __x) {return tanh(__x);}

static long double
    _TG_ATTRS
    __tg_tanh(long double __x) {return tanhl(__x);}

static float _Complex
    _TG_ATTRS
    __tg_tanh(float _Complex __x) {return ctanhf(__x);}

static double _Complex
    _TG_ATTRS
    __tg_tanh(double _Complex __x) {return ctanh(__x);}

static long double _Complex
    _TG_ATTRS
    __tg_tanh(long double _Complex __x) {return ctanhl(__x);}

#undef tanh
#define tanh(__x) __tg_tanh(__tg_promote1((__x))(__x))

// exp

static float
    _TG_ATTRS
    __tg_exp(float __x) {return expf(__x);}

static double
    _TG_ATTRS
    __tg_exp(double __x) {return exp(__x);}

static long double
    _TG_ATTRS
    __tg_exp(long double __x) {return expl(__x);}

static float _Complex
    _TG_ATTRS
    __tg_exp(float _Complex __x) {return cexpf(__x);}

static double _Complex
    _TG_ATTRS
    __tg_exp(double _Complex __x) {return cexp(__x);}

static long double _Complex
    _TG_ATTRS
    __tg_exp(long double _Complex __x) {return cexpl(__x);}

#undef exp
#define exp(__x) __tg_exp(__tg_promote1((__x))(__x))

// log

static float
    _TG_ATTRS
    __tg_log(float __x) {return logf(__x);}

static double
    _TG_ATTRS
    __tg_log(double __x) {return log(__x);}

static long double
    _TG_ATTRS
    __tg_log(long double __x) {return logl(__x);}

static float _Complex
    _TG_ATTRS
    __tg_log(float _Complex __x) {return clogf(__x);}

static double _Complex
    _TG_ATTRS
    __tg_log(double _Complex __x) {return clog(__x);}

static long double _Complex
    _TG_ATTRS
    __tg_log(long double _Complex __x) {return clogl(__x);}

#undef log
#define log(__x) __tg_log(__tg_promote1((__x))(__x))

// pow

static float
    _TG_ATTRS
    __tg_pow(float __x, float __y) {return powf(__x, __y);}

static double
    _TG_ATTRS
    __tg_pow(double __x, double __y) {return pow(__x, __y);}

static long double
    _TG_ATTRS
    __tg_pow(long double __x, long double __y) {return powl(__x, __y);}

static float _Complex
    _TG_ATTRS
    __tg_pow(float _Complex __x, float _Complex __y) {return cpowf(__x, __y);}

static double _Complex
    _TG_ATTRS
    __tg_pow(double _Complex __x, double _Complex __y) {return cpow(__x, __y);}

static long double _Complex
    _TG_ATTRS
    __tg_pow(long double _Complex __x, long double _Complex __y)
    {return cpowl(__x, __y);}

#undef pow
#define pow(__x, __y) __tg_pow(__tg_promote2((__x), (__y))(__x), \\
                               __tg_promote2((__x), (__y))(__y))

// sqrt

static float
    _TG_ATTRS
    __tg_sqrt(float __x) {return sqrtf(__x);}

static double
    _TG_ATTRS
    __tg_sqrt(double __x) {return sqrt(__x);}

static long double
    _TG_ATTRS
    __tg_sqrt(long double __x) {return sqrtl(__x);}

static float _Complex
    _TG_ATTRS
    __tg_sqrt(float _Complex __x) {return csqrtf(__x);}

static double _Complex
    _TG_ATTRS
    __tg_sqrt(double _Complex __x) {return csqrt(__x);}

static long double _Complex
    _TG_ATTRS
    __tg_sqrt(long double _Complex __x) {return csqrtl(__x);}

#undef sqrt
#define sqrt(__x) __tg_sqrt(__tg_promote1((__x))(__x))

// fabs

static float
    _TG_ATTRS
    __tg_fabs(float __x) {return fabsf(__x);}

static double
    _TG_ATTRS
    __tg_fabs(double __x) {return fabs(__x);}

static long double
    _TG_ATTRS
    __tg_fabs(long double __x) {return fabsl(__x);}

static float
    _TG_ATTRS
    __tg_fabs(float _Complex __x) {return cabsf(__x);}

static double
    _TG_ATTRS
    __tg_fabs(double _Complex __x) {return cabs(__x);}

static long double
    _TG_ATTRS
    __tg_fabs(long double _Complex __x) {return cabsl(__x);}

#undef fabs
#define fabs(__x) __tg_fabs(__tg_promote1((__x))(__x))

// atan2

static float
    _TG_ATTRS
    __tg_atan2(float __x, float __y) {return atan2f(__x, __y);}

static double
    _TG_ATTRS
    __tg_atan2(double __x, double __y) {return atan2(__x, __y);}

static long double
    _TG_ATTRS
    __tg_atan2(long double __x, long double __y) {return atan2l(__x, __y);}

#undef atan2
#define atan2(__x, __y) __tg_atan2(__tg_promote2((__x), (__y))(__x), \\
                                   __tg_promote2((__x), (__y))(__y))

// cbrt

static float
    _TG_ATTRS
    __tg_cbrt(float __x) {return cbrtf(__x);}

static double
    _TG_ATTRS
    __tg_cbrt(double __x) {return cbrt(__x);}

static long double
    _TG_ATTRS
    __tg_cbrt(long double __x) {return cbrtl(__x);}

#undef cbrt
#define cbrt(__x) __tg_cbrt(__tg_promote1((__x))(__x))

// ceil

static float
    _TG_ATTRS
    __tg_ceil(float __x) {return ceilf(__x);}

static double
    _TG_ATTRS
    __tg_ceil(double __x) {return ceil(__x);}

static long double
    _TG_ATTRS
    __tg_ceil(long double __x) {return ceill(__x);}

#undef ceil
#define ceil(__x) __tg_ceil(__tg_promote1((__x))(__x))

// copysign

static float
    _TG_ATTRS
    __tg_copysign(float __x, float __y) {return copysignf(__x, __y);}

static double
    _TG_ATTRS
    __tg_copysign(double __x, double __y) {return copysign(__x, __y);}

static long double
    _TG_ATTRS
    __tg_copysign(long double __x, long double __y) {return copysignl(__x, __y);}

#undef copysign
#define copysign(__x, __y) __tg_copysign(__tg_promote2((__x), (__y))(__x), \\
                                         __tg_promote2((__x), (__y))(__y))

// erf

static float
    _TG_ATTRS
    __tg_erf(float __x) {return erff(__x);}

static double
    _TG_ATTRS
    __tg_erf(double __x) {return erf(__x);}

static long double
    _TG_ATTRS
    __tg_erf(long double __x) {return erfl(__x);}

#undef erf
#define erf(__x) __tg_erf(__tg_promote1((__x))(__x))

// erfc

static float
    _TG_ATTRS
    __tg_erfc(float __x) {return erfcf(__x);}

static double
    _TG_ATTRS
    __tg_erfc(double __x) {return erfc(__x);}

static long double
    _TG_ATTRS
    __tg_erfc(long double __x) {return erfcl(__x);}

#undef erfc
#define erfc(__x) __tg_erfc(__tg_promote1((__x))(__x))

// exp2

static float
    _TG_ATTRS
    __tg_exp2(float __x) {return exp2f(__x);}

static double
    _TG_ATTRS
    __tg_exp2(double __x) {return exp2(__x);}

static long double
    _TG_ATTRS
    __tg_exp2(long double __x) {return exp2l(__x);}

#undef exp2
#define exp2(__x) __tg_exp2(__tg_promote1((__x))(__x))

// expm1

static float
    _TG_ATTRS
    __tg_expm1(float __x) {return expm1f(__x);}

static double
    _TG_ATTRS
    __tg_expm1(double __x) {return expm1(__x);}

static long double
    _TG_ATTRS
    __tg_expm1(long double __x) {return expm1l(__x);}

#undef expm1
#define expm1(__x) __tg_expm1(__tg_promote1((__x))(__x))

// fdim

static float
    _TG_ATTRS
    __tg_fdim(float __x, float __y) {return fdimf(__x, __y);}

static double
    _TG_ATTRS
    __tg_fdim(double __x, double __y) {return fdim(__x, __y);}

static long double
    _TG_ATTRS
    __tg_fdim(long double __x, long double __y) {return fdiml(__x, __y);}

#undef fdim
#define fdim(__x, __y) __tg_fdim(__tg_promote2((__x), (__y))(__x), \\
                                 __tg_promote2((__x), (__y))(__y))

// floor

static float
    _TG_ATTRS
    __tg_floor(float __x) {return floorf(__x);}

static double
    _TG_ATTRS
    __tg_floor(double __x) {return floor(__x);}

static long double
    _TG_ATTRS
    __tg_floor(long double __x) {return floorl(__x);}

#undef floor
#define floor(__x) __tg_floor(__tg_promote1((__x))(__x))

// fma

static float
    _TG_ATTRS
    __tg_fma(float __x, float __y, float __z)
    {return fmaf(__x, __y, __z);}

static double
    _TG_ATTRS
    __tg_fma(double __x, double __y, double __z)
    {return fma(__x, __y, __z);}

static long double
    _TG_ATTRS
    __tg_fma(long double __x,long double __y, long double __z)
    {return fmal(__x, __y, __z);}

#undef fma
#define fma(__x, __y, __z)                                \\
        __tg_fma(__tg_promote3((__x), (__y), (__z))(__x), \\
                 __tg_promote3((__x), (__y), (__z))(__y), \\
                 __tg_promote3((__x), (__y), (__z))(__z))

// fmax

static float
    _TG_ATTRS
    __tg_fmax(float __x, float __y) {return fmaxf(__x, __y);}

static double
    _TG_ATTRS
    __tg_fmax(double __x, double __y) {return fmax(__x, __y);}

static long double
    _TG_ATTRS
    __tg_fmax(long double __x, long double __y) {return fmaxl(__x, __y);}

#undef fmax
#define fmax(__x, __y) __tg_fmax(__tg_promote2((__x), (__y))(__x), \\
                                 __tg_promote2((__x), (__y))(__y))

// fmin

static float
    _TG_ATTRS
    __tg_fmin(float __x, float __y) {return fminf(__x, __y);}

static double
    _TG_ATTRS
    __tg_fmin(double __x, double __y) {return fmin(__x, __y);}

static long double
    _TG_ATTRS
    __tg_fmin(long double __x, long double __y) {return fminl(__x, __y);}

#undef fmin
#define fmin(__x, __y) __tg_fmin(__tg_promote2((__x), (__y))(__x), \\
                                 __tg_promote2((__x), (__y))(__y))

// fmod

static float
    _TG_ATTRS
    __tg_fmod(float __x, float __y) {return fmodf(__x, __y);}

static double
    _TG_ATTRS
    __tg_fmod(double __x, double __y) {return fmod(__x, __y);}

static long double
    _TG_ATTRS
    __tg_fmod(long double __x, long double __y) {return fmodl(__x, __y);}

#undef fmod
#define fmod(__x, __y) __tg_fmod(__tg_promote2((__x), (__y))(__x), \\
                                 __tg_promote2((__x), (__y))(__y))

// frexp

static float
    _TG_ATTRS
    __tg_frexp(float __x, int* __y) {return frexpf(__x, __y);}

static double
    _TG_ATTRS
    __tg_frexp(double __x, int* __y) {return frexp(__x, __y);}

static long double
    _TG_ATTRS
    __tg_frexp(long double __x, int* __y) {return frexpl(__x, __y);}

#undef frexp
#define frexp(__x, __y) __tg_frexp(__tg_promote1((__x))(__x), __y)

// hypot

static float
    _TG_ATTRS
    __tg_hypot(float __x, float __y) {return hypotf(__x, __y);}

static double
    _TG_ATTRS
    __tg_hypot(double __x, double __y) {return hypot(__x, __y);}

static long double
    _TG_ATTRS
    __tg_hypot(long double __x, long double __y) {return hypotl(__x, __y);}

#undef hypot
#define hypot(__x, __y) __tg_hypot(__tg_promote2((__x), (__y))(__x), \\
                                   __tg_promote2((__x), (__y))(__y))

// ilogb

static int
    _TG_ATTRS
    __tg_ilogb(float __x) {return ilogbf(__x);}

static int
    _TG_ATTRS
    __tg_ilogb(double __x) {return ilogb(__x);}

static int
    _TG_ATTRS
    __tg_ilogb(long double __x) {return ilogbl(__x);}

#undef ilogb
#define ilogb(__x) __tg_ilogb(__tg_promote1((__x))(__x))

// ldexp

static float
    _TG_ATTRS
    __tg_ldexp(float __x, int __y) {return ldexpf(__x, __y);}

static double
    _TG_ATTRS
    __tg_ldexp(double __x, int __y) {return ldexp(__x, __y);}

static long double
    _TG_ATTRS
    __tg_ldexp(long double __x, int __y) {return ldexpl(__x, __y);}

#undef ldexp
#define ldexp(__x, __y) __tg_ldexp(__tg_promote1((__x))(__x), __y)

// lgamma

static float
    _TG_ATTRS
    __tg_lgamma(float __x) {return lgammaf(__x);}

static double
    _TG_ATTRS
    __tg_lgamma(double __x) {return lgamma(__x);}

static long double
    _TG_ATTRS
    __tg_lgamma(long double __x) {return lgammal(__x);}

#undef lgamma
#define lgamma(__x) __tg_lgamma(__tg_promote1((__x))(__x))

// llrint

static long long
    _TG_ATTRS
    __tg_llrint(float __x) {return llrintf(__x);}

static long long
    _TG_ATTRS
    __tg_llrint(double __x) {return llrint(__x);}

static long long
    _TG_ATTRS
    __tg_llrint(long double __x) {return llrintl(__x);}

#undef llrint
#define llrint(__x) __tg_llrint(__tg_promote1((__x))(__x))

// llround

static long long
    _TG_ATTRS
    __tg_llround(float __x) {return llroundf(__x);}

static long long
    _TG_ATTRS
    __tg_llround(double __x) {return llround(__x);}

static long long
    _TG_ATTRS
    __tg_llround(long double __x) {return llroundl(__x);}

#undef llround
#define llround(__x) __tg_llround(__tg_promote1((__x))(__x))

// log10

static float
    _TG_ATTRS
    __tg_log10(float __x) {return log10f(__x);}

static double
    _TG_ATTRS
    __tg_log10(double __x) {return log10(__x);}

static long double
    _TG_ATTRS
    __tg_log10(long double __x) {return log10l(__x);}

#undef log10
#define log10(__x) __tg_log10(__tg_promote1((__x))(__x))

// log1p

static float
    _TG_ATTRS
    __tg_log1p(float __x) {return log1pf(__x);}

static double
    _TG_ATTRS
    __tg_log1p(double __x) {return log1p(__x);}

static long double
    _TG_ATTRS
    __tg_log1p(long double __x) {return log1pl(__x);}

#undef log1p
#define log1p(__x) __tg_log1p(__tg_promote1((__x))(__x))

// log2

static float
    _TG_ATTRS
    __tg_log2(float __x) {return log2f(__x);}

static double
    _TG_ATTRS
    __tg_log2(double __x) {return log2(__x);}

static long double
    _TG_ATTRS
    __tg_log2(long double __x) {return log2l(__x);}

#undef log2
#define log2(__x) __tg_log2(__tg_promote1((__x))(__x))

// logb

static float
    _TG_ATTRS
    __tg_logb(float __x) {return logbf(__x);}

static double
    _TG_ATTRS
    __tg_logb(double __x) {return logb(__x);}

static long double
    _TG_ATTRS
    __tg_logb(long double __x) {return logbl(__x);}

#undef logb
#define logb(__x) __tg_logb(__tg_promote1((__x))(__x))

// lrint

static long
    _TG_ATTRS
    __tg_lrint(float __x) {return lrintf(__x);}

static long
    _TG_ATTRS
    __tg_lrint(double __x) {return lrint(__x);}

static long
    _TG_ATTRS
    __tg_lrint(long double __x) {return lrintl(__x);}

#undef lrint
#define lrint(__x) __tg_lrint(__tg_promote1((__x))(__x))

// lround

static long
    _TG_ATTRS
    __tg_lround(float __x) {return lroundf(__x);}

static long
    _TG_ATTRS
    __tg_lround(double __x) {return lround(__x);}

static long
    _TG_ATTRS
    __tg_lround(long double __x) {return lroundl(__x);}

#undef lround
#define lround(__x) __tg_lround(__tg_promote1((__x))(__x))

// nearbyint

static float
    _TG_ATTRS
    __tg_nearbyint(float __x) {return nearbyintf(__x);}

static double
    _TG_ATTRS
    __tg_nearbyint(double __x) {return nearbyint(__x);}

static long double
    _TG_ATTRS
    __tg_nearbyint(long double __x) {return nearbyintl(__x);}

#undef nearbyint
#define nearbyint(__x) __tg_nearbyint(__tg_promote1((__x))(__x))

// nextafter

static float
    _TG_ATTRS
    __tg_nextafter(float __x, float __y) {return nextafterf(__x, __y);}

static double
    _TG_ATTRS
    __tg_nextafter(double __x, double __y) {return nextafter(__x, __y);}

static long double
    _TG_ATTRS
    __tg_nextafter(long double __x, long double __y) {return nextafterl(__x, __y);}

#undef nextafter
#define nextafter(__x, __y) __tg_nextafter(__tg_promote2((__x), (__y))(__x), \\
                                           __tg_promote2((__x), (__y))(__y))

// nexttoward

static float
    _TG_ATTRS
    __tg_nexttoward(float __x, long double __y) {return nexttowardf(__x, __y);}

static double
    _TG_ATTRS
    __tg_nexttoward(double __x, long double __y) {return nexttoward(__x, __y);}

static long double
    _TG_ATTRS
    __tg_nexttoward(long double __x, long double __y) {return nexttowardl(__x, __y);}

#undef nexttoward
#define nexttoward(__x, __y) __tg_nexttoward(__tg_promote1((__x))(__x), (__y))

// remainder

static float
    _TG_ATTRS
    __tg_remainder(float __x, float __y) {return remainderf(__x, __y);}

static double
    _TG_ATTRS
    __tg_remainder(double __x, double __y) {return remainder(__x, __y);}

static long double
    _TG_ATTRS
    __tg_remainder(long double __x, long double __y) {return remainderl(__x, __y);}

#undef remainder
#define remainder(__x, __y) __tg_remainder(__tg_promote2((__x), (__y))(__x), \\
                                           __tg_promote2((__x), (__y))(__y))

// remquo

static float
    _TG_ATTRS
    __tg_remquo(float __x, float __y, int* __z)
    {return remquof(__x, __y, __z);}

static double
    _TG_ATTRS
    __tg_remquo(double __x, double __y, int* __z)
    {return remquo(__x, __y, __z);}

static long double
    _TG_ATTRS
    __tg_remquo(long double __x,long double __y, int* __z)
    {return remquol(__x, __y, __z);}

#undef remquo
#define remquo(__x, __y, __z)                         \\
        __tg_remquo(__tg_promote2((__x), (__y))(__x), \\
                    __tg_promote2((__x), (__y))(__y), \\
                    (__z))

// rint

static float
    _TG_ATTRS
    __tg_rint(float __x) {return rintf(__x);}

static double
    _TG_ATTRS
    __tg_rint(double __x) {return rint(__x);}

static long double
    _TG_ATTRS
    __tg_rint(long double __x) {return rintl(__x);}

#undef rint
#define rint(__x) __tg_rint(__tg_promote1((__x))(__x))

// round

static float
    _TG_ATTRS
    __tg_round(float __x) {return roundf(__x);}

static double
    _TG_ATTRS
    __tg_round(double __x) {return round(__x);}

static long double
    _TG_ATTRS
    __tg_round(long double __x) {return roundl(__x);}

#undef round
#define round(__x) __tg_round(__tg_promote1((__x))(__x))

// scalbn

static float
    _TG_ATTRS
    __tg_scalbn(float __x, int __y) {return scalbnf(__x, __y);}

static double
    _TG_ATTRS
    __tg_scalbn(double __x, int __y) {return scalbn(__x, __y);}

static long double
    _TG_ATTRS
    __tg_scalbn(long double __x, int __y) {return scalbnl(__x, __y);}

#undef scalbn
#define scalbn(__x, __y) __tg_scalbn(__tg_promote1((__x))(__x), __y)

// scalbln

static float
    _TG_ATTRS
    __tg_scalbln(float __x, long __y) {return scalblnf(__x, __y);}

static double
    _TG_ATTRS
    __tg_scalbln(double __x, long __y) {return scalbln(__x, __y);}

static long double
    _TG_ATTRS
    __tg_scalbln(long double __x, long __y) {return scalblnl(__x, __y);}

#undef scalbln
#define scalbln(__x, __y) __tg_scalbln(__tg_promote1((__x))(__x), __y)

// tgamma

static float
    _TG_ATTRS
    __tg_tgamma(float __x) {return tgammaf(__x);}

static double
    _TG_ATTRS
    __tg_tgamma(double __x) {return tgamma(__x);}

static long double
    _TG_ATTRS
    __tg_tgamma(long double __x) {return tgammal(__x);}

#undef tgamma
#define tgamma(__x) __tg_tgamma(__tg_promote1((__x))(__x))

// trunc

static float
    _TG_ATTRS
    __tg_trunc(float __x) {return truncf(__x);}

static double
    _TG_ATTRS
    __tg_trunc(double __x) {return trunc(__x);}

static long double
    _TG_ATTRS
    __tg_trunc(long double __x) {return truncl(__x);}

#undef trunc
#define trunc(__x) __tg_trunc(__tg_promote1((__x))(__x))

// carg

static float
    _TG_ATTRS
    __tg_carg(float __x) {return atan2f(0.F, __x);}

static double
    _TG_ATTRS
    __tg_carg(double __x) {return atan2(0., __x);}

static long double
    _TG_ATTRS
    __tg_carg(long double __x) {return atan2l(0.L, __x);}

static float
    _TG_ATTRS
    __tg_carg(float _Complex __x) {return cargf(__x);}

static double
    _TG_ATTRS
    __tg_carg(double _Complex __x) {return carg(__x);}

static long double
    _TG_ATTRS
    __tg_carg(long double _Complex __x) {return cargl(__x);}

#undef carg
#define carg(__x) __tg_carg(__tg_promote1((__x))(__x))

// cimag

static float
    _TG_ATTRS
    __tg_cimag(float __x) {return 0;}

static double
    _TG_ATTRS
    __tg_cimag(double __x) {return 0;}

static long double
    _TG_ATTRS
    __tg_cimag(long double __x) {return 0;}

static float
    _TG_ATTRS
    __tg_cimag(float _Complex __x) {return cimagf(__x);}

static double
    _TG_ATTRS
    __tg_cimag(double _Complex __x) {return cimag(__x);}

static long double
    _TG_ATTRS
    __tg_cimag(long double _Complex __x) {return cimagl(__x);}

#undef cimag
#define cimag(__x) __tg_cimag(__tg_promote1((__x))(__x))

// conj

static float _Complex
    _TG_ATTRS
    __tg_conj(float __x) {return __x;}

static double _Complex
    _TG_ATTRS
    __tg_conj(double __x) {return __x;}

static long double _Complex
    _TG_ATTRS
    __tg_conj(long double __x) {return __x;}

static float _Complex
    _TG_ATTRS
    __tg_conj(float _Complex __x) {return conjf(__x);}

static double _Complex
    _TG_ATTRS
    __tg_conj(double _Complex __x) {return conj(__x);}

static long double _Complex
    _TG_ATTRS
    __tg_conj(long double _Complex __x) {return conjl(__x);}

#undef conj
#define conj(__x) __tg_conj(__tg_promote1((__x))(__x))

// cproj

static float _Complex
    _TG_ATTRS
    __tg_cproj(float __x) {return cprojf(__x);}

static double _Complex
    _TG_ATTRS
    __tg_cproj(double __x) {return cproj(__x);}

static long double _Complex
    _TG_ATTRS
    __tg_cproj(long double __x) {return cprojl(__x);}

static float _Complex
    _TG_ATTRS
    __tg_cproj(float _Complex __x) {return cprojf(__x);}

static double _Complex
    _TG_ATTRS
    __tg_cproj(double _Complex __x) {return cproj(__x);}

static long double _Complex
    _TG_ATTRS
    __tg_cproj(long double _Complex __x) {return cprojl(__x);}

#undef cproj
#define cproj(__x) __tg_cproj(__tg_promote1((__x))(__x))

// creal

static float
    _TG_ATTRS
    __tg_creal(float __x) {return __x;}

static double
    _TG_ATTRS
    __tg_creal(double __x) {return __x;}

static long double
    _TG_ATTRS
    __tg_creal(long double __x) {return __x;}

static float
    _TG_ATTRS
    __tg_creal(float _Complex __x) {return crealf(__x);}

static double
    _TG_ATTRS
    __tg_creal(double _Complex __x) {return creal(__x);}

static long double
    _TG_ATTRS
    __tg_creal(long double _Complex __x) {return creall(__x);}

#undef creal
#define creal(__x) __tg_creal(__tg_promote1((__x))(__x))

#undef _TG_ATTRSp
#undef _TG_ATTRS

#endif /* __cplusplus */
#endif /* __has_include_next */
#endif /* __CLANG_TGMATH_H */
`,"unwind.h":`/*===---- unwind.h - Stack unwinding ----------------------------------------===
 *
 * Part of the LLVM Project, under the Apache License v2.0 with LLVM Exceptions.
 * See https://llvm.org/LICENSE.txt for license information.
 * SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception
 *
 *===-----------------------------------------------------------------------===
 */

/* See "Data Definitions for libgcc_s" in the Linux Standard Base.*/

#ifndef __CLANG_UNWIND_H
#define __CLANG_UNWIND_H

#if defined(__APPLE__) && __has_include_next(<unwind.h>)
/* Darwin (from 11.x on) provide an unwind.h. If that's available,
 * use it. libunwind wraps some of its definitions in #ifdef _GNU_SOURCE,
 * so define that around the include.*/
# ifndef _GNU_SOURCE
#  define _SHOULD_UNDEFINE_GNU_SOURCE
#  define _GNU_SOURCE
# endif
// libunwind's unwind.h reflects the current visibility.  However, Mozilla
// builds with -fvisibility=hidden and relies on gcc's unwind.h to reset the
// visibility to default and export its contents.  gcc also allows users to
// override its override by #defining HIDE_EXPORTS (but note, this only obeys
// the user's -fvisibility setting; it doesn't hide any exports on its own).  We
// imitate gcc's header here:
# ifdef HIDE_EXPORTS
#  include_next <unwind.h>
# else
#  pragma GCC visibility push(default)
#  include_next <unwind.h>
#  pragma GCC visibility pop
# endif
# ifdef _SHOULD_UNDEFINE_GNU_SOURCE
#  undef _GNU_SOURCE
#  undef _SHOULD_UNDEFINE_GNU_SOURCE
# endif
#else

#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

/* It is a bit strange for a header to play with the visibility of the
   symbols it declares, but this matches gcc's behavior and some programs
   depend on it */
#ifndef HIDE_EXPORTS
#pragma GCC visibility push(default)
#endif

typedef uintptr_t _Unwind_Word __attribute__((__mode__(__unwind_word__)));
typedef intptr_t _Unwind_Sword __attribute__((__mode__(__unwind_word__)));
typedef uintptr_t _Unwind_Ptr;
typedef uintptr_t _Unwind_Internal_Ptr;
typedef uint64_t _Unwind_Exception_Class;

typedef intptr_t _sleb128_t;
typedef uintptr_t _uleb128_t;

struct _Unwind_Context;
#if defined(__arm__) && !(defined(__USING_SJLJ_EXCEPTIONS__) || \\
                          defined(__ARM_DWARF_EH__) || defined(__SEH__))
struct _Unwind_Control_Block;
typedef struct _Unwind_Control_Block _Unwind_Control_Block;
#define _Unwind_Exception _Unwind_Control_Block /* Alias */
#else
struct _Unwind_Exception;
typedef struct _Unwind_Exception _Unwind_Exception;
#endif
typedef enum {
  _URC_NO_REASON = 0,
#if defined(__arm__) && !defined(__USING_SJLJ_EXCEPTIONS__) && \\
    !defined(__ARM_DWARF_EH__) && !defined(__SEH__)
  _URC_OK = 0, /* used by ARM EHABI */
#endif
  _URC_FOREIGN_EXCEPTION_CAUGHT = 1,

  _URC_FATAL_PHASE2_ERROR = 2,
  _URC_FATAL_PHASE1_ERROR = 3,
  _URC_NORMAL_STOP = 4,

  _URC_END_OF_STACK = 5,
  _URC_HANDLER_FOUND = 6,
  _URC_INSTALL_CONTEXT = 7,
  _URC_CONTINUE_UNWIND = 8,
#if defined(__arm__) && !defined(__USING_SJLJ_EXCEPTIONS__) && \\
    !defined(__ARM_DWARF_EH__) && !defined(__SEH__)
  _URC_FAILURE = 9 /* used by ARM EHABI */
#endif
} _Unwind_Reason_Code;

typedef enum {
  _UA_SEARCH_PHASE = 1,
  _UA_CLEANUP_PHASE = 2,

  _UA_HANDLER_FRAME = 4,
  _UA_FORCE_UNWIND = 8,
  _UA_END_OF_STACK = 16 /* gcc extension to C++ ABI */
} _Unwind_Action;

typedef void (*_Unwind_Exception_Cleanup_Fn)(_Unwind_Reason_Code,
                                             _Unwind_Exception *);

#if defined(__arm__) && !(defined(__USING_SJLJ_EXCEPTIONS__) || \\
                          defined(__ARM_DWARF_EH__) || defined(__SEH__))
typedef struct _Unwind_Control_Block _Unwind_Control_Block;
typedef uint32_t _Unwind_EHT_Header;

struct _Unwind_Control_Block {
  uint64_t exception_class;
  void (*exception_cleanup)(_Unwind_Reason_Code, _Unwind_Control_Block *);
  /* unwinder cache (private fields for the unwinder's use) */
  struct {
    uint32_t reserved1; /* forced unwind stop function, 0 if not forced */
    uint32_t reserved2; /* personality routine */
    uint32_t reserved3; /* callsite */
    uint32_t reserved4; /* forced unwind stop argument */
    uint32_t reserved5;
  } unwinder_cache;
  /* propagation barrier cache (valid after phase 1) */
  struct {
    uint32_t sp;
    uint32_t bitpattern[5];
  } barrier_cache;
  /* cleanup cache (preserved over cleanup) */
  struct {
    uint32_t bitpattern[4];
  } cleanup_cache;
  /* personality cache (for personality's benefit) */
  struct {
    uint32_t fnstart;         /* function start address */
    _Unwind_EHT_Header *ehtp; /* pointer to EHT entry header word */
    uint32_t additional;      /* additional data */
    uint32_t reserved1;
  } pr_cache;
  long long int : 0; /* force alignment of next item to 8-byte boundary */
} __attribute__((__aligned__(8)));
#else
struct _Unwind_Exception {
  _Unwind_Exception_Class exception_class;
  _Unwind_Exception_Cleanup_Fn exception_cleanup;
#if !defined (__USING_SJLJ_EXCEPTIONS__) && defined (__SEH__)
  _Unwind_Word private_[6];
#else
  _Unwind_Word private_1;
  _Unwind_Word private_2;
#endif
  /* The Itanium ABI requires that _Unwind_Exception objects are "double-word
   * aligned".  GCC has interpreted this to mean "use the maximum useful
   * alignment for the target"; so do we. */
} __attribute__((__aligned__));
#endif

typedef _Unwind_Reason_Code (*_Unwind_Stop_Fn)(int, _Unwind_Action,
                                               _Unwind_Exception_Class,
                                               _Unwind_Exception *,
                                               struct _Unwind_Context *,
                                               void *);

typedef _Unwind_Reason_Code (*_Unwind_Personality_Fn)(int, _Unwind_Action,
                                                      _Unwind_Exception_Class,
                                                      _Unwind_Exception *,
                                                      struct _Unwind_Context *);
typedef _Unwind_Personality_Fn __personality_routine;

typedef _Unwind_Reason_Code (*_Unwind_Trace_Fn)(struct _Unwind_Context *,
                                                void *);

#if defined(__arm__) && !(defined(__USING_SJLJ_EXCEPTIONS__) ||                \\
                          defined(__ARM_DWARF_EH__) || defined(__SEH__))
typedef enum {
  _UVRSC_CORE = 0,        /* integer register */
  _UVRSC_VFP = 1,         /* vfp */
  _UVRSC_WMMXD = 3,       /* Intel WMMX data register */
  _UVRSC_WMMXC = 4,       /* Intel WMMX control register */
  _UVRSC_PSEUDO = 5       /* Special purpose pseudo register */
} _Unwind_VRS_RegClass;

typedef enum {
  _UVRSD_UINT32 = 0,
  _UVRSD_VFPX = 1,
  _UVRSD_UINT64 = 3,
  _UVRSD_FLOAT = 4,
  _UVRSD_DOUBLE = 5
} _Unwind_VRS_DataRepresentation;

typedef enum {
  _UVRSR_OK = 0,
  _UVRSR_NOT_IMPLEMENTED = 1,
  _UVRSR_FAILED = 2
} _Unwind_VRS_Result;

typedef uint32_t _Unwind_State;
#define _US_VIRTUAL_UNWIND_FRAME  ((_Unwind_State)0)
#define _US_UNWIND_FRAME_STARTING ((_Unwind_State)1)
#define _US_UNWIND_FRAME_RESUME   ((_Unwind_State)2)
#define _US_ACTION_MASK           ((_Unwind_State)3)
#define _US_FORCE_UNWIND          ((_Unwind_State)8)

_Unwind_VRS_Result _Unwind_VRS_Get(struct _Unwind_Context *__context,
  _Unwind_VRS_RegClass __regclass,
  uint32_t __regno,
  _Unwind_VRS_DataRepresentation __representation,
  void *__valuep);

_Unwind_VRS_Result _Unwind_VRS_Set(struct _Unwind_Context *__context,
  _Unwind_VRS_RegClass __regclass,
  uint32_t __regno,
  _Unwind_VRS_DataRepresentation __representation,
  void *__valuep);

static __inline__
_Unwind_Word _Unwind_GetGR(struct _Unwind_Context *__context, int __index) {
  _Unwind_Word __value;
  _Unwind_VRS_Get(__context, _UVRSC_CORE, __index, _UVRSD_UINT32, &__value);
  return __value;
}

static __inline__
void _Unwind_SetGR(struct _Unwind_Context *__context, int __index,
                   _Unwind_Word __value) {
  _Unwind_VRS_Set(__context, _UVRSC_CORE, __index, _UVRSD_UINT32, &__value);
}

static __inline__
_Unwind_Word _Unwind_GetIP(struct _Unwind_Context *__context) {
  _Unwind_Word __ip = _Unwind_GetGR(__context, 15);
  return __ip & ~(_Unwind_Word)(0x1); /* Remove thumb mode bit. */
}

static __inline__
void _Unwind_SetIP(struct _Unwind_Context *__context, _Unwind_Word __value) {
  _Unwind_Word __thumb_mode_bit = _Unwind_GetGR(__context, 15) & 0x1;
  _Unwind_SetGR(__context, 15, __value | __thumb_mode_bit);
}
#else
_Unwind_Word _Unwind_GetGR(struct _Unwind_Context *, int);
void _Unwind_SetGR(struct _Unwind_Context *, int, _Unwind_Word);

_Unwind_Word _Unwind_GetIP(struct _Unwind_Context *);
void _Unwind_SetIP(struct _Unwind_Context *, _Unwind_Word);
#endif


_Unwind_Word _Unwind_GetIPInfo(struct _Unwind_Context *, int *);

_Unwind_Word _Unwind_GetCFA(struct _Unwind_Context *);

_Unwind_Word _Unwind_GetBSP(struct _Unwind_Context *);

void *_Unwind_GetLanguageSpecificData(struct _Unwind_Context *);

_Unwind_Ptr _Unwind_GetRegionStart(struct _Unwind_Context *);

/* DWARF EH functions; currently not available on Darwin/ARM */
#if !defined(__APPLE__) || !defined(__arm__)
_Unwind_Reason_Code _Unwind_RaiseException(_Unwind_Exception *);
_Unwind_Reason_Code _Unwind_ForcedUnwind(_Unwind_Exception *, _Unwind_Stop_Fn,
                                         void *);
void _Unwind_DeleteException(_Unwind_Exception *);
void _Unwind_Resume(_Unwind_Exception *);
_Unwind_Reason_Code _Unwind_Resume_or_Rethrow(_Unwind_Exception *);

#endif

_Unwind_Reason_Code _Unwind_Backtrace(_Unwind_Trace_Fn, void *);

/* setjmp(3)/longjmp(3) stuff */
typedef struct SjLj_Function_Context *_Unwind_FunctionContext_t;

void _Unwind_SjLj_Register(_Unwind_FunctionContext_t);
void _Unwind_SjLj_Unregister(_Unwind_FunctionContext_t);
_Unwind_Reason_Code _Unwind_SjLj_RaiseException(_Unwind_Exception *);
_Unwind_Reason_Code _Unwind_SjLj_ForcedUnwind(_Unwind_Exception *,
                                              _Unwind_Stop_Fn, void *);
void _Unwind_SjLj_Resume(_Unwind_Exception *);
_Unwind_Reason_Code _Unwind_SjLj_Resume_or_Rethrow(_Unwind_Exception *);

void *_Unwind_FindEnclosingFunction(void *);

#ifdef __APPLE__

_Unwind_Ptr _Unwind_GetDataRelBase(struct _Unwind_Context *)
    __attribute__((__unavailable__));
_Unwind_Ptr _Unwind_GetTextRelBase(struct _Unwind_Context *)
    __attribute__((__unavailable__));

/* Darwin-specific functions */
void __register_frame(const void *);
void __deregister_frame(const void *);

struct dwarf_eh_bases {
  uintptr_t tbase;
  uintptr_t dbase;
  uintptr_t func;
};
void *_Unwind_Find_FDE(const void *, struct dwarf_eh_bases *);

void __register_frame_info_bases(const void *, void *, void *, void *)
  __attribute__((__unavailable__));
void __register_frame_info(const void *, void *) __attribute__((__unavailable__));
void __register_frame_info_table_bases(const void *, void*, void *, void *)
  __attribute__((__unavailable__));
void __register_frame_info_table(const void *, void *)
  __attribute__((__unavailable__));
void __register_frame_table(const void *) __attribute__((__unavailable__));
void __deregister_frame_info(const void *) __attribute__((__unavailable__));
void __deregister_frame_info_bases(const void *)__attribute__((__unavailable__));

#else

_Unwind_Ptr _Unwind_GetDataRelBase(struct _Unwind_Context *);
_Unwind_Ptr _Unwind_GetTextRelBase(struct _Unwind_Context *);

#endif


#ifndef HIDE_EXPORTS
#pragma GCC visibility pop
#endif

#ifdef __cplusplus
}
#endif

#endif

#endif /* __CLANG_UNWIND_H */
`,"varargs.h":`/*===---- varargs.h - Variable argument handling -------------------------------------===
*
* Part of the LLVM Project, under the Apache License v2.0 with LLVM Exceptions.
* See https://llvm.org/LICENSE.txt for license information.
* SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception
*
*===-----------------------------------------------------------------------===
*/
#ifndef __VARARGS_H
#define __VARARGS_H
#if defined(__MVS__) && __has_include_next(<varargs.h>)
#include_next <varargs.h>
#else
#error "Please use <stdarg.h> instead of <varargs.h>"
#endif /* __MVS__ */
#endif
`}),yn=Object.freeze({name:`clang`,version:`22.1.8`,revision:`ca7933e47d3a3451d81e72ac174dcb5aa28b59d1`});function bn(e,t,n){if(t?.name!==yn.name||t.version!==yn.version||t.revision!==yn.revision||n!==`/lib/clang/22`)return!1;let r=new TextDecoder(`utf-8`,{fatal:!0}),i=[];for(let[a,o]of Object.entries(vn)){let s=`${n}/include/${a}`;try{let n=e.readFile(s);if(n!==null){if(r.decode(n)!==o)throw Error(`Clang ${t.version} resource header differs from its pinned source: ${a}`)}else i.push([s,o])}catch(e){throw Error(`Unable to inspect Clang ${t.version} resource header ${a}: ${e instanceof Error?e.message:String(e)}`,{cause:e})}}if(i.length)try{e.mkdirTree(`${n}/include`)}catch(e){throw Error(`Unable to prepare Clang ${t.version} resource header directory: ${e instanceof Error?e.message:String(e)}`,{cause:e})}let a=new TextEncoder;for(let[n,r]of i)try{e.writeFile(n,a.encode(r))}catch(e){throw Error(`Unable to install Clang ${t.version} resource header ${n.slice(n.lastIndexOf(`/`)+1)}: ${e instanceof Error?e.message:String(e)}`,{cause:e})}return!0}const xn=Object.freeze({name:`clang`,version:`22.1.8`,revision:`ca7933e47d3a3451d81e72ac174dcb5aa28b59d1`}),Sn=Object.freeze({path:`ostream`,bytes:8445,sha256:`f193fb44780e6aed1fb4cf9da83142fcceb62efc7d4087cd051c117db12fce81`}),Cn=Object.freeze({"__algorithm/ranges_contains_subrange.h":`//===----------------------------------------------------------------------===//
//
// Part of the LLVM Project, under the Apache License v2.0 with LLVM Exceptions.
// See https://llvm.org/LICENSE.txt for license information.
// SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception
//
//===----------------------------------------------------------------------===//

#ifndef _LIBCPP___ALGORITHM_RANGES_CONTAINS_SUBRANGE_H
#define _LIBCPP___ALGORITHM_RANGES_CONTAINS_SUBRANGE_H

#include <__algorithm/ranges_search.h>
#include <__config>
#include <__functional/identity.h>
#include <__functional/ranges_operations.h>
#include <__functional/reference_wrapper.h>
#include <__iterator/concepts.h>
#include <__iterator/indirectly_comparable.h>
#include <__iterator/projected.h>
#include <__ranges/access.h>
#include <__ranges/concepts.h>
#include <__ranges/size.h>
#include <__ranges/subrange.h>
#include <__utility/move.h>

#if !defined(_LIBCPP_HAS_NO_PRAGMA_SYSTEM_HEADER)
#  pragma GCC system_header
#endif

_LIBCPP_PUSH_MACROS
#include <__undef_macros>

#if _LIBCPP_STD_VER >= 23

_LIBCPP_BEGIN_NAMESPACE_STD

namespace ranges {
struct __contains_subrange {
  template <forward_iterator _Iter1,
            sentinel_for<_Iter1> _Sent1,
            forward_iterator _Iter2,
            sentinel_for<_Iter2> _Sent2,
            class _Pred  = ranges::equal_to,
            class _Proj1 = identity,
            class _Proj2 = identity>
    requires indirectly_comparable<_Iter1, _Iter2, _Pred, _Proj1, _Proj2>
  [[nodiscard]] _LIBCPP_HIDE_FROM_ABI constexpr bool static operator()(
      _Iter1 __first1,
      _Sent1 __last1,
      _Iter2 __first2,
      _Sent2 __last2,
      _Pred __pred   = {},
      _Proj1 __proj1 = {},
      _Proj2 __proj2 = {}) {
    if (__first2 == __last2)
      return true;

    auto __ret = ranges::search(
        std::move(__first1), __last1, std::move(__first2), __last2, __pred, std::ref(__proj1), std::ref(__proj2));
    return __ret.empty() == false;
  }

  template <forward_range _Range1,
            forward_range _Range2,
            class _Pred  = ranges::equal_to,
            class _Proj1 = identity,
            class _Proj2 = identity>
    requires indirectly_comparable<iterator_t<_Range1>, iterator_t<_Range2>, _Pred, _Proj1, _Proj2>
  [[nodiscard]] _LIBCPP_HIDE_FROM_ABI constexpr bool static
  operator()(_Range1&& __range1, _Range2&& __range2, _Pred __pred = {}, _Proj1 __proj1 = {}, _Proj2 __proj2 = {}) {
    if constexpr (sized_range<_Range2>) {
      if (ranges::size(__range2) == 0)
        return true;
    } else {
      if (ranges::begin(__range2) == ranges::end(__range2))
        return true;
    }

    auto __ret = ranges::search(__range1, __range2, __pred, std::ref(__proj1), std::ref(__proj2));
    return __ret.empty() == false;
  }
};

inline namespace __cpo {
inline constexpr auto contains_subrange = __contains_subrange{};
} // namespace __cpo
} // namespace ranges

_LIBCPP_END_NAMESPACE_STD

#endif // _LIBCPP_STD_VER >= 23

_LIBCPP_POP_MACROS

#endif // _LIBCPP___ALGORITHM_RANGES_CONTAINS_SUBRANGE_H
`,"__algorithm/ranges_ends_with.h":`//===----------------------------------------------------------------------===//
//
// Part of the LLVM Project, under the Apache License v2.0 with LLVM Exceptions.
// See https://llvm.org/LICENSE.txt for license information.
// SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception
//
//===----------------------------------------------------------------------===//

#ifndef _LIBCPP___ALGORITHM_RANGES_ENDS_WITH_H
#define _LIBCPP___ALGORITHM_RANGES_ENDS_WITH_H

#include <__algorithm/ranges_equal.h>
#include <__algorithm/ranges_starts_with.h>
#include <__config>
#include <__functional/identity.h>
#include <__functional/ranges_operations.h>
#include <__functional/reference_wrapper.h>
#include <__iterator/advance.h>
#include <__iterator/concepts.h>
#include <__iterator/distance.h>
#include <__iterator/indirectly_comparable.h>
#include <__iterator/reverse_iterator.h>
#include <__ranges/access.h>
#include <__ranges/concepts.h>
#include <__ranges/size.h>
#include <__utility/move.h>

#if !defined(_LIBCPP_HAS_NO_PRAGMA_SYSTEM_HEADER)
#  pragma GCC system_header
#endif

_LIBCPP_PUSH_MACROS
#include <__undef_macros>

#if _LIBCPP_STD_VER >= 23

_LIBCPP_BEGIN_NAMESPACE_STD

namespace ranges {
struct __ends_with {
  template <class _Iter1, class _Sent1, class _Iter2, class _Sent2, class _Pred, class _Proj1, class _Proj2>
  _LIBCPP_HIDE_FROM_ABI static constexpr bool __ends_with_fn_impl_bidirectional(
      _Iter1 __first1,
      _Sent1 __last1,
      _Iter2 __first2,
      _Sent2 __last2,
      _Pred& __pred,
      _Proj1& __proj1,
      _Proj2& __proj2) {
    auto __rbegin1 = std::make_reverse_iterator(__last1);
    auto __rend1   = std::make_reverse_iterator(__first1);
    auto __rbegin2 = std::make_reverse_iterator(__last2);
    auto __rend2   = std::make_reverse_iterator(__first2);
    return ranges::starts_with(
        __rbegin1, __rend1, __rbegin2, __rend2, std::ref(__pred), std::ref(__proj1), std::ref(__proj2));
  }

  template <class _Iter1, class _Sent1, class _Iter2, class _Sent2, class _Pred, class _Proj1, class _Proj2>
  _LIBCPP_HIDE_FROM_ABI static constexpr bool __ends_with_fn_impl(
      _Iter1 __first1,
      _Sent1 __last1,
      _Iter2 __first2,
      _Sent2 __last2,
      _Pred& __pred,
      _Proj1& __proj1,
      _Proj2& __proj2) {
    if constexpr (std::bidirectional_iterator<_Sent1> && std::bidirectional_iterator<_Sent2> &&
                  (!std::random_access_iterator<_Sent1>) && (!std::random_access_iterator<_Sent2>)) {
      return __ends_with_fn_impl_bidirectional(__first1, __last1, __first2, __last2, __pred, __proj1, __proj2);

    } else {
      auto __n1 = ranges::distance(__first1, __last1);
      auto __n2 = ranges::distance(__first2, __last2);
      if (__n2 == 0)
        return true;
      if (__n2 > __n1)
        return false;

      return __ends_with_fn_impl_with_offset(
          std::move(__first1),
          std::move(__last1),
          std::move(__first2),
          std::move(__last2),
          __pred,
          __proj1,
          __proj2,
          __n1 - __n2);
    }
  }

  template <class _Iter1,
            class _Sent1,
            class _Iter2,
            class _Sent2,
            class _Pred,
            class _Proj1,
            class _Proj2,
            class _Offset>
  static _LIBCPP_HIDE_FROM_ABI constexpr bool __ends_with_fn_impl_with_offset(
      _Iter1 __first1,
      _Sent1 __last1,
      _Iter2 __first2,
      _Sent2 __last2,
      _Pred& __pred,
      _Proj1& __proj1,
      _Proj2& __proj2,
      _Offset __offset) {
    if constexpr (std::bidirectional_iterator<_Sent1> && std::bidirectional_iterator<_Sent2> &&
                  !std::random_access_iterator<_Sent1> && !std::random_access_iterator<_Sent2>) {
      return __ends_with_fn_impl_bidirectional(
          std::move(__first1), std::move(__last1), std::move(__first2), std::move(__last2), __pred, __proj1, __proj2);

    } else {
      ranges::advance(__first1, __offset);
      return ranges::equal(
          std::move(__first1),
          std::move(__last1),
          std::move(__first2),
          std::move(__last2),
          std::ref(__pred),
          std::ref(__proj1),
          std::ref(__proj2));
    }
  }

  template <input_iterator _Iter1,
            sentinel_for<_Iter1> _Sent1,
            input_iterator _Iter2,
            sentinel_for<_Iter2> _Sent2,
            class _Pred  = ranges::equal_to,
            class _Proj1 = identity,
            class _Proj2 = identity>
    requires(forward_iterator<_Iter1> || sized_sentinel_for<_Sent1, _Iter1>) &&
            (forward_iterator<_Iter2> || sized_sentinel_for<_Sent2, _Iter2>) &&
            indirectly_comparable<_Iter1, _Iter2, _Pred, _Proj1, _Proj2>
  [[nodiscard]] _LIBCPP_HIDE_FROM_ABI constexpr bool operator()(
      _Iter1 __first1,
      _Sent1 __last1,
      _Iter2 __first2,
      _Sent2 __last2,
      _Pred __pred   = {},
      _Proj1 __proj1 = {},
      _Proj2 __proj2 = {}) const {
    return __ends_with_fn_impl(
        std::move(__first1), std::move(__last1), std::move(__first2), std::move(__last2), __pred, __proj1, __proj2);
  }

  template <input_range _Range1,
            input_range _Range2,
            class _Pred  = ranges::equal_to,
            class _Proj1 = identity,
            class _Proj2 = identity>
    requires(forward_range<_Range1> || sized_range<_Range1>) && (forward_range<_Range2> || sized_range<_Range2>) &&
            indirectly_comparable<iterator_t<_Range1>, iterator_t<_Range2>, _Pred, _Proj1, _Proj2>
  [[nodiscard]] _LIBCPP_HIDE_FROM_ABI constexpr bool operator()(
      _Range1&& __range1, _Range2&& __range2, _Pred __pred = {}, _Proj1 __proj1 = {}, _Proj2 __proj2 = {}) const {
    if constexpr (sized_range<_Range1> && sized_range<_Range2>) {
      auto __n1 = ranges::size(__range1);
      auto __n2 = ranges::size(__range2);
      if (__n2 == 0)
        return true;
      if (__n2 > __n1)
        return false;
      auto __offset = __n1 - __n2;

      return __ends_with_fn_impl_with_offset(
          ranges::begin(__range1),
          ranges::end(__range1),
          ranges::begin(__range2),
          ranges::end(__range2),
          __pred,
          __proj1,
          __proj2,
          __offset);

    } else {
      return __ends_with_fn_impl(
          ranges::begin(__range1),
          ranges::end(__range1),
          ranges::begin(__range2),
          ranges::end(__range2),
          __pred,
          __proj1,
          __proj2);
    }
  }
};

inline namespace __cpo {
inline constexpr auto ends_with = __ends_with{};
} // namespace __cpo
} // namespace ranges

_LIBCPP_END_NAMESPACE_STD

#endif // _LIBCPP_STD_VER >= 23

_LIBCPP_POP_MACROS

#endif // _LIBCPP___ALGORITHM_RANGES_ENDS_WITH_H
`,"__algorithm/ranges_find_last.h":`//===----------------------------------------------------------------------===//
//
// Part of the LLVM Project, under the Apache License v2.0 with LLVM Exceptions.
// See https://llvm.org/LICENSE.txt for license information.
// SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception
//
//===----------------------------------------------------------------------===//

#ifndef _LIBCPP___ALGORITHM_RANGES_FIND_LAST_H
#define _LIBCPP___ALGORITHM_RANGES_FIND_LAST_H

#include <__config>
#include <__functional/identity.h>
#include <__functional/invoke.h>
#include <__functional/ranges_operations.h>
#include <__iterator/concepts.h>
#include <__iterator/indirectly_comparable.h>
#include <__iterator/next.h>
#include <__iterator/prev.h>
#include <__iterator/projected.h>
#include <__ranges/access.h>
#include <__ranges/concepts.h>
#include <__ranges/subrange.h>
#include <__utility/forward.h>
#include <__utility/move.h>

#if !defined(_LIBCPP_HAS_NO_PRAGMA_SYSTEM_HEADER)
#  pragma GCC system_header
#endif

_LIBCPP_PUSH_MACROS
#include <__undef_macros>

#if _LIBCPP_STD_VER >= 23

_LIBCPP_BEGIN_NAMESPACE_STD

namespace ranges {

template <class _Iter, class _Sent, class _Pred, class _Proj>
_LIBCPP_HIDE_FROM_ABI constexpr subrange<_Iter>
__find_last_impl(_Iter __first, _Sent __last, _Pred __pred, _Proj& __proj) {
  if (__first == __last) {
    return subrange<_Iter>(__first, __first);
  }

  if constexpr (bidirectional_iterator<_Iter>) {
    auto __last_it = ranges::next(__first, __last);
    for (auto __it = ranges::prev(__last_it); __it != __first; --__it) {
      if (__pred(std::invoke(__proj, *__it))) {
        return subrange<_Iter>(std::move(__it), std::move(__last_it));
      }
    }
    if (__pred(std::invoke(__proj, *__first))) {
      return subrange<_Iter>(std::move(__first), std::move(__last_it));
    }
    return subrange<_Iter>(__last_it, __last_it);
  } else {
    bool __found = false;
    _Iter __found_it;
    for (; __first != __last; ++__first) {
      if (__pred(std::invoke(__proj, *__first))) {
        __found    = true;
        __found_it = __first;
      }
    }

    if (__found) {
      return subrange<_Iter>(std::move(__found_it), std::move(__first));
    } else {
      return subrange<_Iter>(__first, __first);
    }
  }
}

struct __find_last {
  template <class _Type>
  struct __op {
    const _Type& __value;
    template <class _Elem>
    _LIBCPP_HIDE_FROM_ABI constexpr decltype(auto) operator()(_Elem&& __elem) const {
      return std::forward<_Elem>(__elem) == __value;
    }
  };

  template <forward_iterator _Iter, sentinel_for<_Iter> _Sent, class _Type, class _Proj = identity>
    requires indirect_binary_predicate<ranges::equal_to, projected<_Iter, _Proj>, const _Type*>
  [[nodiscard]] _LIBCPP_HIDE_FROM_ABI constexpr static subrange<_Iter>
  operator()(_Iter __first, _Sent __last, const _Type& __value, _Proj __proj = {}) {
    return ranges::__find_last_impl(std::move(__first), std::move(__last), __op<_Type>{__value}, __proj);
  }

  template <forward_range _Range, class _Type, class _Proj = identity>
    requires indirect_binary_predicate<ranges::equal_to, projected<iterator_t<_Range>, _Proj>, const _Type*>
  [[nodiscard]] _LIBCPP_HIDE_FROM_ABI constexpr static borrowed_subrange_t<_Range>
  operator()(_Range&& __range, const _Type& __value, _Proj __proj = {}) {
    return ranges::__find_last_impl(ranges::begin(__range), ranges::end(__range), __op<_Type>{__value}, __proj);
  }
};

struct __find_last_if {
  template <class _Pred>
  struct __op {
    _Pred& __pred;
    template <class _Elem>
    _LIBCPP_HIDE_FROM_ABI constexpr decltype(auto) operator()(_Elem&& __elem) const {
      return std::invoke(__pred, std::forward<_Elem>(__elem));
    }
  };

  template <forward_iterator _Iter,
            sentinel_for<_Iter> _Sent,
            class _Proj = identity,
            indirect_unary_predicate<projected<_Iter, _Proj>> _Pred>
  [[nodiscard]] _LIBCPP_HIDE_FROM_ABI constexpr static subrange<_Iter>
  operator()(_Iter __first, _Sent __last, _Pred __pred, _Proj __proj = {}) {
    return ranges::__find_last_impl(std::move(__first), std::move(__last), __op<_Pred>{__pred}, __proj);
  }

  template <forward_range _Range,
            class _Proj = identity,
            indirect_unary_predicate<projected<iterator_t<_Range>, _Proj>> _Pred>
  [[nodiscard]] _LIBCPP_HIDE_FROM_ABI constexpr static borrowed_subrange_t<_Range>
  operator()(_Range&& __range, _Pred __pred, _Proj __proj = {}) {
    return ranges::__find_last_impl(ranges::begin(__range), ranges::end(__range), __op<_Pred>{__pred}, __proj);
  }
};

struct __find_last_if_not {
  template <class _Pred>
  struct __op {
    _Pred& __pred;
    template <class _Elem>
    _LIBCPP_HIDE_FROM_ABI constexpr decltype(auto) operator()(_Elem&& __elem) const {
      return !std::invoke(__pred, std::forward<_Elem>(__elem));
    }
  };

  template <forward_iterator _Iter,
            sentinel_for<_Iter> _Sent,
            class _Proj = identity,
            indirect_unary_predicate<projected<_Iter, _Proj>> _Pred>
  [[nodiscard]] _LIBCPP_HIDE_FROM_ABI constexpr static subrange<_Iter>
  operator()(_Iter __first, _Sent __last, _Pred __pred, _Proj __proj = {}) {
    return ranges::__find_last_impl(std::move(__first), std::move(__last), __op<_Pred>{__pred}, __proj);
  }

  template <forward_range _Range,
            class _Proj = identity,
            indirect_unary_predicate<projected<iterator_t<_Range>, _Proj>> _Pred>
  [[nodiscard]] _LIBCPP_HIDE_FROM_ABI constexpr static borrowed_subrange_t<_Range>
  operator()(_Range&& __range, _Pred __pred, _Proj __proj = {}) {
    return ranges::__find_last_impl(ranges::begin(__range), ranges::end(__range), __op<_Pred>{__pred}, __proj);
  }
};

inline namespace __cpo {
inline constexpr auto find_last        = __find_last{};
inline constexpr auto find_last_if     = __find_last_if{};
inline constexpr auto find_last_if_not = __find_last_if_not{};
} // namespace __cpo
} // namespace ranges

_LIBCPP_END_NAMESPACE_STD

#endif // _LIBCPP_STD_VER >= 23

_LIBCPP_POP_MACROS

#endif // _LIBCPP___ALGORITHM_RANGES_FIND_LAST_H
`,"__algorithm/ranges_fold.h":`// -*- C++ -*-
//===----------------------------------------------------------------------===//
//
// Part of the LLVM Project, under the Apache License v2.0 with LLVM Exceptions.
// See https://llvm.org/LICENSE.txt for license information.
// SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception
//
//===----------------------------------------------------------------------===//

#ifndef _LIBCPP___ALGORITHM_RANGES_FOLD_H
#define _LIBCPP___ALGORITHM_RANGES_FOLD_H

#include <__concepts/assignable.h>
#include <__concepts/constructible.h>
#include <__concepts/convertible_to.h>
#include <__concepts/invocable.h>
#include <__concepts/movable.h>
#include <__config>
#include <__functional/invoke.h>
#include <__functional/reference_wrapper.h>
#include <__iterator/concepts.h>
#include <__iterator/iterator_traits.h>
#include <__iterator/next.h>
#include <__ranges/access.h>
#include <__ranges/concepts.h>
#include <__ranges/dangling.h>
#include <__type_traits/decay.h>
#include <__type_traits/invoke.h>
#include <__utility/forward.h>
#include <__utility/move.h>

#if !defined(_LIBCPP_HAS_NO_PRAGMA_SYSTEM_HEADER)
#  pragma GCC system_header
#endif

_LIBCPP_PUSH_MACROS
#include <__undef_macros>

_LIBCPP_BEGIN_NAMESPACE_STD

#if _LIBCPP_STD_VER >= 23

namespace ranges {
template <class _Ip, class _Tp>
struct in_value_result {
  _LIBCPP_NO_UNIQUE_ADDRESS _Ip in;
  _LIBCPP_NO_UNIQUE_ADDRESS _Tp value;

  template <class _I2, class _T2>
    requires convertible_to<const _Ip&, _I2> && convertible_to<const _Tp&, _T2>
  _LIBCPP_HIDE_FROM_ABI constexpr operator in_value_result<_I2, _T2>() const& {
    return {in, value};
  }

  template <class _I2, class _T2>
    requires convertible_to<_Ip, _I2> && convertible_to<_Tp, _T2>
  _LIBCPP_HIDE_FROM_ABI constexpr operator in_value_result<_I2, _T2>() && {
    return {std::move(in), std::move(value)};
  }
};

template <class _Ip, class _Tp>
using fold_left_with_iter_result = in_value_result<_Ip, _Tp>;

template <class _Fp, class _Tp, class _Ip, class _Rp, class _Up = decay_t<_Rp>>
concept __indirectly_binary_left_foldable_impl =
    convertible_to<_Rp, _Up> &&                    //
    movable<_Tp> &&                                //
    movable<_Up> &&                                //
    convertible_to<_Tp, _Up> &&                    //
    invocable<_Fp&, _Up, iter_reference_t<_Ip>> && //
    assignable_from<_Up&, invoke_result_t<_Fp&, _Up, iter_reference_t<_Ip>>>;

template <class _Fp, class _Tp, class _Ip>
concept __indirectly_binary_left_foldable =
    copy_constructible<_Fp> &&                     //
    invocable<_Fp&, _Tp, iter_reference_t<_Ip>> && //
    __indirectly_binary_left_foldable_impl<_Fp, _Tp, _Ip, invoke_result_t<_Fp&, _Tp, iter_reference_t<_Ip>>>;

struct __fold_left_with_iter {
  template <input_iterator _Ip, sentinel_for<_Ip> _Sp, class _Tp, __indirectly_binary_left_foldable<_Tp, _Ip> _Fp>
  [[nodiscard]] _LIBCPP_HIDE_FROM_ABI static constexpr auto operator()(_Ip __first, _Sp __last, _Tp __init, _Fp __f) {
    using _Up = decay_t<invoke_result_t<_Fp&, _Tp, iter_reference_t<_Ip>>>;

    if (__first == __last) {
      return fold_left_with_iter_result<_Ip, _Up>{std::move(__first), _Up(std::move(__init))};
    }

    _Up __result = std::invoke(__f, std::move(__init), *__first);
    for (++__first; __first != __last; ++__first) {
      __result = std::invoke(__f, std::move(__result), *__first);
    }

    return fold_left_with_iter_result<_Ip, _Up>{std::move(__first), std::move(__result)};
  }

  template <input_range _Rp, class _Tp, __indirectly_binary_left_foldable<_Tp, iterator_t<_Rp>> _Fp>
  [[nodiscard]] _LIBCPP_HIDE_FROM_ABI static constexpr auto operator()(_Rp&& __r, _Tp __init, _Fp __f) {
    auto __result = operator()(ranges::begin(__r), ranges::end(__r), std::move(__init), std::ref(__f));

    using _Up = decay_t<invoke_result_t<_Fp&, _Tp, range_reference_t<_Rp>>>;
    return fold_left_with_iter_result<borrowed_iterator_t<_Rp>, _Up>{std::move(__result.in), std::move(__result.value)};
  }
};

inline constexpr auto fold_left_with_iter = __fold_left_with_iter();

struct __fold_left {
  template <input_iterator _Ip, sentinel_for<_Ip> _Sp, class _Tp, __indirectly_binary_left_foldable<_Tp, _Ip> _Fp>
  [[nodiscard]] _LIBCPP_HIDE_FROM_ABI static constexpr auto operator()(_Ip __first, _Sp __last, _Tp __init, _Fp __f) {
    return fold_left_with_iter(std::move(__first), std::move(__last), std::move(__init), std::ref(__f)).value;
  }

  template <input_range _Rp, class _Tp, __indirectly_binary_left_foldable<_Tp, iterator_t<_Rp>> _Fp>
  [[nodiscard]] _LIBCPP_HIDE_FROM_ABI static constexpr auto operator()(_Rp&& __r, _Tp __init, _Fp __f) {
    return fold_left_with_iter(ranges::begin(__r), ranges::end(__r), std::move(__init), std::ref(__f)).value;
  }
};

inline constexpr auto fold_left = __fold_left();
} // namespace ranges

#endif // _LIBCPP_STD_VER >= 23

_LIBCPP_END_NAMESPACE_STD

_LIBCPP_POP_MACROS

#endif // _LIBCPP___ALGORITHM_RANGES_FOLD_H
`,"__algorithm/ranges_starts_with.h":`//===----------------------------------------------------------------------===//
//
// Part of the LLVM Project, under the Apache License v2.0 with LLVM Exceptions.
// See https://llvm.org/LICENSE.txt for license information.
// SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception
//
//===----------------------------------------------------------------------===//

#ifndef _LIBCPP___ALGORITHM_RANGES_STARTS_WITH_H
#define _LIBCPP___ALGORITHM_RANGES_STARTS_WITH_H

#include <__algorithm/in_in_result.h>
#include <__algorithm/ranges_mismatch.h>
#include <__config>
#include <__functional/identity.h>
#include <__functional/ranges_operations.h>
#include <__iterator/concepts.h>
#include <__iterator/indirectly_comparable.h>
#include <__ranges/access.h>
#include <__ranges/concepts.h>
#include <__utility/move.h>

#if !defined(_LIBCPP_HAS_NO_PRAGMA_SYSTEM_HEADER)
#  pragma GCC system_header
#endif

_LIBCPP_PUSH_MACROS
#include <__undef_macros>

#if _LIBCPP_STD_VER >= 23

_LIBCPP_BEGIN_NAMESPACE_STD

namespace ranges {
struct __starts_with {
  template <input_iterator _Iter1,
            sentinel_for<_Iter1> _Sent1,
            input_iterator _Iter2,
            sentinel_for<_Iter2> _Sent2,
            class _Pred  = ranges::equal_to,
            class _Proj1 = identity,
            class _Proj2 = identity>
    requires indirectly_comparable<_Iter1, _Iter2, _Pred, _Proj1, _Proj2>
  [[nodiscard]] _LIBCPP_HIDE_FROM_ABI static constexpr bool operator()(
      _Iter1 __first1,
      _Sent1 __last1,
      _Iter2 __first2,
      _Sent2 __last2,
      _Pred __pred   = {},
      _Proj1 __proj1 = {},
      _Proj2 __proj2 = {}) {
    return __mismatch::__go(
               std::move(__first1),
               std::move(__last1),
               std::move(__first2),
               std::move(__last2),
               __pred,
               __proj1,
               __proj2)
               .in2 == __last2;
  }

  template <input_range _Range1,
            input_range _Range2,
            class _Pred  = ranges::equal_to,
            class _Proj1 = identity,
            class _Proj2 = identity>
    requires indirectly_comparable<iterator_t<_Range1>, iterator_t<_Range2>, _Pred, _Proj1, _Proj2>
  [[nodiscard]] _LIBCPP_HIDE_FROM_ABI static constexpr bool
  operator()(_Range1&& __range1, _Range2&& __range2, _Pred __pred = {}, _Proj1 __proj1 = {}, _Proj2 __proj2 = {}) {
    return __mismatch::__go(
               ranges::begin(__range1),
               ranges::end(__range1),
               ranges::begin(__range2),
               ranges::end(__range2),
               __pred,
               __proj1,
               __proj2)
               .in2 == ranges::end(__range2);
  }
};
inline namespace __cpo {
inline constexpr auto starts_with = __starts_with{};
} // namespace __cpo
} // namespace ranges

_LIBCPP_END_NAMESPACE_STD

#endif // _LIBCPP_STD_VER >= 23

_LIBCPP_POP_MACROS

#endif // _LIBCPP___ALGORITHM_RANGES_STARTS_WITH_H
`,"__ostream/print.h":`//===---------------------------------------------------------------------===//
//
// Part of the LLVM Project, under the Apache License v2.0 with LLVM Exceptions.
// See https://llvm.org/LICENSE.txt for license information.
// SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception
//
//===---------------------------------------------------------------------===//

#ifndef _LIBCPP___OSTREAM_PRINT_H
#define _LIBCPP___OSTREAM_PRINT_H

#include <__config>

#if _LIBCPP_HAS_LOCALIZATION

#  include <__fwd/ostream.h>
#  include <__iterator/ostreambuf_iterator.h>
#  include <__ostream/basic_ostream.h>
#  include <format>
#  include <ios>
#  include <print>
#  include <streambuf>

#  if !defined(_LIBCPP_HAS_NO_PRAGMA_SYSTEM_HEADER)
#    pragma GCC system_header
#  endif

_LIBCPP_BEGIN_NAMESPACE_STD

#  if _LIBCPP_STD_VER >= 23

template <class = void> // TODO PRINT template or availability markup fires too eagerly (http://llvm.org/PR61563).
_LIBCPP_HIDE_FROM_ABI inline void
__vprint_nonunicode(ostream& __os, string_view __fmt, format_args __args, bool __write_nl) {
  // [ostream.formatted.print]/3
  // Effects: Behaves as a formatted output function
  // ([ostream.formatted.reqmts]) of os, except that:
  // - failure to generate output is reported as specified below, and
  // - any exception thrown by the call to vformat is propagated without regard
  //   to the value of os.exceptions() and without turning on ios_base::badbit
  //   in the error state of os.
  // After constructing a sentry object, the function initializes an automatic
  // variable via
  //   string out = vformat(os.getloc(), fmt, args);

  ostream::sentry __s(__os);
  if (__s) {
    string __o = std::vformat(__os.getloc(), __fmt, __args);
    if (__write_nl)
      __o += '\\n';

#    if _LIBCPP_HAS_EXCEPTIONS
    try {
#    endif // _LIBCPP_HAS_EXCEPTIONS
      if (auto __rdbuf = __os.rdbuf();
          !__rdbuf || __rdbuf->sputn(__o.data(), __o.size()) != static_cast<streamsize>(__o.size()))
        __os.setstate(ios_base::badbit | ios_base::failbit);

#    if _LIBCPP_HAS_EXCEPTIONS
    } catch (...) {
      __os.__set_badbit_and_consider_rethrow();
    }
#    endif // _LIBCPP_HAS_EXCEPTIONS
  }
}

template <class = void> // TODO PRINT template or availability markup fires too eagerly (http://llvm.org/PR61563).
_LIBCPP_HIDE_FROM_ABI inline void vprint_nonunicode(ostream& __os, string_view __fmt, format_args __args) {
  std::__vprint_nonunicode(__os, __fmt, __args, false);
}

// Returns the FILE* associated with the __os.
// Returns a nullptr when no FILE* is associated with __os.
// This function is in the dylib since the type of the buffer associated
// with std::cout, std::cerr, and std::clog is only known in the dylib.
//
// This function implements part of the implementation-defined behavior
// of [ostream.formatted.print]/3
//   If the function is vprint_unicode and os is a stream that refers to
//   a terminal capable of displaying Unicode which is determined in an
//   implementation-defined manner, writes out to the terminal using the
//   native Unicode API;
// Whether the returned FILE* is "a terminal capable of displaying Unicode"
// is determined in the same way as the print(FILE*, ...) overloads.
_LIBCPP_EXPORTED_FROM_ABI FILE* __get_ostream_file(ostream& __os);

#    if _LIBCPP_HAS_UNICODE
template <class = void> // TODO PRINT template or availability markup fires too eagerly (http://llvm.org/PR61563).
_LIBCPP_HIDE_FROM_ABI void __vprint_unicode(ostream& __os, string_view __fmt, format_args __args, bool __write_nl) {
#      if _LIBCPP_AVAILABILITY_HAS_PRINT == 0
  return std::__vprint_nonunicode(__os, __fmt, __args, __write_nl);
#      else
  FILE* __file = std::__get_ostream_file(__os);
  if (!__file || !__print::__is_terminal(__file))
    return std::__vprint_nonunicode(__os, __fmt, __args, __write_nl);

  // [ostream.formatted.print]/3
  //    If the function is vprint_unicode and os is a stream that refers to a
  //    terminal capable of displaying Unicode which is determined in an
  //    implementation-defined manner, writes out to the terminal using the
  //    native Unicode API; if out contains invalid code units, the behavior is
  //    undefined and implementations are encouraged to diagnose it. If the
  //    native Unicode API is used, the function flushes os before writing out.
  //
  // This is the path for the native API, start with flushing.
  __os.flush();

#        if _LIBCPP_HAS_EXCEPTIONS
  try {
#        endif // _LIBCPP_HAS_EXCEPTIONS
    ostream::sentry __s(__os);
    if (__s) {
#        ifndef _LIBCPP_WIN32API
      __print::__vprint_unicode_posix(__file, __fmt, __args, __write_nl, true);
#        elif _LIBCPP_HAS_WIDE_CHARACTERS
    __print::__vprint_unicode_windows(__file, __fmt, __args, __write_nl, true);
#        else
#          error "Windows builds with wchar_t disabled are not supported."
#        endif
    }

#        if _LIBCPP_HAS_EXCEPTIONS
  } catch (...) {
    __os.__set_badbit_and_consider_rethrow();
  }
#        endif // _LIBCPP_HAS_EXCEPTIONS
#      endif   // _LIBCPP_AVAILABILITY_HAS_PRINT
}

template <class = void> // TODO PRINT template or availability markup fires too eagerly (http://llvm.org/PR61563).
_LIBCPP_HIDE_FROM_ABI inline void vprint_unicode(ostream& __os, string_view __fmt, format_args __args) {
  std::__vprint_unicode(__os, __fmt, __args, false);
}
#    endif // _LIBCPP_HAS_UNICODE

template <class... _Args>
_LIBCPP_HIDE_FROM_ABI void print(ostream& __os, format_string<_Args...> __fmt, _Args&&... __args) {
#    if _LIBCPP_HAS_UNICODE
  if constexpr (__print::__use_unicode_execution_charset)
    std::__vprint_unicode(__os, __fmt.get(), std::make_format_args(__args...), false);
  else
    std::__vprint_nonunicode(__os, __fmt.get(), std::make_format_args(__args...), false);
#    else  // _LIBCPP_HAS_UNICODE
  std::__vprint_nonunicode(__os, __fmt.get(), std::make_format_args(__args...), false);
#    endif // _LIBCPP_HAS_UNICODE
}

template <class... _Args>
_LIBCPP_HIDE_FROM_ABI void println(ostream& __os, format_string<_Args...> __fmt, _Args&&... __args) {
#    if _LIBCPP_HAS_UNICODE
  // Note the wording in the Standard is inefficient. The output of
  // std::format is a std::string which is then copied. This solution
  // just appends a newline at the end of the output.
  if constexpr (__print::__use_unicode_execution_charset)
    std::__vprint_unicode(__os, __fmt.get(), std::make_format_args(__args...), true);
  else
    std::__vprint_nonunicode(__os, __fmt.get(), std::make_format_args(__args...), true);
#    else  // _LIBCPP_HAS_UNICODE
  std::__vprint_nonunicode(__os, __fmt.get(), std::make_format_args(__args...), true);
#    endif // _LIBCPP_HAS_UNICODE
}

template <class = void> // TODO PRINT template or availability markup fires too eagerly (http://llvm.org/PR61563).
_LIBCPP_HIDE_FROM_ABI inline void println(ostream& __os) {
  std::print(__os, "\\n");
}

#  endif // _LIBCPP_STD_VER >= 23

_LIBCPP_END_NAMESPACE_STD

#endif // _LIBCPP_HAS_LOCALIZATION

#endif // _LIBCPP___OSTREAM_PRINT_H
`,"__type_traits/is_implicit_lifetime.h":`//===----------------------------------------------------------------------===//
//
// Part of the LLVM Project, under the Apache License v2.0 with LLVM Exceptions.
// See https://llvm.org/LICENSE.txt for license information.
// SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception
//
//===----------------------------------------------------------------------===//

#ifndef _LIBCPP___TYPE_TRAITS_IS_IMPLICIT_LIFETIME_H
#define _LIBCPP___TYPE_TRAITS_IS_IMPLICIT_LIFETIME_H

#include <__config>
#include <__type_traits/integral_constant.h>

#if !defined(_LIBCPP_HAS_NO_PRAGMA_SYSTEM_HEADER)
#  pragma GCC system_header
#endif

_LIBCPP_BEGIN_NAMESPACE_STD

#if _LIBCPP_STD_VER >= 23
#  if __has_builtin(__builtin_is_implicit_lifetime)

template <class _Tp>
struct _LIBCPP_NO_SPECIALIZATIONS is_implicit_lifetime : bool_constant<__builtin_is_implicit_lifetime(_Tp)> {};

template <class _Tp>
_LIBCPP_NO_SPECIALIZATIONS inline constexpr bool is_implicit_lifetime_v = __builtin_is_implicit_lifetime(_Tp);

#  endif
#endif

_LIBCPP_END_NAMESPACE_STD

#endif // _LIBCPP___TYPE_TRAITS_IS_IMPLICIT_LIFETIME_H
`,"__type_traits/is_within_lifetime.h":`//===----------------------------------------------------------------------===//
//
// Part of the LLVM Project, under the Apache License v2.0 with LLVM Exceptions.
// See https://llvm.org/LICENSE.txt for license information.
// SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception
//
//===----------------------------------------------------------------------===//

#ifndef _LIBCPP___TYPE_TRAITS_IS_WITHIN_LIFETIME_H
#define _LIBCPP___TYPE_TRAITS_IS_WITHIN_LIFETIME_H

#include <__config>

#if !defined(_LIBCPP_HAS_NO_PRAGMA_SYSTEM_HEADER)
#  pragma GCC system_header
#endif

_LIBCPP_BEGIN_NAMESPACE_STD

#if _LIBCPP_STD_VER >= 26 && __has_builtin(__builtin_is_within_lifetime)
template <class _Tp>
_LIBCPP_HIDE_FROM_ABI consteval bool is_within_lifetime(const _Tp* __p) noexcept {
  return __builtin_is_within_lifetime(__p);
}
#endif

_LIBCPP_END_NAMESPACE_STD

#endif // _LIBCPP___TYPE_TRAITS_IS_WITHIN_LIFETIME_H
`,"__type_traits/reference_converts_from_temporary.h":`//===----------------------------------------------------------------------===//
//
// Part of the LLVM Project, under the Apache License v2.0 with LLVM Exceptions.
// See https://llvm.org/LICENSE.txt for license information.
// SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception
//
//===----------------------------------------------------------------------===//

#ifndef _LIBCPP___TYPE_TRAITS_REFERENCE_CONVERTS_FROM_TEMPORARY_H
#define _LIBCPP___TYPE_TRAITS_REFERENCE_CONVERTS_FROM_TEMPORARY_H

#include <__config>
#include <__type_traits/integral_constant.h>

#if !defined(_LIBCPP_HAS_NO_PRAGMA_SYSTEM_HEADER)
#  pragma GCC system_header
#endif

_LIBCPP_BEGIN_NAMESPACE_STD

#if _LIBCPP_STD_VER >= 23

template <class _Tp, class _Up>
struct _LIBCPP_NO_SPECIALIZATIONS reference_converts_from_temporary
    : public bool_constant<__reference_converts_from_temporary(_Tp, _Up)> {};

template <class _Tp, class _Up>
_LIBCPP_NO_SPECIALIZATIONS inline constexpr bool reference_converts_from_temporary_v =
    __reference_converts_from_temporary(_Tp, _Up);

#endif

_LIBCPP_END_NAMESPACE_STD

#endif // _LIBCPP___TYPE_TRAITS_REFERENCE_CONVERTS_FROM_TEMPORARY_H
`,"__vector/vector_bool_formatter.h":`//===----------------------------------------------------------------------===//
//
// Part of the LLVM Project, under the Apache License v2.0 with LLVM Exceptions.
// See https://llvm.org/LICENSE.txt for license information.
// SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception
//
//===----------------------------------------------------------------------===//

#ifndef _LIBCPP___VECTOR_VECTOR_BOOL_FORMATTER_H
#define _LIBCPP___VECTOR_VECTOR_BOOL_FORMATTER_H

#include <__concepts/same_as.h>
#include <__config>
#include <__format/formatter.h>
#include <__format/formatter_bool.h>
#include <__fwd/vector.h>

#if !defined(_LIBCPP_HAS_NO_PRAGMA_SYSTEM_HEADER)
#  pragma GCC system_header
#endif

#if _LIBCPP_STD_VER >= 23

_LIBCPP_BEGIN_NAMESPACE_STD

template <class _Tp, class _CharT>
// Since is-vector-bool-reference is only used once it's inlined here.
  requires same_as<typename _Tp::__container, vector<bool, typename _Tp::__container::allocator_type>>
struct formatter<_Tp, _CharT> {
private:
  formatter<bool, _CharT> __underlying_;

public:
  template <class _ParseContext>
  _LIBCPP_HIDE_FROM_ABI constexpr typename _ParseContext::iterator parse(_ParseContext& __ctx) {
    return __underlying_.parse(__ctx);
  }

  template <class _FormatContext>
  _LIBCPP_HIDE_FROM_ABI typename _FormatContext::iterator format(const _Tp& __ref, _FormatContext& __ctx) const {
    return __underlying_.format(__ref, __ctx);
  }
};

_LIBCPP_END_NAMESPACE_STD

#endif // _LIBCPP_STD_VER >= 23

#endif // _LIBCPP___VECTOR_VECTOR_BOOL_FORMATTER_H
`});async function wn(e,t){if(t?.name!==xn.name||t.version!==xn.version||t.revision!==xn.revision)return!1;let n=`/include/c++/v1/`,r=new TextDecoder(`utf-8`,{fatal:!0}),i=e.readFile(`${n}${Sn.path}`);if(i===null||i.byteLength!==Sn.bytes)return!1;let a=new Uint8Array(await crypto.subtle.digest(`SHA-256`,Uint8Array.from(i).buffer));if(Array.from(a,e=>e.toString(16).padStart(2,`0`)).join(``)!==Sn.sha256)return!1;let o=[];for(let[i,a]of Object.entries(Cn)){let s=`${n}${i}`,c=e.readFile(s);if(c===null)o.push([s,a]);else if(r.decode(c)!==a)throw Error(`Clang ${t.version} C++ header differs from its pinned source: ${i}`)}let s=new TextEncoder;for(let[t,n]of o)e.mkdirTree(t.slice(0,t.lastIndexOf(`/`))),e.writeFile(t,s.encode(n));return!0}const Tn=new TextEncoder,En=new TextDecoder,Dn=/* @__PURE__ */ new Uint8Array,On=()=>{},kn=e=>JSON.stringify(e.length>96?e.slice(0,93)+`...`:e);var An=class{ready;mem=null;hostMem_=null;stdinStr;stdinBytes=Dn;stdinOffset=0;stdin;stdout;trace;instance=null;exports;out=!0;filePaths=/* @__PURE__ */ new Set;fileOverlays=/* @__PURE__ */ new Map;directoryPaths=/* @__PURE__ */ new Set;constructor(e){this.stdin=e.stdin,this.stdout=e.stdout,this.stdinStr=e.stdinStr||``,this.trace=e.trace||On;let t=ut(this,`abort`,`host_write`,`host_read`,`memfs_log`,`copy_in`,`copy_out`);this.ready=(e.maxAssetBytes===void 0?e.signal?Pt(e.moduleUrl,e.progress,e.signal):Pt(e.moduleUrl,e.progress):Pt(e.moduleUrl,e.progress,e.signal,e.maxAssetBytes)).then(e=>WebAssembly.instantiate(e,{env:t})).then(e=>{this.instance=e,this.exports=e.exports,this.mem=new mt(this.exports.memory),this.exports.init()})}set hostMem(e){this.hostMem_=e}setStdinStr(e){this.stdinStr=e,this.stdinBytes=Dn,this.stdinOffset=0}addDirectory(e){let t=this.normalizePath(e);this.directoryPaths.has(t)||(this.mem.check(),this.mem.write(this.exports.GetPathBuf(),e),this.exports.AddDirectoryNode(e.length),this.directoryPaths.add(t))}addFile(e,t){let n=t instanceof ArrayBuffer?t.byteLength:t.length;this.mem.check(),this.mem.write(this.exports.GetPathBuf(),e);let r=this.exports.AddFileNode(e.length,n),i=this.exports.GetFileNodeAddress(r);this.mem.check(),this.mem.write(i,t),this.filePaths.add(this.normalizePath(e))}setFile(e,t){let n=this.normalizePath(e);this.filePaths.add(n),this.fileOverlays.set(n,Uint8Array.from(t))}hasFile(e){return this.filePaths.has(this.normalizePath(e))}normalizePath(e){return e.replaceAll(`\\`,`/`).replace(/^\.\//,``).replace(/^\/+/,``)}getFileContents(e){let t=this.fileOverlays.get(this.normalizePath(e));if(t)return t;this.mem.check(),this.mem.write(this.exports.GetPathBuf(),e);let n=this.exports.FindNode(e.length),r=this.exports.GetFileNodeAddress(n),i=this.exports.GetFileNodeSize(n);return new Uint8Array(this.mem.buffer,r,i)}abort(){throw this.trace(`abort()`),new Rt}host_write(e,t,n,r){this.hostMem_.check(),Bt(e<=2);let i=0,a=``;for(let e=0;e<n;++e){let e=this.hostMem_.read32(t);t+=4;let n=this.hostMem_.read32(t);t+=4,a+=this.hostMem_.readStrR(e,n),i+=n}return this.hostMem_.write32(r,i),this.trace!==On&&this.trace(`host_write(fd=${e}, bytes=${i}, data=${kn(a)})`),this.out&&this.stdout(a),0}host_read(e,t,n,r){this.hostMem_.check(),Bt(e===0);let i=0;for(let r=0;r<n;++r){let n=this.hostMem_.read32(t);t+=4;let r=this.hostMem_.read32(t);if(t+=4,r===0)continue;if(this.stdinOffset===this.stdinBytes.length){let e=this.stdinStr.length?this.stdinStr:this.stdin();this.stdinStr=``,this.stdinBytes=Tn.encode(e),this.stdinOffset=0}let a=Math.min(r,this.stdinBytes.length-this.stdinOffset);if(a===0)break;let o=this.stdinBytes.subarray(this.stdinOffset,this.stdinOffset+a);if(this.hostMem_.write(n,o),this.stdinOffset+=a,this.stdinOffset===this.stdinBytes.length&&(this.stdinBytes=Dn,this.stdinOffset=0),i+=a,this.trace!==On&&this.trace(`host_read(fd=${e}, bytes=${a}, data=${kn(En.decode(o))})`),a!==r)break}return this.hostMem_.write32(r,i),i===0&&this.trace!==On&&this.trace(`host_read(fd=${e}, bytes=0)`),0}memfs_log(e,t){if(this.trace===On)return;this.mem.check();let n=this.mem.readStr(e,t);this.trace(`memfs_log(${kn(n)})`)}copy_out(e,t,n){this.hostMem_.check();let r=new Uint8Array(this.hostMem_.buffer,e,n);this.mem.check();let i=new Uint8Array(this.mem.buffer,t,n);r.set(i)}copy_in(e,t,n){this.mem.check();let r=new Uint8Array(this.mem.buffer,e,n);this.hostMem_.check();let i=new Uint8Array(this.hostMem_.buffer,t,n);r.set(i)}};function*jn(e){let t=e instanceof Uint8Array?e:new Uint8Array(e),n=0,r=``,i=e=>(n+=e,dt(t,n-e,e)),a=e=>(n+=e,pt(t,n-e,e)),o=()=>n=n+511&-512;for(;n+512<=t.length;){let e={filename:i(100),mode:a(8),owner:a(8),group:a(8),size:a(12),mtime:a(12),checksum:a(8),type:i(1),linkname:i(100),ustar:i(8)};if(!e.ustar)return;let s={...e,ownerName:i(32),groupName:i(32),devMajor:i(8),devMinor:i(8),filenamePrefix:i(155)};if(o(),(s.size>0||s.type===`0`||s.type===``||s.type===`L`)&&(s.contents=t.subarray(n,n+s.size),n+=s.size,o()),s.type===`L`){s.contents&&(r=dt(s.contents,0,s.size));continue}s.filename=r||(s.filenamePrefix?`${s.filenamePrefix}/${s.filename}`:s.filename),r=``,yield s}}function Mn(e,t){for(let n of jn(e))switch(n.type){case``:case`0`:t.addFile(n.filename,n.contents);break;case`5`:t.addDirectory(n.filename);break;default:throw Error(`unsupported tar entry type: ${n.type}`)}}const Nn=`\x1B[92m`,Pn=`\x1B[0m`,Fn=e=>Math.max(0,Math.min(1,Number.isFinite(e)?e:0));function In(e){let t={clang:0,lld:0,memfs:0},n=()=>{e((t.clang+t.memfs)/2)},r=e=>({set(r){t[e]=Fn(r),n()}});return{clang:r(`clang`),lld:r(`lld`),memfs:r(`memfs`)}}const Ln=(e,t)=>{let n=e?.toString().trim();if(!n)throw Error(`${t} is required`);let r;try{r=new URL(n,typeof location<`u`?location.href:void 0)}catch{throw Error(`${t} must be an absolute HTTP(S) URL`)}if(r.protocol!==`http:`&&r.protocol!==`https:`)throw Error(`${t} must use HTTP(S)`);return r},Rn=e=>{let t=Ln(e,`wasm-clang runtime base URL`);return t.pathname.endsWith(`/`)||(t.pathname+=`/`),t.hash=``,t},B=(e,t)=>new URL(t,Rn(e)).toString(),zn=(e,t)=>B(e,t),Bn=e=>Rn(e).toString(),Vn=e=>zn(e,`runtime-manifest.v1.json`);function Hn(e,t){let n=Bn(e),r=t?.compiler.sysroot.profiles;if(r&&(typeof r.c?.asset!=`string`||!r.c.asset||typeof r.cppAddon?.asset!=`string`||!r.cppAddon.asset))throw TypeError(`Clang sysroot profiles require both C and C++ add-on assets`);return{manifest:Vn(n).toString(),memfs:B(n,t?.compiler.memfs.asset||`bin/memfs.wasm.gz`).toString(),clang:B(n,t?.compiler.clang.asset||`bin/clang.wasm.gz`).toString(),lld:B(n,t?.compiler.lld.asset||`bin/lld.wasm.gz`).toString(),sysroot:B(n,t?.compiler.sysroot.asset||`bin/sysroot.tar.gz`).toString(),...r?{cSysroot:B(n,r.c.asset).toString(),cppAddon:B(n,r.cppAddon.asset).toString()}:{},...t?.compiler.sysroot.printscanLongDouble?{printscanLongDouble:B(n,t.compiler.sysroot.printscanLongDouble.asset).toString()}:{},clangdJs:B(n,t?.clangd.js||`clangd/clangd.js`).toString(),clangdWasm:B(n,t?.clangd.wasm||`clangd/clangd.wasm.gz`).toString()}}const V=e=>e.replaceAll(`\\`,`/`).split(`/`).filter(e=>e&&e!==`.`&&e!==`..`).join(`/`),H=e=>{let t=V(e);return t.startsWith(`workspace/`)?t.slice(10):t};function Un(e,t){let n=V(t||``),r=`main`,i=n&&/\.[A-Za-z0-9_-]+$/.test(n)?n:`${n||r}.${e===`C`?`c`:e===`OBJC`?`m`:`cc`}`,a=(i.split(`/`).pop()||i).replace(/\.[^.]+$/,``)||r;return{input:i,obj:`${a}.o`,wasm:`${a}.wasm`}}async function Wn(e){let t=typeof e==`string`?new TextEncoder().encode(e):(e instanceof Uint8Array,new Uint8Array(e)),n=await globalThis.crypto.subtle.digest(`SHA-256`,t);return Array.from(new Uint8Array(n),e=>e.toString(16).padStart(2,`0`)).join(``)}async function Gn(e,t,n){if(!n)throw Error(`LLDB debug compilation requires compiler provenance in the wasm-clang runtime manifest`);let{input:r}=Un(e.language||`CPP`,H(e.activePath||``)||H(e.fileName||``)||void 0),i=/* @__PURE__ */ new Map;for(let t of e.workspaceFiles||[]){let e=H(t.path);e&&i.set(e,t.content)}i.set(r,e.code);let a=[...i.entries()].sort(([e],[t])=>e<t?-1:+(e>t));return{kind:`dwarf`,sourceRoot:`/workspace`,moduleSha256:await Wn(t),files:await Promise.all(a.map(async([e,t])=>({path:`/workspace/${e}`,contentSha256:await Wn(t)}))),compiler:n}}const Kn=`/include/bits/stdc++.h`,U=`__wasm_idle_build/pch/stdc++.pch`,qn=[/^-[DU][A-Za-z_]/,/^-W/,/^-w$/,/^-f[a-z]/,/^-O([0-3sz]|fast)?$/,/^-std=/,/^-pedantic(-errors)?$/],Jn=/precompiled (header|file)|PCH file|AST file/i;async function Yn(e){try{return Array.from(new Uint8Array(await crypto.subtle.digest(`SHA-256`,Uint8Array.from(e).buffer)),e=>e.toString(16).padStart(2,`0`)).join(``)}catch{return}}async function Xn(e){let t=new TextEncoder,n=[...e].sort(([e],[t])=>e.localeCompare(t)).map(([e,n])=>({bytes:n,metadata:t.encode(JSON.stringify([e,n.byteLength])+`
`)})),r=n.reduce((e,t)=>e+t.metadata.byteLength+t.bytes.byteLength,0),i=new Uint8Array(r),a=0;for(let{metadata:e,bytes:t}of n)i.set(e,a),a+=e.byteLength,i.set(t,a),a+=t.byteLength;return Yn(i)}function Zn(e){let t=e.replace(/^\uFEFF/,``);for(;;)if(t=t.replace(/^\s+/,``),t.startsWith(`//`)){let e=t.indexOf(`
`);if(e<0||t.slice(0,e).trimEnd().endsWith(`\\`))return!1;t=t.slice(e+1)}else if(t.startsWith(`/*`)){let e=t.indexOf(`*/`,2);if(e<0)return!1;t=t.slice(e+2)}else break;return/^#[ \t]*include[ \t]*<bits\/stdc\+\+\.h>/.test(t)}function Qn(e){return e.every(e=>typeof e==`string`&&e!==`-fsyntax-only`&&qn.some(t=>t.test(e)))}const W=`__wasm_idle_build`,$n=`lib/wasm32-wasi/libc-printscan-long-double.a`,er=/\.(?:c|cc|cpp|cxx)$/,tr=e=>e.some(e=>typeof e!=`string`||e.startsWith(`-x`)||e.startsWith(`@`)),nr=/* @__PURE__ */ new Set([`-target`,`--target`,`-triple`,`-target-feature`,`-target-cpu`,`-target-abi`,`-mcpu`,`-march`,`-mattr`,`-mthread-model`,`-mllvm`,`-pthread`,`-fopenmp`,`-msimd128`,`-mno-simd128`,`-matomics`,`-mno-atomics`,`-mmemory64`,`-mno-memory64`,`-mshared-memory`,`-mno-shared-memory`,`-mmulti-memory`,`-mno-multi-memory`]),rr=[`-target=`,`--target=`,`-triple=`,`-target-feature=`,`-target-cpu=`,`-target-abi=`,`-mcpu=`,`-march=`,`-mattr=`,`-mthread-model=`,`-mllvm=`],ir=e=>{let t=encodeURIComponent(e),n=``;for(let e=0;e<t.length;){let r=t[e];if(e+=1,r==`%`){let r=t.substring(e,e+=2);r&&(n+=String.fromCharCode(parseInt(r,16)))}else n+=r}return n};function ar(e,t){let n=[...e],r=t,i,a=!1;for(let t=0;t<e.length;t+=1){let o=e[t],s=e[t+1];if(r){n[t]=` `,o===`*`&&s===`/`&&(n[t+1]=` `,t+=1,r=!1);continue}if(i){n[t]=` `,a?a=!1:o===`\\`?a=!0:o===i&&(i=void 0);continue}if(o===`/`&&s===`*`){n[t]=` `,n[t+1]=` `,t+=1,r=!0;continue}if(o===`/`&&s===`/`){for(let r=t;r<e.length;r+=1)n[r]=` `;break}(o===`"`||o===`'`)&&(n[t]=` `,i=o)}return{line:n.join(``),inBlockComment:r}}var or=class{ready;memfs;stdout;moduleCache;moduleLoads;showTiming;log;debug=!1;debugBreakpoints=/* @__PURE__ */ new Set;debugPauseOnEntry=!1;debugBuffer;debugInterruptBuffer;debugWatchBuffer;debugWatchResultBuffer;onDebugEvent;debugVariableMetadata={};debugGlobalMetadata=[];debugFunctionMetadata={};lastBuildKey=``;precompiledHeaderPlan;usedPrecompiledHeader=!1;mountedPrecompiledHeaderKey=``;path;assetUrls;compilerConfig;wasm;lastArtifactPath=`main.wasm`;traceStartedAt=0;progress;maxAssetBytes;signal;cppSysrootReady;printscanLongDoubleReady;persistentCache;sysrootFingerprints=[];runtimeHeaders=/* @__PURE__ */ new Map;pchFingerprint;workspaceOverridesSystemHeaders=!1;constructor(e){let t=e.maxAssetBytes??134217728;if(!Number.isSafeInteger(t)||t<=0)throw TypeError(`Clang maxAssetBytes must be a positive safe integer`);this.maxAssetBytes=t,this.signal=e.signal,this.persistentCache=e.persistentCache,this.moduleCache={},this.moduleLoads={},this.stdout=e.stdout||(()=>{}),this.showTiming=e.showTiming||!1,this.log=e.log||!1,this.path=e.runtimeBaseUrl.toString(),this.assetUrls=Hn(this.path,e.manifest),this.compilerConfig=e.manifest?.compiler,this.onDebugEvent=e.onDebugEvent,this.progress=In(t=>e.progress?.(t)),this.memfs=new An({stdout:this.stdout,stdin:e.stdin||(()=>``),moduleUrl:this.assetUrls.memfs,progress:this.progress.memfs,signal:e.signal,maxAssetBytes:t,trace:e=>this.trace(e)});let n=this.getModule(this.assetUrls.clang,this.progress.clang,e.signal),r=this.assetUrls.cSysroot||this.assetUrls.sysroot,i=e.signal?z(r,void 0,t,e.signal):z(r,void 0,t),a=Promise.all([this.memfs.ready,i]).then(async([,t])=>{this.sysrootFingerprints.push(Yn(t)),await this.hostLogAsync(`Untarring ${r}`,Promise.resolve().then(()=>(e.signal?.throwIfAborted(),Mn(t,this.memfs)))),e.signal?.throwIfAborted(),bn({readFile:e=>this.memfs.hasFile(e)?this.memfs.getFileContents(e.replace(/^\/+/,``)):null,mkdirTree:e=>this.memfs.addDirectory(e.replace(/^\/+/,``)),writeFile:(e,t)=>this.installRuntimeHeader(e,t)},this.compilerConfig?.provenance,this.compilerConfig?.resourceDir),this.assetUrls.cppAddon||await this.installCppHeaders()});this.ready=Promise.all([n,a]).then(()=>void 0)}ensureCppSysroot(){let e=this.assetUrls.cppAddon;if(!e)return this.ready;if(this.cppSysrootReady)return this.cppSysrootReady;let t=this.signal?z(e,void 0,this.maxAssetBytes,this.signal):z(e,void 0,this.maxAssetBytes),n=Promise.all([this.ready,t]).then(async([,t])=>{this.sysrootFingerprints.push(Yn(t)),await this.hostLogAsync(`Untarring ${e}`,Promise.resolve().then(()=>(this.signal?.throwIfAborted(),Mn(t,this.memfs)))),this.signal?.throwIfAborted(),await this.installCppHeaders()});return this.cppSysrootReady=n,t.catch(()=>{this.cppSysrootReady===n&&(this.cppSysrootReady=void 0)}),n}async installCppHeaders(){_n({addDirectory:e=>this.memfs.addDirectory(e),addFile:(e,t)=>this.installRuntimeHeader(e,new TextEncoder().encode(t))}),await wn({readFile:e=>this.memfs.hasFile(e)?this.memfs.getFileContents(e.replace(/^\/+/,``)):null,mkdirTree:e=>this.memfs.addDirectory(e.replace(/^\/+/,``)),writeFile:(e,t)=>this.installRuntimeHeader(e,t)},this.compilerConfig?.provenance)}installRuntimeHeader(e,t){let n=e.replace(/^\/+/,``);this.memfs.addFile(n,t),this.runtimeHeaders.set(n,Uint8Array.from(t))}async getCompilerFingerprint(){return vt(await this.getModule(this.assetUrls.clang))}async getPrecompiledHeaderFingerprint(){return this.pchFingerprint||=Promise.all([this.getCompilerFingerprint(),Promise.all(this.sysrootFingerprints),Xn(this.runtimeHeaders)]).then(([e,t,n])=>e&&n&&t.length&&t.every(e=>!!e)?{compiler:e,sysroot:t,runtimeHeaders:n}:void 0).catch(()=>void 0),this.pchFingerprint}async prepareLongDoubleLinkArgs(){await this.ready;let e=this.assetUrls.printscanLongDouble;if(e&&!this.memfs.hasFile($n)){if(!this.printscanLongDoubleReady){let t=(this.signal?z(e,void 0,this.maxAssetBytes,this.signal):z(e,void 0,this.maxAssetBytes)).then(e=>{this.signal?.throwIfAborted(),this.memfs.addFile($n,e)});this.printscanLongDoubleReady=t,t.catch(()=>{this.printscanLongDoubleReady===t&&(this.printscanLongDoubleReady=void 0)})}await this.printscanLongDoubleReady}return this.memfs.hasFile($n)?[`-lc-printscan-long-double`]:[]}hostLog(e){if(!this.log)return;let t=`[1;93m>${Pn} `;this.stdout(`${t}${e}`)}beginTrace(e){this.debug=e,this.traceStartedAt=Date.now()}trace(e){if(!this.debug||!this.log)return;let t=Date.now()-this.traceStartedAt;this.stdout(`\x1b[2m[debug +${t}ms] ${e}\x1b[0m\n`)}async hostLogAsync(e,t){let n=+/* @__PURE__ */ new Date;this.hostLog(`${e}...`);let r=await t,i=+/* @__PURE__ */ new Date;return this.log&&this.stdout(` done.`),this.showTiming&&this.stdout(` ${Nn}(${i-n}ms)${Pn}\n`),this.log&&this.stdout(`
`),r}async getModule(e,t,n=this.signal){if(this.moduleCache[e])return this.moduleCache[e];let r=this.moduleLoads[e];if(r)return await r;let i=this.hostLogAsync(`Fetching and compiling ${e}`,Pt(e,t,n,this.maxAssetBytes)).then(t=>(this.moduleCache[e]=t,delete this.moduleLoads[e],t),t=>{throw delete this.moduleLoads[e],t});return this.moduleLoads[e]=i,await i}addWorkspaceDirectories(e,t=/* @__PURE__ */ new Set){let n=V(e).split(`/`).slice(0,-1),r=``;for(let e of n)r=r?`${r}/${e}`:e,t.has(r)||(this.memfs.addDirectory(r),t.add(r))}addWorkspaceFiles(e=[],t=``){let n=/* @__PURE__ */ new Set,r=V(t);for(let t of e){let e=V(t.path);e&&e!==r&&((e.startsWith(`include/`)||e.startsWith(`lib/clang/`))&&(this.workspaceOverridesSystemHeaders=!0),this.addWorkspaceDirectories(e,n),this.memfs.addFile(e,ir(t.content)))}}async compile(e){let t=V(e.input||`main.cc`)||`main.cc`,n=e.code,r=e.obj,i=e.language===`C`?`C`:e.language===`OBJC`?`OBJC`:`CPP`,a=e.compileArgs??e.args??[],{languageArg:o,standardArg:s}=ue(i,e),c=F(e),l=c===`trace`,u=c===`lldb`;if(u)for(let e of a){if(typeof e!=`string`)throw TypeError(`LLDB compile arguments must be strings`);if(nr.has(e)||rr.some(t=>e.startsWith(t)))throw Error(`LLDB compile argument ${JSON.stringify(e)} cannot change the WAMR debug target profile`)}let d=c===`none`?e.opt||`2`:`0`;if(l){let e=n.split(`
`),t=!1,r=e.map(e=>{let n=ar(e,t);return t=n.inBlockComment,n.line}),a=e=>{if(/^(?:do|else)$/.test(e))return!0;if(!/^(?:else\s+)?(?:if|for|while)\s*\(/.test(e))return!1;let t=e.indexOf(`(`),n=0;for(let r=t;r<e.length;r+=1)if(e[r]===`(`&&(n+=1),e[r]===`)`&&(--n,n===0))return e.slice(r+1).trim()===``;return!1},o=/* @__PURE__ */ new Set,s=!1,c=!1;for(let e=0;e<r.length;e+=1){let t=r[e].trim();if(!t)continue;let n=c,i=n;n&&t.includes(`;`)&&(c=!1),s&&(s=!1,t!==`{`&&(i=!0,!t.includes(`;`)&&!t.includes(`{`)&&!a(t)&&(c=!0))),/^while\s*\(.*\)\s*;$/.test(t)&&(i=!0),i&&o.add(e),a(t)&&(s=!0)}let l=0,u=0,d=0,f=1,p=1,m=/* @__PURE__ */ new Map,h=/* @__PURE__ */ new Map,g=/* @__PURE__ */ new Map,_,v=/* @__PURE__ */ new Map,y=``,b=[],x=!1;for(let t of e){let e=t;if(x){let t=e.indexOf(`*/`);if(t===-1)continue;e=e.slice(t+2),x=!1}let n=e.indexOf(`/*`);if(n!==-1){let t=e.indexOf(`*/`,n+2);t===-1?(x=!0,e=e.slice(0,n)):e=e.slice(0,n)+e.slice(t+2)}let r=e.indexOf(`//`);r!==-1&&(e=e.slice(0,r));let i=e.trim();if(!y){let e=i.match(/^struct\s+([A-Za-z_]\w*)\s*\{$/);e?.[1]&&(y=e[1],b=[]);continue}if(i===`};`){let e=0,t=1,n=[];for(let r of b){let i=r.kind===`double`?8:r.kind===`bool`||r.kind===`char`?1:4;e%i!==0&&(e+=i-e%i),n.push({name:r.name,kind:r.kind,offset:e}),e+=i,t=Math.max(t,i)}e%t!==0&&(e+=t-e%t),v.set(y,{fields:n,size:Math.max(e,1)}),y=``,b=[];continue}let a=i.match(/^(?:const\s+)?(?:(?:unsigned|signed)\s+)?(?:(?:short|long long|long)\s+)?(int|float|double|bool|char)\s+(.+);$/);if(a)for(let e of a[2].split(`,`)){let t=e.split(`=`)[0]?.trim()||``;if(!t||/[*&\[]/.test(t))continue;let n=t.match(/([A-Za-z_]\w*)\s*$/)?.[1];n&&b.push({name:n,kind:a[1]})}}this.debugVariableMetadata={},this.debugGlobalMetadata=[],this.debugFunctionMetadata={};let S=[],C=i===`CPP`?`extern "C" `:``,w=[`${C}__attribute__((import_module("env"), import_name("__wasm_idle_debug_enter"))) void __wasm_idle_debug_enter(int functionId, int line);`,`${C}__attribute__((import_module("env"), import_name("__wasm_idle_debug_leave"))) void __wasm_idle_debug_leave(int functionId);`,`${C}__attribute__((import_module("env"), import_name("__wasm_idle_debug_value_num"))) void __wasm_idle_debug_value_num(int functionId, int slot, double value);`,`${C}__attribute__((import_module("env"), import_name("__wasm_idle_debug_value_bool"))) void __wasm_idle_debug_value_bool(int functionId, int slot, int value);`,`${C}__attribute__((import_module("env"), import_name("__wasm_idle_debug_value_addr"))) void __wasm_idle_debug_value_addr(int functionId, int slot, int value);`,`${C}__attribute__((import_module("env"), import_name("__wasm_idle_debug_value_text"))) void __wasm_idle_debug_value_text(int functionId, int slot, const char* ptr, int len);`,`${C}__attribute__((import_module("env"), import_name("__wasm_idle_debug_line"))) void __wasm_idle_debug_line(int functionId, int line);`],T=i===`CPP`?[`#include <cstdio>`,`#include <iostream>`,`#include <map>`,`#include <set>`,`#include <string>`,`#include <type_traits>`,`#include <vector>`,...w,`template <typename T>`,`static inline std::string __wasm_idle_debug_format_value(const T& value) {`,`    if constexpr (std::is_same_v<T, bool>) return value ? "true" : "false";`,`    else if constexpr (std::is_same_v<T, char>) return std::string("'") + value + "'";`,`    else if constexpr (std::is_same_v<T, signed char> || std::is_same_v<T, unsigned char>) return std::to_string((int)value);`,`    else if constexpr (std::is_integral_v<T> || std::is_floating_point_v<T>) return std::to_string(value);`,`    else return "?";`,`}`,`template <typename T>`,`static inline void __wasm_idle_debug_emit_vector(int functionId, int slot, const std::vector<T>& values) {`,`    std::string text = "[";`,`    int count = 0;`,`    for (const auto& value : values) {`,`        if (count > 0) text += ", ";`,`        if (count >= 8) { text += "..."; break; }`,`        text += __wasm_idle_debug_format_value(value);`,`        count += 1;`,`    }`,`    text += "]";`,`    __wasm_idle_debug_value_text(functionId, slot, text.c_str(), (int)text.size());`,`}`,`template <typename T>`,`static inline void __wasm_idle_debug_emit_set(int functionId, int slot, const std::set<T>& values) {`,`    std::string text = "{";`,`    int count = 0;`,`    for (const auto& value : values) {`,`        if (count > 0) text += ", ";`,`        if (count >= 8) { text += "..."; break; }`,`        text += __wasm_idle_debug_format_value(value);`,`        count += 1;`,`    }`,`    text += "}";`,`    __wasm_idle_debug_value_text(functionId, slot, text.c_str(), (int)text.size());`,`}`,`template <typename K, typename V>`,`static inline void __wasm_idle_debug_emit_map(int functionId, int slot, const std::map<K, V>& values) {`,`    std::string text = "{";`,`    int count = 0;`,`    for (const auto& entry : values) {`,`        if (count > 0) text += ", ";`,`        if (count >= 8) { text += "..."; break; }`,`        text += __wasm_idle_debug_format_value(entry.first);`,`        text += ": ";`,`        text += __wasm_idle_debug_format_value(entry.second);`,`        count += 1;`,`    }`,`    text += "}";`,`    __wasm_idle_debug_value_text(functionId, slot, text.c_str(), (int)text.size());`,`}`]:[`#include <stdio.h>`,...w];for(let t=0;t<e.length;t+=1){let n=e[t],a=n.match(/^\s*/)?.[0]||``,s=n,c=r[t],y=c.trim(),b=o.has(t),x=u>0&&l>=u,C=u===0&&l===0&&!y.includes(`(`)&&!y.startsWith(`#`),w=/^(while|if|for)\s*\(/.test(y)&&!y.includes(`{`),E=[],D=[],O=/* @__PURE__ */ new Set,k=C&&y.match(/^(?:const\s+)?(?:(?:unsigned|signed)\s+)?(?:(?:short|long long|long)\s+)?(int|float|double|bool|char)\s+(.+);$/);if(k){let e=k[1]===`bool`?`bool`:`number`,n=[],r=``,i=0;for(let e of k[2]){if(e===`,`&&i===0){r.trim()&&n.push(r.trim()),r=``;continue}e===`{`&&(i+=1),e===`}`&&(i=Math.max(0,i-1)),r+=e}r.trim()&&n.push(r.trim());for(let r of n){let[n]=r.split(`=`),i=n?.trim()||``;if(/[*&\[]/.test(i))continue;let a=i.match(/([A-Za-z_]\w*)\s*$/)?.[1];if(!a)continue;let o=p++;h.set(a,{slot:o,kind:e,fromLine:t+1,toLine:2**53-1}),this.debugGlobalMetadata=[...this.debugGlobalMetadata,{slot:o,name:a,kind:e,fromLine:t+1,toLine:2**53-1}],S.push(`${e===`bool`?`__wasm_idle_debug_value_bool`:`__wasm_idle_debug_value_num`}(0, ${o}, ${a});`)}}let A=C&&y.match(/^(?:const\s+)?([A-Za-z_]\w*)\s+([A-Za-z_]\w*)\s*\[(\d+)\]\s*(?:=.*)?;$/);if(A){let e=v.get(A[1]);if(e){let n=p++;this.debugGlobalMetadata=[...this.debugGlobalMetadata,{slot:n,name:A[2],kind:`array`,length:Number(A[3]),dimensions:[Number(A[3])],structFields:e.fields,structSize:e.size,fromLine:t+1,toLine:2**53-1}],S.push(`__wasm_idle_debug_value_addr(0, ${n}, (int)((unsigned long long)(${A[2]})));`)}}if(x&&!b&&y&&!y.startsWith(`#`)&&y!==`{`&&y!==`}`&&!y.startsWith(`else`)&&!y.startsWith(`case `)&&y!==`case`&&!y.startsWith(`default`)&&!y.startsWith(`catch`)&&!/^(public|private|protected)\s*:/.test(y)&&!y.endsWith(`:`)&&!y.includes(` else `)){E.push(`${a}__wasm_idle_debug_line(${d}, ${t+1});`);let e=y.match(/^(?:const\s+)?(?:(?:unsigned|signed)\s+)?(?:(?:short|long long|long)\s+)?(int|float|double|bool|char)\s+(.+);$/),n=y.match(/^(?:const\s+)?(?:(?:std::)?(vector|set|map))\s*<(.+)>\s+([A-Za-z_]\w*)\s*(?:=.*)?;$/);if(n&&d){let e=p++,r=n[1],i=n[3];O.add(i),g.set(i,{slot:e,container:r,fromLine:t+1,toLine:2**53-1}),this.debugVariableMetadata[d]=[...this.debugVariableMetadata[d]||[],{slot:e,name:i,kind:`text`,fromLine:t+1,toLine:2**53-1}],D.push(`${a}__wasm_idle_debug_emit_${r}(${d}, ${e}, ${i});`)}if(e&&d){let n=e[1]===`bool`?`bool`:`number`,r=[],i=``,o=0,s=0;for(let t of e[2]){if(t===`,`&&o===0&&s===0){i.trim()&&r.push(i.trim()),i=``;continue}t===`(`&&(o+=1),t===`)`&&(o=Math.max(0,o-1)),t===`{`&&(s+=1),t===`}`&&(s=Math.max(0,s-1)),i+=t}i.trim()&&r.push(i.trim());for(let i of r){let[r]=i.split(`=`),o=r?.trim()||``,s=[];for(let e of o.matchAll(/\[(\d+)\]/g))s.push(Number(e[1]));let c=o.match(/([A-Za-z_]\w*)\s*(?=\[\d+\])/);if(s.length&&c){let n=p++;this.debugVariableMetadata[d]=[...this.debugVariableMetadata[d]||[],{slot:n,name:c[1],kind:`array`,elementKind:e[1],length:s[0],dimensions:s,fromLine:t+1,toLine:2**53-1}],D.push(`${a}__wasm_idle_debug_value_addr(${d}, ${n}, (int)((unsigned long long)(${c[1]})));`);continue}if(/[*&]/.test(o))continue;let l=o.match(/([A-Za-z_]\w*)\s*(?:\[[^\]]*\])?$/)?.[1];if(l){if(!m.has(l)){let e=p++;m.set(l,{slot:e,kind:n,fromLine:t+1,toLine:2**53-1}),this.debugVariableMetadata[d]=[...this.debugVariableMetadata[d]||[],{slot:e,name:l,kind:n,fromLine:t+1,toLine:2**53-1}]}if(i.includes(`=`)){let e=m.get(l);e&&D.push(`${a}${e.kind===`bool`?`__wasm_idle_debug_value_bool`:`__wasm_idle_debug_value_num`}(${d}, ${e.slot}, ${l});`)}}}}let r=y.match(/^for\s*\(\s*(?:const\s+)?(?:(?:unsigned|signed)\s+)?(?:(?:short|long long|long)\s+)?(int|float|double|bool|char)\s+([A-Za-z_]\w*)\s*=/);if(r&&d){let e=r[1]===`bool`?`bool`:`number`,n=r[2];if(!m.has(n)){let r=p++;m.set(n,{slot:r,kind:e,fromLine:t+1,toLine:2**53-1}),this.debugVariableMetadata[d]=[...this.debugVariableMetadata[d]||[],{slot:r,name:n,kind:e,fromLine:t+1,toLine:2**53-1}]}}if(!w){for(let[e,t]of g){if(O.has(e))continue;let n=e.replace(/[.*+?^${}()|[\]\\]/g,`\\$&`);RegExp(`\\b${n}\\b`).test(y)&&D.push(`${a}__wasm_idle_debug_emit_${t.container}(${d}, ${t.slot}, ${e});`)}for(let[e,n]of m){let r=e.replace(/[.*+?^${}()|[\]\\]/g,`\\$&`);y.startsWith(`for`)&&n.toLine===t+1||(RegExp(`(?:^|[^\\w])(?:\\+\\+|--)\\s*${r}\\b`).test(y)||RegExp(`\\b${r}\\s*(?:(?:<<|>>|[+\\-*/%&|^])?=|\\+\\+|--)`).test(y)||RegExp(`&\\s*${r}\\b`).test(y)||RegExp(`\\b(?:cin|std::cin)\\b[^;]*>>\\s*${r}\\b`).test(y))&&D.push(`${a}${n.kind===`bool`?`__wasm_idle_debug_value_bool`:`__wasm_idle_debug_value_num`}(${d}, ${n.slot}, ${e});`)}for(let[e,t]of h){if(m.has(e)||g.has(e))continue;let n=e.replace(/[.*+?^${}()|[\]\\]/g,`\\$&`);(RegExp(`(?:^|[^\\w])(?:\\+\\+|--)\\s*${n}\\b`).test(y)||RegExp(`\\b${n}\\s*(?:(?:<<|>>|[+\\-*/%&|^])?=|\\+\\+|--)`).test(y)||RegExp(`&\\s*${n}\\b`).test(y)||RegExp(`\\b(?:cin|std::cin)\\b[^;]*>>\\s*${n}\\b`).test(y))&&D.push(`${a}${t.kind===`bool`?`__wasm_idle_debug_value_bool`:`__wasm_idle_debug_value_num`}(0, ${t.slot}, ${e});`)}}/^return\b/.test(y)&&E.push(`${a}__wasm_idle_debug_leave(${d});`)}if(u>0&&l===u&&y===`}`&&E.push(`${a}__wasm_idle_debug_leave(${d});`),x&&d&&(/^(while|if)\s*\(/.test(y)||/^for\s*\(/.test(y))){let e=y.match(/^(while|if|for)\b/)?.[1],r=n.indexOf(e||``),i=r>=0?n.indexOf(`(`,r):-1;if(i>=0){let r=-1,o=0;for(let e=i;e<n.length;e+=1){let t=n[e];if(t===`(`&&(o+=1),t===`)`&&(--o,o===0)){r=e;break}for(let[e,t]of h){if(m.has(e)||g.has(e))continue;let n=e.replace(/[.*+?^${}()|[\]\\]/g,`\\$&`);!w&&(RegExp(`(?:^|[^\\w])(?:\\+\\+|--)\\s*${n}\\b`).test(y)||RegExp(`\\b${n}\\s*(?:(?:<<|>>|[+\\-*/%&|^])?=|\\+\\+|--)`).test(y)||RegExp(`&\\s*${n}\\b`).test(y))&&D.push(`${a}${t.kind===`bool`?`__wasm_idle_debug_value_bool`:`__wasm_idle_debug_value_num`}(0, ${t.slot}, ${e});`)}}if(r>i){let a=n.slice(i+1,r);if(e===`for`){let e=[],o=``,c=0;for(let t of a){if(t===`;`&&c===0){e.push(o),o=``;continue}t===`(`&&(c+=1),t===`)`&&(c=Math.max(0,c-1)),o+=t}if(e.push(o),e.length===3&&e[1]?.trim()){let a=e[0].trim(),o=e[2].trim(),c=[],l=[],u=[],f=/^(?:const\s+)?(?:(?:unsigned|signed)\s+)?(?:(?:short|long long|long)\s+)?(?:int|float|double|bool|char)\b/.test(a);for(let[e,t]of m){let n=e.replace(/[.*+?^${}()|[\]\\]/g,`\\$&`),r=RegExp(`(?:^|[^\\w])(?:\\+\\+|--)\\s*${n}\\b|\\b${n}\\s*(?:(?:<<|>>|[+\\-*/%&|^])?=|\\+\\+|--)`);!f&&r.test(a)&&c.push(`${t.kind===`bool`?`__wasm_idle_debug_value_bool`:`__wasm_idle_debug_value_num`}(${d}, ${t.slot}, ${e})`),f&&r.test(a)&&l.push(`${t.kind===`bool`?`__wasm_idle_debug_value_bool`:`__wasm_idle_debug_value_num`}(${d}, ${t.slot}, ${e})`),r.test(o)&&u.push(`${t.kind===`bool`?`__wasm_idle_debug_value_bool`:`__wasm_idle_debug_value_num`}(${d}, ${t.slot}, ${e})`)}let p=c.length&&a?`(${a}, ${c.join(`, `)})`:e[0],h=u.length&&o?`(${o}, ${u.join(`, `)})`:e[2];s=n.slice(0,i+1)+`${p}; (${l.length?`${l.join(`, `)}, `:``}__wasm_idle_debug_line(${d}, ${t+1}), (${e[1].trim()})); ${h}`+n.slice(r)}}else{let e=[];if(w){for(let[t,n]of m){let r=t.replace(/[.*+?^${}()|[\]\\]/g,`\\$&`);RegExp(`(?:^|[^\\w])(?:\\+\\+|--)\\s*${r}\\b|\\b${r}\\s*(?:(?:<<|>>|[+\\-*/%&|^])?=|\\+\\+|--)`).test(a)&&e.push(`${n.kind===`bool`?`__wasm_idle_debug_value_bool`:`__wasm_idle_debug_value_num`}(${d}, ${n.slot}, ${t})`)}for(let[t,n]of h){if(m.has(t)||g.has(t))continue;let r=t.replace(/[.*+?^${}()|[\]\\]/g,`\\$&`);RegExp(`(?:^|[^\\w])(?:\\+\\+|--)\\s*${r}\\b|\\b${r}\\s*(?:(?:<<|>>|[+\\-*/%&|^])?=|\\+\\+|--)`).test(a)&&e.push(`${n.kind===`bool`?`__wasm_idle_debug_value_bool`:`__wasm_idle_debug_value_num`}(0, ${n.slot}, ${t})`)}}let o=e.length?`((${a.trim()}) ? (${e.join(`, `)}, 1) : (${e.join(`, `)}, 0))`:`(${a.trim()})`;s=n.slice(0,i+1)+`(__wasm_idle_debug_line(${d}, ${t+1}), ${o})`+n.slice(r)}}}}T.push(...E),T.push(s),T.push(...D);let j=u===0&&y.includes(`(`)&&y.includes(`)`)&&y.includes(`{`)&&(c.match(/{/g)||[]).length>(c.match(/}/g)||[]).length&&!/^(if|for|while|switch|catch)\b/.test(y)&&!/^(class|struct|namespace|enum|union)\b/.test(y),ee=u===0&&!!_&&y===`{`;if(l+=(c.match(/{/g)||[]).length,l-=(c.match(/}/g)||[]).length,j||ee){u=l,d=f++;let e=`anonymous`,n=i===`OBJC`&&j?y.match(/^([-+])\s*\([^)]*\)\s*([A-Za-z_]\w*)/):null;if(j?(e=y.slice(0,y.indexOf(`(`)).trim().split(/\s+/).pop()||e,n&&(e=`${n[1]}${n[2]}`)):_&&(e=_.functionName||e),this.debugFunctionMetadata[d]=e,p=1,m=/* @__PURE__ */ new Map,g=/* @__PURE__ */ new Map,T.push(`${a}    __wasm_idle_debug_enter(${d}, ${t+1});`),e===`main`){i===`CPP`&&(T.push(`${a}    std::cout.setf(std::ios::unitbuf);`),T.push(`${a}    std::cerr.setf(std::ios::unitbuf);`));let e=i===`CPP`?`nullptr`:`NULL`;T.push(`${a}    setvbuf(stdout, ${e}, _IONBF, 0);`),T.push(`${a}    setvbuf(stderr, ${e}, _IONBF, 0);`)}let r=j?n?``:y.slice(y.indexOf(`(`)+1,y.lastIndexOf(`)`)):_?.parameters||``;for(let e of r.split(`,`).map(e=>e.trim()).filter(Boolean)){let n=e.split(`=`)[0]?.trim()||``,r=n.match(/^(?:const\s+)?(?:(?:std::)?(vector|set|map)\s*<.+>)\s*&?\s*([A-Za-z_]\w*)\s*$/);if(r){let e=p++,n=r[1],i=r[2];g.set(i,{slot:e,container:n,fromLine:t+1,toLine:2**53-1}),this.debugVariableMetadata[d]=[...this.debugVariableMetadata[d]||[],{slot:e,name:i,kind:`text`,fromLine:t+1,toLine:2**53-1}],T.push(`${a}    __wasm_idle_debug_emit_${n}(${d}, ${e}, ${i});`);continue}let i=[];for(let e of n.matchAll(/\[(\d+)\]/g))i.push(Number(e[1]));let o=n.match(/([A-Za-z_]\w*)\s*(?=\[\d+\])/);if(i.length&&o&&/\b(int|float|double|bool|char)\b/.test(n)){let e=p++;this.debugVariableMetadata[d]=[...this.debugVariableMetadata[d]||[],{slot:e,name:o[1],kind:`array`,elementKind:n.match(/\b(int|float|double|bool|char)\b/)?.[1]||`int`,length:i[0],dimensions:i,fromLine:t+1,toLine:2**53-1}],T.push(`${a}    __wasm_idle_debug_value_addr(${d}, ${e}, (int)((unsigned long long)(${o[1]})));`);continue}if(/[*&\[]/.test(n))continue;let s=n.match(/([A-Za-z_]\w*)\s*(?:\[[^\]]*\])?\s*$/);if(!s)continue;let c=s[1],l=/\bbool\b/.test(n)?`bool`:/\b(?:int|float|double|char|short|long)\b/.test(n)?`number`:``;if(!l)continue;let u=p++;m.set(c,{slot:u,kind:l,fromLine:t+1,toLine:2**53-1}),this.debugVariableMetadata[d]=[...this.debugVariableMetadata[d]||[],{slot:u,name:c,kind:l,fromLine:t+1,toLine:2**53-1}],T.push(`${a}    ${l===`bool`?`__wasm_idle_debug_value_bool`:`__wasm_idle_debug_value_num`}(${d}, ${u}, ${c});`)}_=void 0}else u===0&&y.includes(`(`)&&y.includes(`)`)&&!y.includes(`{`)&&!y.endsWith(`;`)&&!/^(if|for|while|switch|catch)\b/.test(y)&&!/^(class|struct|namespace|enum|union)\b/.test(y)?_={functionName:y.slice(0,y.indexOf(`(`)).trim().split(/\s+/).pop()||`anonymous`,parameters:y.slice(y.indexOf(`(`)+1,y.lastIndexOf(`)`))}:y&&y!==`{`&&(_=void 0);u>0&&l<u&&(u=0,d=0,m=/* @__PURE__ */ new Map,g=/* @__PURE__ */ new Map)}S.length&&(i===`CPP`?(T.push(`struct __wasm_idle_debug_globals_init {`),T.push(`    __wasm_idle_debug_globals_init() {`),T.push(...S.map(e=>`        ${e}`)),T.push(`    }`),T.push(`} __wasm_idle_debug_globals_init_instance;`)):(T.push(`__attribute__((constructor)) static void __wasm_idle_debug_globals_init(void) {`),T.push(...S.map(e=>`    ${e}`)),T.push(`}`))),n=T.join(`
`)}else this.debugVariableMetadata={},this.debugGlobalMetadata=[],this.debugFunctionMetadata={};typeof e.transformSource==`function`&&(n=e.transformSource(n));let f=ir(n);await(i!==`C`||tr(a)?this.ensureCppSysroot():this.ready),(t.startsWith(`include/`)||t.startsWith(`lib/clang/`))&&(this.workspaceOverridesSystemHeaders=!0),e.sourceAlreadyMounted||(this.addWorkspaceFiles(e.workspaceFiles,t),this.addWorkspaceDirectories(t),this.memfs.addFile(t,f)),this.memfs.addFile(r,/* @__PURE__ */ new Uint8Array);let p=await this.getModule(this.assetUrls.clang),m=this.compilerConfig?.resourceDir||`/lib/clang/8.0.1`,h=de(i,``,m).flatMap(e=>[`-internal-isystem`,e]),g=(e,t,n,r,o=[])=>[`-cc1`,`-triple`,ae,e,`-disable-free`,`-isysroot`,`/`,`-resource-dir`,m,...h,...i===`OBJC`?[`-I.`]:[],`-ferror-limit`,`19`,`-fcolor-diagnostics`,...u?[]:[`-O`+d],`-o`,t,s,`-x`,n,...i===`OBJC`?oe:[],...o,r,...a,...u?[`-O0`,`-debug-info-kind=standalone`,`-dwarf-version=4`,`-debugger-tuning=gdb`,`-fdebug-compilation-dir=/workspace`]:[]],_=i===`CPP`&&!l&&typeof e.transformSource!=`function`&&Zn(n)&&Qn(a)&&!this.workspaceOverridesSystemHeaders?await(async()=>{let t=g(`-emit-pch`,`/${U}`,`c++-header`,Kn),n=await this.getPrecompiledHeaderFingerprint();if(n)return{key:JSON.stringify({format:`clang-pch-v2`,args:t,...n}),args:t,cache:_e(xe(this.persistentCache,e.persistentCache))}})():void 0;if(_&&(this.precompiledHeaderPlan=_),e.planPrecompiledHeaderOnly)return null;let v=e.precompiledHeader;if(_&&v?.key!==_.key){let e=await _.cache.read(_.key,this.signal).catch(()=>void 0);this.signal?.throwIfAborted(),e?.byteLength&&(v={key:_.key,bytes:e})}if(_&&v?.key===_.key){this.mountedPrecompiledHeaderKey!==v.key&&(this.addWorkspaceDirectories(U),this.memfs.addFile(U,v.bytes),this.mountedPrecompiledHeaderKey=v.key),this.trace(`compile ${t} -> ${r} with ${U}`);let e=[],n=this.memfs.stdout;this.memfs.stdout=t=>e.push(t);let i=!1;try{let e=await this.run(p,!0,`clang`,...g(`-emit-obj`,r,o,t,[`-include-pch`,`/${U}`]));return this.usedPrecompiledHeader=!0,e}catch(n){if(i=Jn.test(e.join(``)),!i){if(Uint8Array.from(this.memfs.getFileContents(r)).length>0)return this.usedPrecompiledHeader=!0,null;throw n}await _.cache.remove(_.key,this.signal).catch(()=>void 0),this.trace(`precompiled header rejected; compiling ${t} without it`),this.memfs.addFile(r,/* @__PURE__ */ new Uint8Array)}finally{if(this.memfs.stdout=n,!i)for(let t of e)n(t)}}let y=g(`-emit-obj`,r,o,t);this.trace(`compile ${t} -> ${r}`);try{return await this.run(p,!0,`clang`,...y)}catch(e){if(Uint8Array.from(this.memfs.getFileContents(r)).length>0)return this.trace(`recover ${r} after clang output stream exit`),null;throw e}}async link(e,t,n=`none`,r=`CPP`){let i=typeof e==`string`?[e]:[...e];if(i.length===0||i.some(e=>typeof e!=`string`||e.length===0))throw TypeError(`At least one nonempty object file is required for linking`);let a=F(typeof n==`boolean`?{debug:n}:{debugMode:n}),o=`lib/wasm32-wasi`,s=this.compilerConfig?.compilerRuntimeLibDir||`lib/clang/8.0.1/lib/wasi`,c=`${o}/crt1.o`;await(r===`C`?this.ready:this.ensureCppSysroot());let l=await this.prepareLongDoubleLinkArgs(),u=await this.getModule(this.assetUrls.lld);return this.trace(`link ${i.join(`, `)} -> ${t}`),await this.run(u,this.log,`wasm-ld`,`--export-dynamic`,...a===`trace`?[`--allow-undefined`]:[],`-z`,`stack-size=1048576`,`-L${o}/noeh`,`-L${o}`,c,...i,...l,`-lc`,...r===`C`?[]:[`-lc++`,`-lc++abi`],`-lm`,`-L${s}`,`-lclang_rt.builtins-wasm32`,`-o`,t)}async run(e,t,...n){return this.runWithOptions(e,t,n)}async runWithOptions(e,t,n,r={},i,a){this.memfs.out=t,this.hostLog(`${n.join(` `)}\n`),this.trace(`run ${n.join(` `)}`);let o=+/* @__PURE__ */ new Date,s=new sn(e,this.memfs,n[0],...n.slice(1),{extraImports:i,instanceRef:a});s.environ={...s.environ,...r},s.trace=e=>this.trace(e),s.debugSession={buffer:this.debugBuffer,interruptBuffer:this.debugInterruptBuffer,watchBuffer:this.debugWatchBuffer,watchResultBuffer:this.debugWatchResultBuffer,breakpoints:new Set(this.debugBreakpoints),breakpointVersion:0,pauseOnEntry:this.debugPauseOnEntry,stepArmed:this.debugPauseOnEntry,nextLineArmed:!1,stepOutArmed:!1,callDepth:0,stepOutDepth:0,currentFunctionId:0,currentLine:0,resumeSkipActive:!1,resumeSkipFunctionId:0,resumeSkipLine:0,nextLineFunctionId:0,nextLineLine:0,variableMetadata:this.debugVariableMetadata,globalVariableMetadata:this.debugGlobalMetadata,functionMetadata:this.debugFunctionMetadata,frames:[],globalValues:/* @__PURE__ */ new Map,onPause:e=>this.onDebugEvent?.(e)};let c=+/* @__PURE__ */ new Date,l=await s.run(),u=+/* @__PURE__ */ new Date;return this.log&&this.stdout(`
`),this.showTiming&&this.stdout(`${Nn}(${o-c}ms/${u-c}ms)${Pn}\n`),l?s:null}async compileLink(e,t={}){let{language:n=`CPP`,fileName:r,activePath:i,workspaceFiles:a=[],args:o=[],compileArgs:s=o,debugMode:c,debug:l,breakpoints:u=[],pauseOnEntry:d=!1,cppVersion:f,cVersion:p,debugBuffer:m,interruptBuffer:h,watchBuffer:g,watchResultBuffer:_,precompiledHeader:v}=t,y=F({debugMode:c,debug:l}),b=y===`lldb`?H:V,x=a.map(e=>({...e,path:b(e.path)})),{input:S,obj:C,wasm:w}=Un(n,b(i||``)||b(r||``)||void 0),T=/* @__PURE__ */ new Map;for(let e of x)if(e.path){if(e.path===W||e.path.startsWith(`${W}/`))throw Error(`Workspace path uses reserved build namespace ${JSON.stringify(W)}`);T.set(e.path,e)}if(S===W||S.startsWith(`${W}/`))throw Error(`Active source path uses reserved build namespace ${JSON.stringify(W)}`);T.set(S,{path:S,content:e});let E=[...T.values()].sort((e,t)=>e.path<t.path?-1:+(e.path>t.path)),D=E.filter(e=>e.path===S||er.test(e.path)),O=n===`C`&&D.every(e=>e.path===S||e.path.endsWith(`.c`))&&!tr(s)?[`C`]:[],k=y===`trace`;if(k&&D.length>1)throw Error(`Trace debug mode does not support multiple C/C++ translation units`);this.beginTrace(k),this.debugBreakpoints=new Set(k?u:[]),this.debugPauseOnEntry=k&&d,this.debugBuffer=m,this.debugInterruptBuffer=h,this.debugWatchBuffer=g,this.debugWatchResultBuffer=_,this.lastArtifactPath=w;let A=JSON.stringify({code:e,input:S,wasm:w,language:n,compileArgs:s,workspaceFiles:E,cppVersion:f,cVersion:p,debugMode:y});if(this.lastBuildKey===A)return this.trace(`reuse ${w}`),this.wasm;if(this.precompiledHeaderPlan=void 0,this.usedPrecompiledHeader=!1,this.getModule(this.assetUrls.lld).catch(()=>void 0),D.length===1)await this.compile({input:S,code:e,obj:C,language:n,compileArgs:s,workspaceFiles:x,cppVersion:f,cVersion:p,debugMode:y,precompiledHeader:v,persistentCache:t.persistentCache}),await this.link(C,w,y,...O);else{await this.ready,this.addWorkspaceFiles(E),this.memfs.addDirectory(W),this.memfs.addDirectory(`${W}/objects`);let e=[];for(let[r,i]of D.entries()){let a=`${W}/objects/${r.toString().padStart(4,`0`)}.o`;e.push(a),await this.compile({input:i.path,code:i.content,obj:a,language:i.path===S?n:i.path.endsWith(`.c`)?`C`:`CPP`,compileArgs:s,workspaceFiles:[],cppVersion:f,cVersion:p,debugMode:y,precompiledHeader:v,persistentCache:t.persistentCache,sourceAlreadyMounted:!0})}await this.link(e,w,y,...O)}this.lastBuildKey=A;let j=Uint8Array.from(this.memfs.getFileContents(w));return this.wasm=await this.hostLogAsync(`Compiling ${w}`,WebAssembly.compile(j))}async buildPrecompiledHeader(){let e=this.precompiledHeaderPlan;if(!e)return;await this.ensureCppSysroot(),this.addWorkspaceDirectories(U),this.memfs.addFile(U,/* @__PURE__ */ new Uint8Array),this.mountedPrecompiledHeaderKey=``;let t=await this.getModule(this.assetUrls.clang);this.trace(`precompile ${Kn} -> ${U}`);try{await this.run(t,!1,`clang`,...e.args)}catch{}let n=Uint8Array.from(this.memfs.getFileContents(U));if(n.length!==0)return this.mountedPrecompiledHeaderKey=e.key,await e.cache?.write(e.key,n,this.signal).catch(()=>!1),this.signal?.throwIfAborted(),{key:e.key,bytes:n}}async buildPrecompiledHeaderFor(e,t={}){let{language:n=`CPP`,fileName:r,activePath:i,args:a=[],compileArgs:o=a}=t,s=F(t),c=s===`lldb`?H:V,{input:l,obj:u}=Un(n,c(i||``)||c(r||``)||void 0);return this.precompiledHeaderPlan=void 0,await this.compile({input:l,code:e,obj:u,language:n,compileArgs:o,cppVersion:t.cppVersion,cVersion:t.cVersion,debugMode:s,planPrecompiledHeaderOnly:!0,persistentCache:t.persistentCache}),this.buildPrecompiledHeader()}async compileArtifact(e,t={}){let n=F(t),r=await this.compileLink(e,t),i=Uint8Array.from(this.memfs.getFileContents(this.lastArtifactPath)),a=t.language||`CPP`,o={code:e,language:a,fileName:t.fileName,activePath:t.activePath,workspaceFiles:t.workspaceFiles,compileArgs:t.compileArgs,cppVersion:t.cppVersion,cVersion:t.cVersion,debugMode:n};return{bytes:i,wasm:r,target:`wasm32-wasi`,format:`wasi-core-wasm`,fileName:this.lastArtifactPath,language:a,...n===`trace`?{debugMetadata:{variableMetadata:this.debugVariableMetadata,globalVariableMetadata:this.debugGlobalMetadata,functionMetadata:this.debugFunctionMetadata}}:{},...n===`lldb`?{debug:await Gn(o,i,this.compilerConfig?.provenance)}:{}}}async compileLinkRun(e,t={}){let{language:n=`CPP`,fileName:r,activePath:i,workspaceFiles:a=[],args:o=[],compileArgs:s=o,programArgs:c=[],debugMode:l,debug:u,breakpoints:d=[],pauseOnEntry:f=!1,cppVersion:p,cVersion:m,debugBuffer:h,interruptBuffer:g,watchBuffer:_,watchResultBuffer:v,precompiledHeader:y}=t,b=F({debugMode:l,debug:u});if(b===`lldb`)throw Error(`compileLinkRun() cannot execute LLDB artifacts in the browser WebAssembly engine. Use compileArtifact() and @wasm-idle/llvm-core/debug instead.`);this.debug=b===`trace`;let{wasm:x}=Un(n,V(i||``)||V(r||``)||void 0);return await this.run(await this.compileLink(e,{language:n,fileName:r,activePath:i,workspaceFiles:a,compileArgs:s,debugMode:b,breakpoints:d,pauseOnEntry:f,cppVersion:p,cVersion:m,debugBuffer:h,interruptBuffer:g,watchBuffer:_,watchResultBuffer:v,...y?{precompiledHeader:y}:{},persistentCache:t.persistentCache}),!0,x,...c)}};const sr=`__wasm_idle_build`,cr=/\.(?:c|cc|cpp|cxx)$/;var lr=class extends or{exportDynamic=!1;minimalLink=!1;linked;invalidateArtifact(){this.linked=void 0,this.lastBuildKey=``,this.wasm=void 0}async compile(e){return this.invalidateArtifact(),super.compile(e)}async link(e,t,n=`none`,r=`CPP`){this.invalidateArtifact();let i=F(typeof n==`boolean`?{debug:n}:{debugMode:n}),a=this.minimalLink;this.minimalLink=i===`none`&&!this.exportDynamic;try{return await super.link(e,t,i,r)}finally{this.minimalLink=a}}async run(e,t,...n){return this.minimalLink&&n[0]===`wasm-ld`&&(n=n.filter(e=>e!==`--export-dynamic`)),super.run(e,t,...n)}async buildBytes(e,t){try{return await this.buildLinkedBytes(e,t)}catch(e){throw this.invalidateArtifact(),e}}async buildLinkedBytes(e,t){let{language:n=`CPP`,fileName:r,activePath:i,workspaceFiles:a=[],args:o=[],compileArgs:s=o,cppVersion:c,cVersion:l,breakpoints:u=[],pauseOnEntry:d=!1,debugBuffer:f,interruptBuffer:p,watchBuffer:m,watchResultBuffer:h,precompiledHeader:g}=t,_=F(t),v=_===`lldb`?H:V,y=a.map(e=>({...e,path:v(e.path)})),{input:b,obj:x,wasm:S}=Un(n,v(i||``)||v(r||``)||void 0),C=/* @__PURE__ */ new Map;for(let t of[...y,{path:b,content:e}])if(t.path){if(t.path===sr||t.path.startsWith(`${sr}/`))throw Error(`Workspace path uses reserved build namespace ${JSON.stringify(sr)}`);C.set(t.path,t)}let w=[...C.values()].sort((e,t)=>e.path<t.path?-1:+(e.path>t.path)),T=w.filter(e=>e.path===b||cr.test(e.path));if(_===`trace`&&T.length>1)throw Error(`Trace debug mode does not support multiple C/C++ translation units`);let E=n===`C`&&T.every(e=>e.path===b||e.path.endsWith(`.c`))&&!s.some(e=>typeof e!=`string`||e.startsWith(`-x`)||e.startsWith(`@`));this.beginTrace(_===`trace`),this.debugBreakpoints=new Set(_===`trace`?u:[]),this.debugPauseOnEntry=_===`trace`&&d,this.debugBuffer=f,this.debugInterruptBuffer=p,this.debugWatchBuffer=m,this.debugWatchResultBuffer=h;let D=JSON.stringify({code:e,input:b,wasm:S,language:n,compileArgs:s,workspaceFiles:w,cppVersion:c,cVersion:l,debugMode:_,exportDynamic:this.exportDynamic});if(this.linked?.key===D)return this.lastArtifactPath=S,this.trace(`reuse ${S}`),this.linked;this.invalidateArtifact(),this.precompiledHeaderPlan=void 0,this.usedPrecompiledHeader=!1,this.getModule(this.assetUrls.lld).catch(()=>void 0);let O={compileArgs:s,cppVersion:c,cVersion:l,debugMode:_,precompiledHeader:g,persistentCache:t.persistentCache},k=[];if(T.length===1)await this.compile({...O,input:b,code:e,obj:x,language:n,workspaceFiles:y}),k.push(x);else{await this.ready,this.addWorkspaceFiles(w),this.memfs.addDirectory(sr),this.memfs.addDirectory(`${sr}/objects`);for(let[e,t]of T.entries()){let r=`${sr}/objects/${e.toString().padStart(4,`0`)}.o`;await this.compile({...O,input:t.path,code:t.content,obj:r,language:t.path===b?n:t.path.endsWith(`.c`)?`C`:`CPP`,workspaceFiles:[],sourceAlreadyMounted:!0}),k.push(r)}}this.memfs.addFile(S,/* @__PURE__ */ new Uint8Array),await this.link(k,S,_,E?`C`:`CPP`);let A=Uint8Array.from(this.memfs.getFileContents(S));if(!A.length)throw Error(`Linker produced an empty artifact: ${S}`);return this.lastArtifactPath=S,this.lastBuildKey=D,this.linked={key:D,bytes:A}}async compileLink(e,t={}){let n=await this.buildBytes(e,t);try{return n.module||=await this.hostLogAsync(`Compiling ${this.lastArtifactPath}`,WebAssembly.compile(Uint8Array.from(n.bytes))),this.wasm=n.module,n.module}catch(e){throw this.invalidateArtifact(),e}}async compileArtifact(e,t={}){let n=await this.buildBytes(e,t),r=F(t),i=r===`lldb`?void 0:await this.compileLink(e,t),a=Uint8Array.from(n.bytes),o=t.language||`CPP`;return{bytes:a,...i?{wasm:i}:{},target:`wasm32-wasi`,format:`wasi-core-wasm`,fileName:this.lastArtifactPath,language:o,...r===`trace`?{debugMetadata:{variableMetadata:this.debugVariableMetadata,globalVariableMetadata:this.debugGlobalMetadata,functionMetadata:this.debugFunctionMetadata}}:{},...r===`lldb`?{debug:await Gn({code:e,language:o,fileName:t.fileName,activePath:t.activePath,workspaceFiles:t.workspaceFiles,compileArgs:t.compileArgs??t.args,cppVersion:t.cppVersion,cVersion:t.cVersion,debugMode:r},a,this.compilerConfig?.provenance)}:{}}}};function G(e,t){if(!e||typeof e!=`object`||Array.isArray(e))throw Error(`invalid ${t} in wasm-clang runtime manifest`);return e}function K(e,t){if(typeof e!=`string`||e.length===0)throw Error(`invalid ${t} in wasm-clang runtime manifest`);return e}function ur(e,t){if(e!==`wasm32-wasi`)throw Error(`invalid ${t} in wasm-clang runtime manifest`);return e}function dr(e){let t=G(e,`root.compiler.provenance`);if(t.name!==`clang`)throw Error(`invalid root.compiler.provenance.name in wasm-clang runtime manifest`);return{name:`clang`,version:K(t.version,`root.compiler.provenance.version`),revision:K(t.revision,`root.compiler.provenance.revision`)}}function fr(e){let t=G(e,`root.compiler.sysroot.profiles`);return{c:{asset:K(G(t.c,`root.compiler.sysroot.profiles.c`).asset,`root.compiler.sysroot.profiles.c.asset`)},cppAddon:{asset:K(G(t.cppAddon,`root.compiler.sysroot.profiles.cppAddon`).asset,`root.compiler.sysroot.profiles.cppAddon.asset`)}}}function pr(e){let t=G(e,`root.compiler`),n=G(t.sysroot,`root.compiler.sysroot`);return{memfs:{asset:K(G(t.memfs,`root.compiler.memfs`).asset,`root.compiler.memfs.asset`),argv0:K(G(t.memfs,`root.compiler.memfs`).argv0,`root.compiler.memfs.argv0`)},clang:{asset:K(G(t.clang,`root.compiler.clang`).asset,`root.compiler.clang.asset`),argv0:K(G(t.clang,`root.compiler.clang`).argv0,`root.compiler.clang.argv0`)},lld:{asset:K(G(t.lld,`root.compiler.lld`).asset,`root.compiler.lld.asset`),argv0:K(G(t.lld,`root.compiler.lld`).argv0,`root.compiler.lld.argv0`)},sysroot:{asset:K(n.asset,`root.compiler.sysroot.asset`),...n.printscanLongDouble===void 0?{}:{printscanLongDouble:{asset:K(G(n.printscanLongDouble,`root.compiler.sysroot.printscanLongDouble`).asset,`root.compiler.sysroot.printscanLongDouble.asset`)}},...typeof n.runtimeRoot==`string`?{runtimeRoot:n.runtimeRoot}:{},...n.profiles===void 0?{}:{profiles:fr(n.profiles)}},...t.resourceDir===void 0?{}:{resourceDir:K(t.resourceDir,`root.compiler.resourceDir`)},...t.compilerRuntimeLibDir===void 0?{}:{compilerRuntimeLibDir:K(t.compilerRuntimeLibDir,`root.compiler.compilerRuntimeLibDir`)},...typeof t.defaultCppStandard==`string`?{defaultCppStandard:t.defaultCppStandard}:{},...typeof t.defaultCStandard==`string`?{defaultCStandard:t.defaultCStandard}:{},...t.provenance===void 0?{}:{provenance:dr(t.provenance)}}}function mr(e){let t=G(e,`root.clangd.headers`),n=e=>{throw Error(`invalid root.clangd.headers.${e} in wasm-clang runtime manifest`)};t.asset!==`clangd/clangd.headers.json.gz`&&n(`asset`),t.format!==`clangd-headers-v1`&&n(`format`);for(let e of[`sha256`,`uncompressedSha256`,`version`])(typeof t[e]!=`string`||!/^[a-f0-9]{64}$/.test(t[e]))&&n(e);t.version!==t.uncompressedSha256&&n(`version`);for(let e of[`bytes`,`uncompressedBytes`])(!Number.isSafeInteger(t[e])||t[e]<=0||t[e]>134217728)&&n(e);let r=K(t.resourceDir,`root.clangd.headers.resourceDir`);return(!/^\/lib\/clang\/[a-zA-Z0-9_.-]+$/.test(r)||[`.`,`..`].includes(r.split(`/`).at(-1)))&&n(`resourceDir`),{asset:`clangd/clangd.headers.json.gz`,format:`clangd-headers-v1`,version:t.version,targetTriple:ur(t.targetTriple,`root.clangd.headers.targetTriple`),resourceDir:r,bytes:t.bytes,sha256:t.sha256,uncompressedBytes:t.uncompressedBytes,uncompressedSha256:t.uncompressedSha256}}function hr(e){let t=G(e,`root.clangd`);return{js:K(t.js,`root.clangd.js`),wasm:K(t.wasm,`root.clangd.wasm`),...t.headers===void 0?{}:{headers:mr(t.headers)}}}function gr(e,t){let n=G(e,t);if(G(n.execution,`${t}.execution`).kind!==`wasi-preview1`)throw Error(`invalid ${t}.execution.kind in wasm-clang runtime manifest`);if(n.artifactFormat!==`wasi-core-wasm`)throw Error(`invalid ${t}.artifactFormat in wasm-clang runtime manifest`);return{artifactFormat:`wasi-core-wasm`,execution:{kind:`wasi-preview1`}}}function _r(e){return{"wasm32-wasi":gr(G(e,`root.targets`)[`wasm32-wasi`],`root.targets.wasm32-wasi`)}}function vr(e){let t=G(e,`root`);if(t.manifestVersion!==1)throw Error(`invalid root.manifestVersion in wasm-clang runtime manifest`);let n=pr(t.compiler),r=hr(t.clangd);if(r.headers&&n.resourceDir&&r.headers.resourceDir!==n.resourceDir)throw Error(`root.clangd.headers.resourceDir does not match the compiler in wasm-clang runtime manifest`);return{manifestVersion:1,version:K(t.version,`root.version`),defaultTarget:ur(t.defaultTarget,`root.defaultTarget`),compiler:n,clangd:r,targets:_r(t.targets)}}async function yr(e,t=fetch,n,r=St){return vr(await kt(Ln(e,`wasm-clang runtime manifest URL`),{fetchImpl:t,label:`wasm-clang runtime manifest`,maxBytes:Math.min(r,St),signal:n}))}function br(e){return Vn(e)}var xr=class e{static read_bytes(t,n){let r=new e;return r.buf=t.getUint32(n,!0),r.buf_len=t.getUint32(n+4,!0),r}static read_bytes_array(t,n,r){let i=[];for(let a=0;a<r;a++)i.push(e.read_bytes(t,n+8*a));return i}},Sr=class e{static read_bytes(t,n){let r=new e;return r.buf=t.getUint32(n,!0),r.buf_len=t.getUint32(n+4,!0),r}static read_bytes_array(t,n,r){let i=[];for(let a=0;a<r;a++)i.push(e.read_bytes(t,n+8*a));return i}},Cr=class{head_length(){return 24}name_length(){return this.dir_name.byteLength}write_head_bytes(e,t){e.setBigUint64(t,this.d_next,!0),e.setBigUint64(t+8,this.d_ino,!0),e.setUint32(t+16,this.dir_name.length,!0),e.setUint8(t+20,this.d_type)}write_name_bytes(e,t,n){e.set(this.dir_name.slice(0,Math.min(this.dir_name.byteLength,n)),t)}constructor(e,t,n,r){let i=new TextEncoder().encode(n);this.d_next=e,this.d_ino=t,this.d_namlen=i.byteLength,this.d_type=r,this.dir_name=i}},wr=class{write_bytes(e,t){e.setUint8(t,this.fs_filetype),e.setUint16(t+2,this.fs_flags,!0),e.setBigUint64(t+8,this.fs_rights_base,!0),e.setBigUint64(t+16,this.fs_rights_inherited,!0)}constructor(e,t){this.fs_rights_base=0n,this.fs_rights_inherited=0n,this.fs_filetype=e,this.fs_flags=t}},Tr=class{write_bytes(e,t){e.setBigUint64(t,this.dev,!0),e.setBigUint64(t+8,this.ino,!0),e.setUint8(t+16,this.filetype),e.setBigUint64(t+24,this.nlink,!0),e.setBigUint64(t+32,this.size,!0),e.setBigUint64(t+38,this.atim,!0),e.setBigUint64(t+46,this.mtim,!0),e.setBigUint64(t+52,this.ctim,!0)}constructor(e,t,n){this.dev=0n,this.nlink=0n,this.atim=0n,this.mtim=0n,this.ctim=0n,this.ino=e,this.filetype=t,this.size=n}},Er=class e{static read_bytes(t,n){return new e(t.getBigUint64(n,!0),t.getUint8(n+8),t.getUint32(n+16,!0),t.getBigUint64(n+24,!0),t.getUint16(n+36,!0))}constructor(e,t,n,r,i){this.userdata=e,this.eventtype=t,this.clockid=n,this.timeout=r,this.flags=i}},Dr=class{write_bytes(e,t){e.setBigUint64(t,this.userdata,!0),e.setUint16(t+8,this.error,!0),e.setUint8(t+10,this.eventtype)}constructor(e,t,n){this.userdata=e,this.error=t,this.eventtype=n}},Or=class{write_bytes(e,t){e.setUint32(t,this.pr_name.byteLength,!0)}constructor(e){this.pr_name=new TextEncoder().encode(e)}},kr=class e{static dir(t){let n=new e;return n.tag=0,n.inner=new Or(t),n}write_bytes(e,t){e.setUint32(t,this.tag,!0),this.inner.write_bytes(e,t+4)}};let Ar=class{enable(e){this.log=jr(e===void 0||e,this.prefix)}get enabled(){return this.isEnabled}constructor(e){this.isEnabled=e,this.prefix=`wasi:`,this.enable(e)}};function jr(e,t){return e?console.log.bind(console,`%c%s`,`color: #265BA0`,t):()=>{}}const q=new Ar(!1);var Mr=class extends Error{constructor(e){super(`exit with exit code `+e),this.code=e}};let Nr=class{start(e){this.inst=e;try{return e.exports._start(),0}catch(e){if(e instanceof Mr)return e.code;throw e}}initialize(e){this.inst=e,e.exports._initialize&&e.exports._initialize()}constructor(e,t,n,r={}){this.args=[],this.env=[],this.fds=[],q.enable(r.debug),this.args=e,this.env=t,this.fds=n;let i=this;this.wasiImport={args_sizes_get(e,t){let n=new DataView(i.inst.exports.memory.buffer);n.setUint32(e,i.args.length,!0);let r=0;for(let e of i.args)r+=e.length+1;return n.setUint32(t,r,!0),q.log(n.getUint32(e,!0),n.getUint32(t,!0)),0},args_get(e,t){let n=new DataView(i.inst.exports.memory.buffer),r=new Uint8Array(i.inst.exports.memory.buffer),a=t;for(let a=0;a<i.args.length;a++){n.setUint32(e,t,!0),e+=4;let o=new TextEncoder().encode(i.args[a]);r.set(o,t),n.setUint8(t+o.length,0),t+=o.length+1}return q.enabled&&q.log(new TextDecoder(`utf-8`).decode(r.slice(a,t))),0},environ_sizes_get(e,t){let n=new DataView(i.inst.exports.memory.buffer);n.setUint32(e,i.env.length,!0);let r=0;for(let e of i.env)r+=new TextEncoder().encode(e).length+1;return n.setUint32(t,r,!0),q.log(n.getUint32(e,!0),n.getUint32(t,!0)),0},environ_get(e,t){let n=new DataView(i.inst.exports.memory.buffer),r=new Uint8Array(i.inst.exports.memory.buffer),a=t;for(let a=0;a<i.env.length;a++){n.setUint32(e,t,!0),e+=4;let o=new TextEncoder().encode(i.env[a]);r.set(o,t),n.setUint8(t+o.length,0),t+=o.length+1}return q.enabled&&q.log(new TextDecoder(`utf-8`).decode(r.slice(a,t))),0},clock_res_get(e,t){let n;switch(e){case 1:n=5000n;break;case 0:n=1000000n;break;default:return 52}return new DataView(i.inst.exports.memory.buffer).setBigUint64(t,n,!0),0},clock_time_get(e,t,n){let r=new DataView(i.inst.exports.memory.buffer);if(e===0)r.setBigUint64(n,BigInt((/* @__PURE__ */ new Date()).getTime())*1000000n,!0);else if(e==1){let e;try{e=BigInt(Math.round(performance.now()*1e6))}catch{e=0n}r.setBigUint64(n,e,!0)}else r.setBigUint64(n,0n,!0);return 0},fd_advise(e,t,n,r){return i.fds[e]==null?8:0},fd_allocate(e,t,n){return i.fds[e]==null?8:i.fds[e].fd_allocate(t,n)},fd_close(e){if(i.fds[e]!=null){let t=i.fds[e].fd_close();return i.fds[e]=void 0,t}return 8},fd_datasync(e){return i.fds[e]==null?8:i.fds[e].fd_sync()},fd_fdstat_get(e,t){if(i.fds[e]!=null){let{ret:n,fdstat:r}=i.fds[e].fd_fdstat_get();return r?.write_bytes(new DataView(i.inst.exports.memory.buffer),t),n}return 8},fd_fdstat_set_flags(e,t){return i.fds[e]==null?8:i.fds[e].fd_fdstat_set_flags(t)},fd_fdstat_set_rights(e,t,n){return i.fds[e]==null?8:i.fds[e].fd_fdstat_set_rights(t,n)},fd_filestat_get(e,t){if(i.fds[e]!=null){let{ret:n,filestat:r}=i.fds[e].fd_filestat_get();return r?.write_bytes(new DataView(i.inst.exports.memory.buffer),t),n}return 8},fd_filestat_set_size(e,t){return i.fds[e]==null?8:i.fds[e].fd_filestat_set_size(t)},fd_filestat_set_times(e,t,n,r){return i.fds[e]==null?8:i.fds[e].fd_filestat_set_times(t,n,r)},fd_pread(e,t,n,r,a){let o=new DataView(i.inst.exports.memory.buffer),s=new Uint8Array(i.inst.exports.memory.buffer);if(i.fds[e]!=null){let c=xr.read_bytes_array(o,t,n),l=0;for(let t of c){let{ret:n,data:c}=i.fds[e].fd_pread(t.buf_len,r);if(n!=0)return o.setUint32(a,l,!0),n;if(s.set(c,t.buf),l+=c.length,r+=BigInt(c.length),c.length!=t.buf_len)break}return o.setUint32(a,l,!0),0}return 8},fd_prestat_get(e,t){let n=new DataView(i.inst.exports.memory.buffer);if(i.fds[e]!=null){let{ret:r,prestat:a}=i.fds[e].fd_prestat_get();return a?.write_bytes(n,t),r}return 8},fd_prestat_dir_name(e,t,n){if(i.fds[e]!=null){let{ret:r,prestat:a}=i.fds[e].fd_prestat_get();if(a==null)return r;let o=a.inner.pr_name;return new Uint8Array(i.inst.exports.memory.buffer).set(o.slice(0,n),t),o.byteLength>n?37:0}return 8},fd_pwrite(e,t,n,r,a){let o=new DataView(i.inst.exports.memory.buffer),s=new Uint8Array(i.inst.exports.memory.buffer);if(i.fds[e]!=null){let c=Sr.read_bytes_array(o,t,n),l=0;for(let t of c){let n=s.slice(t.buf,t.buf+t.buf_len),{ret:c,nwritten:u}=i.fds[e].fd_pwrite(n,r);if(c!=0)return o.setUint32(a,l,!0),c;if(l+=u,r+=BigInt(u),u!=n.byteLength)break}return o.setUint32(a,l,!0),0}return 8},fd_read(e,t,n,r){let a=new DataView(i.inst.exports.memory.buffer),o=new Uint8Array(i.inst.exports.memory.buffer);if(i.fds[e]!=null){let s=xr.read_bytes_array(a,t,n),c=0;for(let t of s){let{ret:n,data:s}=i.fds[e].fd_read(t.buf_len);if(n!=0)return a.setUint32(r,c,!0),n;if(o.set(s,t.buf),c+=s.length,s.length!=t.buf_len)break}return a.setUint32(r,c,!0),0}return 8},fd_readdir(e,t,n,r,a){let o=new DataView(i.inst.exports.memory.buffer),s=new Uint8Array(i.inst.exports.memory.buffer);if(i.fds[e]!=null){let c=0;for(;;){let{ret:l,dirent:u}=i.fds[e].fd_readdir_single(r);if(l!=0)return o.setUint32(a,c,!0),l;if(u==null)break;if(n-c<u.head_length()){c=n;break}let d=new ArrayBuffer(u.head_length());if(u.write_head_bytes(new DataView(d),0),s.set(new Uint8Array(d).slice(0,Math.min(d.byteLength,n-c)),t),t+=u.head_length(),c+=u.head_length(),n-c<u.name_length()){c=n;break}u.write_name_bytes(s,t,n-c),t+=u.name_length(),c+=u.name_length(),r=u.d_next}return o.setUint32(a,c,!0),0}return 8},fd_renumber(e,t){if(i.fds[e]!=null&&i.fds[t]!=null){let n=i.fds[t].fd_close();return n==0?(i.fds[t]=i.fds[e],i.fds[e]=void 0,0):n}return 8},fd_seek(e,t,n,r){let a=new DataView(i.inst.exports.memory.buffer);if(i.fds[e]!=null){let{ret:o,offset:s}=i.fds[e].fd_seek(t,n);return a.setBigInt64(r,s,!0),o}return 8},fd_sync(e){return i.fds[e]==null?8:i.fds[e].fd_sync()},fd_tell(e,t){let n=new DataView(i.inst.exports.memory.buffer);if(i.fds[e]!=null){let{ret:r,offset:a}=i.fds[e].fd_tell();return n.setBigUint64(t,a,!0),r}return 8},fd_write(e,t,n,r){let a=new DataView(i.inst.exports.memory.buffer),o=new Uint8Array(i.inst.exports.memory.buffer);if(i.fds[e]!=null){let s=Sr.read_bytes_array(a,t,n),c=0;for(let t of s){let n=o.slice(t.buf,t.buf+t.buf_len),{ret:s,nwritten:l}=i.fds[e].fd_write(n);if(s!=0)return a.setUint32(r,c,!0),s;if(c+=l,l!=n.byteLength)break}return a.setUint32(r,c,!0),0}return 8},path_create_directory(e,t,n){let r=new Uint8Array(i.inst.exports.memory.buffer);if(i.fds[e]!=null){let a=new TextDecoder(`utf-8`).decode(r.slice(t,t+n));return i.fds[e].path_create_directory(a)}return 8},path_filestat_get(e,t,n,r,a){let o=new DataView(i.inst.exports.memory.buffer),s=new Uint8Array(i.inst.exports.memory.buffer);if(i.fds[e]!=null){let c=new TextDecoder(`utf-8`).decode(s.slice(n,n+r)),{ret:l,filestat:u}=i.fds[e].path_filestat_get(t,c);return u?.write_bytes(o,a),l}return 8},path_filestat_set_times(e,t,n,r,a,o,s){let c=new Uint8Array(i.inst.exports.memory.buffer);if(i.fds[e]!=null){let l=new TextDecoder(`utf-8`).decode(c.slice(n,n+r));return i.fds[e].path_filestat_set_times(t,l,a,o,s)}return 8},path_link(e,t,n,r,a,o,s){let c=new Uint8Array(i.inst.exports.memory.buffer);if(i.fds[e]!=null&&i.fds[a]!=null){let l=new TextDecoder(`utf-8`).decode(c.slice(n,n+r)),u=new TextDecoder(`utf-8`).decode(c.slice(o,o+s)),{ret:d,inode_obj:f}=i.fds[e].path_lookup(l,t);return f==null?d:i.fds[a].path_link(u,f,!1)}return 8},path_open(e,t,n,r,a,o,s,c,l){let u=new DataView(i.inst.exports.memory.buffer),d=new Uint8Array(i.inst.exports.memory.buffer);if(i.fds[e]!=null){let f=new TextDecoder(`utf-8`).decode(d.slice(n,n+r));q.log(f);let{ret:p,fd_obj:m}=i.fds[e].path_open(t,f,a,o,s,c);if(p!=0)return p;i.fds.push(m);let h=i.fds.length-1;return u.setUint32(l,h,!0),0}return 8},path_readlink(e,t,n,r,a,o){let s=new DataView(i.inst.exports.memory.buffer),c=new Uint8Array(i.inst.exports.memory.buffer);if(i.fds[e]!=null){let l=new TextDecoder(`utf-8`).decode(c.slice(t,t+n));q.log(l);let{ret:u,data:d}=i.fds[e].path_readlink(l);if(d!=null){let e=new TextEncoder().encode(d);if(e.length>a)return s.setUint32(o,0,!0),8;c.set(e,r),s.setUint32(o,e.length,!0)}return u}return 8},path_remove_directory(e,t,n){let r=new Uint8Array(i.inst.exports.memory.buffer);if(i.fds[e]!=null){let a=new TextDecoder(`utf-8`).decode(r.slice(t,t+n));return i.fds[e].path_remove_directory(a)}return 8},path_rename(e,t,n,r,a,o){let s=new Uint8Array(i.inst.exports.memory.buffer);if(i.fds[e]!=null&&i.fds[r]!=null){let c=new TextDecoder(`utf-8`).decode(s.slice(t,t+n)),l=new TextDecoder(`utf-8`).decode(s.slice(a,a+o)),{ret:u,inode_obj:d}=i.fds[e].path_unlink(c);if(d==null)return u;if(u=i.fds[r].path_link(l,d,!0),u!=0&&i.fds[e].path_link(c,d,!0)!=0)throw`path_link should always return success when relinking an inode back to the original place`;return u}return 8},path_symlink(e,t,n,r,a){let o=new Uint8Array(i.inst.exports.memory.buffer);return i.fds[n]==null?8:(new TextDecoder(`utf-8`).decode(o.slice(e,e+t)),new TextDecoder(`utf-8`).decode(o.slice(r,r+a)),58)},path_unlink_file(e,t,n){let r=new Uint8Array(i.inst.exports.memory.buffer);if(i.fds[e]!=null){let a=new TextDecoder(`utf-8`).decode(r.slice(t,t+n));return i.fds[e].path_unlink_file(a)}return 8},poll_oneoff(e,t,n){if(n===0)return 28;if(n>1)return q.log(`poll_oneoff: only a single subscription is supported`),58;let r=new DataView(i.inst.exports.memory.buffer),a=Er.read_bytes(r,e),o=a.eventtype,s=a.clockid,c=a.timeout;if(o!==0)return q.log(`poll_oneoff: only clock subscriptions are supported`),58;let l;if(s===1)l=()=>BigInt(Math.round(performance.now()*1e6));else if(s===0)l=()=>BigInt((/* @__PURE__ */ new Date()).getTime())*1000000n;else return 28;let u=a.flags&1?c:l()+c;for(;u>l(););return new Dr(a.userdata,0,o).write_bytes(r,t),0},proc_exit(e){throw new Mr(e)},proc_raise(e){throw`raised signal `+e},sched_yield(){},random_get(e,t){let n=new Uint8Array(i.inst.exports.memory.buffer).subarray(e,e+t);if(`crypto`in globalThis&&(typeof SharedArrayBuffer>`u`||!(i.inst.exports.memory.buffer instanceof SharedArrayBuffer)))for(let e=0;e<t;e+=65536)crypto.getRandomValues(n.subarray(e,e+65536));else for(let e=0;e<t;e++)n[e]=Math.random()*256|0},sock_recv(e,t,n){throw`sockets not supported`},sock_send(e,t,n){throw`sockets not supported`},sock_shutdown(e,t){throw`sockets not supported`},sock_accept(e,t){throw`sockets not supported`}}}};var Pr=class{fd_allocate(e,t){return 58}fd_close(){return 0}fd_fdstat_get(){return{ret:58,fdstat:null}}fd_fdstat_set_flags(e){return 58}fd_fdstat_set_rights(e,t){return 58}fd_filestat_get(){return{ret:58,filestat:null}}fd_filestat_set_size(e){return 58}fd_filestat_set_times(e,t,n){return 58}fd_pread(e,t){return{ret:58,data:/* @__PURE__ */ new Uint8Array}}fd_prestat_get(){return{ret:58,prestat:null}}fd_pwrite(e,t){return{ret:58,nwritten:0}}fd_read(e){return{ret:58,data:/* @__PURE__ */ new Uint8Array}}fd_readdir_single(e){return{ret:58,dirent:null}}fd_seek(e,t){return{ret:58,offset:0n}}fd_sync(){return 0}fd_tell(){return{ret:58,offset:0n}}fd_write(e){return{ret:58,nwritten:0}}path_create_directory(e){return 58}path_filestat_get(e,t){return{ret:58,filestat:null}}path_filestat_set_times(e,t,n,r,i){return 58}path_link(e,t,n){return 58}path_unlink(e){return{ret:58,inode_obj:null}}path_lookup(e,t){return{ret:58,inode_obj:null}}path_open(e,t,n,r,i,a){return{ret:54,fd_obj:null}}path_readlink(e){return{ret:58,data:null}}path_remove_directory(e){return 58}path_rename(e,t,n){return 58}path_unlink_file(e){return 58}},Fr=class e{static issue_ino(){return e.next_ino++}static root_ino(){return 0n}constructor(){this.ino=e.issue_ino()}};Fr.next_ino=1n;var Ir=class extends Pr{fd_allocate(e,t){if(!(this.file.size>e+t)){let n=new Uint8Array(Number(e+t));n.set(this.file.data,0),this.file.data=n}return 0}fd_fdstat_get(){return{ret:0,fdstat:new wr(4,0)}}fd_filestat_set_size(e){if(this.file.size>e)this.file.data=new Uint8Array(this.file.data.buffer.slice(0,Number(e)));else{let t=new Uint8Array(Number(e));t.set(this.file.data,0),this.file.data=t}return 0}fd_read(e){let t=this.file.data.slice(Number(this.file_pos),Number(this.file_pos+BigInt(e)));return this.file_pos+=BigInt(t.length),{ret:0,data:t}}fd_pread(e,t){return{ret:0,data:this.file.data.slice(Number(t),Number(t+BigInt(e)))}}fd_seek(e,t){let n;switch(t){case 0:n=e;break;case 1:n=this.file_pos+e;break;case 2:n=BigInt(this.file.data.byteLength)+e;break;default:return{ret:28,offset:0n}}return n<0?{ret:28,offset:0n}:(this.file_pos=n,{ret:0,offset:this.file_pos})}fd_tell(){return{ret:0,offset:this.file_pos}}fd_write(e){if(this.file.readonly)return{ret:8,nwritten:0};if(this.file_pos+BigInt(e.byteLength)>this.file.size){let t=this.file.data;this.file.data=new Uint8Array(Number(this.file_pos+BigInt(e.byteLength))),this.file.data.set(t)}return this.file.data.set(e,Number(this.file_pos)),this.file_pos+=BigInt(e.byteLength),{ret:0,nwritten:e.byteLength}}fd_pwrite(e,t){if(this.file.readonly)return{ret:8,nwritten:0};if(t+BigInt(e.byteLength)>this.file.size){let n=this.file.data;this.file.data=new Uint8Array(Number(t+BigInt(e.byteLength))),this.file.data.set(n)}return this.file.data.set(e,Number(t)),{ret:0,nwritten:e.byteLength}}fd_filestat_get(){return{ret:0,filestat:this.file.stat()}}constructor(e){super(),this.file_pos=0n,this.file=e}},Lr=class extends Pr{fd_seek(e,t){return{ret:8,offset:0n}}fd_tell(){return{ret:8,offset:0n}}fd_allocate(e,t){return 8}fd_fdstat_get(){return{ret:0,fdstat:new wr(3,0)}}fd_readdir_single(e){if(q.enabled&&(q.log(`readdir_single`,e),q.log(e,this.dir.contents.keys())),e==0n)return{ret:0,dirent:new Cr(1n,this.dir.ino,`.`,3)};if(e==1n)return{ret:0,dirent:new Cr(2n,this.dir.parent_ino(),`..`,3)};if(e>=BigInt(this.dir.contents.size)+2n)return{ret:0,dirent:null};let[t,n]=Array.from(this.dir.contents.entries())[Number(e-2n)];return{ret:0,dirent:new Cr(e+1n,n.ino,t,n.stat().filetype)}}path_filestat_get(e,t){let{ret:n,path:r}=J.from(t);if(r==null)return{ret:n,filestat:null};let{ret:i,entry:a}=this.dir.get_entry_for_path(r);return a==null?{ret:i,filestat:null}:{ret:0,filestat:a.stat()}}path_lookup(e,t){let{ret:n,path:r}=J.from(e);if(r==null)return{ret:n,inode_obj:null};let{ret:i,entry:a}=this.dir.get_entry_for_path(r);return a==null?{ret:i,inode_obj:null}:{ret:0,inode_obj:a}}path_open(e,t,n,r,i,a){let{ret:o,path:s}=J.from(t);if(s==null)return{ret:o,fd_obj:null};let{ret:c,entry:l}=this.dir.get_entry_for_path(s);if(l==null){if(c!=44)return{ret:c,fd_obj:null};if((n&1)==1){let{ret:e,entry:r}=this.dir.create_entry_for_path(t,(n&2)==2);if(r==null)return{ret:e,fd_obj:null};l=r}else return{ret:44,fd_obj:null}}else if((n&4)==4)return{ret:20,fd_obj:null};return(n&2)==2&&l.stat().filetype!==3?{ret:54,fd_obj:null}:l.path_open(n,r,a)}path_create_directory(e){return this.path_open(0,e,3,0n,0n,0).ret}path_link(e,t,n){let{ret:r,path:i}=J.from(e);if(i==null)return r;if(i.is_dir)return 44;let{ret:a,parent_entry:o,filename:s,entry:c}=this.dir.get_parent_dir_and_entry_for_path(i,!0);if(o==null||s==null)return a;if(c!=null){let e=t.stat().filetype==3,r=c.stat().filetype==3;if(e&&r){if(n&&c instanceof Y){if(c.contents.size!=0)return 55}else return 20}else if(e&&!r)return 54;else if(!e&&r)return 31;else if(t.stat().filetype!=4||c.stat().filetype!=4)return 20}return!n&&t.stat().filetype==3?63:(o.contents.set(s,t),0)}path_unlink(e){let{ret:t,path:n}=J.from(e);if(n==null)return{ret:t,inode_obj:null};let{ret:r,parent_entry:i,filename:a,entry:o}=this.dir.get_parent_dir_and_entry_for_path(n,!0);return i==null||a==null?{ret:r,inode_obj:null}:o==null?{ret:44,inode_obj:null}:(i.contents.delete(a),{ret:0,inode_obj:o})}path_unlink_file(e){let{ret:t,path:n}=J.from(e);if(n==null)return t;let{ret:r,parent_entry:i,filename:a,entry:o}=this.dir.get_parent_dir_and_entry_for_path(n,!1);return i==null||a==null||o==null?r:o.stat().filetype===3?31:(i.contents.delete(a),0)}path_remove_directory(e){let{ret:t,path:n}=J.from(e);if(n==null)return t;let{ret:r,parent_entry:i,filename:a,entry:o}=this.dir.get_parent_dir_and_entry_for_path(n,!1);return i==null||a==null||o==null?r:!(o instanceof Y)||o.stat().filetype!==3?54:o.contents.size===0?i.contents.delete(a)?0:44:55}fd_filestat_get(){return{ret:0,filestat:this.dir.stat()}}fd_filestat_set_size(e){return 8}fd_read(e){return{ret:8,data:/* @__PURE__ */ new Uint8Array}}fd_pread(e,t){return{ret:8,data:/* @__PURE__ */ new Uint8Array}}fd_write(e){return{ret:8,nwritten:0}}fd_pwrite(e,t){return{ret:8,nwritten:0}}constructor(e){super(),this.dir=e}},Rr=class extends Lr{fd_prestat_get(){return{ret:0,prestat:kr.dir(this.prestat_name)}}constructor(e,t){super(new Y(t)),this.prestat_name=e}},zr=class extends Fr{path_open(e,t,n){if(this.readonly&&(t&BigInt(64))==BigInt(64))return{ret:63,fd_obj:null};if((e&8)==8){if(this.readonly)return{ret:63,fd_obj:null};this.data=new Uint8Array([])}let r=new Ir(this);return n&1&&r.fd_seek(0n,2),{ret:0,fd_obj:r}}get size(){return BigInt(this.data.byteLength)}stat(){return new Tr(this.ino,4,this.size)}constructor(e,t){super(),this.data=new Uint8Array(e),this.readonly=!!t?.readonly}};let J=class e{static from(t){let n=new e;if(n.is_dir=t.endsWith(`/`),t.startsWith(`/`))return{ret:76,path:null};if(t.includes(`\0`))return{ret:28,path:null};for(let e of t.split(`/`))if(e!==``&&e!==`.`){if(e===`..`){if(n.parts.pop()==null)return{ret:76,path:null};continue}n.parts.push(e)}return{ret:0,path:n}}to_path_string(){let e=this.parts.join(`/`);return this.is_dir&&(e+=`/`),e}constructor(){this.parts=[],this.is_dir=!1}};var Y=class e extends Fr{parent_ino(){return this.parent==null?Fr.root_ino():this.parent.ino}path_open(e,t,n){return{ret:0,fd_obj:new Lr(this)}}stat(){return new Tr(this.ino,3,0n)}get_entry_for_path(t){let n=this;for(let r of t.parts){if(!(n instanceof e))return{ret:54,entry:null};let t=n.contents.get(r);if(t!==void 0)n=t;else return q.log(r),{ret:44,entry:null}}return t.is_dir&&n.stat().filetype!=3?{ret:54,entry:null}:{ret:0,entry:n}}get_parent_dir_and_entry_for_path(t,n){let r=t.parts.pop();if(r===void 0)return{ret:28,parent_entry:null,filename:null,entry:null};let{ret:i,entry:a}=this.get_entry_for_path(t);if(a==null)return{ret:i,parent_entry:null,filename:null,entry:null};if(!(a instanceof e))return{ret:54,parent_entry:null,filename:null,entry:null};let o=a.contents.get(r);return o===void 0?n?{ret:0,parent_entry:a,filename:r,entry:null}:{ret:44,parent_entry:null,filename:null,entry:null}:t.is_dir&&o.stat().filetype!=3?{ret:54,parent_entry:null,filename:null,entry:null}:{ret:0,parent_entry:a,filename:r,entry:o}}create_entry_for_path(t,n){let{ret:r,path:i}=J.from(t);if(i==null)return{ret:r,entry:null};let{ret:a,parent_entry:o,filename:s,entry:c}=this.get_parent_dir_and_entry_for_path(i,!0);if(o==null||s==null)return{ret:a,entry:null};if(c!=null)return{ret:20,entry:null};q.log(`create`,i);let l;return l=n?new e(/* @__PURE__ */ new Map):new zr(/* @__PURE__ */ new ArrayBuffer(0)),o.contents.set(s,l),c=l,{ret:0,entry:c}}constructor(t){super(),this.parent=null,this.contents=t instanceof Array?new Map(t):t;for(let t of this.contents.values())t instanceof e&&(t.parent=this)}};function Br(e){let t=e.replace(/\\/g,`/`),n=t.startsWith(`/`)?t:`/${t}`,r=[];for(let t of n.split(`/`))if(t&&t!==`.`){if(t===`..`)throw Error(`wasm-clang does not allow guest path traversal: ${e}`);r.push(t)}return`/${r.join(`/`)}`}function Vr(e){return typeof e==`string`?new TextEncoder().encode(e):(e instanceof Uint8Array,new Uint8Array(e))}var Hr=class extends Pr{ino=Fr.issue_ino();decoder=new TextDecoder;chunks=[];output;constructor(e){super(),this.output=e}fd_filestat_get(){return{ret:0,filestat:new Tr(this.ino,2,0n)}}fd_fdstat_get(){let e=new wr(2,0);return e.fs_rights_base=BigInt(64),{ret:0,fdstat:e}}fd_write(e){let t=this.decoder.decode(e,{stream:!0});return this.chunks.push(t),this.output?.(t),{ret:0,nwritten:e.byteLength}}getText(){let e=this.decoder.decode();return e&&(this.chunks.push(e),this.output?.(e)),this.chunks.join(``)}},Ur=class{currentChunk=/* @__PURE__ */ new Uint8Array;currentOffset=0;readInput;constructor(e){this.readInput=e}read(e){for(;this.currentOffset>=this.currentChunk.length;){let e=this.readInput?.();if(e==null)return/* @__PURE__ */ new Uint8Array;this.currentChunk=Vr(e),this.currentOffset=0,this.currentChunk.byteLength}let t=this.currentChunk.slice(this.currentOffset,this.currentOffset+e);return this.currentOffset+=t.byteLength,t}},Wr=class extends Pr{ino=Fr.issue_ino();source;constructor(e){super(),this.source=e}fd_filestat_get(){return{ret:0,filestat:new Tr(this.ino,2,0n)}}fd_fdstat_get(){let e=new wr(2,0);return e.fs_rights_base=BigInt(2),{ret:0,fdstat:e}}fd_read(e){return{ret:0,data:this.source.read(e)}}};function Gr(e={}){let t=new Y(/* @__PURE__ */ new Map);for(let n of e.files||[]){let e=Br(n.path).slice(1).split(`/`),r=t;for(let t of e.slice(0,-1)){let e=r.contents.get(t);if(e instanceof Y){r=e;continue}let n=new Y(/* @__PURE__ */ new Map);r.contents.set(t,n),r=n}r.contents.set(e.at(-1),new zr(Vr(n.contents)))}let n=new Ur(e.stdin),r=new Hr(e.stdout),i=new Hr(e.stderr),a=/* @__PURE__ */ new Map([[`PWD`,`/`]]);for(let[t,n]of Object.entries(e.env||{}))a.set(t,n);return{args:[e.programName||`main.wasm`,...e.args||[]],envEntries:Array.from(a.entries()).map(([e,t])=>`${e}=${t}`),rootDirectory:t,stdout:r,stderr:i,fds:[new Wr(n),r,i,new Rr(`/tmp`,/* @__PURE__ */ new Map),new Rr(`/`,t.contents)]}}async function Kr(e,t={}){if(e.target!==`wasm32-wasi`||e.format!==`wasi-core-wasm`)throw Error(`wasm-clang currently executes only wasm32-wasi preview1 core wasm artifacts.`);let n=Gr({...t,programName:t.programName||e.fileName}),r=new Nr(n.args,n.envEntries,n.fds,{debug:!1}),i=(e.bytes instanceof Uint8Array,new Uint8Array(e.bytes)),a=e.wasm||await WebAssembly.compile(i),o={current:null},s=typeof t.extraImports==`function`?await t.extraImports({host:n,module:a,instance:o}):t.extraImports||{},c=await WebAssembly.instantiate(a,{...s,wasi_unstable:r.wasiImport,wasi_snapshot_preview1:r.wasiImport});return o.current=c,{exitCode:r.start(c),stdout:n.stdout.getText(),stderr:n.stderr.getText()}}const qr=[`libobjc.a`,`headers.json`,`libgnustep-base.a`,`libgnustep-base.o`,`foundation-headers.json`,`libffi.a`];let Jr=null,X=null;const Z=e=>Jr?.postMessage(e),Yr=e=>X?.configureRuntimeAssets(e),Xr=e=>X?.handleAssetMessage(e)??!1,Zr=(e,t)=>{if(!X)throw Error(`Objective-C worker dependencies are not installed.`);return X.waitForStdin(e,t)},Qr=new TextDecoder(`utf-8`,{fatal:!0}),$r=new TextEncoder,ei=4096,ti=1024,ni=/[\u0000-\u001f\u007f]/u,ri=[],ii=/^\s*#\s*(?:include|import)(?:_next)?\s+[<"]([^>"]+)[>"]/gm,ai=[`Foundation/`,`GNUstepBase/`,`CoreFoundation/`],oi=[`._OBJC_CLASS_NSObject`,`._OBJC_CLASS_NSConstantString`,`GSPrivateNotifyASAP`];let si=null,Q=null,$=null,ci=0,li=null,ui=``,di=!1,fi=null,pi=null,mi=null,hi=!1;const gi=/* @__PURE__ */ new Set;let _i=!1,vi=null,yi=!1;const bi=e=>e.replaceAll(`\\`,`/`).split(`/`).filter(e=>e&&e!==`.`&&e!==`..`).join(`/`),xi=e=>e.split(`/`).pop()||e,Si=e=>xi(e).replace(/\.[^.]+$/,``)||`main`,Ci=e=>e.endsWith(`
`)?e:`${e}\n`;function wi(e,t){let n=e?.trim();if(!n)throw Error(`${t} is required.`);let r;try{r=new URL(n,typeof location<`u`?location.href:void 0)}catch{throw Error(`${t} must be an absolute HTTP(S) URL.`)}if(r.protocol!==`http:`&&r.protocol!==`https:`)throw Error(`${t} must use HTTP(S).`);return r.toString()}function Ti(e){if(typeof X?.verifyRuntimeAssetIntegrity!=`function`)throw Error(`Objective-C runtime asset integrity verifier is not installed.`);let t=e.integrity,n=e.maxAssetBytes??134217728;if(!Number.isSafeInteger(n)||n<=0)throw Error(`Objective-C maxAssetBytes must be a positive safe integer.`);if(!t||typeof t!=`object`||Array.isArray(t))throw Error(`Objective-C runtime asset integrity receipt is required.`);let r=Object.keys(t).sort(),i=[...qr].sort();if(r.length!==i.length||r.some((e,t)=>e!==i[t]))throw Error(`Objective-C runtime asset integrity receipt is incomplete.`);let a=Object.freeze(Object.fromEntries(qr.map(e=>{let r=t[e];if(!r||typeof r!=`object`||!Number.isSafeInteger(r.bytes)||r.bytes<=0||typeof r.sha256!=`string`||!/^[a-f0-9]{64}$/u.test(r.sha256))throw Error(`Objective-C runtime asset integrity receipt is invalid for ${e}.`);if(r.bytes>n)throw Error(`Objective-C runtime asset ${e} exceeds the ${n} byte limit.`);return[e,Object.freeze({bytes:r.bytes,sha256:r.sha256})]})));return{libobjcUrl:wi(e.libobjcUrl,`Objective-C libobjc URL`),headersUrl:wi(e.headersUrl,`Objective-C headers URL`),libgnustepBaseUrl:wi(e.libgnustepBaseUrl,`Objective-C GNUstep Base URL`),libgnustepBaseObjectUrl:wi(e.libgnustepBaseObjectUrl,`Objective-C GNUstep Base object URL`),foundationHeadersUrl:wi(e.foundationHeadersUrl,`Objective-C Foundation headers URL`),libffiUrl:wi(e.libffiUrl,`Objective-C libffi URL`),integrity:a,maxAssetBytes:n}}const Ei=e=>{let t=bi(e||``);return t?/\.[A-Za-z0-9_-]+$/.test(t)?t:`${t}.m`:`main.m`};async function Di(e,t,n,r,i=r[n].bytes){let a=r[n],o=Math.min(i,a.bytes),s=new URL(e).href,c=new AbortController().signal,l;try{l=await z(s,void 0,o,c)}catch(e){let n=e instanceof Error?e.message:String(e),r=`Failed to load runtime asset ${s}: `;if(!n.startsWith(r))throw e;let i=new URL(s);i.pathname+=`.gz`;let a=i.href;try{l=await z(a,void 0,o,c)}catch(e){throw(e instanceof Error?e.message:String(e)).startsWith(`Failed to load runtime asset ${a}: `)?Error(`Failed to load ${t}: ${n.slice(r.length)}`,{cause:e}):e}}let u=X?.verifyRuntimeAssetIntegrity;if(!u)throw Error(`Objective-C runtime asset integrity verifier is not installed.`);return await u({asset:n,bytes:l,expected:{sha256:a.sha256,bytes:a.bytes,uncompressedSha256:a.sha256,uncompressedBytes:a.bytes},stage:`uncompressed`,runtimeId:`OBJC`,profileId:`wasm-llvm/objective-c-browser`}),l}async function Oi(e,t,n,r){let i=await Di(e,t,n,r,St),a;try{a=JSON.parse(Qr.decode(i))}catch(e){throw Error(`${t} metadata is not valid UTF-8 JSON.`,{cause:e})}if(typeof a!=`object`||!a||Array.isArray(a)||Object.getPrototypeOf(a)!==Object.prototype)throw Error(`${t} metadata must be a plain object.`);let o=Object.entries(a);if(o.length>ei)throw Error(`${t} metadata exceeds the ${ei} header entry limit.`);let s=Object.create(null),c=/* @__PURE__ */ new Set,l=/* @__PURE__ */ new Set;for(let[e,n]of o){if(typeof n!=`string`)throw Error(`${t} metadata contains a non-string header source.`);let r=e.split(`/`);if(!e||e.startsWith(`/`)||/^[A-Za-z]:\//u.test(e)||e.includes(`\\`)||ni.test(e)||r.some(e=>!e||e===`.`||e===`..`))throw Error(`${t} metadata contains an unsafe header path.`);if($r.encode(e).byteLength>ti)throw Error(`${t} metadata header path exceeds the ${ti} byte limit.`);if(l.has(e))throw Error(`${t} metadata contains a file/directory path collision.`);let i=``;for(let e of r.slice(0,-1)){if(i=i?`${i}/${e}`:e,c.has(i))throw Error(`${t} metadata contains a file/directory path collision.`);l.add(i)}c.add(e),s[e]=n}return s}function ki(e){let t=()=>{let t=e.current?.exports.memory;if(!(t instanceof WebAssembly.Memory))throw Error(`Objective-C libffi bridge missing exported memory`);return new DataView(t.buffer)},n=()=>{let t=e.current?.exports.__indirect_function_table;if(!(t instanceof WebAssembly.Table))throw Error(`Objective-C libffi bridge missing exported function table`);return t},r=()=>{let t=e.current?.exports.malloc;if(typeof t!=`function`)throw Error(`Objective-C libffi bridge missing exported malloc`);return t},i=()=>{let t=e.current?.exports.free;if(typeof t!=`function`)throw Error(`Objective-C libffi bridge missing exported free`);return t},a=()=>{let e=n(),t=ri.pop();if(t!=null)return t;let r=e.length;return e.grow(1),r},o=(e,t)=>e.getUint32(t,!0),s=(e,t)=>e.getUint16(t+6,!0),c=(e,t,n)=>{switch(n){case 1:case 9:return e.getUint32(t,!0);case 10:return e.getInt32(t,!0);case 2:return e.getFloat32(t,!0);case 3:return e.getFloat64(t,!0);case 5:return e.getUint8(t);case 6:return e.getInt8(t);case 7:return e.getUint16(t,!0);case 8:return e.getInt16(t,!0);case 11:return e.getBigUint64(t,!0);case 12:return e.getBigInt64(t,!0);case 14:return e.getUint32(t,!0);default:throw Error(`Objective-C libffi bridge cannot marshal argument type ${n}`)}},l=(e,t,n,r)=>{if(t&&n!==0)switch(n){case 1:case 9:e.setUint32(t,Number(r),!0);break;case 10:e.setInt32(t,Number(r),!0);break;case 2:e.setFloat32(t,Number(r),!0);break;case 3:e.setFloat64(t,Number(r),!0);break;case 5:e.setUint8(t,Number(r));break;case 6:e.setInt8(t,Number(r));break;case 7:e.setUint16(t,Number(r),!0);break;case 8:e.setInt16(t,Number(r),!0);break;case 11:e.setBigUint64(t,BigInt(r),!0);break;case 12:e.setBigInt64(t,BigInt(r),!0);break;case 14:e.setUint32(t,Number(r),!0);break;default:throw Error(`Objective-C libffi bridge cannot marshal return type ${n}`)}};return{env:{ffi_call_js:(e,r,i,a)=>{let u=t(),d=o(u,e+4),f=o(u,e+8),p=o(u,e+12),m=s(u,p),h=[];for(let e=0;e<d;e+=1){let t=o(u,a+e*4),n=o(u,f+e*4);h.push(c(u,t,s(u,n)))}let g=n().get(r);if(typeof g!=`function`)throw Error(`Objective-C libffi bridge missing function table entry ${r}`);l(u,i,m,g(...h))},ffi_closure_alloc_js:(e,n)=>{let i=t(),o=r()(e),s=a();return n&&i.setUint32(n,s,!0),i.setUint32(o,s,!0),o},ffi_closure_free_js:e=>{let n=t(),r=o(n,e);ri.push(r),i()(e)},ffi_prep_closure_loc_js:()=>2,GSLeftInsertionPointForKeyInSortedRange:(e,t,n=0)=>n,GSRightInsertionPointForKeyInSortedRange:(e,t,n=0)=>n,GSSortStable:()=>void 0,GSSortStableConcurrent:()=>void 0,GSSortUnstable:()=>void 0,GSSortUnstableConcurrent:()=>void 0}}}async function Ai(e,t,n){let r=bi(t).split(`/`).slice(0,-1),i=``;for(let t of r){i=i?`${i}/${t}`:t;try{e.memfs.addDirectory(i)}catch{}}e.memfs.addFile(t,n)}async function ji(e,t,n){let r=e=>{n&&console.log(`[wasm-idle:objectivec-worker] load: ${e}`)};r(`resolving asset configuration`);let i=Ti(t);Yr(e||null);let a=e?.baseUrl||``,o=await yr(br(a),fetch,void 0,i.maxAssetBytes);r(`compiler manifest loaded`),Q=new lr({stdout:e=>Z({output:e}),stdin:()=>``,progress:e=>Z({progress:e}),onDebugEvent:e=>Z({debugEvent:e}),log:n,maxAssetBytes:i.maxAssetBytes,runtimeBaseUrl:a,manifest:o}),r(`compiler host constructed`),$=i,di=!1,pi=null,mi=null,hi=!1,gi.clear();let[s,c]=await Promise.all([Di(i.libobjcUrl,`libobjc.a`,`libobjc.a`,i.integrity),Oi(i.headersUrl,`Objective-C headers`,`headers.json`,i.integrity)]);r(`Objective-C base assets loaded`),await Q.ready,r(`compiler host ready`),r(`installing Objective-C headers and runtime`),Z({progress:{percent:99,stage:`Installing Objective-C headers and runtime`}});for(let[e,t]of Object.entries(c))gi.add(e),await Ai(Q,e,t);Q.memfs.addFile(`libobjc.a`,s),r(`Objective-C headers and runtime installed`)}async function Mi(){if(!Q)throw Error(`Objective-C runtime is not loaded.`);if(!$)throw Error(`Objective-C runtime asset config is not loaded.`);if(di)return;let e=await Oi($.foundationHeadersUrl,`Objective-C Foundation headers`,`foundation-headers.json`,$.integrity);fi=e,e[`blocks_runtime.h`]!=null&&!gi.has(`blocks_runtime.h`)&&(gi.add(`blocks_runtime.h`),await Ai(Q,`blocks_runtime.h`,e[`blocks_runtime.h`])),di=!0}async function Ni(){if(!Q)throw Error(`Objective-C runtime is not loaded.`);if(!$)throw Error(`Objective-C runtime asset config is not loaded.`);if(!hi){if(!pi||!mi){let[e,t]=await Promise.all([Di($.libgnustepBaseUrl,`libgnustep-base.a`,`libgnustep-base.a`,$.integrity),Di($.libffiUrl,`libffi.a`,`libffi.a`,$.integrity)]);pi=e,mi=t}Q.memfs.addFile(`libffi.a`,mi),Q.memfs.addFile(`libgnustep-base.a`,pi),hi=!0}}function Pi(){return _i?yi?null:(yi=!0,vi??``):Zr(si,()=>Z({buffer:!0}))}function Fi(e){let t=e.toLowerCase();return t.endsWith(`.mm`)?`objective-c++`:t.endsWith(`.m`)?`objective-c`:t.endsWith(`.c`)?`c`:null}function Ii(e){return e===`objective-c`||e===`objective-c++`}function Li(e){return/#\s*(?:include|import)\s+[<"]Foundation\/|@import\s+Foundation\b/u.test(e)}function Ri(e,t,n){if(t.startsWith(`ObjectiveC2/`)){let r=t.slice(12);return n[r]==null?n[`objc/${r}`]==null?Ri(e,r,n):`objc/${r}`:r}if(n[t]!=null)return t;let r=e.includes(`/`)?e.split(`/`).slice(0,-1).join(`/`):``;if(r&&!t.includes(`/`)){let e=`${r}/${t}`;if(n[e]!=null)return e}for(let e of[`Foundation`,`CoreFoundation`,`GNUstepBase`]){let r=`${e}/${t}`;if(n[r]!=null)return r}return null}function zi(e,t){let n=t[e];return n==null?``:e===`Foundation/NSObjCRuntime.h`?`#include <stdint.h>
@class NSString;
#ifndef GSNativeChar
typedef char GSNativeChar;
#endif
${n.replace(/^\s*#\s*import\s*<GNUstepBase\/GSBlocks\.h>\s*$/m,`
#ifndef BLOCK_SCOPE
#define BLOCK_SCOPE __block
#endif
#ifndef DEFINE_BLOCK_TYPE
#define DEFINE_BLOCK_TYPE(name, retTy, argTys, ...) typedef retTy(^name)(argTys, ## __VA_ARGS__)
#endif
#ifndef DEFINE_BLOCK_TYPE_NO_ARGS
#define DEFINE_BLOCK_TYPE_NO_ARGS(name, retTy) typedef retTy(^name)()
#endif
#ifndef CALL_NON_NULL_BLOCK
#define CALL_NON_NULL_BLOCK(block, args, ...) block(args, ## __VA_ARGS__)
#endif
#ifndef CALL_NON_NULL_BLOCK_NO_ARGS
#define CALL_NON_NULL_BLOCK_NO_ARGS(block) block()
#endif
`).replace(/^\s*#\s*import\s*<GNUstepBase\/GSObjCRuntime\.h>\s*$/m,``)}`:n}function Bi(e,t,n=/* @__PURE__ */ new Set){if(n.has(e))return``;n.add(e);let r=zi(e,t);if(!r)return``;let i=``,a=0;ii.lastIndex=0;for(let o of r.matchAll(ii)){let s=o[1],c=Ri(e,s,t),l=c!=null&&ai.some(e=>c.startsWith(e));i+=r.slice(a,o.index),i+=c&&l&&c!==`GNUstepBase/GSBlocks.h`&&c!==`GNUstepBase/GSObjCRuntime.h`?`\n${Bi(c,t,n)}\n`:s===`ObjectiveC2/blocks_runtime.h`?o[0].replace(s,`blocks_runtime.h`):s===`ObjectiveC2/objc/runtime.h`?o[0].replace(s,`objc/runtime.h`):o[0],a=o.index+o[0].length}return i+r.slice(a)}function Vi(e,t){if(!fi)return t;let n=/* @__PURE__ */ new Set,r=``,i=0;ii.lastIndex=0;for(let a of t.matchAll(ii)){if(!ai.some(e=>a[1].startsWith(e))&&a[1]!==`Foundation.h`)continue;let o=Ri(e,a[1],fi);o&&(r+=t.slice(i,a.index),r+=`\n${Bi(o,fi,n)}\n`,i=a.index+a[0].length)}return r+t.slice(i)}async function Hi(e,t,n,r,i=[],a=!1,o){if(!Q)throw Error(`Objective-C runtime is not loaded.`);if(a){if(r===`objective-c++`)throw Error(`Objective-C++ trace debugging is not supported.`);if(t==null)throw Error(`Objective-C debug compilation requires the active source text.`);await Q.compile({input:e,code:t,obj:n,language:r===`objective-c`?`OBJC`:`C`,compileArgs:i,debug:!0,transformSource:o});return}t!=null&&await Ai(Q,e,t),Q.memfs.addFile(n,/* @__PURE__ */ new Uint8Array);let s=await Q.getModule(Q.assetUrls.clang),c=Q,l=c.stdout,u=[],d=Q.compilerConfig?.resourceDir||`/lib/clang/8.0.1`,f=[`-cc1`,`-triple`,ae,`-emit-obj`,`-disable-free`,`-isysroot`,`/`,`-resource-dir`,d,...de(r===`objective-c++`?`OBJCXX`:`OBJC`,``,d).flatMap(e=>[`-internal-isystem`,e]),`-I.`,`-ferror-limit`,`20`,`-O2`,`-o`,n,ue(r===`objective-c++`?`CPP`:`C`,{}).standardArg,`-x`,r,...Ii(r)?oe:[],e,...i];try{c.stdout=e=>u.push(e),await Q.run(s,!0,`clang`,...f)}catch(e){if(Uint8Array.from(Q.memfs.getFileContents(n)).length>0)return;for(let e of u)Z({output:e});throw e}finally{c.stdout=l}}async function Ui(e,t,n,r=[],i=!1){if(!Q)throw Error(`Objective-C runtime is not loaded.`);let a=e=>console.log(`[wasm-idle:objectivec-worker] ${e}`),o=Ei(t),s=`__wasm_idle_objc_${++ci}`,c=[],l=/* @__PURE__ */ new Set;for(let e of n){let t=bi(e.path);if(!t||t===o||l.has(t))continue;l.add(t);let n=`${s}/${t}`;await Ai(Q,n,e.content);let r=Fi(t);r&&c.push({path:t,prefixedPath:n,language:r})}let u=Si(o),d=`${s}/${o}`,f=`${s}/${u}.o`,p=`${s}/objc_ctor.c`,m=`${s}/objc_ctor.o`,h=`${s}/${u}.wasm`,g=[],_=Fi(o)||`objective-c`,v=Li(e)||n.some(e=>Li(e.content)),y=!v&&Ii(_)&&(/@\s*(?:interface|implementation|protocol)\b/u.test(e)||n.some(e=>{let t=Fi(e.path);return t!==null&&Ii(t)&&/@\s*(?:interface|implementation|protocol)\b/u.test(e.content)})),b=v?[`-Wno-macro-redefined`,`-Wno-nullability-completeness`]:[],x=e;v&&(await Mi(),i||(x=Vi(o,e))),y&&(a(`compiling Objective-C load constructor`),await Hi(p,`extern void __wasm_idle_objc_load(void) __asm__(".objcv2_load_function") __attribute__((weak));

__attribute__((constructor))
static void __wasm_idle_objc_ctor(void)
{
    if (__wasm_idle_objc_load) __wasm_idle_objc_load();
}
`,m,`c`)),a(`compiling ${o}`),await Hi(d,Ci(x),f,_,[`-I`,s,...b,...r],i,i&&v?e=>Vi(o,e):void 0);for(let e of c){let t=`${s}/${e.path.replace(/[^A-Za-z0-9_.-]/g,`_`).replace(/\.[^.]+$/,``)}.o`;a(`compiling ${e.path}`),await Hi(e.prefixedPath,null,t,e.language,[`-I`,s,...b,...r]),g.push(t)}let S=`lib/wasm32-wasi`,C=Q.compilerConfig?.compilerRuntimeLibDir||`lib/clang/8.0.1/lib/wasi`,w=await Q.prepareLongDoubleLinkArgs(),T=await Q.getModule(Q.assetUrls.lld);v&&await Ni(),await Q.run(T,Q.log,`wasm-ld`,...v?[`--export=malloc`,`--export=free`]:[`--export-dynamic`],`--gc-sections`,...v||i?[`--allow-undefined`]:[],...v?[`--export-table`]:[],`-z`,`stack-size=1048576`,`-L${S}/noeh`,`-L${S}`,`${S}/crt1.o`,...y?[m]:[],f,...g,...v?oi.flatMap(e=>[`-u`,e]):[],...v?[`libgnustep-base.a`]:[],`libobjc.a`,...v?[`libffi.a`]:[],`-lwasi-emulated-mman`,...w,`-lc`,`-lc++`,`-lc++abi`,`-lm`,`-L${C}`,`-lclang_rt.builtins-wasm32`,`-o`,h);let E=Uint8Array.from(Q.memfs.getFileContents(h));return{bytes:E,wasm:await WebAssembly.compile(E),target:`wasm32-wasi`,format:`wasi-core-wasm`,fileName:h,language:`C`,debugMetadata:i?{variableMetadata:Q.debugVariableMetadata,globalVariableMetadata:Q.debugGlobalMetadata,functionMetadata:Q.debugFunctionMetadata}:void 0,needsLibffi:v}}function Wi(e,t,n,r,i){return JSON.stringify({code:e,activePath:t||``,workspaceFiles:n,compileArgs:r,debug:i})}const Gi=async e=>{if(Xr(e.data))return;let{code:t,buffer:n,load:r,log:i,prepare:a,compileArgs:o,programArgs:s,activePath:c,workspaceFiles:l,stdin:u,debug:d,breakpoints:f,pauseOnEntry:p,debugBuffer:m,watchBuffer:h,watchResultBuffer:g,interrupt:_,clangAssets:v,objectivecAssets:y}=e.data;if(r)try{await ji(v,y,i),Z({load:!0})}catch(e){Z({error:e.message})}else if(typeof i==`boolean`&&!t)Q&&(Q.log=i),typeof t==`string`&&Z({results:!0});else if(t){if(!Q){Z({error:`Objective-C runtime is not loaded.`});return}Q.log=i,si=new Int32Array(n),_i=typeof u==`string`,vi=_i?u:null,yi=!1;try{let e=l||[],n=o||[],r=!!d;Q.beginTrace(r),Q.debugBreakpoints=new Set(r&&f||[]),Q.debugPauseOnEntry=r&&!!p,Q.debugBuffer=m?new Int32Array(m):void 0,Q.debugWatchBuffer=h?new Int32Array(h):void 0,Q.debugWatchResultBuffer=g?new Int32Array(g):void 0,Q.debugInterruptBuffer=_?new Uint8Array(_):void 0;let i=Wi(t,c,e,n,r),u;if(a){u=await Ui(t,c,e,n,r),li=u,ui=i,Z({results:!0});return}if(li&&ui===i?u=li:(u=await Ui(t,c,e,n,r),li=u,ui=i),!a&&r){Q.memfs.stdin=()=>Pi()??``;let e={current:null};await Q.runWithOptions(u.wasm,!0,[u.fileName||`main.wasm`,...s||[]],{},u.needsLibffi?ki(e):void 0,e)}else if(!a){let e=await Kr(u,{args:s||[],stdin:Pi,stdout:e=>Z({output:e}),stderr:e=>Z({output:e}),extraImports:u.needsLibffi?({instance:e})=>ki(e):void 0});if(e.exitCode)throw Error(`Objective-C program exited with ${e.exitCode}`)}Z({results:!0})}catch(e){Z({error:e.message||e.stack})}}};function Ki(e,t){Jr=e,X=t,e.document={querySelectorAll(){return[]}},e.onmessage=Gi}Ki(self,{configureRuntimeAssets:re,handleAssetMessage:ie,waitForStdin:s,verifyRuntimeAssetIntegrity:me});