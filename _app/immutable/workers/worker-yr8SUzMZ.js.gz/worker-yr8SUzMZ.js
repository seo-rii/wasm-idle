var e=Object.create,t=Object.defineProperty,n=Object.getOwnPropertyDescriptor,r=Object.getOwnPropertyNames,i=Object.getPrototypeOf,a=Object.prototype.hasOwnProperty,o=(e,t)=>function(){try{return t||(0,e[r(e)[0]])((t={exports:{}}).exports,t),t.exports}catch(e){throw t=0,e}},s=(e,i,o,s)=>{if(i&&typeof i==`object`||typeof i==`function`)for(let c of r(i))!a.call(e,c)&&c!==o&&t(e,c,{get:()=>i[c],enumerable:!(s=n(i,c))||s.enumerable});return e},c=(n,r,a)=>(a=n==null?{}:e(i(n)),s(r||!n||!n.__esModule?t(a,`default`,{value:n,enumerable:!0}):a,n)),l=o({"../../node_modules/.pnpm/vscode-jsonrpc@10.0.0/node_modules/vscode-jsonrpc/lib/common/is.js"(e){Object.defineProperty(e,"__esModule",{value:!0}),e.boolean=t,e.string=n,e.number=r,e.error=i,e.func=a,e.array=o,e.stringArray=s;function t(e){return e===!0||e===!1}function n(e){return typeof e==`string`||e instanceof String}function r(e){return typeof e==`number`||e instanceof Number}function i(e){return e instanceof Error}function a(e){return typeof e==`function`}function o(e){return Array.isArray(e)}function s(e){return o(e)&&e.every(e=>n(e))}}}),u=o({"../../node_modules/.pnpm/vscode-jsonrpc@10.0.0/node_modules/vscode-jsonrpc/lib/common/messages.js"(e){var t=e&&e.__createBinding||(Object.create?(function(e,t,n,r){r===void 0&&(r=n);var i=Object.getOwnPropertyDescriptor(t,n);(!i||(`get`in i?!t.__esModule:i.writable||i.configurable))&&(i={enumerable:!0,get:function(){return t[n]}}),Object.defineProperty(e,r,i)}):(function(e,t,n,r){r===void 0&&(r=n),e[r]=t[n]})),n=e&&e.__setModuleDefault||(Object.create?(function(e,t){Object.defineProperty(e,"default",{enumerable:!0,value:t})}):function(e,t){e.default=t}),r=e&&e.__importStar||(function(){var e=function(t){return e=Object.getOwnPropertyNames||function(e){var t=[];for(var n in e)Object.prototype.hasOwnProperty.call(e,n)&&(t[t.length]=n);return t},e(t)};return function(r){if(r&&r.__esModule)return r;var i={};if(r!=null)for(var a=e(r),o=0;o<a.length;o++)a[o]!=="default"&&t(i,r,a[o]);return n(i,r),i}})();Object.defineProperty(e,"__esModule",{value:!0}),e.Message=e.NotificationType9=e.NotificationType8=e.NotificationType7=e.NotificationType6=e.NotificationType5=e.NotificationType4=e.NotificationType3=e.NotificationType2=e.NotificationType1=e.NotificationType0=e.NotificationType=e.RequestType9=e.RequestType8=e.RequestType7=e.RequestType6=e.RequestType5=e.RequestType4=e.RequestType3=e.RequestType2=e.RequestType1=e.RequestType=e.RequestType0=e.AbstractMessageSignature=e.ParameterStructures=e.ResponseError=e.ErrorCodes=void 0;var i=r(l()),a;(function(e){e.ParseError=-32700,e.InvalidRequest=-32600,e.MethodNotFound=-32601,e.InvalidParams=-32602,e.InternalError=-32603,e.jsonrpcReservedErrorRangeStart=-32099,e.serverErrorStart=-32099,e.MessageWriteError=-32099,e.MessageReadError=-32098,e.PendingResponseRejected=-32097,e.ConnectionInactive=-32096,e.ServerNotInitialized=-32002,e.UnknownErrorCode=-32001,e.jsonrpcReservedErrorRangeEnd=-32e3,e.serverErrorEnd=-32e3})(a||(e.ErrorCodes=a={})),e.ResponseError=class e extends Error{code;data;constructor(t,n,r){super(n),this.code=i.number(t)?t:a.UnknownErrorCode,this.data=r,Object.setPrototypeOf(this,e.prototype)}toJson(){let e={code:this.code,message:this.message};return this.data!==void 0&&(e.data=this.data),e}};var o=class e{kind;static auto=new e(`auto`);static byPosition=new e(`byPosition`);static byName=new e(`byName`);constructor(e){this.kind=e}static is(t){return t===e.auto||t===e.byName||t===e.byPosition}toString(){return this.kind}};e.ParameterStructures=o;var s=class{method;numberOfParams;constructor(e,t){this.method=e,this.numberOfParams=t}get parameterStructures(){return o.auto}};e.AbstractMessageSignature=s,e.RequestType0=class extends s{_;constructor(e){super(e,0)}},e.RequestType=class extends s{_parameterStructures;_;constructor(e,t=o.auto){super(e,1),this._parameterStructures=t}get parameterStructures(){return this._parameterStructures}},e.RequestType1=class extends s{_parameterStructures;_;constructor(e,t=o.auto){super(e,1),this._parameterStructures=t}get parameterStructures(){return this._parameterStructures}},e.RequestType2=class extends s{_;constructor(e){super(e,2)}},e.RequestType3=class extends s{_;constructor(e){super(e,3)}},e.RequestType4=class extends s{_;constructor(e){super(e,4)}},e.RequestType5=class extends s{_;constructor(e){super(e,5)}},e.RequestType6=class extends s{_;constructor(e){super(e,6)}},e.RequestType7=class extends s{_;constructor(e){super(e,7)}},e.RequestType8=class extends s{_;constructor(e){super(e,8)}},e.RequestType9=class extends s{_;constructor(e){super(e,9)}},e.NotificationType=class extends s{_parameterStructures;_;constructor(e,t=o.auto){super(e,1),this._parameterStructures=t}get parameterStructures(){return this._parameterStructures}},e.NotificationType0=class extends s{_;constructor(e){super(e,0)}},e.NotificationType1=class extends s{_parameterStructures;_;constructor(e,t=o.auto){super(e,1),this._parameterStructures=t}get parameterStructures(){return this._parameterStructures}},e.NotificationType2=class extends s{_;constructor(e){super(e,2)}},e.NotificationType3=class extends s{_;constructor(e){super(e,3)}},e.NotificationType4=class extends s{_;constructor(e){super(e,4)}},e.NotificationType5=class extends s{_;constructor(e){super(e,5)}},e.NotificationType6=class extends s{_;constructor(e){super(e,6)}},e.NotificationType7=class extends s{_;constructor(e){super(e,7)}},e.NotificationType8=class extends s{_;constructor(e){super(e,8)}},e.NotificationType9=class extends s{_;constructor(e){super(e,9)}};var c;(function(e){function t(e){let t=e;return t&&i.string(t.method)&&(i.string(t.id)||i.number(t.id))}e.isRequest=t;function n(e){let t=e;return t&&i.string(t.method)&&e.id===void 0}e.isNotification=n;function r(e){let t=e;return t&&(t.result!==void 0||!!t.error)&&(i.string(t.id)||i.number(t.id)||t.id===null)}e.isResponse=r})(c||(e.Message=c={}))}}),d=o({"../../node_modules/.pnpm/vscode-jsonrpc@10.0.0/node_modules/vscode-jsonrpc/lib/common/linkedMap.js"(e){Object.defineProperty(e,"__esModule",{value:!0}),e.LRUCache=e.LinkedMap=e.Touch=void 0;var t;(function(e){e.None=0,e.First=1,e.AsOld=e.First,e.Last=2,e.AsNew=e.Last})(t||(e.Touch=t={}));var n=class{[Symbol.toStringTag]=`LinkedMap`;_map;_head;_tail;_size;_state;constructor(){this._map=/* @__PURE__ */ new Map,this._head=void 0,this._tail=void 0,this._size=0,this._state=0}clear(){this._map.clear(),this._head=void 0,this._tail=void 0,this._size=0,this._state++}isEmpty(){return!this._head&&!this._tail}get size(){return this._size}get first(){return this._head?.value}get last(){return this._tail?.value}before(e){let t=this._map.get(e);return t?t.previous?.value:void 0}after(e){let t=this._map.get(e);return t?t.next?.value:void 0}has(e){return this._map.has(e)}get(e,n=t.None){let r=this._map.get(e);if(r)return n!==t.None&&this.touch(r,n),r.value}set(e,n,r=t.None){let i=this._map.get(e);if(i)i.value=n,r!==t.None&&this.touch(i,r);else{switch(i={key:e,value:n,next:void 0,previous:void 0},r){case t.None:this.addItemLast(i);break;case t.First:this.addItemFirst(i);break;case t.Last:this.addItemLast(i);break;default:this.addItemLast(i)}this._map.set(e,i),this._size++}return this}delete(e){return!!this.remove(e)}remove(e){let t=this._map.get(e);if(t)return this._map.delete(e),this.removeItem(t),this._size--,t.value}shift(){if(!this._head&&!this._tail)return;if(!this._head||!this._tail)throw Error(`Invalid list`);let e=this._head;return this._map.delete(e.key),this.removeItem(e),this._size--,e.value}forEach(e,t){let n=this._state,r=this._head;for(;r;){if(t?e.bind(t)(r.value,r.key,this):e(r.value,r.key,this),this._state!==n)throw Error(`LinkedMap got modified during iteration.`);r=r.next}}keys(){let e=this._state,t=this._head,n={[Symbol.iterator]:()=>n,next:()=>{if(this._state!==e)throw Error(`LinkedMap got modified during iteration.`);if(t){let e={value:t.key,done:!1};return t=t.next,e}return{value:void 0,done:!0}}};return n}values(){let e=this._state,t=this._head,n={[Symbol.iterator]:()=>n,next:()=>{if(this._state!==e)throw Error(`LinkedMap got modified during iteration.`);if(t){let e={value:t.value,done:!1};return t=t.next,e}return{value:void 0,done:!0}}};return n}entries(){let e=this._state,t=this._head,n={[Symbol.iterator]:()=>n,next:()=>{if(this._state!==e)throw Error(`LinkedMap got modified during iteration.`);if(t){let e={value:[t.key,t.value],done:!1};return t=t.next,e}return{value:void 0,done:!0}}};return n}[Symbol.iterator](){return this.entries()}trimOld(e){if(e>=this.size)return;if(e===0){this.clear();return}let t=this._head,n=this.size;for(;t&&n>e;)this._map.delete(t.key),t=t.next,n--;this._head=t,this._size=n,t&&(t.previous=void 0),this._state++}addItemFirst(e){if(!this._head&&!this._tail)this._tail=e;else if(this._head)e.next=this._head,this._head.previous=e;else throw Error(`Invalid list`);this._head=e,this._state++}addItemLast(e){if(!this._head&&!this._tail)this._head=e;else if(this._tail)e.previous=this._tail,this._tail.next=e;else throw Error(`Invalid list`);this._tail=e,this._state++}removeItem(e){if(e===this._head&&e===this._tail)this._head=void 0,this._tail=void 0;else if(e===this._head){if(!e.next)throw Error(`Invalid list`);e.next.previous=void 0,this._head=e.next}else if(e===this._tail){if(!e.previous)throw Error(`Invalid list`);e.previous.next=void 0,this._tail=e.previous}else{let t=e.next,n=e.previous;if(!t||!n)throw Error(`Invalid list`);t.previous=n,n.next=t}e.next=void 0,e.previous=void 0,this._state++}touch(e,n){if(!this._head||!this._tail)throw Error(`Invalid list`);if(n===t.First||n===t.Last){if(n===t.First){if(e===this._head)return;let t=e.next,n=e.previous;e===this._tail?(n.next=void 0,this._tail=n):(t.previous=n,n.next=t),e.previous=void 0,e.next=this._head,this._head.previous=e,this._head=e,this._state++}else if(n===t.Last){if(e===this._tail)return;let t=e.next,n=e.previous;e===this._head?(t.previous=void 0,this._head=t):(t.previous=n,n.next=t),e.next=void 0,e.previous=this._tail,this._tail.next=e,this._tail=e,this._state++}}}toJSON(){let e=[];return this.forEach((t,n)=>{e.push([n,t])}),e}fromJSON(e){this.clear();for(let[t,n]of e)this.set(t,n)}};e.LinkedMap=n,e.LRUCache=class extends n{_limit;_ratio;constructor(e,t=1){super(),this._limit=e,this._ratio=Math.min(Math.max(0,t),1)}get limit(){return this._limit}set limit(e){this._limit=e,this.checkTrim()}get ratio(){return this._ratio}set ratio(e){this._ratio=Math.min(Math.max(0,e),1),this.checkTrim()}get(e,n=t.AsNew){return super.get(e,n)}peek(e){return super.get(e,t.None)}set(e,n){return super.set(e,n,t.Last),this.checkTrim(),this}checkTrim(){this.size>this._limit&&this.trimOld(Math.round(this._limit*this._ratio))}}}}),f=o({"../../node_modules/.pnpm/vscode-jsonrpc@10.0.0/node_modules/vscode-jsonrpc/lib/common/disposable.js"(e){Object.defineProperty(e,"__esModule",{value:!0}),e.Disposable=void 0;var t;(function(e){function t(e){return{dispose:e}}e.create=t})(t||(e.Disposable=t={}))}}),p=o({"../../node_modules/.pnpm/vscode-jsonrpc@10.0.0/node_modules/vscode-jsonrpc/lib/common/ral.js"(e){Object.defineProperty(e,"__esModule",{value:!0});var t;function n(){if(t===void 0)throw Error(`No runtime abstraction layer installed`);return t}(function(e){function n(e){if(e===void 0)throw Error(`No runtime abstraction layer provided`);t=e}e.install=n})(n||={}),e.default=n}}),m=o({"../../node_modules/.pnpm/vscode-jsonrpc@10.0.0/node_modules/vscode-jsonrpc/lib/common/events.js"(e){var t=e&&e.__importDefault||function(e){return e&&e.__esModule?e:{default:e}};Object.defineProperty(e,"__esModule",{value:!0}),e.Emitter=e.Event=void 0;var n=t(p()),r;(function(e){let t={dispose(){}};e.None=function(){return t}})(r||(e.Event=r={}));var i=class{_callbacks;_contexts;add(e,t=null,n){this._callbacks||(this._callbacks=[],this._contexts=[]),this._callbacks.push(e),this._contexts.push(t),Array.isArray(n)&&n.push({dispose:()=>this.remove(e,t)})}remove(e,t=null){if(!this._callbacks)return;let n=!1;for(let r=0,i=this._callbacks.length;r<i;r++)if(this._callbacks[r]===e){if(this._contexts[r]===t){this._callbacks.splice(r,1),this._contexts.splice(r,1);return}n=!0}if(n)throw Error(`When adding a listener with a context, you should remove it with the same context`)}invoke(...e){if(!this._callbacks)return[];let t=[],r=this._callbacks.slice(0),i=this._contexts.slice(0);for(let a=0,o=r.length;a<o;a++)try{t.push(r[a].apply(i[a],e))}catch(e){(0,n.default)().console.error(e)}return t}isEmpty(){return!this._callbacks||this._callbacks.length===0}dispose(){this._callbacks=void 0,this._contexts=void 0}};e.Emitter=class e{_options;static _noop=function(){};_event;_callbacks;constructor(e){this._options=e}get event(){return this._event||=(t,n,r)=>{this._callbacks||=new i,this._options&&this._options.onFirstListenerAdd&&this._callbacks.isEmpty()&&this._options.onFirstListenerAdd(this),this._callbacks.add(t,n);let a={dispose:()=>{this._callbacks&&(this._callbacks.remove(t,n),a.dispose=e._noop,this._options&&this._options.onLastListenerRemove&&this._callbacks.isEmpty()&&this._options.onLastListenerRemove(this))}};return Array.isArray(r)&&r.push(a),a},this._event}fire(e){this._callbacks&&this._callbacks.invoke.call(this._callbacks,e)}dispose(){this._callbacks&&=(this._callbacks.dispose(),void 0)}}}}),h=o({"../../node_modules/.pnpm/vscode-jsonrpc@10.0.0/node_modules/vscode-jsonrpc/lib/common/cancellation.js"(e){var t=e&&e.__createBinding||(Object.create?(function(e,t,n,r){r===void 0&&(r=n);var i=Object.getOwnPropertyDescriptor(t,n);(!i||(`get`in i?!t.__esModule:i.writable||i.configurable))&&(i={enumerable:!0,get:function(){return t[n]}}),Object.defineProperty(e,r,i)}):(function(e,t,n,r){r===void 0&&(r=n),e[r]=t[n]})),n=e&&e.__setModuleDefault||(Object.create?(function(e,t){Object.defineProperty(e,"default",{enumerable:!0,value:t})}):function(e,t){e.default=t}),r=e&&e.__importStar||(function(){var e=function(t){return e=Object.getOwnPropertyNames||function(e){var t=[];for(var n in e)Object.prototype.hasOwnProperty.call(e,n)&&(t[t.length]=n);return t},e(t)};return function(r){if(r&&r.__esModule)return r;var i={};if(r!=null)for(var a=e(r),o=0;o<a.length;o++)a[o]!=="default"&&t(i,r,a[o]);return n(i,r),i}})(),i=e&&e.__importDefault||function(e){return e&&e.__esModule?e:{default:e}};Object.defineProperty(e,"__esModule",{value:!0}),e.CancellationTokenSource=e.CancellationToken=void 0;var a=i(p()),o=r(l()),s=m(),c;(function(e){e.None=Object.freeze({isCancellationRequested:!1,onCancellationRequested:s.Event.None}),e.Cancelled=Object.freeze({isCancellationRequested:!0,onCancellationRequested:s.Event.None});function t(t){let n=t;return n&&(n===e.None||n===e.Cancelled||o.boolean(n.isCancellationRequested)&&!!n.onCancellationRequested)}e.is=t})(c||(e.CancellationToken=c={}));var u=Object.freeze(function(e,t){let n=(0,a.default)().timer.setTimeout(e.bind(t),0);return{dispose(){n.dispose()}}}),d=class{_isCancelled=!1;_emitter;cancel(){this._isCancelled||(this._isCancelled=!0,this._emitter&&(this._emitter.fire(void 0),this.dispose()))}get isCancellationRequested(){return this._isCancelled}get onCancellationRequested(){return this._isCancelled?u:(this._emitter||=new s.Emitter,this._emitter.event)}dispose(){this._emitter&&=(this._emitter.dispose(),void 0)}};e.CancellationTokenSource=class{_token;get token(){return this._token||=new d,this._token}cancel(){this._token?this._token.cancel():this._token=c.Cancelled}dispose(){this._token?this._token instanceof d&&this._token.dispose():this._token=c.None}}}}),g=o({"../../node_modules/.pnpm/vscode-jsonrpc@10.0.0/node_modules/vscode-jsonrpc/lib/common/sharedArrayCancellation.js"(e){Object.defineProperty(e,"__esModule",{value:!0}),e.SharedArrayReceiverStrategy=e.SharedArraySenderStrategy=void 0;var t=h(),n;(function(e){e.Continue=0,e.Cancelled=1})(n||={}),e.SharedArraySenderStrategy=class{buffers;constructor(){this.buffers=/* @__PURE__ */ new Map}enableCancellation(e){if(e.id===null)return;let t=new SharedArrayBuffer(4),r=new Int32Array(t,0,1);r[0]=n.Continue,this.buffers.set(e.id,t),e.$cancellationData=t}async sendCancellation(e,t){let r=this.buffers.get(t);if(r===void 0)return;let i=new Int32Array(r,0,1);Atomics.store(i,0,n.Cancelled)}cleanup(e){this.buffers.delete(e)}dispose(){this.buffers.clear()}};var r=class{data;constructor(e){this.data=new Int32Array(e,0,1)}get isCancellationRequested(){return Atomics.load(this.data,0)===n.Cancelled}get onCancellationRequested(){throw Error(`Cancellation over SharedArrayBuffer doesn't support cancellation events`)}},i=class{token;constructor(e){this.token=new r(e)}cancel(){}dispose(){}};e.SharedArrayReceiverStrategy=class{kind=`request`;createCancellationTokenSource(e){let n=e.$cancellationData;return n===void 0?new t.CancellationTokenSource:new i(n)}}}}),_=o({"../../node_modules/.pnpm/vscode-jsonrpc@10.0.0/node_modules/vscode-jsonrpc/lib/common/semaphore.js"(e){var t=e&&e.__importDefault||function(e){return e&&e.__esModule?e:{default:e}};Object.defineProperty(e,"__esModule",{value:!0}),e.Semaphore=void 0;var n=t(p());e.Semaphore=class{_capacity;_active;_waiting;constructor(e=1){if(e<=0)throw Error(`Capacity must be greater than 0`);this._capacity=e,this._active=0,this._waiting=[]}lock(e){return new Promise((t,n)=>{this._waiting.push({thunk:e,resolve:t,reject:n}),this.runNext()})}get active(){return this._active}runNext(){this._waiting.length!==0&&this._active!==this._capacity&&(0,n.default)().timer.setImmediate(()=>this.doRunNext())}doRunNext(){if(this._waiting.length===0||this._active===this._capacity)return;let e=this._waiting.shift();if(this._active++,this._active>this._capacity)throw Error(`Too many thunks active`);try{let t=e.thunk();t instanceof Promise?t.then(t=>{this._active--,e.resolve(t),this.runNext()},t=>{this._active--,e.reject(t),this.runNext()}):(this._active--,e.resolve(t),this.runNext())}catch(t){this._active--,e.reject(t),this.runNext()}}}}}),ee=o({"../../node_modules/.pnpm/vscode-jsonrpc@10.0.0/node_modules/vscode-jsonrpc/lib/common/messageReader.js"(e){var t=e&&e.__createBinding||(Object.create?(function(e,t,n,r){r===void 0&&(r=n);var i=Object.getOwnPropertyDescriptor(t,n);(!i||(`get`in i?!t.__esModule:i.writable||i.configurable))&&(i={enumerable:!0,get:function(){return t[n]}}),Object.defineProperty(e,r,i)}):(function(e,t,n,r){r===void 0&&(r=n),e[r]=t[n]})),n=e&&e.__setModuleDefault||(Object.create?(function(e,t){Object.defineProperty(e,"default",{enumerable:!0,value:t})}):function(e,t){e.default=t}),r=e&&e.__importStar||(function(){var e=function(t){return e=Object.getOwnPropertyNames||function(e){var t=[];for(var n in e)Object.prototype.hasOwnProperty.call(e,n)&&(t[t.length]=n);return t},e(t)};return function(r){if(r&&r.__esModule)return r;var i={};if(r!=null)for(var a=e(r),o=0;o<a.length;o++)a[o]!=="default"&&t(i,r,a[o]);return n(i,r),i}})(),i=e&&e.__importDefault||function(e){return e&&e.__esModule?e:{default:e}};Object.defineProperty(e,"__esModule",{value:!0}),e.ReadableStreamMessageReader=e.AbstractMessageReader=e.MessageReader=void 0;var a=i(p()),o=r(l()),s=m(),c=_(),u;(function(e){function t(e){let t=e;return t&&o.func(t.listen)&&o.func(t.dispose)&&o.func(t.onError)&&o.func(t.onClose)&&o.func(t.onPartialMessage)}e.is=t})(u||(e.MessageReader=u={}));var d=class{errorEmitter;closeEmitter;partialMessageEmitter;constructor(){this.errorEmitter=new s.Emitter,this.closeEmitter=new s.Emitter,this.partialMessageEmitter=new s.Emitter}dispose(){this.errorEmitter.dispose(),this.closeEmitter.dispose(),this.partialMessageEmitter.dispose()}get onError(){return this.errorEmitter.event}fireError(e){this.errorEmitter.fire(this.asError(e))}get onClose(){return this.closeEmitter.event}fireClose(){this.closeEmitter.fire(void 0)}get onPartialMessage(){return this.partialMessageEmitter.event}firePartialMessage(e){this.partialMessageEmitter.fire(e)}asError(e){return e instanceof Error?e:/* @__PURE__ */ Error(`Reader received error. Reason: ${o.string(e.message)?e.message:`unknown`}`)}};e.AbstractMessageReader=d;var f;(function(e){function t(e){let t,n,r=/* @__PURE__ */ new Map,i,o=/* @__PURE__ */ new Map;if(e===void 0||typeof e==`string`)t=e??`utf-8`;else{if(t=e.charset??`utf-8`,e.contentDecoder!==void 0&&(n=e.contentDecoder,r.set(n.name,n)),e.contentDecoders!==void 0)for(let t of e.contentDecoders)r.set(t.name,t);if(e.contentTypeDecoder!==void 0&&(i=e.contentTypeDecoder,o.set(i.name,i)),e.contentTypeDecoders!==void 0)for(let t of e.contentTypeDecoders)o.set(t.name,t)}return i===void 0&&(i=(0,a.default)().applicationJson.decoder,o.set(i.name,i)),{charset:t,contentDecoder:n,contentDecoders:r,contentTypeDecoder:i,contentTypeDecoders:o}}e.fromOptions=t})(f||={}),e.ReadableStreamMessageReader=class extends d{readable;options;callback;nextMessageLength;messageToken;buffer;partialMessageTimer;_partialMessageTimeout;readSemaphore;constructor(e,t){super(),this.readable=e,this.options=f.fromOptions(t),this.buffer=(0,a.default)().messageBuffer.create(this.options.charset),this._partialMessageTimeout=1e4,this.nextMessageLength=-1,this.messageToken=0,this.readSemaphore=new c.Semaphore(1)}set partialMessageTimeout(e){this._partialMessageTimeout=e}get partialMessageTimeout(){return this._partialMessageTimeout}listen(e){this.nextMessageLength=-1,this.messageToken=0,this.partialMessageTimer=void 0,this.callback=e;let t=this.readable.onData(e=>{this.onData(e)});return this.readable.onError(e=>this.fireError(e)),this.readable.onClose(()=>this.fireClose()),t}onData(e){try{for(this.buffer.append(e);;){if(this.nextMessageLength===-1){let e=this.buffer.tryReadHeaders(!0);if(!e)return;let t=e.get(`content-length`);if(!t){this.fireError(/* @__PURE__ */ Error(`Header must provide a Content-Length property.
${JSON.stringify(Object.fromEntries(e))}`));return}let n=parseInt(t);if(isNaN(n)){this.fireError(/* @__PURE__ */ Error(`Content-Length value must be a number. Got ${t}`));return}this.nextMessageLength=n}let e=this.buffer.tryReadBody(this.nextMessageLength);if(e===void 0){this.setPartialMessageTimer();return}this.clearPartialMessageTimer(),this.nextMessageLength=-1,this.readSemaphore.lock(async()=>{let t=this.options.contentDecoder===void 0?e:await this.options.contentDecoder.decode(e),n=await this.options.contentTypeDecoder.decode(t,this.options);this.callback(n)}).catch(e=>{this.fireError(e)})}}catch(e){this.fireError(e)}}clearPartialMessageTimer(){this.partialMessageTimer&&=(this.partialMessageTimer.dispose(),void 0)}setPartialMessageTimer(){this.clearPartialMessageTimer(),!(this._partialMessageTimeout<=0)&&(this.partialMessageTimer=(0,a.default)().timer.setTimeout((e,t)=>{this.partialMessageTimer=void 0,e===this.messageToken&&(this.firePartialMessage({messageToken:e,waitingTime:t}),this.setPartialMessageTimer())},this._partialMessageTimeout,this.messageToken,this._partialMessageTimeout))}}}}),te=o({"../../node_modules/.pnpm/vscode-jsonrpc@10.0.0/node_modules/vscode-jsonrpc/lib/common/messageWriter.js"(e){var t=e&&e.__createBinding||(Object.create?(function(e,t,n,r){r===void 0&&(r=n);var i=Object.getOwnPropertyDescriptor(t,n);(!i||(`get`in i?!t.__esModule:i.writable||i.configurable))&&(i={enumerable:!0,get:function(){return t[n]}}),Object.defineProperty(e,r,i)}):(function(e,t,n,r){r===void 0&&(r=n),e[r]=t[n]})),n=e&&e.__setModuleDefault||(Object.create?(function(e,t){Object.defineProperty(e,"default",{enumerable:!0,value:t})}):function(e,t){e.default=t}),r=e&&e.__importStar||(function(){var e=function(t){return e=Object.getOwnPropertyNames||function(e){var t=[];for(var n in e)Object.prototype.hasOwnProperty.call(e,n)&&(t[t.length]=n);return t},e(t)};return function(r){if(r&&r.__esModule)return r;var i={};if(r!=null)for(var a=e(r),o=0;o<a.length;o++)a[o]!=="default"&&t(i,r,a[o]);return n(i,r),i}})(),i=e&&e.__importDefault||function(e){return e&&e.__esModule?e:{default:e}};Object.defineProperty(e,"__esModule",{value:!0}),e.WriteableStreamMessageWriter=e.AbstractMessageWriter=e.MessageWriter=void 0;var a=i(p()),o=r(l()),s=_(),c=m(),u=`Content-Length: `,d=`\r
`,f;(function(e){function t(e){let t=e;return t&&o.func(t.dispose)&&o.func(t.onClose)&&o.func(t.onError)&&o.func(t.write)}e.is=t})(f||(e.MessageWriter=f={}));var h=class{errorEmitter;closeEmitter;constructor(){this.errorEmitter=new c.Emitter,this.closeEmitter=new c.Emitter}dispose(){this.errorEmitter.dispose(),this.closeEmitter.dispose()}get onError(){return this.errorEmitter.event}fireError(e,t,n){this.errorEmitter.fire([this.asError(e),t,n])}get onClose(){return this.closeEmitter.event}fireClose(){this.closeEmitter.fire(void 0)}asError(e){return e instanceof Error?e:/* @__PURE__ */ Error(`Writer received error. Reason: ${o.string(e.message)?e.message:`unknown`}`)}};e.AbstractMessageWriter=h;var g;(function(e){function t(e){return e===void 0||typeof e==`string`?{charset:e??`utf-8`,contentTypeEncoder:(0,a.default)().applicationJson.encoder}:{charset:e.charset??`utf-8`,contentEncoder:e.contentEncoder,contentTypeEncoder:e.contentTypeEncoder??(0,a.default)().applicationJson.encoder}}e.fromOptions=t})(g||={}),e.WriteableStreamMessageWriter=class extends h{writable;options;errorCount;writeSemaphore;constructor(e,t){super(),this.writable=e,this.options=g.fromOptions(t),this.errorCount=0,this.writeSemaphore=new s.Semaphore(1),this.writable.onError(e=>this.fireError(e)),this.writable.onClose(()=>this.fireClose())}async write(e){return this.writeSemaphore.lock(async()=>this.options.contentTypeEncoder.encode(e,this.options).then(e=>this.options.contentEncoder===void 0?e:this.options.contentEncoder.encode(e)).then(t=>{let n=[];return n.push(u,t.byteLength.toString(),d),n.push(d),this.doWrite(e,n,t)},e=>{throw this.fireError(e),e}))}async doWrite(e,t,n){try{return await this.writable.write(t.join(``),`ascii`),this.writable.write(n)}catch(t){return this.handleError(t,e),Promise.reject(t)}}handleError(e,t){this.errorCount++,this.fireError(e,t,this.errorCount)}end(){this.writable.end()}}}}),ne=o({"../../node_modules/.pnpm/vscode-jsonrpc@10.0.0/node_modules/vscode-jsonrpc/lib/common/messageBuffer.js"(e){Object.defineProperty(e,"__esModule",{value:!0}),e.AbstractMessageBuffer=void 0;var t=13,n=10,r=`\r
`;e.AbstractMessageBuffer=class{_encoding;_chunks;_totalLength;constructor(e=`utf-8`){this._encoding=e,this._chunks=[],this._totalLength=0}get encoding(){return this._encoding}append(e){let t=typeof e==`string`?this.fromString(e,this._encoding):e;this._chunks.push(t),this._totalLength+=t.byteLength}tryReadHeaders(e=!1){if(this._chunks.length===0)return;let i=0,a=0,o=0,s=0;row:for(;a<this._chunks.length;){let e=this._chunks[a];for(o=0;o<e.length;){switch(e[o]){case t:switch(i){case 0:i=1;break;case 2:i=3;break;default:i=0}break;case n:switch(i){case 1:i=2;break;case 3:i=4,o++;break row;default:i=0}break;default:i=0}o++}s+=e.byteLength,a++}if(i!==4)return;let c=this._read(s+o),l=/* @__PURE__ */ new Map,u=this.toString(c,`ascii`).split(r);if(u.length<2)return l;for(let t=0;t<u.length-2;t++){let n=u[t],r=n.indexOf(`:`);if(r===-1)throw Error(`Message header must separate key and value using ':'
${n}`);let i=n.substr(0,r),a=n.substr(r+1).trim();l.set(e?i.toLowerCase():i,a)}return l}tryReadBody(e){if(!(this._totalLength<e))return this._read(e)}get numberOfBytes(){return this._totalLength}_read(e){if(e===0)return this.emptyBuffer();if(e>this._totalLength)throw Error(`Cannot read so many bytes!`);if(this._chunks[0].byteLength===e){let t=this._chunks[0];return this._chunks.shift(),this._totalLength-=e,this.asNative(t)}if(this._chunks[0].byteLength>e){let t=this._chunks[0],n=this.asNative(t,e);return this._chunks[0]=t.slice(e),this._totalLength-=e,n}let t=this.allocNative(e),n=0;for(;e>0;){let r=this._chunks[0];if(r.byteLength>e){let i=r.slice(0,e);t.set(i,n),n+=e,this._chunks[0]=r.slice(e),this._totalLength-=e,e-=e}else t.set(r,n),n+=r.byteLength,this._chunks.shift(),this._totalLength-=r.byteLength,e-=r.byteLength}return t}}}}),v=o({"../../node_modules/.pnpm/vscode-jsonrpc@10.0.0/node_modules/vscode-jsonrpc/lib/common/connection.js"(e){var t=e&&e.__createBinding||(Object.create?(function(e,t,n,r){r===void 0&&(r=n);var i=Object.getOwnPropertyDescriptor(t,n);(!i||(`get`in i?!t.__esModule:i.writable||i.configurable))&&(i={enumerable:!0,get:function(){return t[n]}}),Object.defineProperty(e,r,i)}):(function(e,t,n,r){r===void 0&&(r=n),e[r]=t[n]})),n=e&&e.__setModuleDefault||(Object.create?(function(e,t){Object.defineProperty(e,"default",{enumerable:!0,value:t})}):function(e,t){e.default=t}),r=e&&e.__importStar||(function(){var e=function(t){return e=Object.getOwnPropertyNames||function(e){var t=[];for(var n in e)Object.prototype.hasOwnProperty.call(e,n)&&(t[t.length]=n);return t},e(t)};return function(r){if(r&&r.__esModule)return r;var i={};if(r!=null)for(var a=e(r),o=0;o<a.length;o++)a[o]!=="default"&&t(i,r,a[o]);return n(i,r),i}})(),i=e&&e.__importDefault||function(e){return e&&e.__esModule?e:{default:e}};Object.defineProperty(e,"__esModule",{value:!0}),e.ConnectionOptions=e.MessageStrategy=e.CancellationStrategy=e.CancellationSenderStrategy=e.CancellationReceiverStrategy=e.RequestCancellationReceiverStrategy=e.IdCancellationReceiverStrategy=e.ConnectionStrategy=e.ConnectionError=e.ConnectionErrors=e.LogTraceNotification=e.SetTraceNotification=e.TraceFormat=e.TraceValues=e.TraceValue=e.Trace=e.NullLogger=e.ProgressType=e.ProgressToken=void 0,e.createMessageConnection=M;var a=i(p()),o=r(l()),s=u(),c=d(),f=m(),g=h(),_;(function(e){e.type=new s.NotificationType(`$/cancelRequest`)})(_||={});var ee;(function(e){function t(e){return typeof e==`string`||typeof e==`number`}e.is=t})(ee||(e.ProgressToken=ee={}));var te;(function(e){e.type=new s.NotificationType(`$/progress`)})(te||={}),e.ProgressType=class{__;_pr;constructor(){}};var ne;(function(e){function t(e){return o.func(e)}e.is=t})(ne||={}),e.NullLogger=Object.freeze({error:()=>{},warn:()=>{},info:()=>{},log:()=>{}});var v;(function(e){e[e.Off=0]=`Off`,e[e.Messages=1]=`Messages`,e[e.Compact=2]=`Compact`,e[e.Verbose=3]=`Verbose`})(v||(e.Trace=v={}));var y;(function(e){e.Off=`off`,e.Messages=`messages`,e.Compact=`compact`,e.Verbose=`verbose`})(y||(e.TraceValue=y={})),e.TraceValues=y,(function(e){function t(t){if(!o.string(t))return e.Off;switch(t=t.toLowerCase(),t){case`off`:return e.Off;case`messages`:return e.Messages;case`compact`:return e.Compact;case`verbose`:return e.Verbose;default:return e.Off}}e.fromString=t;function n(t){switch(t){case e.Off:return`off`;case e.Messages:return`messages`;case e.Compact:return`compact`;case e.Verbose:return`verbose`;default:return`off`}}e.toString=n})(v||(e.Trace=v={}));var b;(function(e){e.Text=`text`,e.JSON=`json`})(b||(e.TraceFormat=b={})),(function(e){function t(t){return o.string(t)?(t=t.toLowerCase(),t===`json`?e.JSON:e.Text):e.Text}e.fromString=t})(b||(e.TraceFormat=b={}));var x;(function(e){e.type=new s.NotificationType(`$/setTrace`)})(x||(e.SetTraceNotification=x={}));var re;(function(e){e.type=new s.NotificationType(`$/logTrace`)})(re||(e.LogTraceNotification=re={}));var S;(function(e){e[e.Closed=1]=`Closed`,e[e.Disposed=2]=`Disposed`,e[e.AlreadyListening=3]=`AlreadyListening`})(S||(e.ConnectionErrors=S={}));var C=class e extends Error{code;constructor(t,n){super(n),this.code=t,Object.setPrototypeOf(this,e.prototype)}};e.ConnectionError=C;var w;(function(e){function t(e){let t=e;return t&&o.func(t.cancelUndispatched)}e.is=t})(w||(e.ConnectionStrategy=w={}));var T;(function(e){function t(e){let t=e;return t&&(t.kind===void 0||t.kind===`id`)&&o.func(t.createCancellationTokenSource)&&(t.dispose===void 0||o.func(t.dispose))}e.is=t})(T||(e.IdCancellationReceiverStrategy=T={}));var E;(function(e){function t(e){let t=e;return t&&t.kind===`request`&&o.func(t.createCancellationTokenSource)&&(t.dispose===void 0||o.func(t.dispose))}e.is=t})(E||(e.RequestCancellationReceiverStrategy=E={}));var D;(function(e){e.Message=Object.freeze({createCancellationTokenSource(e){return new g.CancellationTokenSource}});function t(e){return T.is(e)||E.is(e)}e.is=t})(D||(e.CancellationReceiverStrategy=D={}));var O;(function(e){e.Message=Object.freeze({sendCancellation(e,t){return e.sendNotification(_.type,{id:t})},cleanup(e){}});function t(e){let t=e;return t&&o.func(t.sendCancellation)&&o.func(t.cleanup)}e.is=t})(O||(e.CancellationSenderStrategy=O={}));var k;(function(e){e.Message=Object.freeze({receiver:D.Message,sender:O.Message});function t(e){let t=e;return t&&D.is(t.receiver)&&O.is(t.sender)}e.is=t})(k||(e.CancellationStrategy=k={}));var ie;(function(e){function t(e){let t=e;return t&&o.func(t.handleMessage)}e.is=t})(ie||(e.MessageStrategy=ie={}));var A;(function(e){function t(e){let t=e;return t&&(k.is(t.cancellationStrategy)||w.is(t.connectionStrategy)||ie.is(t.messageStrategy)||o.number(t.maxParallelism))}e.is=t})(A||(e.ConnectionOptions=A={}));var j;(function(e){e[e.New=1]=`New`,e[e.Listening=2]=`Listening`,e[e.Closed=3]=`Closed`,e[e.Disposed=4]=`Disposed`})(j||={});function M(t,n,r,i){let l=r===void 0?e.NullLogger:r,u=0,d=0,p=0,m=i?.maxParallelism??-1,h=0,y,w=/* @__PURE__ */ new Map,E,D=/* @__PURE__ */ new Map,O=/* @__PURE__ */ new Map,A,M=new c.LinkedMap,N=/* @__PURE__ */ new Map,P=/* @__PURE__ */ new Set,F=/* @__PURE__ */ new Map,I=v.Off,L=b.Text,R,z=j.New,ae=new f.Emitter,oe=new f.Emitter,se=new f.Emitter,ce=new f.Emitter,le=new f.Emitter,B=i&&i.cancellationStrategy?i.cancellationStrategy:k.Message;function ue(e){}function V(){return z===j.Listening}function H(){return z===j.Closed}function U(){return z===j.Disposed}function de(){(z===j.New||z===j.Listening)&&(z=j.Closed,oe.fire(void 0))}function fe(e){ae.fire([e,void 0,void 0])}function pe(e){ae.fire(e)}t.onClose(de),t.onError(fe),n.onClose(de),n.onError(pe);function me(e){if(e===null)throw Error(`Can't send requests with id null since the response can't be correlated.`);return`req-`+e.toString()}function he(e){return e===null?`res-unknown-`+(++p).toString():`res-`+e.toString()}function ge(){return`not-`+(++d).toString()}function _e(e,t){s.Message.isRequest(t)?e.set(me(t.id),t):s.Message.isResponse(t)?m===-1?e.set(he(t.id),t):xe(t):e.set(ge(),t)}function W(){A||M.size===0||m!==-1&&h>=m||(A=(0,a.default)().timer.setImmediate(async()=>{if(A=void 0,M.size===0||m!==-1&&h>=m)return;let e=M.shift(),t;try{h++;let n=i?.messageStrategy;t=ie.is(n)?n.handleMessage(e,ve):ve(e)}catch(e){l.error(`Processing message queue failed: ${e.toString()}`)}finally{t instanceof Promise?t.then(()=>{}).catch(e=>{l.error(`Processing message queue failed: ${e.toString()}`)}).finally(()=>{h--,W()}):h--,W()}}))}async function ve(e){return s.Message.isRequest(e)?be(e):s.Message.isNotification(e)?Se(e):s.Message.isResponse(e)?xe(e):Ce(e)}let ye=e=>{try{if(s.Message.isNotification(e)&&e.method===_.type.method){let t=e.params.id,r=me(t),a=M.get(r);if(s.Message.isRequest(a)){let o=i?.connectionStrategy,s=o&&o.cancelUndispatched?o.cancelUndispatched(a,ue):void 0;if(s&&(s.error!==void 0||s.result!==void 0)){M.delete(r),F.delete(t),s.id=a.id,q(s,e.method,Date.now()),n.write(s).catch(()=>l.error(`Sending response for canceled message failed.`));return}}let o=F.get(t);if(o!==void 0){o.cancel(),Ee(e);return}P.add(t)}_e(M,e)}finally{W()}};async function be(e){if(U())return Promise.resolve();function t(t,r,i){let a={jsonrpc:`2.0`,id:e.id};return t instanceof s.ResponseError?a.error=t.toJson():a.result=t===void 0?null:t,q(a,r,i),n.write(a)}function r(t,r,i){let a={jsonrpc:`2.0`,id:e.id,error:t.toJson()};return q(a,r,i),n.write(a)}Te(e);let i=w.get(e.method),a,c;i&&(a=i.type,c=i.handler);let l=Date.now();if(c||y){let n=e.id??String(Date.now()),i=T.is(B.receiver)?B.receiver.createCancellationTokenSource(n):B.receiver.createCancellationTokenSource(e);e.id!==null&&P.has(e.id)&&i.cancel(),e.id!==null&&F.set(n,i);try{let n;if(c){if(e.params===void 0){if(a!==void 0&&a.numberOfParams!==0)return r(new s.ResponseError(s.ErrorCodes.InvalidParams,`Request ${e.method} defines ${a.numberOfParams} params but received none.`),e.method,l);n=c(i.token)}else if(Array.isArray(e.params)){if(a!==void 0&&a.parameterStructures===s.ParameterStructures.byName)return r(new s.ResponseError(s.ErrorCodes.InvalidParams,`Request ${e.method} defines parameters by name but received parameters by position`),e.method,l);n=c(...e.params,i.token)}else{if(a!==void 0&&a.parameterStructures===s.ParameterStructures.byPosition)return r(new s.ResponseError(s.ErrorCodes.InvalidParams,`Request ${e.method} defines parameters by position but received parameters by name`),e.method,l);n=c(e.params,i.token)}}else y&&(n=y(e.method,e.params,i.token));await t(await n,e.method,l)}catch(n){n instanceof s.ResponseError?await t(n,e.method,l):n&&o.string(n.message)?await r(new s.ResponseError(s.ErrorCodes.InternalError,`Request ${e.method} failed with message: ${n.message}`),e.method,l):await r(new s.ResponseError(s.ErrorCodes.InternalError,`Request ${e.method} failed unexpectedly without providing any details.`),e.method,l)}finally{F.delete(n)}}else await r(new s.ResponseError(s.ErrorCodes.MethodNotFound,`Unhandled method ${e.method}`),e.method,l)}function xe(e){if(!U()){if(e.id===null)e.error?l.error(`Received response message without id: Error is: 
${JSON.stringify(e.error,void 0,4)}`):l.error(`Received response message without id. No further error information provided.`);else{let t=e.id,n=N.get(t);if(De(e,n),n!==void 0){N.delete(t);try{if(e.error){let t=e.error;n.reject(new s.ResponseError(t.code,t.message,t.data))}else if(e.result!==void 0)n.resolve(e.result);else throw Error(`Should never happen.`)}catch(e){e.message?l.error(`Response handler '${n.method}' failed with message: ${e.message}`):l.error(`Response handler '${n.method}' failed unexpectedly.`)}}}}}async function Se(e){if(U())return;let t,n;if(e.method===_.type.method){let t=e.params.id;P.delete(t),Ee(e);return}{let r=D.get(e.method);r&&(n=r.handler,t=r.type)}if(n||E)try{if(Ee(e),n){if(e.params===void 0)t!==void 0&&t.numberOfParams!==0&&t.parameterStructures!==s.ParameterStructures.byName&&l.error(`Notification ${e.method} defines ${t.numberOfParams} params but received none.`),await n();else if(Array.isArray(e.params)){let r=e.params;e.method===te.type.method&&r.length===2&&ee.is(r[0])?await n({token:r[0],value:r[1]}):(t!==void 0&&(t.parameterStructures===s.ParameterStructures.byName&&l.error(`Notification ${e.method} defines parameters by name but received parameters by position`),t.numberOfParams!==e.params.length&&l.error(`Notification ${e.method} defines ${t.numberOfParams} params but received ${r.length} arguments`)),await n(...r))}else t!==void 0&&t.parameterStructures===s.ParameterStructures.byPosition&&l.error(`Notification ${e.method} defines parameters by position but received parameters by name`),await n(e.params)}else E&&await E(e.method,e.params)}catch(t){t.message?l.error(`Notification handler '${e.method}' failed with message: ${t.message}`):l.error(`Notification handler '${e.method}' failed unexpectedly.`)}else se.fire(e)}function Ce(e){if(!e){l.error(`Received empty message.`);return}l.error(`Received message which is neither a response nor a notification message:
${JSON.stringify(e,null,4)}`);let t=e;if(o.string(t.id)||o.number(t.id)){let e=t.id,n=N.get(e);n&&n.reject(/* @__PURE__ */ Error(`The received response has neither a result nor an error property.`))}}function G(e){if(e!=null)switch(I){case v.Verbose:return JSON.stringify(e,null,4);case v.Compact:return JSON.stringify(e);default:return}}function we(e){if(I!==v.Off&&R){if(L===b.Text){let t;(I===v.Verbose||I===v.Compact)&&e.params&&(t=`Params: ${G(e.params)}`),R.log(`Sending request '${e.method} - (${e.id})'.`,t)}else J(`send-request`,e)}}function K(e){if(I!==v.Off&&R){if(L===b.Text){let t;(I===v.Verbose||I===v.Compact)&&(t=e.params?`Params: ${G(e.params)}`:`No parameters provided.`),R.log(`Sending notification '${e.method}'.`,t)}else J(`send-notification`,e)}}function q(e,t,n){if(I!==v.Off&&R){if(L===b.Text){let r;(I===v.Verbose||I===v.Compact)&&(e.error&&e.error.data?r=`Error data: ${G(e.error.data)}`:e.result?r=`Result: ${G(e.result)}`:e.error===void 0&&(r=`No result returned.`));let i=e.error?` Request failed: ${e.error.message} (${e.error.code}).`:``;R.log(`Sending response '${t} - (${e.id})'. Processing request took ${Date.now()-n}ms.${i}`,r)}else J(`send-response`,e)}}function Te(e){if(I!==v.Off&&R){if(L===b.Text){let t;(I===v.Verbose||I===v.Compact)&&e.params&&(t=`Params: ${G(e.params)}`),R.log(`Received request '${e.method} - (${e.id})'.`,t)}else J(`receive-request`,e)}}function Ee(e){if(I!==v.Off&&R&&e.method!==re.type.method){if(L===b.Text){let t;(I===v.Verbose||I===v.Compact)&&(t=e.params?`Params: ${G(e.params)}`:`No parameters provided.`),R.log(`Received notification '${e.method}'.`,t)}else J(`receive-notification`,e)}}function De(e,t){if(I!==v.Off&&R){if(L===b.Text){let n;if((I===v.Verbose||I===v.Compact)&&(e.error&&e.error.data?n=`Error data: ${G(e.error.data)}`:e.result?n=`Result: ${G(e.result)}`:e.error===void 0&&(n=`No result returned.`)),t){let r=e.error?` Request failed: ${e.error.message} (${e.error.code}).`:``;R.log(`Received response '${t.method} - (${e.id})' in ${Date.now()-t.timerStart}ms.${r}`,n)}else R.log(`Received response ${e.id} without active response promise.`,n)}else J(`receive-response`,e)}}function J(e,t){if(!R||I===v.Off)return;let n={isLSPMessage:!0,type:e,message:t,timestamp:Date.now()};R.log(n)}function Y(){if(H())throw new C(S.Closed,`Connection is closed.`);if(U())throw new C(S.Disposed,`Connection is disposed.`)}function Oe(){if(V())throw new C(S.AlreadyListening,`Connection is already listening`)}function ke(){if(!V())throw Error(`Call listen() first.`)}function X(e){return e===void 0?null:e}function Ae(e){if(e!==null)return e}function je(e){return e!=null&&!Array.isArray(e)&&typeof e==`object`}function Me(e,t){switch(e){case s.ParameterStructures.auto:return je(t)?Ae(t):[X(t)];case s.ParameterStructures.byName:if(!je(t))throw Error(`Received parameters by name but param is not an object literal.`);return Ae(t);case s.ParameterStructures.byPosition:return[X(t)];default:throw Error(`Unknown parameter structure ${e.toString()}`)}}function Ne(e,t){let n,r=e.numberOfParams;switch(r){case 0:n=void 0;break;case 1:n=Me(e.parameterStructures,t[0]);break;default:n=[];for(let e=0;e<t.length&&e<r;e++)n.push(X(t[e]));if(t.length<r)for(let e=t.length;e<r;e++)n.push(null)}return n}let Z={sendNotification:(e,...t)=>{Y();let r,i;if(o.string(e)){r=e;let n=t[0],a=0,o=s.ParameterStructures.auto;s.ParameterStructures.is(n)&&(a=1,o=n);let c=t.length,l=c-a;switch(l){case 0:i=void 0;break;case 1:i=Me(o,t[a]);break;default:if(o===s.ParameterStructures.byName)throw Error(`Received ${l} parameters for 'by Name' notification parameter structure.`);i=t.slice(a,c).map(e=>X(e))}}else{let n=t;r=e.method,i=Ne(e,n)}let a={jsonrpc:`2.0`,method:r,params:i};return K(a),n.write(a).catch(e=>{throw l.error(`Sending notification failed.`),e})},onNotification:(e,t)=>{Y();let n;return o.func(e)?E=e:t&&(o.string(e)?(n=e,D.set(e,{type:void 0,handler:t})):(n=e.method,D.set(e.method,{type:e,handler:t}))),{dispose:()=>{n===void 0?E===e&&(E=void 0):D.get(n)?.handler===t&&D.delete(n)}}},onProgress:(e,t,n)=>{if(O.has(t))throw Error(`Progress handler for token ${t} already registered`);return O.set(t,n),{dispose:()=>{O.get(t)===n&&O.delete(t)}}},sendProgress:(e,t,n)=>Z.sendNotification(te.type,{token:t,value:n}),onUnhandledProgress:ce.event,sendRequest:(e,...t)=>{Y(),ke();function r(e,t){let n=B.sender.sendCancellation(e,t);n===void 0?l.log(`Received no promise from cancellation strategy when cancelling id ${t}`):n.catch(()=>{l.log(`Sending cancellation messages for id ${t} failed.`)})}let i,a,c;if(o.string(e)){i=e;let n=t[0],r=t[t.length-1],o=0,l=s.ParameterStructures.auto;s.ParameterStructures.is(n)&&(o=1,l=n);let u=t.length;g.CancellationToken.is(r)&&(--u,c=r);let d=u-o;switch(d){case 0:a=void 0;break;case 1:a=Me(l,t[o]);break;default:if(l===s.ParameterStructures.byName)throw Error(`Received ${d} parameters for 'by Name' request parameter structure.`);a=t.slice(o,u).map(e=>X(e))}}else{let n=t;i=e.method,a=Ne(e,n);let r=e.numberOfParams;c=g.CancellationToken.is(n[r])?n[r]:void 0}let d=u++,f,p=!1;c!==void 0&&(c.isCancellationRequested?p=!0:f=c.onCancellationRequested(()=>{r(Z,d)}));let m={jsonrpc:`2.0`,id:d,method:i,params:a};return we(m),typeof B.sender.enableCancellation==`function`&&B.sender.enableCancellation(m),new Promise(async(e,t)=>{let a={method:i,timerStart:Date.now(),resolve:t=>{e(t),B.sender.cleanup(d),f?.dispose()},reject:e=>{t(e),B.sender.cleanup(d),f?.dispose()}};try{N.set(d,a),await n.write(m),p&&r(Z,d)}catch(e){N.delete(d),a.reject(new s.ResponseError(s.ErrorCodes.MessageWriteError,e.message?e.message:`Unknown reason`)),l.error(`Sending request failed.`)}})},onRequest:(e,t)=>{Y();let n=null;return ne.is(e)?(n=void 0,y=e):o.string(e)?(n=null,t!==void 0&&(n=e,w.set(e,{handler:t,type:void 0}))):t!==void 0&&(n=e.method,w.set(e.method,{type:e,handler:t})),{dispose:()=>{n!==null&&(n===void 0?y===e&&(y=void 0):w.get(n)?.handler===t&&w.delete(n))}}},hasPendingResponse:()=>N.size>0,trace:async(e,t,n)=>{let r=!1,i=b.Text;n!==void 0&&(o.boolean(n)?r=n:(r=n.sendNotification||!1,i=n.traceFormat||b.Text)),I=e,L=i,R=I===v.Off?void 0:t,r&&!H()&&!U()&&await Z.sendNotification(x.type,{value:v.toString(e)})},onError:ae.event,onClose:oe.event,onUnhandledNotification:se.event,onDispose:le.event,end:()=>{n.end()},dispose:()=>{if(U())return;z=j.Disposed,le.fire(void 0);let e=new s.ResponseError(s.ErrorCodes.PendingResponseRejected,`Pending response rejected since connection got disposed`);for(let t of N.values())t.reject(e);N=/* @__PURE__ */ new Map,F=/* @__PURE__ */ new Map,P=/* @__PURE__ */ new Set,M=new c.LinkedMap,o.func(n.dispose)&&n.dispose(),o.func(t.dispose)&&t.dispose()},listen:()=>{Y(),Oe(),z=j.Listening,t.listen(ye)},inspect:()=>{(0,a.default)().console.log(`inspect`)}};return Z.onNotification(re.type,e=>{if(I===v.Off||!R)return;let t=I===v.Verbose||I===v.Compact;R.log(e.message,t?e.verbose:void 0)}),Z.onNotification(te.type,async e=>{let t=O.get(e.token);t?await t(e.value):ce.fire(e)}),Z}}}),y=o({"../../node_modules/.pnpm/vscode-jsonrpc@10.0.0/node_modules/vscode-jsonrpc/lib/common/api.js"(e){var t=e&&e.__importDefault||function(e){return e&&e.__esModule?e:{default:e}};Object.defineProperty(e,"__esModule",{value:!0}),e.ProgressType=e.ProgressToken=e.createMessageConnection=e.NullLogger=e.ConnectionOptions=e.ConnectionStrategy=e.AbstractMessageBuffer=e.WriteableStreamMessageWriter=e.AbstractMessageWriter=e.MessageWriter=e.ReadableStreamMessageReader=e.AbstractMessageReader=e.MessageReader=e.SharedArrayReceiverStrategy=e.SharedArraySenderStrategy=e.CancellationToken=e.CancellationTokenSource=e.Emitter=e.Event=e.Disposable=e.LRUCache=e.Touch=e.LinkedMap=e.ParameterStructures=e.NotificationType9=e.NotificationType8=e.NotificationType7=e.NotificationType6=e.NotificationType5=e.NotificationType4=e.NotificationType3=e.NotificationType2=e.NotificationType1=e.NotificationType0=e.NotificationType=e.ErrorCodes=e.ResponseError=e.RequestType9=e.RequestType8=e.RequestType7=e.RequestType6=e.RequestType5=e.RequestType4=e.RequestType3=e.RequestType2=e.RequestType1=e.RequestType0=e.RequestType=e.Message=e.RAL=void 0,e.MessageStrategy=e.CancellationStrategy=e.CancellationSenderStrategy=e.RequestCancellationReceiverStrategy=e.IdCancellationReceiverStrategy=e.CancellationReceiverStrategy=e.ConnectionError=e.ConnectionErrors=e.LogTraceNotification=e.SetTraceNotification=e.TraceFormat=e.TraceValues=e.TraceValue=e.Trace=void 0;var n=u();Object.defineProperty(e,"Message",{enumerable:!0,get:function(){return n.Message}}),Object.defineProperty(e,"RequestType",{enumerable:!0,get:function(){return n.RequestType}}),Object.defineProperty(e,"RequestType0",{enumerable:!0,get:function(){return n.RequestType0}}),Object.defineProperty(e,"RequestType1",{enumerable:!0,get:function(){return n.RequestType1}}),Object.defineProperty(e,"RequestType2",{enumerable:!0,get:function(){return n.RequestType2}}),Object.defineProperty(e,"RequestType3",{enumerable:!0,get:function(){return n.RequestType3}}),Object.defineProperty(e,"RequestType4",{enumerable:!0,get:function(){return n.RequestType4}}),Object.defineProperty(e,"RequestType5",{enumerable:!0,get:function(){return n.RequestType5}}),Object.defineProperty(e,"RequestType6",{enumerable:!0,get:function(){return n.RequestType6}}),Object.defineProperty(e,"RequestType7",{enumerable:!0,get:function(){return n.RequestType7}}),Object.defineProperty(e,"RequestType8",{enumerable:!0,get:function(){return n.RequestType8}}),Object.defineProperty(e,"RequestType9",{enumerable:!0,get:function(){return n.RequestType9}}),Object.defineProperty(e,"ResponseError",{enumerable:!0,get:function(){return n.ResponseError}}),Object.defineProperty(e,"ErrorCodes",{enumerable:!0,get:function(){return n.ErrorCodes}}),Object.defineProperty(e,"NotificationType",{enumerable:!0,get:function(){return n.NotificationType}}),Object.defineProperty(e,"NotificationType0",{enumerable:!0,get:function(){return n.NotificationType0}}),Object.defineProperty(e,"NotificationType1",{enumerable:!0,get:function(){return n.NotificationType1}}),Object.defineProperty(e,"NotificationType2",{enumerable:!0,get:function(){return n.NotificationType2}}),Object.defineProperty(e,"NotificationType3",{enumerable:!0,get:function(){return n.NotificationType3}}),Object.defineProperty(e,"NotificationType4",{enumerable:!0,get:function(){return n.NotificationType4}}),Object.defineProperty(e,"NotificationType5",{enumerable:!0,get:function(){return n.NotificationType5}}),Object.defineProperty(e,"NotificationType6",{enumerable:!0,get:function(){return n.NotificationType6}}),Object.defineProperty(e,"NotificationType7",{enumerable:!0,get:function(){return n.NotificationType7}}),Object.defineProperty(e,"NotificationType8",{enumerable:!0,get:function(){return n.NotificationType8}}),Object.defineProperty(e,"NotificationType9",{enumerable:!0,get:function(){return n.NotificationType9}}),Object.defineProperty(e,"ParameterStructures",{enumerable:!0,get:function(){return n.ParameterStructures}});var r=d();Object.defineProperty(e,"LinkedMap",{enumerable:!0,get:function(){return r.LinkedMap}}),Object.defineProperty(e,"LRUCache",{enumerable:!0,get:function(){return r.LRUCache}}),Object.defineProperty(e,"Touch",{enumerable:!0,get:function(){return r.Touch}});var i=f();Object.defineProperty(e,"Disposable",{enumerable:!0,get:function(){return i.Disposable}});var a=m();Object.defineProperty(e,"Event",{enumerable:!0,get:function(){return a.Event}}),Object.defineProperty(e,"Emitter",{enumerable:!0,get:function(){return a.Emitter}});var o=h();Object.defineProperty(e,"CancellationTokenSource",{enumerable:!0,get:function(){return o.CancellationTokenSource}}),Object.defineProperty(e,"CancellationToken",{enumerable:!0,get:function(){return o.CancellationToken}});var s=g();Object.defineProperty(e,"SharedArraySenderStrategy",{enumerable:!0,get:function(){return s.SharedArraySenderStrategy}}),Object.defineProperty(e,"SharedArrayReceiverStrategy",{enumerable:!0,get:function(){return s.SharedArrayReceiverStrategy}});var c=ee();Object.defineProperty(e,"MessageReader",{enumerable:!0,get:function(){return c.MessageReader}}),Object.defineProperty(e,"AbstractMessageReader",{enumerable:!0,get:function(){return c.AbstractMessageReader}}),Object.defineProperty(e,"ReadableStreamMessageReader",{enumerable:!0,get:function(){return c.ReadableStreamMessageReader}});var l=te();Object.defineProperty(e,"MessageWriter",{enumerable:!0,get:function(){return l.MessageWriter}}),Object.defineProperty(e,"AbstractMessageWriter",{enumerable:!0,get:function(){return l.AbstractMessageWriter}}),Object.defineProperty(e,"WriteableStreamMessageWriter",{enumerable:!0,get:function(){return l.WriteableStreamMessageWriter}});var _=ne();Object.defineProperty(e,"AbstractMessageBuffer",{enumerable:!0,get:function(){return _.AbstractMessageBuffer}});var y=v();Object.defineProperty(e,"ConnectionStrategy",{enumerable:!0,get:function(){return y.ConnectionStrategy}}),Object.defineProperty(e,"ConnectionOptions",{enumerable:!0,get:function(){return y.ConnectionOptions}}),Object.defineProperty(e,"NullLogger",{enumerable:!0,get:function(){return y.NullLogger}}),Object.defineProperty(e,"createMessageConnection",{enumerable:!0,get:function(){return y.createMessageConnection}}),Object.defineProperty(e,"ProgressToken",{enumerable:!0,get:function(){return y.ProgressToken}}),Object.defineProperty(e,"ProgressType",{enumerable:!0,get:function(){return y.ProgressType}}),Object.defineProperty(e,"Trace",{enumerable:!0,get:function(){return y.Trace}}),Object.defineProperty(e,"TraceValue",{enumerable:!0,get:function(){return y.TraceValue}}),Object.defineProperty(e,"TraceFormat",{enumerable:!0,get:function(){return y.TraceFormat}}),Object.defineProperty(e,"SetTraceNotification",{enumerable:!0,get:function(){return y.SetTraceNotification}}),Object.defineProperty(e,"LogTraceNotification",{enumerable:!0,get:function(){return y.LogTraceNotification}}),Object.defineProperty(e,"ConnectionErrors",{enumerable:!0,get:function(){return y.ConnectionErrors}}),Object.defineProperty(e,"ConnectionError",{enumerable:!0,get:function(){return y.ConnectionError}}),Object.defineProperty(e,"CancellationReceiverStrategy",{enumerable:!0,get:function(){return y.CancellationReceiverStrategy}}),Object.defineProperty(e,"IdCancellationReceiverStrategy",{enumerable:!0,get:function(){return y.IdCancellationReceiverStrategy}}),Object.defineProperty(e,"RequestCancellationReceiverStrategy",{enumerable:!0,get:function(){return y.RequestCancellationReceiverStrategy}}),Object.defineProperty(e,"CancellationSenderStrategy",{enumerable:!0,get:function(){return y.CancellationSenderStrategy}}),Object.defineProperty(e,"CancellationStrategy",{enumerable:!0,get:function(){return y.CancellationStrategy}}),Object.defineProperty(e,"MessageStrategy",{enumerable:!0,get:function(){return y.MessageStrategy}}),Object.defineProperty(e,"TraceValues",{enumerable:!0,get:function(){return y.TraceValues}}),e.RAL=t(p()).default}}),b=o({"../../node_modules/.pnpm/vscode-jsonrpc@10.0.0/node_modules/vscode-jsonrpc/lib/browser/ril.js"(e){Object.defineProperty(e,"__esModule",{value:!0}),e.PromiseImpl=e.QueueMicrotaskImpl=void 0;var t=y(),n=class e extends t.AbstractMessageBuffer{static emptyBuffer=/* @__PURE__ */ new Uint8Array;asciiDecoder;constructor(e=`utf-8`){super(e),this.asciiDecoder=new TextDecoder(`ascii`)}emptyBuffer(){return e.emptyBuffer}fromString(e,t){return new TextEncoder().encode(e)}toString(e,t){return t===`ascii`?this.asciiDecoder.decode(e):new TextDecoder(t).decode(e)}asNative(e,t){return t===void 0?e:e.slice(0,t)}allocNative(e){return new Uint8Array(e)}},r=class{socket;_onData;_messageListener;constructor(e){this.socket=e,this._onData=new t.Emitter,this._messageListener=e=>{e.data.arrayBuffer().then(e=>{this._onData.fire(new Uint8Array(e))},()=>{(0,t.RAL)().console.error(`Converting blob to array buffer failed.`)})},this.socket.addEventListener(`message`,this._messageListener)}onClose(e){return this.socket.addEventListener(`close`,e),t.Disposable.create(()=>this.socket.removeEventListener(`close`,e))}onError(e){return this.socket.addEventListener(`error`,e),t.Disposable.create(()=>this.socket.removeEventListener(`error`,e))}onEnd(e){return this.socket.addEventListener(`end`,e),t.Disposable.create(()=>this.socket.removeEventListener(`end`,e))}onData(e){return this._onData.event(e)}},i=class{socket;constructor(e){this.socket=e}onClose(e){return this.socket.addEventListener(`close`,e),t.Disposable.create(()=>this.socket.removeEventListener(`close`,e))}onError(e){return this.socket.addEventListener(`error`,e),t.Disposable.create(()=>this.socket.removeEventListener(`error`,e))}onEnd(e){return this.socket.addEventListener(`end`,e),t.Disposable.create(()=>this.socket.removeEventListener(`end`,e))}write(e,t){if(typeof e==`string`){if(t!==void 0&&t!==`utf-8`)throw Error(`In a Browser environments only utf-8 text encoding is supported. But got encoding: ${t}`);this.socket.send(e)}else e.buffer instanceof ArrayBuffer?this.socket.send(e.buffer):this.socket.send(new Uint8Array(e.buffer).slice().buffer);return Promise.resolve()}end(){this.socket.close()}},a=class{isDisposed;constructor(e,...t){this.isDisposed=!1,queueMicrotask(()=>{this.isDisposed||e(...t)})}dispose(){this.isDisposed=!0}};e.QueueMicrotaskImpl=a;var o=class{isDisposed;constructor(e,...t){this.isDisposed=!1,Promise.resolve().then(()=>{this.isDisposed||e(...t)},()=>{})}dispose(){this.isDisposed=!0}};e.PromiseImpl=o;var s=new TextEncoder,c=Object.freeze({crypto:Object.freeze({randomUUID(){return typeof globalThis.crypto.randomUUID==`function`?globalThis.crypto.randomUUID():`10000000-1000-4000-8000-100000000000`.replace(/[018]/g,e=>(+e^globalThis.crypto.getRandomValues(/* @__PURE__ */ new Uint8Array(1))[0]&15>>e/4).toString(16))}}),messageBuffer:Object.freeze({create:e=>new n(e)}),applicationJson:Object.freeze({encoder:Object.freeze({name:`application/json`,encode:(e,t)=>{if(t.charset!==`utf-8`)throw Error(`In a Browser environments only utf-8 text encoding is supported. But got encoding: ${t.charset}`);return Promise.resolve(s.encode(JSON.stringify(e,void 0,0)))}}),decoder:Object.freeze({name:`application/json`,decode:(e,t)=>{if(!(e instanceof Uint8Array))throw Error(`In a Browser environments only Uint8Arrays are supported.`);return Promise.resolve(JSON.parse(new TextDecoder(t.charset).decode(e)))}})}),stream:Object.freeze({asReadableStream:e=>new r(e),asWritableStream:e=>new i(e)}),console,timer:Object.freeze({setTimeout(e,t,...n){let r=setTimeout(e,t,...n);return{dispose:()=>clearTimeout(r)}},setImmediate(e,...t){if(typeof globalThis.queueMicrotask==`function`)return new a(e,...t);if(Promise!==void 0)return new o(e,...t);{let n=setTimeout(e,0,...t);return{dispose:()=>clearTimeout(n)}}},setInterval(e,t,...n){let r=setInterval(e,t,...n);return{dispose:()=>clearInterval(r)}}})});function l(){return c}(function(e){function n(){t.RAL.install(c)}e.install=n})(l||={}),e.default=l}}),x=c(o({"../../node_modules/.pnpm/vscode-jsonrpc@10.0.0/node_modules/vscode-jsonrpc/lib/browser/main.js"(e){var t=e&&e.__createBinding||(Object.create?(function(e,t,n,r){r===void 0&&(r=n);var i=Object.getOwnPropertyDescriptor(t,n);(!i||(`get`in i?!t.__esModule:i.writable||i.configurable))&&(i={enumerable:!0,get:function(){return t[n]}}),Object.defineProperty(e,r,i)}):(function(e,t,n,r){r===void 0&&(r=n),e[r]=t[n]})),n=e&&e.__exportStar||function(e,n){for(var r in e)r!=="default"&&!Object.prototype.hasOwnProperty.call(n,r)&&t(n,e,r)},r=e&&e.__importDefault||function(e){return e&&e.__esModule?e:{default:e}};Object.defineProperty(e,"__esModule",{value:!0}),e.BrowserMessageWriter=e.BrowserMessageReader=void 0,e.createMessageConnection=a,r(b()).default.install();var i=y();n(y(),e),e.BrowserMessageReader=class extends i.AbstractMessageReader{_onData;_messageListener;constructor(e){super(),this._onData=new i.Emitter,this._messageListener=e=>{this._onData.fire(e.data)},e.addEventListener(`error`,e=>this.fireError(e)),e.onmessage=this._messageListener}listen(e){return this._onData.event(e)}},e.BrowserMessageWriter=class extends i.AbstractMessageWriter{port;errorCount;constructor(e){super(),this.port=e,this.errorCount=0,e.addEventListener(`error`,e=>this.fireError(e))}write(e){try{return this.port.postMessage(e),Promise.resolve()}catch(t){return this.handleError(t,e),Promise.reject(t)}}handleError(e,t){this.errorCount++,this.fireError(e,t,this.errorCount)}end(){}};function a(e,t,n,r){return n===void 0&&(n=i.NullLogger),i.ConnectionStrategy.is(r)&&(r={connectionStrategy:r}),(0,i.createMessageConnection)(e,t,n,r)}}})(),1),re=x.BrowserMessageReader,S=x.BrowserMessageWriter;x.ReadableStreamMessageReader,x.WriteableStreamMessageWriter,x.Emitter;var C=class extends Error{code;phase;runtimeId;profileId;recoverable;constructor(e,t){super(e,{cause:t.cause}),this.name=`WasmIdleError`,this.code=t.code,this.phase=t.phase,this.runtimeId=t.runtimeId,this.profileId=t.profileId,this.recoverable=t.recoverable??!1}},w=class extends C{constructor(e,t={}){super(e,{...t,code:`asset-integrity`,phase:t.phase??`asset`,recoverable:t.recoverable??!1}),this.name=`AssetIntegrityError`}};const T=/* @__PURE__ */ new Set([`application/javascript`,`text/javascript`]);async function E(e){let t=e.stage??`compressed`,n={runtimeId:e.runtimeId,profileId:e.profileId};if(!e.asset||e.asset.includes(`\0`))throw new w(`Runtime asset identity must be a non-empty safe string`,n);if(!ArrayBuffer.isView(e.bytes)||Object.prototype.toString.call(e.bytes)!==`[object Uint8Array]`)throw new w(`Runtime asset ${e.asset} did not provide byte data`,n);let r,i,a;if(typeof e.expected==`string`){if(t===`uncompressed`)throw new w(`Runtime asset ${e.asset} is missing uncompressed integrity metadata`,n);r=e.expected}else if(e.expected&&typeof e.expected==`object`){if(t===`compressed`)r=e.expected.sha256,i=e.expected.bytes,e.expected.uncompressedSha256===void 0&&e.expected.uncompressedBytes===void 0&&(a=e.expected.mediaType);else{if(e.expected.uncompressedSha256===void 0||e.expected.uncompressedBytes===void 0)throw new w(`Runtime asset ${e.asset} is missing uncompressed integrity metadata`,n);r=e.expected.uncompressedSha256,i=e.expected.uncompressedBytes,a=e.expected.mediaType}}else throw new w(`Runtime asset ${e.asset} has invalid integrity metadata`,n);if(!/^[a-f0-9]{64}$/u.test(r))throw new w(`Runtime asset ${e.asset} has an invalid expected ${t} SHA-256 digest`,n);if(i!==void 0&&(!Number.isSafeInteger(i)||i<0))throw new w(`Runtime asset ${e.asset} has an invalid expected ${t} byte size`,n);if(i!==void 0&&e.bytes.byteLength!==i)throw new w(`Runtime asset ${e.asset} ${t} size mismatch: expected ${i} bytes, received ${e.bytes.byteLength}`,n);if(a!==void 0){if(!a.includes(`/`))throw new w(`Runtime asset ${e.asset} has an invalid expected MIME type`,n);let t=e.mimeType?.split(`;`,1)[0]?.trim().toLowerCase()||`missing`,r=a.trim().toLowerCase();if(t!==r&&!(T.has(t)&&T.has(r)))throw new w(`Runtime asset ${e.asset} MIME type mismatch: expected ${r}, received ${t}`,n)}if(!globalThis.crypto?.subtle)throw new w(`Web Crypto SHA-256 is unavailable`,n);let o=e.bytes.byteOffset===0&&e.bytes.byteLength===e.bytes.buffer.byteLength&&e.bytes.buffer instanceof ArrayBuffer?e.bytes.buffer:Uint8Array.from(e.bytes).buffer,s=new Uint8Array(await globalThis.crypto.subtle.digest(`SHA-256`,o)),c=Array.from(s,e=>e.toString(16).padStart(2,`0`)).join(``);if(c!==r)throw new w(`Runtime asset ${e.asset} ${t} SHA-256 mismatch: expected ${r}, received ${c}`,n);return Object.freeze({asset:e.asset,stage:t,sha256:c,bytes:e.bytes.byteLength,mediaType:a?e.mimeType?.split(`;`,1)[0]?.trim().toLowerCase():void 0})}var D=class extends Error{code;path;limit;actual;constructor(e,t,n={}){super(t),this.name=`WorkspaceValidationError`,this.code=e,this.path=n.path,this.limit=n.limit,this.actual=n.actual}};const O=Object.freeze({maxFiles:256,maxFileBytes:2097152,maxTotalBytes:8388608,maxPathBytes:1024,caseSensitive:!1});new TextEncoder;const k=/^[a-z][a-z0-9+.-]*:/iu,ie=/[\u0000-\u001f\u007f]/u,A=Object.getPrototypeOf(Uint8Array.prototype);Object.getOwnPropertyDescriptor(A,Symbol.toStringTag).get,Object.getOwnPropertyDescriptor(A,`byteLength`).get,Object.getOwnPropertyDescriptor(A,`byteOffset`).get,Object.getOwnPropertyDescriptor(A,`buffer`).get;function j(e){if(typeof e!=`string`||e.length===0||e.startsWith(`/`)||e.startsWith(`\\`)||k.test(e)||ie.test(e))throw new D(`invalid-path`,`Invalid workspace path: ${e}`,{path:e});let t=e.replaceAll(`\\`,`/`);if(t.split(`/`).some(e=>e.length===0||e===`.`||e===`..`))throw new D(`invalid-path`,`Invalid workspace path: ${e}`,{path:e});return t}const M=String.raw`#ifndef WASM_CLANG_EXT_PB_DS_TREE_POLICY_HPP
#define WASM_CLANG_EXT_PB_DS_TREE_POLICY_HPP

#include <cstddef>

namespace __gnu_pbds {

struct null_type {};
struct rb_tree_tag {};
struct splay_tree_tag {};
struct ov_tree_tag {};

template <typename Node_CItr, typename Node_Itr, typename Cmp_Fn, typename Allocator>
class null_node_update {
public:
	typedef Node_CItr node_const_iterator;
	typedef Node_Itr node_iterator;
	typedef Cmp_Fn cmp_fn;
	typedef Allocator allocator_type;
};

template <typename Node_CItr, typename Node_Itr, typename Cmp_Fn, typename Allocator>
class tree_order_statistics_node_update {
public:
	typedef Node_CItr node_const_iterator;
	typedef Node_Itr node_iterator;
	typedef Cmp_Fn cmp_fn;
	typedef Allocator allocator_type;
};

} // namespace __gnu_pbds

#endif
`,N=String.raw`#ifndef WASM_CLANG_EXT_PB_DS_ASSOC_CONTAINER_HPP
#define WASM_CLANG_EXT_PB_DS_ASSOC_CONTAINER_HPP

#include <algorithm>
#include <cstddef>
#include <functional>
#include <iterator>
#include <map>
#include <memory>
#include <set>
#include <type_traits>
#include <unordered_map>
#include <unordered_set>
#include <utility>
#include <ext/pb_ds/tree_policy.hpp>

namespace __gnu_pbds {

namespace detail {

template <typename Allocator, typename Value>
struct rebind_allocator {
	typedef typename std::allocator_traits<Allocator>::template rebind_alloc<Value> type;
};

template <typename Iterator>
Iterator advance_to_order(Iterator first, Iterator last, std::size_t order) {
	if (order >= static_cast<std::size_t>(std::distance(first, last))) return last;
	std::advance(
		first,
		static_cast<typename std::iterator_traits<Iterator>::difference_type>(order)
	);
	return first;
}

template <
	typename Key,
	typename Mapped,
	typename Hash_Fn,
	typename Eq_Fn,
	typename Allocator
>
struct hash_table_selector {
	typedef std::pair<const Key, Mapped> value_type;
	typedef typename rebind_allocator<Allocator, value_type>::type allocator_type;
	typedef std::unordered_map<Key, Mapped, Hash_Fn, Eq_Fn, allocator_type> type;
};

template <typename Key, typename Hash_Fn, typename Eq_Fn, typename Allocator>
struct hash_table_selector<Key, null_type, Hash_Fn, Eq_Fn, Allocator> {
	typedef typename rebind_allocator<Allocator, Key>::type allocator_type;
	typedef std::unordered_set<Key, Hash_Fn, Eq_Fn, allocator_type> type;
};

} // namespace detail

template <
	typename Key,
	typename Mapped,
	typename Cmp_Fn = std::less<Key>,
	typename Tag = rb_tree_tag,
	template <typename Node_CItr, typename Node_Itr, typename Cmp_Fn_, typename Allocator_>
	class Node_Update = null_node_update,
	typename Allocator = std::allocator<char>
>
class tree {
public:
	typedef Key key_type;
	typedef Mapped mapped_type;
	typedef std::pair<const Key, Mapped> value_type;
	typedef Cmp_Fn cmp_fn;
	typedef Tag container_category;
	typedef Allocator allocator_type;
	typedef std::size_t size_type;

private:
	typedef typename detail::rebind_allocator<Allocator, value_type>::type value_allocator_type;
	typedef std::map<Key, Mapped, Cmp_Fn, value_allocator_type> container_type;

public:
	typedef typename container_type::iterator iterator;
	typedef typename container_type::const_iterator const_iterator;
	typedef typename container_type::iterator point_iterator;
	typedef typename container_type::const_iterator const_point_iterator;
	typedef typename container_type::reverse_iterator reverse_iterator;
	typedef typename container_type::const_reverse_iterator const_reverse_iterator;

	tree() = default;
	explicit tree(const Cmp_Fn& compare) : values_(compare) {}

	template <typename InputIt>
	tree(InputIt first, InputIt last) : values_(first, last) {}

	bool empty() const { return values_.empty(); }
	size_type size() const { return values_.size(); }
	size_type max_size() const { return values_.max_size(); }

	iterator begin() { return values_.begin(); }
	const_iterator begin() const { return values_.begin(); }
	const_iterator cbegin() const { return values_.cbegin(); }
	iterator end() { return values_.end(); }
	const_iterator end() const { return values_.end(); }
	const_iterator cend() const { return values_.cend(); }
	reverse_iterator rbegin() { return values_.rbegin(); }
	const_reverse_iterator rbegin() const { return values_.rbegin(); }
	reverse_iterator rend() { return values_.rend(); }
	const_reverse_iterator rend() const { return values_.rend(); }

	std::pair<iterator, bool> insert(const value_type& value) { return values_.insert(value); }
	std::pair<iterator, bool> insert(value_type&& value) { return values_.insert(std::move(value)); }

	template <typename InputIt>
	void insert(InputIt first, InputIt last) {
		values_.insert(first, last);
	}

	mapped_type& operator[](const key_type& key) { return values_[key]; }
	mapped_type& at(const key_type& key) { return values_.at(key); }
	const mapped_type& at(const key_type& key) const { return values_.at(key); }

	iterator find(const key_type& key) { return values_.find(key); }
	const_iterator find(const key_type& key) const { return values_.find(key); }
	bool contains(const key_type& key) const { return values_.find(key) != values_.end(); }
	size_type count(const key_type& key) const { return values_.count(key); }

	iterator lower_bound(const key_type& key) { return values_.lower_bound(key); }
	const_iterator lower_bound(const key_type& key) const { return values_.lower_bound(key); }
	iterator upper_bound(const key_type& key) { return values_.upper_bound(key); }
	const_iterator upper_bound(const key_type& key) const { return values_.upper_bound(key); }

	size_type erase(const key_type& key) { return values_.erase(key); }
	iterator erase(const_iterator position) { return values_.erase(position); }
	iterator erase(const_iterator first, const_iterator last) { return values_.erase(first, last); }
	void clear() { values_.clear(); }
	void swap(tree& other) { values_.swap(other.values_); }

	iterator find_by_order(size_type order) {
		return detail::advance_to_order(values_.begin(), values_.end(), order);
	}

	const_iterator find_by_order(size_type order) const {
		return detail::advance_to_order(values_.begin(), values_.end(), order);
	}

	size_type order_of_key(const key_type& key) const {
		return static_cast<size_type>(std::distance(values_.begin(), values_.lower_bound(key)));
	}

	void join(tree& other) {
		values_.insert(other.values_.begin(), other.values_.end());
		other.values_.clear();
	}

	void split(const key_type& key, tree& other) {
		iterator first = values_.upper_bound(key);
		other.values_.insert(first, values_.end());
		values_.erase(first, values_.end());
	}

private:
	container_type values_;
};

template <
	typename Key,
	typename Cmp_Fn,
	typename Tag,
	template <typename Node_CItr, typename Node_Itr, typename Cmp_Fn_, typename Allocator_>
	class Node_Update,
	typename Allocator
>
class tree<Key, null_type, Cmp_Fn, Tag, Node_Update, Allocator> {
public:
	typedef Key key_type;
	typedef null_type mapped_type;
	typedef Key value_type;
	typedef Cmp_Fn cmp_fn;
	typedef Tag container_category;
	typedef Allocator allocator_type;
	typedef std::size_t size_type;

private:
	typedef typename detail::rebind_allocator<Allocator, value_type>::type value_allocator_type;
	typedef std::set<Key, Cmp_Fn, value_allocator_type> container_type;

public:
	typedef typename container_type::iterator iterator;
	typedef typename container_type::const_iterator const_iterator;
	typedef typename container_type::iterator point_iterator;
	typedef typename container_type::const_iterator const_point_iterator;
	typedef typename container_type::reverse_iterator reverse_iterator;
	typedef typename container_type::const_reverse_iterator const_reverse_iterator;

	tree() = default;
	explicit tree(const Cmp_Fn& compare) : values_(compare) {}

	template <typename InputIt>
	tree(InputIt first, InputIt last) : values_(first, last) {}

	bool empty() const { return values_.empty(); }
	size_type size() const { return values_.size(); }
	size_type max_size() const { return values_.max_size(); }

	iterator begin() { return values_.begin(); }
	const_iterator begin() const { return values_.begin(); }
	const_iterator cbegin() const { return values_.cbegin(); }
	iterator end() { return values_.end(); }
	const_iterator end() const { return values_.end(); }
	const_iterator cend() const { return values_.cend(); }
	reverse_iterator rbegin() { return values_.rbegin(); }
	const_reverse_iterator rbegin() const { return values_.rbegin(); }
	reverse_iterator rend() { return values_.rend(); }
	const_reverse_iterator rend() const { return values_.rend(); }

	std::pair<iterator, bool> insert(const value_type& value) { return values_.insert(value); }
	std::pair<iterator, bool> insert(value_type&& value) { return values_.insert(std::move(value)); }

	template <typename InputIt>
	void insert(InputIt first, InputIt last) {
		values_.insert(first, last);
	}

	iterator find(const key_type& key) { return values_.find(key); }
	const_iterator find(const key_type& key) const { return values_.find(key); }
	bool contains(const key_type& key) const { return values_.find(key) != values_.end(); }
	size_type count(const key_type& key) const { return values_.count(key); }

	iterator lower_bound(const key_type& key) { return values_.lower_bound(key); }
	const_iterator lower_bound(const key_type& key) const { return values_.lower_bound(key); }
	iterator upper_bound(const key_type& key) { return values_.upper_bound(key); }
	const_iterator upper_bound(const key_type& key) const { return values_.upper_bound(key); }

	size_type erase(const key_type& key) { return values_.erase(key); }
	iterator erase(const_iterator position) { return values_.erase(position); }
	iterator erase(const_iterator first, const_iterator last) { return values_.erase(first, last); }
	void clear() { values_.clear(); }
	void swap(tree& other) { values_.swap(other.values_); }

	iterator find_by_order(size_type order) {
		return detail::advance_to_order(values_.begin(), values_.end(), order);
	}

	const_iterator find_by_order(size_type order) const {
		return detail::advance_to_order(values_.begin(), values_.end(), order);
	}

	size_type order_of_key(const key_type& key) const {
		return static_cast<size_type>(std::distance(values_.begin(), values_.lower_bound(key)));
	}

	void join(tree& other) {
		values_.insert(other.values_.begin(), other.values_.end());
		other.values_.clear();
	}

	void split(const key_type& key, tree& other) {
		iterator first = values_.upper_bound(key);
		other.values_.insert(first, values_.end());
		values_.erase(first, values_.end());
	}

private:
	container_type values_;
};

template <
	typename Key,
	typename Mapped,
	typename Hash_Fn = std::hash<Key>,
	typename Eq_Fn = std::equal_to<Key>,
	typename Comb_Hash_Fn = void,
	typename Resize_Policy = void,
	bool Store_Hash = false,
	typename Allocator = std::allocator<char>
>
using gp_hash_table = typename detail::hash_table_selector<
	Key,
	Mapped,
	Hash_Fn,
	Eq_Fn,
	Allocator
>::type;

template <
	typename Key,
	typename Mapped,
	typename Hash_Fn = std::hash<Key>,
	typename Eq_Fn = std::equal_to<Key>,
	typename Comb_Hash_Fn = void,
	typename Resize_Policy = void,
	bool Store_Hash = false,
	typename Allocator = std::allocator<char>
>
using cc_hash_table = typename detail::hash_table_selector<
	Key,
	Mapped,
	Hash_Fn,
	Eq_Fn,
	Allocator
>::type;

} // namespace __gnu_pbds

#endif
`,P=String.raw`#ifndef WASM_CLANG_EXT_PB_DS_HASH_POLICY_HPP
#define WASM_CLANG_EXT_PB_DS_HASH_POLICY_HPP

#include <cstddef>

namespace __gnu_pbds {

template <typename Size_Type = std::size_t>
class direct_mask_range_hashing {
public:
	typedef Size_Type size_type;
};

template <typename Size_Type = std::size_t>
class direct_mod_range_hashing {
public:
	typedef Size_Type size_type;
};

template <typename Size_Type = std::size_t>
class linear_probe_fn {
public:
	typedef Size_Type size_type;
};

template <typename Size_Type = std::size_t>
class quadratic_probe_fn {
public:
	typedef Size_Type size_type;
};

class hash_exponential_size_policy {};
class hash_prime_size_policy {};

template <bool External_Load_Access = false, typename Size_Type = std::size_t>
class hash_load_check_resize_trigger {
public:
	typedef Size_Type size_type;
	explicit hash_load_check_resize_trigger(float = 0.125, float = 0.5) {}
};

template <bool External_Load_Access = false, typename Size_Type = std::size_t>
class cc_hash_max_collision_check_resize_trigger {
public:
	typedef Size_Type size_type;
	explicit cc_hash_max_collision_check_resize_trigger(float = 0.5) {}
};

template <
	typename Size_Policy = hash_exponential_size_policy,
	typename Trigger_Policy = hash_load_check_resize_trigger<>,
	bool External_Size_Access = false,
	typename Size_Type = std::size_t
>
class hash_standard_resize_policy {
public:
	typedef Size_Type size_type;
	hash_standard_resize_policy() = default;
	explicit hash_standard_resize_policy(const Size_Policy&) {}
	hash_standard_resize_policy(const Size_Policy&, const Trigger_Policy&) {}
};

} // namespace __gnu_pbds

#endif
`,F=String.raw`#ifndef WASM_CLANG_EXT_PB_DS_PRIORITY_QUEUE_HPP
#define WASM_CLANG_EXT_PB_DS_PRIORITY_QUEUE_HPP

#include <algorithm>
#include <cstddef>
#include <functional>
#include <memory>
#include <queue>
#include <utility>
#include <vector>

namespace __gnu_pbds {

struct pairing_heap_tag {};
struct binary_heap_tag {};
struct binomial_heap_tag {};
struct rc_binomial_heap_tag {};
struct thin_heap_tag {};

namespace detail {

template <typename Allocator, typename Value>
struct priority_queue_rebind_allocator {
	typedef typename std::allocator_traits<Allocator>::template rebind_alloc<Value> type;
};

} // namespace detail

template <
	typename Value_Type,
	typename Cmp_Fn = std::less<Value_Type>,
	typename Tag = pairing_heap_tag,
	typename Allocator = std::allocator<char>
>
class priority_queue {
public:
	typedef Value_Type value_type;
	typedef Cmp_Fn cmp_fn;
	typedef Tag container_category;
	typedef Allocator allocator_type;
	typedef std::size_t size_type;
	typedef value_type& reference;
	typedef const value_type& const_reference;

private:
	typedef typename detail::priority_queue_rebind_allocator<Allocator, value_type>::type value_allocator_type;
	typedef std::vector<value_type, value_allocator_type> container_type;

public:
	typedef typename container_type::iterator point_iterator;
	typedef typename container_type::const_iterator const_point_iterator;

	priority_queue() : values_(), compare_() {
		std::make_heap(values_.begin(), values_.end(), compare_);
	}

	explicit priority_queue(const Cmp_Fn& compare) : values_(), compare_(compare) {
		std::make_heap(values_.begin(), values_.end(), compare_);
	}

	template <typename InputIt>
	priority_queue(InputIt first, InputIt last) : values_(first, last), compare_() {
		std::make_heap(values_.begin(), values_.end(), compare_);
	}

	bool empty() const { return values_.empty(); }
	size_type size() const { return values_.size(); }
	const_reference top() const { return values_.front(); }
	void clear() { values_.clear(); }
	void swap(priority_queue& other) {
		values_.swap(other.values_);
		std::swap(compare_, other.compare_);
	}

	point_iterator push(const_reference value) {
		values_.push_back(value);
		std::push_heap(values_.begin(), values_.end(), compare_);
		return values_.empty() ? values_.end() : values_.begin();
	}

	void pop() {
		std::pop_heap(values_.begin(), values_.end(), compare_);
		values_.pop_back();
	}

	void modify(point_iterator position, const_reference value) {
		if (position == values_.end()) return;
		*position = value;
		std::make_heap(values_.begin(), values_.end(), compare_);
	}

	void erase(point_iterator position) {
		if (position == values_.end()) return;
		values_.erase(position);
		std::make_heap(values_.begin(), values_.end(), compare_);
	}

	void join(priority_queue& other) {
		values_.insert(values_.end(), other.values_.begin(), other.values_.end());
		other.values_.clear();
		std::make_heap(values_.begin(), values_.end(), compare_);
	}

private:
	container_type values_;
	Cmp_Fn compare_;
};

} // namespace __gnu_pbds

#endif
`,I=String.raw`#ifndef WASM_CLANG_EXT_ROPE
#define WASM_CLANG_EXT_ROPE

#include <algorithm>
#include <cstddef>
#include <iosfwd>
#include <iterator>
#include <memory>
#include <ostream>
#include <string>
#include <utility>

namespace __gnu_cxx {

template <typename CharT, typename Alloc = std::allocator<CharT>>
class rope {
public:
	typedef CharT value_type;
	typedef Alloc allocator_type;
	typedef std::basic_string<CharT, std::char_traits<CharT>, Alloc> string_type;
	typedef typename string_type::traits_type traits_type;
	typedef typename string_type::size_type size_type;
	typedef typename string_type::difference_type difference_type;
	typedef typename string_type::reference reference;
	typedef typename string_type::const_reference const_reference;
	typedef typename string_type::iterator iterator;
	typedef typename string_type::const_iterator const_iterator;

	static const size_type npos = string_type::npos;

	rope() = default;
	rope(const rope&) = default;
	rope(rope&&) = default;
	rope& operator=(const rope&) = default;
	rope& operator=(rope&&) = default;

	rope(const CharT* value) : data_(value ? value : empty_c_str()) {}
	rope(const CharT* value, size_type count) : data_(value, count) {}
	rope(size_type count, CharT value) : data_(count, value) {}
	rope(const string_type& value) : data_(value) {}
	rope(string_type&& value) : data_(std::move(value)) {}

	template <typename InputIt>
	rope(InputIt first, InputIt last) : data_(first, last) {}

	bool empty() const { return data_.empty(); }
	size_type size() const { return data_.size(); }
	size_type length() const { return data_.length(); }
	size_type max_size() const { return data_.max_size(); }
	void clear() { data_.clear(); }

	const CharT* c_str() const { return data_.c_str(); }
	const string_type& str() const { return data_; }

	iterator begin() { return data_.begin(); }
	const_iterator begin() const { return data_.begin(); }
	const_iterator cbegin() const { return data_.cbegin(); }
	iterator end() { return data_.end(); }
	const_iterator end() const { return data_.end(); }
	const_iterator cend() const { return data_.cend(); }

	reference operator[](size_type index) { return data_[index]; }
	const_reference operator[](size_type index) const { return data_[index]; }
	reference at(size_type index) { return data_.at(index); }
	const_reference at(size_type index) const { return data_.at(index); }
	reference mutable_reference_at(size_type index) { return data_.at(index); }

	void push_back(CharT value) { data_.push_back(value); }
	void pop_back() { data_.pop_back(); }

	rope& append(const rope& value) {
		data_.append(value.data_);
		return *this;
	}

	rope& append(const CharT* value) {
		data_.append(value ? value : empty_c_str());
		return *this;
	}

	rope& append(const CharT* value, size_type count) {
		data_.append(value, count);
		return *this;
	}

	rope& append(size_type count, CharT value) {
		data_.append(count, value);
		return *this;
	}

	rope& insert(size_type position, const rope& value) {
		data_.insert(position, value.data_);
		return *this;
	}

	rope& insert(size_type position, const CharT* value) {
		data_.insert(position, value ? value : empty_c_str());
		return *this;
	}

	rope& insert(size_type position, const CharT* value, size_type count) {
		data_.insert(position, value, count);
		return *this;
	}

	rope& insert(size_type position, size_type count, CharT value) {
		data_.insert(position, count, value);
		return *this;
	}

	rope& erase(size_type position = 0, size_type count = npos) {
		data_.erase(position, count);
		return *this;
	}

	rope& replace(size_type position, size_type count, const rope& value) {
		data_.replace(position, count, value.data_);
		return *this;
	}

	rope& replace(size_type position, size_type count, const CharT* value) {
		data_.replace(position, count, value ? value : empty_c_str());
		return *this;
	}

	rope substr(size_type position = 0, size_type count = npos) const {
		return rope(data_.substr(position, count));
	}

	size_type copy(size_type position, size_type count, CharT* target) const {
		if (position > data_.size()) return 0;
		const size_type copied = std::min(count, data_.size() - position);
		traits_type::copy(target, data_.data() + position, copied);
		return copied;
	}

	int compare(const rope& value) const { return data_.compare(value.data_); }

	rope& operator+=(const rope& value) { return append(value); }
	rope& operator+=(const CharT* value) { return append(value); }
	rope& operator+=(CharT value) {
		push_back(value);
		return *this;
	}

private:
	static const CharT* empty_c_str() {
		static const CharT empty[1] = {};
		return empty;
	}

	string_type data_;
};

template <typename CharT, typename Alloc>
rope<CharT, Alloc> operator+(rope<CharT, Alloc> left, const rope<CharT, Alloc>& right) {
	left += right;
	return left;
}

template <typename CharT, typename Alloc>
bool operator==(const rope<CharT, Alloc>& left, const rope<CharT, Alloc>& right) {
	return left.compare(right) == 0;
}

template <typename CharT, typename Alloc>
bool operator!=(const rope<CharT, Alloc>& left, const rope<CharT, Alloc>& right) {
	return !(left == right);
}

template <typename CharT, typename Alloc>
bool operator<(const rope<CharT, Alloc>& left, const rope<CharT, Alloc>& right) {
	return left.compare(right) < 0;
}

template <typename CharT, typename Alloc>
std::basic_ostream<CharT>& operator<<(
	std::basic_ostream<CharT>& output,
	const rope<CharT, Alloc>& value
) {
	return output << value.str();
}

typedef rope<char> crope;
typedef rope<wchar_t> wrope;

} // namespace __gnu_cxx

#endif
`,L=String.raw`#ifndef WASM_CLANG_SETJMP_H
#define WASM_CLANG_SETJMP_H

#ifdef __cplusplus
extern "C" {
#endif

typedef long jmp_buf[32];
int setjmp(jmp_buf);
__attribute__((noreturn)) void longjmp(jmp_buf, int);

#ifdef __cplusplus
}
#endif

#endif
`,R=String.raw`#ifndef WASM_CLANG_BITS_STDCPP_H
#define WASM_CLANG_BITS_STDCPP_H

#include <algorithm>
#include <array>
#include <bitset>
#include <cassert>
#include <cctype>
#include <cerrno>
#include <cfloat>
#include <climits>
#include <cmath>
#include <cstddef>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <deque>
#include <functional>
#include <iomanip>
#include <iostream>
#include <iterator>
#include <limits>
#include <list>
#include <map>
#include <memory>
#include <numeric>
#include <queue>
#include <set>
#include <sstream>
#include <stack>
#include <string>
#include <string_view>
#include <tuple>
#include <type_traits>
#include <unordered_map>
#include <unordered_set>
#include <utility>
#include <vector>

#endif
`,z=String.raw`#ifndef WASM_CLANG_BITS_EXTCXX_H
#define WASM_CLANG_BITS_EXTCXX_H

#include <bits/stdc++.h>
#include <ext/hash_map>
#include <ext/hash_set>
#include <ext/rope>
#include <ext/pb_ds/assoc_container.hpp>
#include <ext/pb_ds/hash_policy.hpp>
#include <ext/pb_ds/priority_queue.hpp>
#include <ext/pb_ds/tree_policy.hpp>

#endif
`,ae=[{path:`include/setjmp.h`,contents:L},{path:`include/bits/stdc++.h`,contents:R},{path:`include/bits/extc++.h`,contents:z},{path:`include/c++/v1/ext/rope`,contents:I},{path:`include/c++/v1/ext/pb_ds/tree_policy.hpp`,contents:M},{path:`include/c++/v1/ext/pb_ds/assoc_container.hpp`,contents:N},{path:`include/c++/v1/ext/pb_ds/hash_policy.hpp`,contents:P},{path:`include/c++/v1/ext/pb_ds/priority_queue.hpp`,contents:F}],oe=[`include/c++/v1/ext/pb_ds`,`include/bits`],se=(e,t)=>{let n=e.replace(/\/+$/,``),r=t.replace(/^\/+/,``);return n?`${n}/${r}`:r};function ce(e,t=``){for(let n of oe)e.mkdirTree(se(t,n));for(let n of ae)e.writeFile(se(t,n.path),n.contents)}var le=class{inJson=!1;rawText=[];unbalancedBraces=0;inString=!1;inEscape=0;textDecoder=new TextDecoder;insert(e){if(!this.inJson&&e===123&&(this.inJson=!0,this.rawText=[]),!this.inJson)return null;if(this.rawText.push(e),this.inString)this.inEscape?(e===75&&(this.inEscape+=4),--this.inEscape):e===92?this.inEscape=1:e===34&&(this.inString=!1);else if(e===123)this.unbalancedBraces+=1;else if(e===125){if(--this.unbalancedBraces,this.unbalancedBraces===0)return this.inJson=!1,this.textDecoder.decode(new Uint8Array(this.rawText))}else e===34&&(this.inString=!0);return null}};const B=e=>e.byteLength>=2&&e[0]===31&&e[1]===139;async function ue(e,t,n,r){let i=e.getReader(),a=r,o=!1;if(a?.aborted){o=!0;let e=V(a);try{Promise.resolve(i.cancel(e)).catch(()=>{})}catch{}try{i.releaseLock()}catch{}throw e}let s,c=a?new Promise((e,t)=>{s=()=>{if(o)return;o=!0;let e=V(a);try{Promise.resolve(i.cancel(e)).catch(()=>{})}catch{}t(e)},a.addEventListener(`abort`,s,{once:!0})}):void 0,l=new Uint8Array(Math.min(65536,n)),u=0,d=!1,f,p;try{for(H(a);;){let e=i.read(),{done:r,value:o}=c?await Promise.race([e,c]):await e;if(H(a),r)break;if(!o)continue;let s=u+o.byteLength;if(s>n)throw Error(`Runtime asset ${t} decompressed size exceeds the ${n} byte limit`);if(s>l.byteLength){let e=Math.min(n,Math.max(s,Math.max(l.byteLength*2,1))),t=new Uint8Array(e);t.set(l.subarray(0,u)),l=t}l.set(o,u),u=s}H(a),f=l.subarray(0,u),d=!0}catch(e){if(a?.aborted)throw V(a);if(!o){o=!0;try{Promise.resolve(i.cancel(e)).catch(()=>{})}catch{}}throw e}finally{s&&a?.removeEventListener(`abort`,s);try{i.releaseLock()}catch(e){d&&(p={error:e})}}if(p)throw p.error;return f}function V(e){return e.reason??new DOMException(`Runtime asset load aborted`,`AbortError`)}function H(e){if(e?.aborted)throw V(e)}async function U(e,t=`runtime asset`,n=134217728,r){if(!Number.isSafeInteger(n)||n<0)throw Error(`Runtime asset decompression limit must be a non-negative safe integer`);if(H(r),!B(e)){if(e.byteLength>n)throw Error(`Runtime asset ${t} decompressed size exceeds the ${n} byte limit`);return e}if(typeof DecompressionStream!=`function`)throw Error(`Failed to decompress runtime asset ${t}: DecompressionStream('gzip') is unavailable`);try{let i=Uint8Array.from(e),a=new ReadableStream({start(e){e.enqueue(i),e.close()}}),o=new DecompressionStream(`gzip`);return await ue(a.pipeThrough({readable:o.readable,writable:o.writable}),t,n,r)}catch(e){throw r?.aborted?V(r):Error(`Failed to decompress runtime asset ${t}: ${e instanceof Error?e.message:String(e)}`)}}Object.freeze({name:`emscripten`,version:`6.0.0`,revision:`afa15e0c56d1292e073c2c91bafc1d5e0cdf0dd3`}),Object.freeze({name:`clang`,version:`22.1.8`,revision:`ca7933e47d3a3451d81e72ac174dcb5aa28b59d1`});const de=Object.freeze([`-D__SSE__=1`,`-D__SSE2__=1`,`-D__SSE3__=1`,`-D__SSSE3__=1`,`-D__SSE4_1__=1`,`-D__SSE4_2__=1`,`-D__AVX__=1`,`-D__AVX2__=1`]),fe=Object.freeze({"immintrin.h":`/*
 * Copyright 2020 The Emscripten Authors.  All rights reserved.
 * Emscripten is available under two separate licenses, the MIT license and the
 * University of Illinois/NCSA Open Source License.  Both these licenses can be
 * found in the LICENSE file.
 */
#ifndef __emscripten_immintrin_h__
#define __emscripten_immintrin_h__

#ifdef __SSE__
#include <xmmintrin.h>
#endif

#ifdef __SSE2__
#include <emmintrin.h>
#endif

#ifdef __SSE3__
#include <pmmintrin.h>
#endif

#ifdef __SSSE3__
#include <tmmintrin.h>
#endif

#ifdef __SSE4_1__
#include <smmintrin.h>
#endif

#ifdef __SSE4_2__
#include <nmmintrin.h>
#endif

#ifdef __AVX__
#include <avxintrin.h>
#endif

#ifdef __AVX2__
#include <avx2intrin.h>
#endif

#endif /* __emscripten_immintrin_h__ */
`,"xmmintrin.h":`/*
 * Copyright 2020 The Emscripten Authors.  All rights reserved.
 * Emscripten is available under two separate licenses, the MIT license and the
 * University of Illinois/NCSA Open Source License.  Both these licenses can be
 * found in the LICENSE file.
 */
#ifndef __emscripten_xmmintrin_h__
#define __emscripten_xmmintrin_h__

#include <wasm_simd128.h>

#include <limits.h>
#include <math.h>
#include <string.h>

#ifndef __SSE__
#error "SSE instruction set not enabled"
#endif

#ifdef WASM_SIMD_COMPAT_SLOW
#define DIAGNOSE_SLOW diagnose_if(1, "Instruction emulated via slow path.", "warning")
#else
#define DIAGNOSE_SLOW
#endif

// Emscripten SIMD support doesn't support MMX/float32x2/__m64.
// However, we support loading and storing 2-vectors, so
// recognize the type at least.
typedef float __m64 __attribute__((__vector_size__(8), __aligned__(8)));
typedef __f32x4 __m128;
typedef v128_t __m128i;

#define __f32x4_shuffle(__a, __b, __c0, __c1, __c2, __c3)                   \\
  ((v128_t)(__builtin_shufflevector((__f32x4)(__a), (__f32x4)(__b), __c0,   \\
                                    __c1, __c2, __c3)))

// This is defined as a macro because __builtin_shufflevector requires its
// mask argument to be a compile-time constant.
#define _mm_shuffle_ps(__a, __b, __mask) __extension__ ({ \\
  ((__m128)__f32x4_shuffle(__a, __b, \\
                           (((__mask) >> 0) & 0x3) + 0, \\
                           (((__mask) >> 2) & 0x3) + 0, \\
                           (((__mask) >> 4) & 0x3) + 4, \\
                           (((__mask) >> 6) & 0x3) + 4)); })

static __inline__ __m128 __attribute__((__always_inline__, __nodebug__))
_mm_set_ps(float __z, float __y, float __x, float __w)
{
  return (__m128)wasm_f32x4_make(__w, __x, __y, __z);
}

static __inline__ __m128 __attribute__((__always_inline__, __nodebug__))
_mm_setr_ps(float __z, float __y, float __x, float __w)
{
  return (__m128)wasm_f32x4_make(__z, __y, __x, __w);
}

static __inline__ __m128 __attribute__((__always_inline__, __nodebug__))
_mm_set_ss(float __w)
{
  return (__m128)wasm_f32x4_make(__w, 0, 0, 0);
}

static __inline__ __m128 __attribute__((__always_inline__, __nodebug__))
_mm_set_ps1(float __w)
{
  return (__m128)wasm_f32x4_splat(__w);
}

#define _mm_set1_ps _mm_set_ps1

static __inline__ __m128 __attribute__((__always_inline__, __nodebug__))
_mm_setzero_ps(void)
{
  return (__m128)wasm_f32x4_const(0.f, 0.f, 0.f, 0.f);
}

static __inline__ __m128 __attribute__((__always_inline__, __nodebug__))
_mm_load_ps(const float *__p)
{
  return *(__m128*)__p;
}

static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, DIAGNOSE_SLOW))
_mm_loadl_pi(__m128 __a, const void /*__m64*/ *__p)
{
  return (__m128)wasm_v128_load64_lane(__p, (v128_t)__a, 0);
}

static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, DIAGNOSE_SLOW))
_mm_loadh_pi(__m128 __a, const void /*__m64*/ *__p)
{
  return (__m128)wasm_v128_load64_lane(__p, (v128_t)__a, 1);
}

static __inline__ __m128 __attribute__((__always_inline__, __nodebug__))
_mm_loadr_ps(const float *__p)
{
  __m128 __v = _mm_load_ps(__p);
  return (__m128)__f32x4_shuffle(__v, __v, 3, 2, 1, 0);
}

static __inline__ __m128 __attribute__((__always_inline__, __nodebug__))
_mm_loadu_ps(const float *__p)
{
  return (__m128)wasm_v128_load(__p);
}

static __inline__ __m128 __attribute__((__always_inline__, __nodebug__))
_mm_load_ps1(const float *__p)
{
  return (__m128)wasm_v32x4_load_splat(__p);
}
#define _mm_load1_ps _mm_load_ps1

static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, DIAGNOSE_SLOW))
_mm_load_ss(const float *__p)
{
  return (__m128)wasm_v128_load32_zero(__p);
}

static __inline__ void __attribute__((__always_inline__, __nodebug__, DIAGNOSE_SLOW))
_mm_storel_pi(__m64 *__p, __m128 __a)
{
  wasm_v128_store64_lane((void*)__p, (v128_t)__a, 0);
}

static __inline__ void __attribute__((__always_inline__, __nodebug__, DIAGNOSE_SLOW))
_mm_storeh_pi(__m64 *__p, __m128 __a)
{
  wasm_v128_store64_lane((void*)__p, (v128_t)__a, 1);
}

static __inline__ void __attribute__((__always_inline__, __nodebug__))
_mm_store_ps(float *__p, __m128 __a)
{
  *(__m128 *)__p = __a;
}
// No NTA cache hint available.
#define _mm_stream_ps _mm_store_ps

#define _MM_HINT_T0 3
#define _MM_HINT_T1 2
#define _MM_HINT_T2 1
#define _MM_HINT_NTA 0
// No prefetch available, dummy it out.
static __inline__ void __attribute__((__always_inline__, __nodebug__))
_mm_prefetch(const void *__p, int __i)
{
  ((void)__p);
  ((void)__i);
}

static __inline__ void __attribute__((__always_inline__, __nodebug__))
_mm_sfence(void)
{
  // Wasm/SharedArrayBuffer memory model is sequentially consistent.
  // Perhaps a future version of the spec can provide a related fence.
  __sync_synchronize();
}

#define _MM_SHUFFLE(w, z, y, x) (((w) << 6) | ((z) << 4) | ((y) << 2) | (x))

static __inline__ void __attribute__((__always_inline__, __nodebug__))
_mm_storer_ps(float *__p, __m128 __a)
{
  _mm_store_ps(__p, _mm_shuffle_ps(__a, __a, _MM_SHUFFLE(0, 1, 2, 3)));
}

static __inline__ void __attribute__((__always_inline__, __nodebug__))
_mm_store_ps1(float *__p, __m128 __a)
{
  _mm_store_ps(__p, _mm_shuffle_ps(__a, __a, _MM_SHUFFLE(0, 0, 0, 0)));
}
#define _mm_store1_ps _mm_store_ps1

static __inline__ void __attribute__((__always_inline__, __nodebug__))
_mm_store_ss(float *__p, __m128 __a)
{
  wasm_v128_store32_lane((void*)__p, (v128_t)__a, 0);
}

static __inline__ void __attribute__((__always_inline__, __nodebug__))
_mm_storeu_ps(float *__p, __m128 __a)
{
  struct __unaligned {
    __m128 __v;
  } __attribute__((__packed__, __may_alias__));
  ((struct __unaligned *)__p)->__v = __a;
}

static __inline__ int __attribute__((__always_inline__, __nodebug__))
_mm_movemask_ps(__m128 __a)
{
  return (int)wasm_i32x4_bitmask((v128_t)__a);
}

static __inline__ __m128 __attribute__((__always_inline__, __nodebug__))
_mm_move_ss(__m128 __a, __m128 __b)
{
  return (__m128)__f32x4_shuffle(__a, __b, 4, 1, 2, 3);
}

static __inline__ __m128 __attribute__((__always_inline__, __nodebug__))
_mm_add_ps(__m128 __a, __m128 __b)
{
  return (__m128)wasm_f32x4_add((v128_t)__a, (v128_t)__b);
}

static __inline__ __m128 __attribute__((__always_inline__, __nodebug__))
_mm_add_ss(__m128 __a, __m128 __b)
{
  return _mm_move_ss(__a, _mm_add_ps(__a, __b));
}

static __inline__ __m128 __attribute__((__always_inline__, __nodebug__))
_mm_sub_ps(__m128 __a, __m128 __b)
{
  return (__m128)wasm_f32x4_sub((v128_t)__a, (v128_t)__b);
}

static __inline__ __m128 __attribute__((__always_inline__, __nodebug__))
_mm_sub_ss(__m128 __a, __m128 __b)
{
  return _mm_move_ss(__a, _mm_sub_ps(__a, __b));
}

static __inline__ __m128 __attribute__((__always_inline__, __nodebug__))
_mm_mul_ps(__m128 __a, __m128 __b)
{
  return (__m128)wasm_f32x4_mul((v128_t)__a, (v128_t)__b);
}

static __inline__ __m128 __attribute__((__always_inline__, __nodebug__))
_mm_mul_ss(__m128 __a, __m128 __b)
{
  return _mm_move_ss(__a, _mm_mul_ps(__a, __b));
}

static __inline__ __m128 __attribute__((__always_inline__, __nodebug__))
_mm_div_ps(__m128 __a, __m128 __b)
{
  return (__m128)wasm_f32x4_div((v128_t)__a, (v128_t)__b);
}

static __inline__ __m128 __attribute__((__always_inline__, __nodebug__))
_mm_div_ss(__m128 __a, __m128 __b)
{
  return _mm_move_ss(__a, _mm_div_ps(__a, __b));
}

static __inline__ __m128 __attribute__((__always_inline__, __nodebug__))
_mm_min_ps(__m128 __a, __m128 __b)
{
//  return (__m128)wasm_f32x4_pmin((v128_t)__a, (v128_t)__b); // TODO: Migrate to this, once it works in VMs
  return (__m128)wasm_v128_bitselect((v128_t)__a, (v128_t)__b, (v128_t)wasm_f32x4_lt((v128_t)__a, (v128_t)__b));
}

static __inline__ __m128 __attribute__((__always_inline__, __nodebug__))
_mm_min_ss(__m128 __a, __m128 __b)
{
  return _mm_move_ss(__a, _mm_min_ps(__a, __b));
}

static __inline__ __m128 __attribute__((__always_inline__, __nodebug__))
_mm_max_ps(__m128 __a, __m128 __b)
{
//  return (__m128)wasm_f32x4_pmax((v128_t)__a, (v128_t)__b); // TODO: Migrate to this, once it works in VMs
  return (__m128)wasm_v128_bitselect((v128_t)__a, (v128_t)__b, (v128_t)wasm_f32x4_gt((v128_t)__a, (v128_t)__b));
}

static __inline__ __m128 __attribute__((__always_inline__, __nodebug__))
_mm_max_ss(__m128 __a, __m128 __b)
{
  return _mm_move_ss(__a, _mm_max_ps(__a, __b));
}

static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, DIAGNOSE_SLOW))
_mm_rcp_ps(__m128 __a)
{
    return (__m128)wasm_f32x4_div((v128_t)_mm_set1_ps(1.0f), (v128_t)__a);
}

static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, DIAGNOSE_SLOW))
_mm_rcp_ss(__m128 __a)
{
  return _mm_move_ss(__a, _mm_rcp_ps(__a));
}

static __inline__ __m128 __attribute__((__always_inline__, __nodebug__))
_mm_sqrt_ps(__m128 __a)
{
  return (__m128)wasm_f32x4_sqrt((v128_t)__a);
}

static __inline__ __m128 __attribute__((__always_inline__, __nodebug__))
_mm_sqrt_ss(__m128 __a)
{
  return _mm_move_ss(__a, _mm_sqrt_ps(__a));
}

#define _mm_rsqrt_ps(__a) _mm_rcp_ps(_mm_sqrt_ps((__a)))

static __inline__ __m128 __attribute__((__always_inline__, __nodebug__))
_mm_rsqrt_ss(__m128 __a)
{
  return _mm_move_ss(__a, _mm_rsqrt_ps(__a));
}

static __inline__ __m128 __attribute__((__always_inline__, __nodebug__))
_mm_unpackhi_ps(__m128 __a, __m128 __b)
{
  return (__m128)__f32x4_shuffle(__a, __b, 2, 6, 3, 7);
}

static __inline__ __m128 __attribute__((__always_inline__, __nodebug__))
_mm_unpacklo_ps(__m128 __a, __m128 __b)
{
  return (__m128)__f32x4_shuffle(__a, __b, 0, 4, 1, 5);
}

static __inline__ __m128 __attribute__((__always_inline__, __nodebug__))
_mm_movehl_ps(__m128 __a, __m128 __b)
{
  return (__m128)__f32x4_shuffle(__a, __b, 6, 7, 2, 3);
}

static __inline__ __m128 __attribute__((__always_inline__, __nodebug__))
_mm_movelh_ps(__m128 __a, __m128 __b)
{
  return (__m128)__f32x4_shuffle(__a, __b, 0, 1, 4, 5);
}

#define _MM_TRANSPOSE4_PS(row0, row1, row2, row3) \\
  do { \\
    __m128 __row0 = (row0); \\
    __m128 __row1 = (row1); \\
    __m128 __row2 = (row2); \\
    __m128 __row3 = (row3); \\
    __m128 __tmp0 = _mm_unpacklo_ps(__row0, __row1); \\
    __m128 __tmp1 = _mm_unpackhi_ps(__row0, __row1); \\
    __m128 __tmp2 = _mm_unpacklo_ps(__row2, __row3); \\
    __m128 __tmp3 = _mm_unpackhi_ps(__row2, __row3); \\
    (row0) = _mm_movelh_ps(__tmp0, __tmp2); \\
    (row1) = _mm_movehl_ps(__tmp2, __tmp0); \\
    (row2) = _mm_movelh_ps(__tmp1, __tmp3); \\
    (row3) = _mm_movehl_ps(__tmp3, __tmp1); \\
  } while (0)

static __inline__ __m128 __attribute__((__always_inline__, __nodebug__))
_mm_cmplt_ps(__m128 __a, __m128 __b)
{
  return (__m128)wasm_f32x4_lt((v128_t)__a, (v128_t)__b);
}

static __inline__ __m128 __attribute__((__always_inline__, __nodebug__))
_mm_cmplt_ss(__m128 __a, __m128 __b)
{
  return _mm_move_ss(__a, _mm_cmplt_ps(__a, __b));
}

static __inline__ __m128 __attribute__((__always_inline__, __nodebug__))
_mm_cmple_ps(__m128 __a, __m128 __b)
{
  return (__m128)wasm_f32x4_le((v128_t)__a, (v128_t)__b);
}

static __inline__ __m128 __attribute__((__always_inline__, __nodebug__))
_mm_cmple_ss(__m128 __a, __m128 __b)
{
  return _mm_move_ss(__a, _mm_cmple_ps(__a, __b));
}

static __inline__ __m128 __attribute__((__always_inline__, __nodebug__))
_mm_cmpeq_ps(__m128 __a, __m128 __b)
{
  return (__m128)wasm_f32x4_eq((v128_t)__a, (v128_t)__b);
}

static __inline__ __m128 __attribute__((__always_inline__, __nodebug__))
_mm_cmpeq_ss(__m128 __a, __m128 __b)
{
  return _mm_move_ss(__a, _mm_cmpeq_ps(__a, __b));
}

static __inline__ __m128 __attribute__((__always_inline__, __nodebug__))
_mm_cmpge_ps(__m128 __a, __m128 __b)
{
  return (__m128)wasm_f32x4_ge((v128_t)__a, (v128_t)__b);
}

static __inline__ __m128 __attribute__((__always_inline__, __nodebug__))
_mm_cmpge_ss(__m128 __a, __m128 __b)
{
  return _mm_move_ss(__a, _mm_cmpge_ps(__a, __b));
}

static __inline__ __m128 __attribute__((__always_inline__, __nodebug__))
_mm_cmpgt_ps(__m128 __a, __m128 __b)
{
  return (__m128)wasm_f32x4_gt((v128_t)__a, (v128_t)__b);
}

static __inline__ __m128 __attribute__((__always_inline__, __nodebug__))
_mm_cmpgt_ss(__m128 __a, __m128 __b)
{
  return _mm_move_ss(__a, _mm_cmpgt_ps(__a, __b));
}

static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, DIAGNOSE_SLOW)) _mm_cmpord_ps(__m128 __a, __m128 __b)
{
  return (__m128)wasm_v128_and(wasm_f32x4_eq((v128_t)__a, (v128_t)__a),
                               wasm_f32x4_eq((v128_t)__b, (v128_t)__b));
}

static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, DIAGNOSE_SLOW)) _mm_cmpord_ss(__m128 __a, __m128 __b)
{
  return _mm_move_ss(__a, _mm_cmpord_ps(__a, __b));
}

static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, DIAGNOSE_SLOW)) _mm_cmpunord_ps(__m128 __a, __m128 __b)
{
  return (__m128)wasm_v128_or(wasm_f32x4_ne((v128_t)__a, (v128_t)__a),
                              wasm_f32x4_ne((v128_t)__b, (v128_t)__b));
}

static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, DIAGNOSE_SLOW)) _mm_cmpunord_ss(__m128 __a, __m128 __b)
{
  return _mm_move_ss(__a, _mm_cmpunord_ps(__a, __b));
}

static __inline__ __m128 __attribute__((__always_inline__, __nodebug__))
_mm_and_ps(__m128 __a, __m128 __b)
{
  return (__m128)wasm_v128_and((v128_t)__a, (v128_t)__b);
}

static __inline__ __m128 __attribute__((__always_inline__, __nodebug__))
_mm_andnot_ps(__m128 __a, __m128 __b)
{
  return (__m128)wasm_v128_andnot((v128_t)__b, (v128_t)__a);
}

static __inline__ __m128 __attribute__((__always_inline__, __nodebug__))
_mm_or_ps(__m128 __a, __m128 __b)
{
  return (__m128)wasm_v128_or((v128_t)__a, (v128_t)__b);
}

static __inline__ __m128 __attribute__((__always_inline__, __nodebug__))
_mm_xor_ps(__m128 __a, __m128 __b)
{
  return (__m128)wasm_v128_xor((v128_t)__a, (v128_t)__b);
}

static __inline__ __m128 __attribute__((__always_inline__, __nodebug__))
_mm_cmpneq_ps(__m128 __a, __m128 __b)
{
  return (__m128)wasm_f32x4_ne((v128_t)__a, (v128_t)__b);
}

static __inline__ __m128 __attribute__((__always_inline__, __nodebug__))
_mm_cmpneq_ss(__m128 __a, __m128 __b)
{
  return _mm_move_ss(__a, _mm_cmpneq_ps(__a, __b));
}

static __inline__ __m128 __attribute__((__always_inline__, __nodebug__))
_mm_cmpnge_ps(__m128 __a, __m128 __b)
{
  return (__m128)wasm_v128_not((v128_t)_mm_cmpge_ps(__a, __b));
}

static __inline__ __m128 __attribute__((__always_inline__, __nodebug__))
_mm_cmpnge_ss(__m128 __a, __m128 __b)
{
  return _mm_move_ss(__a, _mm_cmpnge_ps(__a, __b));
}

static __inline__ __m128 __attribute__((__always_inline__, __nodebug__))
_mm_cmpngt_ps(__m128 __a, __m128 __b)
{
  return (__m128)wasm_v128_not((v128_t)_mm_cmpgt_ps(__a, __b));
}

static __inline__ __m128 __attribute__((__always_inline__, __nodebug__))
_mm_cmpngt_ss(__m128 __a, __m128 __b)
{
  return _mm_move_ss(__a, _mm_cmpngt_ps(__a, __b));
}

static __inline__ __m128 __attribute__((__always_inline__, __nodebug__))
_mm_cmpnle_ps(__m128 __a, __m128 __b)
{
  return (__m128)wasm_v128_not((v128_t)_mm_cmple_ps(__a, __b));
}

static __inline__ __m128 __attribute__((__always_inline__, __nodebug__))
_mm_cmpnle_ss(__m128 __a, __m128 __b)
{
  return _mm_move_ss(__a, _mm_cmpnle_ps(__a, __b));
}

static __inline__ __m128 __attribute__((__always_inline__, __nodebug__))
_mm_cmpnlt_ps(__m128 __a, __m128 __b)
{
  return (__m128)wasm_v128_not((v128_t)_mm_cmplt_ps(__a, __b));
}

static __inline__ __m128 __attribute__((__always_inline__, __nodebug__))
_mm_cmpnlt_ss(__m128 __a, __m128 __b)
{
  return _mm_move_ss(__a, _mm_cmpnlt_ps(__a, __b));
}

static __inline__ int __attribute__((__always_inline__, __nodebug__, DIAGNOSE_SLOW))
_mm_comieq_ss(__m128 __a, __m128 __b)
{
  return wasm_f32x4_extract_lane((v128_t)__a, 0) == wasm_f32x4_extract_lane((v128_t)__b, 0);
}

static __inline__ int __attribute__((__always_inline__, __nodebug__, DIAGNOSE_SLOW))
_mm_comige_ss(__m128 __a, __m128 __b)
{
  return wasm_f32x4_extract_lane((v128_t)__a, 0) >= wasm_f32x4_extract_lane((v128_t)__b, 0);
}

static __inline__ int __attribute__((__always_inline__, __nodebug__, DIAGNOSE_SLOW))
_mm_comigt_ss(__m128 __a, __m128 __b)
{
  return wasm_f32x4_extract_lane((v128_t)__a, 0) > wasm_f32x4_extract_lane((v128_t)__b, 0);
}

static __inline__ int __attribute__((__always_inline__, __nodebug__, DIAGNOSE_SLOW))
_mm_comile_ss(__m128 __a, __m128 __b)
{
  return wasm_f32x4_extract_lane((v128_t)__a, 0) <= wasm_f32x4_extract_lane((v128_t)__b, 0);
}

static __inline__ int __attribute__((__always_inline__, __nodebug__, DIAGNOSE_SLOW))
_mm_comilt_ss(__m128 __a, __m128 __b)
{
  return wasm_f32x4_extract_lane((v128_t)__a, 0) < wasm_f32x4_extract_lane((v128_t)__b, 0);
}

static __inline__ int __attribute__((__always_inline__, __nodebug__, DIAGNOSE_SLOW))
_mm_comineq_ss(__m128 __a, __m128 __b)
{
  return wasm_f32x4_extract_lane((v128_t)__a, 0) != wasm_f32x4_extract_lane((v128_t)__b, 0);
}

static __inline__ int __attribute__((__always_inline__, __nodebug__, DIAGNOSE_SLOW))
_mm_ucomieq_ss(__m128 __a, __m128 __b)
{
  return wasm_f32x4_extract_lane((v128_t)__a, 0) == wasm_f32x4_extract_lane((v128_t)__b, 0);
}

static __inline__ int __attribute__((__always_inline__, __nodebug__, DIAGNOSE_SLOW))
_mm_ucomige_ss(__m128 __a, __m128 __b)
{
  return wasm_f32x4_extract_lane((v128_t)__a, 0) >= wasm_f32x4_extract_lane((v128_t)__b, 0);
}

static __inline__ int __attribute__((__always_inline__, __nodebug__, DIAGNOSE_SLOW))
_mm_ucomigt_ss(__m128 __a, __m128 __b)
{
  return wasm_f32x4_extract_lane((v128_t)__a, 0) > wasm_f32x4_extract_lane((v128_t)__b, 0);
}

static __inline__ int __attribute__((__always_inline__, __nodebug__, DIAGNOSE_SLOW))
_mm_ucomile_ss(__m128 __a, __m128 __b)
{
  return wasm_f32x4_extract_lane((v128_t)__a, 0) <= wasm_f32x4_extract_lane((v128_t)__b, 0);
}

static __inline__ int __attribute__((__always_inline__, __nodebug__, DIAGNOSE_SLOW))
_mm_ucomilt_ss(__m128 __a, __m128 __b)
{
  return wasm_f32x4_extract_lane((v128_t)__a, 0) < wasm_f32x4_extract_lane((v128_t)__b, 0);
}

static __inline__ int __attribute__((__always_inline__, __nodebug__, DIAGNOSE_SLOW))
_mm_ucomineq_ss(__m128 __a, __m128 __b)
{
  return wasm_f32x4_extract_lane((v128_t)__a, 0) != wasm_f32x4_extract_lane((v128_t)__b, 0);
}

static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, DIAGNOSE_SLOW))
_mm_cvtsi32_ss(__m128 __a, int __b)
{
  __f32x4 __v = (__f32x4)__a;
  __v[0] = (float)__b;
  return (__m128)__v;
}
#define _mm_cvt_si2ss _mm_cvtsi32_ss

static __inline__ int __attribute__((__always_inline__, __nodebug__, DIAGNOSE_SLOW)) _mm_cvtss_si32(__m128 __a)
{
  float e = ((__f32x4)__a)[0];
  if (e < 2147483648.0f && e >= -2147483648.0f && (lrint(e) != 0 || fabsf(e) < 2.f))
    return lrint(e);
  else
    return (int)0x80000000;
}
#define _mm_cvt_ss2si _mm_cvtss_si32

static __inline__ int __attribute__((__always_inline__, __nodebug__, DIAGNOSE_SLOW)) _mm_cvttss_si32(__m128 __a)
{
  float e = ((__f32x4)__a)[0];
  if (e < 2147483648.0f && e >= -2147483648.0f && (lrint(e) != 0 || fabsf(e) < 2.f))
    return (int)e;
  else
    return (int)0x80000000;
}
#define _mm_cvtt_ss2si _mm_cvttss_si32

static __inline__ __m128 __attribute__((__always_inline__, __nodebug__, DIAGNOSE_SLOW))
_mm_cvtsi64_ss(__m128 __a, long long __b)
{
  __f32x4 __v = (__f32x4)__a;
  __v[0] = (float)__b;
  return (__m128)__v;
}

static __inline__ long long __attribute__((__always_inline__, __nodebug__, DIAGNOSE_SLOW))
_mm_cvtss_si64(__m128 __a)
{
  float e = ((__f32x4)__a)[0];
  long long x = llrintf(e);
  if (e <= LLONG_MAX && e >= LLONG_MIN && (x != 0 || fabsf(e) < 2.f))
    return x;
  else
    return 0x8000000000000000LL;
}

static __inline__ long long __attribute__((__always_inline__, __nodebug__, DIAGNOSE_SLOW))
_mm_cvttss_si64(__m128 __a)
{
  float e = ((__f32x4)__a)[0];
  long long x = llrintf(e);
  if (e <= LLONG_MAX && e >= LLONG_MIN && (x != 0 || fabsf(e) < 2.f))
    return (long long)e;
  else
    return 0x8000000000000000LL;
}

static __inline__ float __attribute__((__always_inline__, __nodebug__))
_mm_cvtss_f32(__m128 __a)
{
  return (float)((__f32x4)__a)[0];
}

#define _mm_malloc(__size, __align) memalign((__align), (__size))
#define _mm_free free

static __inline__ __m128 __attribute__((__always_inline__, __nodebug__))
_mm_undefined()
{
  __m128 val;
  return val;
}

static __inline__ __m128 __attribute__((__always_inline__, __nodebug__))
_mm_undefined_ps()
{
  __m128 val;
  return val;
}

#define _MM_EXCEPT_MASK       0x003f
#define _MM_EXCEPT_INVALID    0x0001
#define _MM_EXCEPT_DENORM     0x0002
#define _MM_EXCEPT_DIV_ZERO   0x0004
#define _MM_EXCEPT_OVERFLOW   0x0008
#define _MM_EXCEPT_UNDERFLOW  0x0010
#define _MM_EXCEPT_INEXACT    0x0020

#define _MM_MASK_MASK         0x1f80
#define _MM_MASK_INVALID      0x0080
#define _MM_MASK_DENORM       0x0100
#define _MM_MASK_DIV_ZERO     0x0200
#define _MM_MASK_OVERFLOW     0x0400
#define _MM_MASK_UNDERFLOW    0x0800
#define _MM_MASK_INEXACT      0x1000

#define _MM_ROUND_MASK        0x6000
#define _MM_ROUND_NEAREST     0x0000
#define _MM_ROUND_DOWN        0x2000
#define _MM_ROUND_UP          0x4000
#define _MM_ROUND_TOWARD_ZERO 0x6000

#define _MM_FLUSH_ZERO_MASK   0x8000
#define _MM_FLUSH_ZERO_ON     0x8000
#define _MM_FLUSH_ZERO_OFF    0x0000

static __inline__ int __attribute__((__always_inline__, __nodebug__))
_mm_getcsr()
{
  return _MM_MASK_INEXACT | _MM_MASK_DENORM | _MM_MASK_DIV_ZERO | _MM_MASK_OVERFLOW | _MM_MASK_UNDERFLOW | _MM_MASK_INVALID
    | _MM_ROUND_NEAREST | _MM_FLUSH_ZERO_OFF;
}

#define _MM_GET_EXCEPTION_STATE() (_mm_getcsr() & _MM_EXCEPT_MASK)
#define _MM_GET_EXCEPTION_MASK() (_mm_getcsr() & _MM_MASK_MASK)
#define _MM_GET_ROUNDING_MODE() (_mm_getcsr() & _MM_ROUND_MASK)
#define _MM_GET_FLUSH_ZERO_MODE() (_mm_getcsr() & _MM_FLUSH_ZERO_MASK)

// Unavailable functions:
// void _MM_SET_EXCEPTION_STATE(unsigned int __a);
// void _MM_SET_EXCEPTION_MASK(unsigned int __a);
// void _MM_GET_ROUNDING_MODE(unsigned int __a);
// void _MM_GET_FLUSH_ZERO_MODE(unsigned int __a);

#endif /* __emscripten_xmmintrin_h__ */
`,"emmintrin.h":`/*
 * Copyright 2020 The Emscripten Authors.  All rights reserved.
 * Emscripten is available under two separate licenses, the MIT license and the
 * University of Illinois/NCSA Open Source License.  Both these licenses can be
 * found in the LICENSE file.
 */
#ifndef __emscripten_emmintrin_h__
#define __emscripten_emmintrin_h__

#ifndef __SSE2__
#error "SSE2 instruction set not enabled"
#endif

#include <xmmintrin.h>

// Alias different (functionally) equivalent intrinsics.
#define _mm_set_epi64x _mm_set_epi64
#define _mm_cvtsd_si64x _mm_cvtsd_si64
#define _mm_cvtsi128_si64x _mm_cvtsi128_si64
#define _mm_cvtsi64x_sd _mm_cvtsi64_sd
#define _mm_cvtsi64x_si128 _mm_cvtsi64_si128
#define _mm_cvttsd_si64x _mm_cvttsd_si64
#define _mm_store_pd1 _mm_store1_pd

typedef __f64x2 __m128d;

static __inline__ __m128d __attribute__((__always_inline__, __nodebug__))
_mm_move_sd(__m128d __a, __m128d __b)
{
  return (__m128d){ __b[0], __a[1] };
}

static __inline__ __m128d __attribute__((__always_inline__, __nodebug__))
_mm_add_pd(__m128d __a, __m128d __b)
{
  return (__m128d)wasm_f64x2_add((v128_t)__a, (v128_t)__b);
}

static __inline__ __m128d __attribute__((__always_inline__, __nodebug__))
_mm_add_sd(__m128d __a, __m128d __b)
{
  return _mm_move_sd(__a, _mm_add_pd(__a, __b));
}

static __inline__ __m128d __attribute__((__always_inline__, __nodebug__))
_mm_sub_pd(__m128d __a, __m128d __b)
{
  return (__m128d)wasm_f64x2_sub((v128_t)__a, (v128_t)__b);
}

static __inline__ __m128d __attribute__((__always_inline__, __nodebug__))
_mm_sub_sd(__m128d __a, __m128d __b)
{
  return _mm_move_sd(__a, _mm_sub_pd(__a, __b));
}

static __inline__ __m128d __attribute__((__always_inline__, __nodebug__))
_mm_mul_pd(__m128d __a, __m128d __b)
{
  return (__m128d)wasm_f64x2_mul((v128_t)__a, (v128_t)__b);
}

static __inline__ __m128d __attribute__((__always_inline__, __nodebug__))
_mm_mul_sd(__m128d __a, __m128d __b)
{
  return _mm_move_sd(__a, _mm_mul_pd(__a, __b));
}

static __inline__ __m128d __attribute__((__always_inline__, __nodebug__))
_mm_div_pd(__m128d __a, __m128d __b)
{
  return (__m128d)wasm_f64x2_div((v128_t)__a, (v128_t)__b);
}

static __inline__ __m128d __attribute__((__always_inline__, __nodebug__))
_mm_div_sd(__m128d __a, __m128d __b)
{
  return _mm_move_sd(__a, _mm_div_pd(__a, __b));
}

static __inline__ __m128d __attribute__((__always_inline__, __nodebug__))
_mm_sqrt_pd(__m128d __a)
{
  return (__m128d)wasm_f64x2_sqrt((v128_t)__a);
}

static __inline__ __m128d __attribute__((__always_inline__, __nodebug__))
_mm_sqrt_sd(__m128d __a, __m128d __b)
{
  return _mm_move_sd(__a, _mm_sqrt_pd(__b));
}

static __inline__ __m128d __attribute__((__always_inline__, __nodebug__))
_mm_min_pd(__m128d __a, __m128d __b)
{
//  return (__m128d)wasm_f32x4_pmin((v128_t)__a, (v128_t)__b); // TODO: Migrate to this, once it works in VMs
  return (__m128d)wasm_v128_bitselect((v128_t)__a, (v128_t)__b, (v128_t)wasm_f64x2_lt((v128_t)__a, (v128_t)__b));
}

static __inline__ __m128d __attribute__((__always_inline__, __nodebug__))
_mm_min_sd(__m128d __a, __m128d __b)
{
  return _mm_move_sd(__a, _mm_min_pd(__a, __b));
}

static __inline__ __m128d __attribute__((__always_inline__, __nodebug__))
_mm_max_pd(__m128d __a, __m128d __b)
{
//  return (__m128)wasm_f32x4_pmax((v128_t)__a, (v128_t)__b); // TODO: Migrate to this, once it works in VMs
  return (__m128d)wasm_v128_bitselect((v128_t)__a, (v128_t)__b, (v128_t)wasm_f64x2_gt((v128_t)__a, (v128_t)__b));
}

static __inline__ __m128d __attribute__((__always_inline__, __nodebug__))
_mm_max_sd(__m128d __a, __m128d __b)
{
  return _mm_move_sd(__a, _mm_max_pd(__a, __b));
}

static __inline__ __m128d __attribute__((__always_inline__, __nodebug__))
_mm_and_pd(__m128d __a, __m128d __b)
{
  return (__m128d)wasm_v128_and((v128_t)__a, (v128_t)__b);
}

static __inline__ __m128d __attribute__((__always_inline__, __nodebug__))
_mm_andnot_pd(__m128d __a, __m128d __b)
{
  return (__m128d)wasm_v128_andnot((v128_t)__b, (v128_t)__a);
}

static __inline__ __m128d __attribute__((__always_inline__, __nodebug__))
_mm_or_pd(__m128d __a, __m128d __b)
{
  return (__m128d)wasm_v128_or((v128_t)__a, (v128_t)__b);
}

static __inline__ __m128d __attribute__((__always_inline__, __nodebug__))
_mm_xor_pd(__m128d __a, __m128d __b)
{
  return (__m128d)wasm_v128_xor((v128_t)__a, (v128_t)__b);
}

static __inline__ __m128d __attribute__((__always_inline__, __nodebug__))
_mm_cmpeq_pd(__m128d __a, __m128d __b)
{
  return (__m128d)wasm_f64x2_eq((v128_t)__a, (v128_t)__b);
}

static __inline__ __m128d __attribute__((__always_inline__, __nodebug__))
_mm_cmplt_pd(__m128d __a, __m128d __b)
{
  return (__m128d)wasm_f64x2_lt((v128_t)__a, (v128_t)__b);
}

static __inline__ __m128d __attribute__((__always_inline__, __nodebug__))
_mm_cmple_pd(__m128d __a, __m128d __b)
{
  return (__m128d)wasm_f64x2_le((v128_t)__a, (v128_t)__b);
}

static __inline__ __m128d __attribute__((__always_inline__, __nodebug__))
_mm_cmpgt_pd(__m128d __a, __m128d __b)
{
  return (__m128d)wasm_f64x2_gt((v128_t)__a, (v128_t)__b);
}

static __inline__ __m128d __attribute__((__always_inline__, __nodebug__))
_mm_cmpge_pd(__m128d __a, __m128d __b)
{
  return (__m128d)wasm_f64x2_ge((v128_t)__a, (v128_t)__b);
}

static __inline__ __m128d __attribute__((__always_inline__, __nodebug__))
_mm_cmpord_pd(__m128d __a, __m128d __b)
{
  return (__m128d)wasm_v128_and(wasm_f64x2_eq((v128_t)__a, (v128_t)__a),
                                wasm_f64x2_eq((v128_t)__b, (v128_t)__b));
}

static __inline__ __m128d __attribute__((__always_inline__, __nodebug__))
_mm_cmpunord_pd(__m128d __a, __m128d __b)
{
  return (__m128d)wasm_v128_or(wasm_f64x2_ne((v128_t)__a, (v128_t)__a),
                               wasm_f64x2_ne((v128_t)__b, (v128_t)__b));
}

static __inline__ __m128d __attribute__((__always_inline__, __nodebug__))
_mm_cmpneq_pd(__m128d __a, __m128d __b)
{
  return (__m128d)wasm_f64x2_ne((v128_t)__a, (v128_t)__b);
}

static __inline__ __m128d __attribute__((__always_inline__, __nodebug__))
_mm_cmpnlt_pd(__m128d __a, __m128d __b)
{
  return (__m128d)wasm_v128_not((v128_t)_mm_cmplt_pd(__a, __b));
}

static __inline__ __m128d __attribute__((__always_inline__, __nodebug__))
_mm_cmpnle_pd(__m128d __a, __m128d __b)
{
  return (__m128d)wasm_v128_not((v128_t)_mm_cmple_pd(__a, __b));
}

static __inline__ __m128d __attribute__((__always_inline__, __nodebug__))
_mm_cmpngt_pd(__m128d __a, __m128d __b)
{
  return (__m128d)wasm_v128_not((v128_t)_mm_cmpgt_pd(__a, __b));
}

static __inline__ __m128d __attribute__((__always_inline__, __nodebug__))
_mm_cmpnge_pd(__m128d __a, __m128d __b)
{
  return (__m128d)wasm_v128_not((v128_t)_mm_cmpge_pd(__a, __b));
}

static __inline__ __m128d __attribute__((__always_inline__, __nodebug__))
_mm_cmpeq_sd(__m128d __a, __m128d __b)
{
  return _mm_move_sd(__a, _mm_cmpeq_pd(__a, __b));
}

static __inline__ __m128d __attribute__((__always_inline__, __nodebug__))
_mm_cmplt_sd(__m128d __a, __m128d __b)
{
  return _mm_move_sd(__a, _mm_cmplt_pd(__a, __b));
}

static __inline__ __m128d __attribute__((__always_inline__, __nodebug__))
_mm_cmple_sd(__m128d __a, __m128d __b)
{
  return _mm_move_sd(__a, _mm_cmple_pd(__a, __b));
}

static __inline__ __m128d __attribute__((__always_inline__, __nodebug__))
_mm_cmpgt_sd(__m128d __a, __m128d __b)
{
  return _mm_move_sd(__a, _mm_cmpgt_pd(__a, __b));
}

static __inline__ __m128d __attribute__((__always_inline__, __nodebug__))
_mm_cmpge_sd(__m128d __a, __m128d __b)
{
  return _mm_move_sd(__a, _mm_cmpge_pd(__a, __b));
}

static __inline__ __m128d __attribute__((__always_inline__, __nodebug__))
_mm_cmpord_sd(__m128d __a, __m128d __b)
{
  return _mm_move_sd(__a, _mm_cmpord_pd(__a, __b));
}

static __inline__ __m128d __attribute__((__always_inline__, __nodebug__))
_mm_cmpunord_sd(__m128d __a, __m128d __b)
{
  return _mm_move_sd(__a, _mm_cmpunord_pd(__a, __b));
}

static __inline__ __m128d __attribute__((__always_inline__, __nodebug__))
_mm_cmpneq_sd(__m128d __a, __m128d __b)
{
  return _mm_move_sd(__a, _mm_cmpneq_pd(__a, __b));
}

static __inline__ __m128d __attribute__((__always_inline__, __nodebug__))
_mm_cmpnlt_sd(__m128d __a, __m128d __b)
{
  return _mm_move_sd(__a, _mm_cmpnlt_pd(__a, __b));
}

static __inline__ __m128d __attribute__((__always_inline__, __nodebug__))
_mm_cmpnle_sd(__m128d __a, __m128d __b)
{
  return _mm_move_sd(__a, _mm_cmpnle_pd(__a, __b));
}

static __inline__ __m128d __attribute__((__always_inline__, __nodebug__))
_mm_cmpngt_sd(__m128d __a, __m128d __b)
{
  return _mm_move_sd(__a, _mm_cmpngt_pd(__a, __b));
}

static __inline__ __m128d __attribute__((__always_inline__, __nodebug__))
_mm_cmpnge_sd(__m128d __a, __m128d __b)
{
  return _mm_move_sd(__a, _mm_cmpnge_pd(__a, __b));
}

static __inline__ int __attribute__((__always_inline__, __nodebug__))
_mm_comieq_sd(__m128d __a, __m128d __b)
{
  return wasm_f64x2_extract_lane((v128_t)__a, 0) == wasm_f64x2_extract_lane((v128_t)__b, 0);
}

static __inline__ int __attribute__((__always_inline__, __nodebug__))
_mm_comilt_sd(__m128d __a, __m128d __b)
{
  return wasm_f64x2_extract_lane((v128_t)__a, 0) < wasm_f64x2_extract_lane((v128_t)__b, 0);
}

static __inline__ int __attribute__((__always_inline__, __nodebug__))
_mm_comile_sd(__m128d __a, __m128d __b)
{
  return wasm_f64x2_extract_lane((v128_t)__a, 0) <= wasm_f64x2_extract_lane((v128_t)__b, 0);
}

static __inline__ int __attribute__((__always_inline__, __nodebug__))
_mm_comigt_sd(__m128d __a, __m128d __b)
{
  return wasm_f64x2_extract_lane((v128_t)__a, 0) > wasm_f64x2_extract_lane((v128_t)__b, 0);
}

static __inline__ int __attribute__((__always_inline__, __nodebug__))
_mm_comige_sd(__m128d __a, __m128d __b)
{
  return wasm_f64x2_extract_lane((v128_t)__a, 0) >= wasm_f64x2_extract_lane((v128_t)__b, 0);
}

static __inline__ int __attribute__((__always_inline__, __nodebug__))
_mm_comineq_sd(__m128d __a, __m128d __b)
{
  return wasm_f64x2_extract_lane((v128_t)__a, 0) != wasm_f64x2_extract_lane((v128_t)__b, 0);
}

static __inline__ int __attribute__((__always_inline__, __nodebug__))
_mm_ucomieq_sd(__m128d __a, __m128d __b)
{
  return wasm_f64x2_extract_lane((v128_t)__a, 0) == wasm_f64x2_extract_lane((v128_t)__b, 0);
}

static __inline__ int __attribute__((__always_inline__, __nodebug__))
_mm_ucomilt_sd(__m128d __a, __m128d __b)
{
  return wasm_f64x2_extract_lane((v128_t)__a, 0) < wasm_f64x2_extract_lane((v128_t)__b, 0);
}

static __inline__ int __attribute__((__always_inline__, __nodebug__))
_mm_ucomile_sd(__m128d __a, __m128d __b)
{
  return wasm_f64x2_extract_lane((v128_t)__a, 0) <= wasm_f64x2_extract_lane((v128_t)__b, 0);
}

static __inline__ int __attribute__((__always_inline__, __nodebug__))
_mm_ucomigt_sd(__m128d __a, __m128d __b)
{
  return wasm_f64x2_extract_lane((v128_t)__a, 0) > wasm_f64x2_extract_lane((v128_t)__b, 0);
}

static __inline__ int __attribute__((__always_inline__, __nodebug__))
_mm_ucomige_sd(__m128d __a, __m128d __b)
{
  return wasm_f64x2_extract_lane((v128_t)__a, 0) >= wasm_f64x2_extract_lane((v128_t)__b, 0);
}

static __inline__ int __attribute__((__always_inline__, __nodebug__))
_mm_ucomineq_sd(__m128d __a, __m128d __b)
{
  return wasm_f64x2_extract_lane((v128_t)__a, 0) != wasm_f64x2_extract_lane((v128_t)__b, 0);
}

static __inline__ __m128 __attribute__((__always_inline__, __nodebug__))
_mm_cvtpd_ps(__m128d __a)
{
  return (__m128)wasm_f32x4_demote_f64x2_zero((v128_t)__a);
}

static __inline__ __m128d __attribute__((__always_inline__, __nodebug__))
_mm_cvtps_pd(__m128 __a)
{
  return (__m128d)wasm_f64x2_promote_low_f32x4((v128_t)__a);
}

static __inline__ __m128d __attribute__((__always_inline__, __nodebug__))
_mm_cvtepi32_pd(__m128i __a)
{
  return (__m128d)wasm_f64x2_convert_low_i32x4((v128_t)__a);
}

static __inline__ __m128i __attribute__((__always_inline__, __nodebug__))
_mm_cvtpd_epi32(__m128d __a)
{
  // TODO: OPTIMIZE!
  int m[2];
  for(int i = 0; i < 2; ++i)
  {
    double e = __a[i];
    int x = lrint(e);
    if (e <= INT_MAX && e >= INT_MIN && (x != 0 || fabs(e) < 2.0))
      m[i] = x;
    else
      m[i] = (int)0x80000000;
  }
  return wasm_i32x4_make(m[0], m[1], 0, 0);
}

static __inline__ int __attribute__((__always_inline__, __nodebug__))
_mm_cvtsd_si32(__m128d __a)
{
  // TODO: OPTIMIZE!
  double e = __a[0];
  int x = lrint(e);
  if (e <= INT_MAX && e >= INT_MIN && (x != 0 || fabs(e) < 2.0))
    return x;
  else
    return (int)0x80000000;
}

static __inline__ __m128 __attribute__((__always_inline__, __nodebug__))
_mm_cvtsd_ss(__m128 __a, __m128d __b)
{
  __a[0] = __b[0];
  return __a;
}

static __inline__ __m128d __attribute__((__always_inline__, __nodebug__))
_mm_cvtsi32_sd(__m128d __a, int __b)
{
  __a[0] = __b;
  return __a;
}

static __inline__ __m128d __attribute__((__always_inline__, __nodebug__))
_mm_cvtss_sd(__m128d __a, __m128 __b)
{
  __a[0] = __b[0];
  return __a;
}

static __inline__ __m128i __attribute__((__always_inline__, __nodebug__))
_mm_cvttpd_epi32(__m128d __a)
{
  // TODO: OPTIMIZE!
  int m[2];
  for(int i = 0; i < 2; ++i)
  {
    double elem = __a[i];
    if (elem < 2147483648.0 && elem >= -2147483648.0 && (lrint(elem) != 0 || fabs(elem) < 2.0))
      // Use the trapping instruction here since we have explicit bounds checks
      // above.
      m[i] = __builtin_wasm_trunc_s_i32_f64(elem);
    else
      m[i] = (int)0x80000000;
  }
  return wasm_i32x4_make(m[0], m[1], 0, 0);
}

static __inline__ int __attribute__((__always_inline__, __nodebug__))
_mm_cvttsd_si32(__m128d __a)
{
  // TODO: OPTIMIZE!
  double elem = __a[0];
  if (elem < 2147483648.0 && elem >= -2147483648.0 && (lrint(elem) != 0 || fabs(elem) < 2.0))
    // Use the trapping instruction here since we have explicit bounds checks
    // above.
    return __builtin_wasm_trunc_s_i32_f64(elem);
  else
    return (int)0x80000000;
}

static __inline__ double __attribute__((__always_inline__, __nodebug__))
_mm_cvtsd_f64(__m128d __a)
{
  return wasm_f64x2_extract_lane((v128_t)__a, 0);
}

static __inline__ __m128d __attribute__((__always_inline__, __nodebug__))
_mm_load_pd(double const *__dp)
{
  return *(__m128d*)__dp;
}

static __inline__ __m128d __attribute__((__always_inline__, __nodebug__))
_mm_load1_pd(double const *__dp)
{
  return (__m128d)wasm_v64x2_load_splat(__dp);
}

#define        _mm_load_pd1(dp)        _mm_load1_pd(dp)

static __inline__ __m128d __attribute__((__always_inline__, __nodebug__))
_mm_loadr_pd(double const *__p)
{
  __m128d __u = *(__m128d*)__p; // aligned load
  return (__m128d)wasm_i64x2_shuffle((v128_t)__u, (v128_t)__u, 1, 0);
}

static __inline__ __m128d __attribute__((__always_inline__, __nodebug__))
_mm_loadu_pd(double const *__dp)
{
  struct __loadu_pd {
    __m128d __v;
  } __attribute__((__packed__, __may_alias__));
  return ((struct __loadu_pd*)__dp)->__v;
}

static __inline__ __m128d __attribute__((__always_inline__, __nodebug__))
_mm_load_sd(double const *__p)
{
  return (__m128d)wasm_v128_load64_zero((const void*)__p);
}

static __inline__ __m128d __attribute__((__always_inline__, __nodebug__))
_mm_loadh_pd(__m128d __a, double const *__dp)
{
  return (__m128d)wasm_v128_load64_lane((const void*)__dp, (v128_t)__a, 1);
}

static __inline__ __m128d __attribute__((__always_inline__, __nodebug__))
_mm_loadl_pd(__m128d __a, double const *__dp)
{
  return (__m128d)wasm_v128_load64_lane((const void*)__dp, (v128_t)__a, 0);
}

static __inline__ __m128d __attribute__((__always_inline__, __nodebug__))
_mm_set_sd(double __w)
{
  return (__m128d)wasm_f64x2_make(__w, 0);
}

static __inline__ __m128d __attribute__((__always_inline__, __nodebug__))
_mm_set1_pd(double __w)
{
  return (__m128d)wasm_f64x2_splat(__w);
}

static __inline__ __m128d __attribute__((__always_inline__, __nodebug__))
_mm_set_pd(double __c1, double __c0)
{
  return (__m128d)wasm_f64x2_make(__c0, __c1);
}

static __inline__ __m128d __attribute__((__always_inline__, __nodebug__))
_mm_setr_pd(double __c0, double __c1)
{
  return (__m128d)wasm_f64x2_make(__c0, __c1);
}

static __inline__ __m128d __attribute__((__always_inline__, __nodebug__))
_mm_setzero_pd(void)
{
  return (__m128d)wasm_f64x2_const(0.0, 0.0);
}

static __inline__ void __attribute__((__always_inline__, __nodebug__))
_mm_store_sd(double *__dp, __m128d __a)
{
  wasm_v128_store64_lane((void*)__dp, (v128_t)__a, 0);
}

static __inline__ void __attribute__((__always_inline__, __nodebug__))
_mm_store1_pd(double *__dp, __m128d __a)
{
  struct __mm_store1_pd_struct {
    double __u[2];
  } __attribute__((__packed__, __may_alias__));
  ((struct __mm_store1_pd_struct*)__dp)->__u[0] = __a[0];
  ((struct __mm_store1_pd_struct*)__dp)->__u[1] = __a[0];
}

static __inline__ void __attribute__((__always_inline__, __nodebug__))
_mm_store_pd(double *__dp, __m128d __a)
{
  *(__m128d *)__dp = __a;
}

static __inline__ void __attribute__((__always_inline__, __nodebug__))
_mm_storeu_pd(double *__dp, __m128d __a)
{
  struct __unaligned {
    __m128d __v;
  } __attribute__((__packed__, __may_alias__));

  ((struct __unaligned *)__dp)->__v = __a;
}

static __inline__ void __attribute__((__always_inline__, __nodebug__))
_mm_storer_pd(double *__p, __m128d __a)
{
  *(__m128d *)__p = (__m128d)wasm_i64x2_shuffle((v128_t)__a, (v128_t)__a, 1, 0);
}

static __inline__ void __attribute__((__always_inline__, __nodebug__))
_mm_storeh_pd(double *__dp, __m128d __a)
{
  wasm_v128_store64_lane((void*)__dp, (v128_t)__a, 1);
}

static __inline__ void __attribute__((__always_inline__, __nodebug__))
_mm_storel_pd(double *__dp, __m128d __a)
{
  wasm_v128_store64_lane((void*)__dp, (v128_t)__a, 0);
}

static __inline__ __m128i __attribute__((__always_inline__, __nodebug__))
_mm_add_epi8(__m128i __a, __m128i __b)
{
  return (__m128i)wasm_i8x16_add((v128_t)__a, (v128_t)__b);
}

static __inline__ __m128i __attribute__((__always_inline__, __nodebug__))
_mm_add_epi16(__m128i __a, __m128i __b)
{
  return (__m128i)wasm_i16x8_add((v128_t)__a, (v128_t)__b);
}

static __inline__ __m128i __attribute__((__always_inline__, __nodebug__))
_mm_add_epi32(__m128i __a, __m128i __b)
{
  return (__m128i)wasm_i32x4_add((v128_t)__a, (v128_t)__b);
}

static __inline__ __m128i __attribute__((__always_inline__, __nodebug__))
_mm_add_epi64(__m128i __a, __m128i __b)
{
  return (__m128i)wasm_i64x2_add((v128_t)__a, (v128_t)__b);
}

static __inline__ __m128i __attribute__((__always_inline__, __nodebug__))
_mm_adds_epi8(__m128i __a, __m128i __b)
{
  return (__m128i)wasm_i8x16_add_saturate((v128_t)__a, (v128_t)__b);
}

static __inline__ __m128i __attribute__((__always_inline__, __nodebug__))
_mm_adds_epi16(__m128i __a, __m128i __b)
{
  return (__m128i)wasm_i16x8_add_saturate((v128_t)__a, (v128_t)__b);
}

static __inline__ __m128i __attribute__((__always_inline__, __nodebug__))
_mm_adds_epu8(__m128i __a, __m128i __b)
{
  return (__m128i)wasm_u8x16_add_saturate((v128_t)__a, (v128_t)__b);
}

static __inline__ __m128i __attribute__((__always_inline__, __nodebug__))
_mm_adds_epu16(__m128i __a, __m128i __b)
{
  return (__m128i)wasm_u16x8_add_saturate((v128_t)__a, (v128_t)__b);
}

static __inline__ __m128i __attribute__((__always_inline__, __nodebug__))
_mm_avg_epu8(__m128i __a, __m128i __b)
{
  return (__m128i)wasm_u8x16_avgr((v128_t)__a, (v128_t)__b);
}

static __inline__ __m128i __attribute__((__always_inline__, __nodebug__))
_mm_avg_epu16(__m128i __a, __m128i __b)
{
  return (__m128i)wasm_u16x8_avgr((v128_t)__a, (v128_t)__b);
}

static __inline__ __m128i __attribute__((__always_inline__, __nodebug__))
_mm_madd_epi16(__m128i __a, __m128i __b)
{
  return (__m128i)wasm_i32x4_dot_i16x8((v128_t)__a, (v128_t)__b);
}

static __inline__ __m128i __attribute__((__always_inline__, __nodebug__))
_mm_max_epi16(__m128i __a, __m128i __b)
{
  return (__m128i)wasm_i16x8_max((v128_t)__a, (v128_t)__b);
}

static __inline__ __m128i __attribute__((__always_inline__, __nodebug__))
_mm_max_epu8(__m128i __a, __m128i __b)
{
  return (__m128i)wasm_u8x16_max((v128_t)__a, (v128_t)__b);
}

static __inline__ __m128i __attribute__((__always_inline__, __nodebug__))
_mm_min_epi16(__m128i __a, __m128i __b)
{
  return (__m128i)wasm_i16x8_min((v128_t)__a, (v128_t)__b);
}

static __inline__ __m128i __attribute__((__always_inline__, __nodebug__))
_mm_min_epu8(__m128i __a, __m128i __b)
{
  return (__m128i)wasm_u8x16_min((v128_t)__a, (v128_t)__b);
}

static __inline__ __m128i __attribute__((__always_inline__, __nodebug__))
_mm_mulhi_epi16(__m128i __a, __m128i __b)
{
  const v128_t lo = wasm_i32x4_extmul_low_i16x8((v128_t)__a, (v128_t)__b);
  const v128_t hi = wasm_i32x4_extmul_high_i16x8((v128_t)__a, (v128_t)__b);
  return (__m128i)wasm_i16x8_shuffle(lo, hi, 1, 3, 5, 7, 9, 11, 13, 15);
}

static __inline__ __m128i __attribute__((__always_inline__, __nodebug__))
_mm_mulhi_epu16(__m128i __a, __m128i __b)
{
  const v128_t lo = wasm_u32x4_extmul_low_u16x8((v128_t)__a, (v128_t)__b);
  const v128_t hi = wasm_u32x4_extmul_high_u16x8((v128_t)__a, (v128_t)__b);
  return (__m128i)wasm_i16x8_shuffle(lo, hi, 1, 3, 5, 7, 9, 11, 13, 15);
}

static __inline__ __m128i __attribute__((__always_inline__, __nodebug__))
_mm_mullo_epi16(__m128i __a, __m128i __b)
{
  return (__m128i)wasm_i16x8_mul((v128_t)__a, (v128_t)__b);
}

static __inline__ __m128i __attribute__((__always_inline__, __nodebug__))
_mm_mul_epu32(__m128i __a, __m128i __b)
{
  return (__m128i)wasm_u64x2_extmul_low_u32x4(
      wasm_v32x4_shuffle((v128_t)__a, (v128_t)__a, 0, 2, 0, 2),
      wasm_v32x4_shuffle((v128_t)__b, (v128_t)__b, 0, 2, 0, 2));
}

static __inline__ __m128i __attribute__((__always_inline__, __nodebug__))
_mm_sub_epi8(__m128i __a, __m128i __b)
{
  return (__m128i)wasm_i8x16_sub((v128_t)__a, (v128_t)__b);
}

static __inline__ __m128i __attribute__((__always_inline__, __nodebug__))
_mm_sub_epi16(__m128i __a, __m128i __b)
{
  return (__m128i)wasm_i16x8_sub((v128_t)__a, (v128_t)__b);
}

static __inline__ __m128i __attribute__((__always_inline__, __nodebug__))
_mm_sub_epi32(__m128i __a, __m128i __b)
{
  return (__m128i)wasm_i32x4_sub((v128_t)__a, (v128_t)__b);
}

static __inline__ __m128i __attribute__((__always_inline__, __nodebug__))
_mm_sub_epi64(__m128i __a, __m128i __b)
{
  return (__m128i)wasm_i64x2_sub((v128_t)__a, (v128_t)__b);
}

static __inline__ __m128i __attribute__((__always_inline__, __nodebug__))
_mm_subs_epi8(__m128i __a, __m128i __b)
{
  return (__m128i)wasm_i8x16_sub_saturate((v128_t)__a, (v128_t)__b);
}

static __inline__ __m128i __attribute__((__always_inline__, __nodebug__))
_mm_subs_epi16(__m128i __a, __m128i __b)
{
  return (__m128i)wasm_i16x8_sub_saturate((v128_t)__a, (v128_t)__b);
}

static __inline__ __m128i __attribute__((__always_inline__, __nodebug__))
_mm_subs_epu8(__m128i __a, __m128i __b)
{
  return (__m128i)wasm_u8x16_sub_saturate((v128_t)__a, (v128_t)__b);
}

static __inline__ __m128i __attribute__((__always_inline__, __nodebug__))
_mm_subs_epu16(__m128i __a, __m128i __b)
{
  return (__m128i)wasm_u16x8_sub_saturate((v128_t)__a, (v128_t)__b);
}

static __inline__ __m128i __attribute__((__always_inline__, __nodebug__))
_mm_and_si128(__m128i __a, __m128i __b)
{
  return (__m128i)wasm_v128_and((v128_t)__a, (v128_t)__b);
}

static __inline__ __m128i __attribute__((__always_inline__, __nodebug__))
_mm_andnot_si128(__m128i __a, __m128i __b)
{
  return (__m128i)wasm_v128_andnot((v128_t)__b, (v128_t)__a);
}

static __inline__ __m128i __attribute__((__always_inline__, __nodebug__))
_mm_or_si128(__m128i __a, __m128i __b)
{
  return (__m128i)wasm_v128_or((v128_t)__b, (v128_t)__a);
}

static __inline__ __m128i __attribute__((__always_inline__, __nodebug__))
_mm_xor_si128(__m128i __a, __m128i __b)
{
  return (__m128i)wasm_v128_xor((v128_t)__b, (v128_t)__a);
}

#define _mm_slli_si128(__a, __imm) __extension__ ({               \\
  (__m128i)wasm_i8x16_shuffle(_mm_setzero_si128(),                \\
                             (__a),                               \\
                             ((__imm)&0xF0) ? 0 : 16 - ((__imm)&0xF), \\
                             ((__imm)&0xF0) ? 0 : 17 - ((__imm)&0xF), \\
                             ((__imm)&0xF0) ? 0 : 18 - ((__imm)&0xF), \\
                             ((__imm)&0xF0) ? 0 : 19 - ((__imm)&0xF), \\
                             ((__imm)&0xF0) ? 0 : 20 - ((__imm)&0xF), \\
                             ((__imm)&0xF0) ? 0 : 21 - ((__imm)&0xF), \\
                             ((__imm)&0xF0) ? 0 : 22 - ((__imm)&0xF), \\
                             ((__imm)&0xF0) ? 0 : 23 - ((__imm)&0xF), \\
                             ((__imm)&0xF0) ? 0 : 24 - ((__imm)&0xF), \\
                             ((__imm)&0xF0) ? 0 : 25 - ((__imm)&0xF), \\
                             ((__imm)&0xF0) ? 0 : 26 - ((__imm)&0xF), \\
                             ((__imm)&0xF0) ? 0 : 27 - ((__imm)&0xF), \\
                             ((__imm)&0xF0) ? 0 : 28 - ((__imm)&0xF), \\
                             ((__imm)&0xF0) ? 0 : 29 - ((__imm)&0xF), \\
                             ((__imm)&0xF0) ? 0 : 30 - ((__imm)&0xF), \\
                             ((__imm)&0xF0) ? 0 : 31 - ((__imm)&0xF)); })
#define _mm_bslli_si128(__a, __imm) \\
  _mm_slli_si128((__a), (__imm))

static __inline__ __m128i __attribute__((__always_inline__, __nodebug__))
_mm_slli_epi16(__m128i __a, int __count)
{
  return (__m128i)((__count < 16) ? wasm_i16x8_shl((v128_t)__a, __count) : wasm_i16x8_const(0,0,0,0,0,0,0,0));
}

static __inline__ __m128i __attribute__((__always_inline__, __nodebug__))
_mm_sll_epi16(__m128i __a, __m128i __count)
{
  unsigned long long __c = (unsigned long long)((__u64x2)__count)[0];
  return (__m128i)((__c < 16) ? wasm_i16x8_shl((v128_t)__a, __c) : wasm_i16x8_const(0,0,0,0,0,0,0,0));
}

static __inline__ __m128i __attribute__((__always_inline__, __nodebug__))
_mm_slli_epi32(__m128i __a, int __count)
{
  return (__m128i)((__count < 32) ? wasm_i32x4_shl((v128_t)__a, __count) : wasm_i32x4_const(0,0,0,0));
}

static __inline__ __m128i __attribute__((__always_inline__, __nodebug__))
_mm_sll_epi32(__m128i __a, __m128i __count)
{
  unsigned long long __c = (unsigned long long)((__u64x2)__count)[0];
  return (__m128i)((__c < 32) ? wasm_i32x4_shl((v128_t)__a, __c) : wasm_i32x4_const(0,0,0,0));
}

static __inline__ __m128i __attribute__((__always_inline__, __nodebug__))
_mm_slli_epi64(__m128i __a, int __count)
{
  return (__m128i)((__count < 64) ? wasm_i64x2_shl((v128_t)__a, __count) : wasm_i64x2_const(0,0));
}

static __inline__ __m128i __attribute__((__always_inline__, __nodebug__))
_mm_sll_epi64(__m128i __a, __m128i __count)
{
  unsigned long long __c = (unsigned long long)((__u64x2)__count)[0];
  return (__m128i)((__c < 64) ? wasm_i64x2_shl((v128_t)__a, __c) : wasm_i64x2_const(0,0));
}

static __inline__ __m128i __attribute__((__always_inline__, __nodebug__))
_mm_srai_epi16(__m128i __a, int __count)
{
  __count = __count < 15 ? __count : 15;
  return (__m128i)wasm_i16x8_shr((v128_t)__a, __count);
}

static __inline__ __m128i __attribute__((__always_inline__, __nodebug__))
_mm_sra_epi16(__m128i __a, __m128i __count)
{
  unsigned long long __c = (unsigned long long)((__u64x2)__count)[0];
  __c = __c < 15 ? __c : 15;
  return (__m128i)wasm_i16x8_shr((v128_t)__a, __c);
}

static __inline__ __m128i __attribute__((__always_inline__, __nodebug__))
_mm_srai_epi32(__m128i __a, int __count)
{
  __count = __count < 31 ? __count : 31;
  return (__m128i)wasm_i32x4_shr((v128_t)__a, __count);
}

static __inline__ __m128i __attribute__((__always_inline__, __nodebug__))
_mm_sra_epi32(__m128i __a, __m128i __count)
{
  unsigned long long __c = (unsigned long long)((__u64x2)__count)[0];
  __c = __c < 31 ? __c : 31;
  return (__m128i)wasm_i32x4_shr((v128_t)__a, __c);
}

#define _mm_srli_si128(__a, __imm) __extension__ ({                     \\
  (__m128i)wasm_i8x16_shuffle((__a),                                    \\
                              _mm_setzero_si128(),                      \\
                              ((__imm)&0xF0) ? 16 : ((__imm)&0xF) + 0,  \\
                              ((__imm)&0xF0) ? 16 : ((__imm)&0xF) + 1,  \\
                              ((__imm)&0xF0) ? 16 : ((__imm)&0xF) + 2,  \\
                              ((__imm)&0xF0) ? 16 : ((__imm)&0xF) + 3,  \\
                              ((__imm)&0xF0) ? 16 : ((__imm)&0xF) + 4,  \\
                              ((__imm)&0xF0) ? 16 : ((__imm)&0xF) + 5,  \\
                              ((__imm)&0xF0) ? 16 : ((__imm)&0xF) + 6,  \\
                              ((__imm)&0xF0) ? 16 : ((__imm)&0xF) + 7,  \\
                              ((__imm)&0xF0) ? 16 : ((__imm)&0xF) + 8,  \\
                              ((__imm)&0xF0) ? 16 : ((__imm)&0xF) + 9,  \\
                              ((__imm)&0xF0) ? 16 : ((__imm)&0xF) + 10, \\
                              ((__imm)&0xF0) ? 16 : ((__imm)&0xF) + 11, \\
                              ((__imm)&0xF0) ? 16 : ((__imm)&0xF) + 12, \\
                              ((__imm)&0xF0) ? 16 : ((__imm)&0xF) + 13, \\
                              ((__imm)&0xF0) ? 16 : ((__imm)&0xF) + 14, \\
                              ((__imm)&0xF0) ? 16 : ((__imm)&0xF) + 15); })

#define _mm_bsrli_si128(__a, __imm) \\
  _mm_srli_si128((__a), (__imm))

static __inline__ __m128i __attribute__((__always_inline__, __nodebug__))
_mm_srli_epi16(__m128i __a, int __count)
{
  return (__m128i)(((unsigned int)__count < 16) ? wasm_u16x8_shr((v128_t)__a, __count) : wasm_i16x8_const(0,0,0,0,0,0,0,0));
}

static __inline__ __m128i __attribute__((__always_inline__, __nodebug__))
_mm_srl_epi16(__m128i __a, __m128i __count)
{
  unsigned long long __c = (unsigned long long)((__u64x2)__count)[0];
  return (__m128i)((__c < 16) ? wasm_u16x8_shr((v128_t)__a, __c) : wasm_i16x8_const(0,0,0,0,0,0,0,0));
}

static __inline__ __m128i __attribute__((__always_inline__, __nodebug__))
_mm_srli_epi32(__m128i __a, int __count)
{
  return (__m128i)(((unsigned int)__count < 32) ? wasm_u32x4_shr((v128_t)__a, __count) : wasm_i32x4_const(0,0,0,0));
}

static __inline__ __m128i __attribute__((__always_inline__, __nodebug__))
_mm_srl_epi32(__m128i __a, __m128i __count)
{
  unsigned long long __c = (unsigned long long)((__u64x2)__count)[0];
  return (__m128i)((__c < 32) ? wasm_u32x4_shr((v128_t)__a, __c) : wasm_i32x4_const(0,0,0,0));
}

static __inline__ __m128i __attribute__((__always_inline__, __nodebug__))
_mm_srli_epi64(__m128i __a, int __count)
{
  return (__m128i)(((unsigned int)__count < 64) ? wasm_u64x2_shr((v128_t)__a, __count) : wasm_i64x2_const(0,0));
}

static __inline__ __m128i __attribute__((__always_inline__, __nodebug__))
_mm_srl_epi64(__m128i __a, __m128i __count)
{
  unsigned long long __c = (unsigned long long)((__u64x2)__count)[0];
  return (__m128i)((__c < 64) ? wasm_u64x2_shr((v128_t)__a, __c) : wasm_i64x2_const(0,0));
}

static __inline__ __m128i __attribute__((__always_inline__, __nodebug__))
_mm_cmpeq_epi8(__m128i __a, __m128i __b)
{
  return (__m128i)wasm_i8x16_eq((v128_t)__a, (v128_t)__b);
}

static __inline__ __m128i __attribute__((__always_inline__, __nodebug__))
_mm_cmpeq_epi16(__m128i __a, __m128i __b)
{
  return (__m128i)wasm_i16x8_eq((v128_t)__a, (v128_t)__b);
}

static __inline__ __m128i __attribute__((__always_inline__, __nodebug__))
_mm_cmpeq_epi32(__m128i __a, __m128i __b)
{
  return (__m128i)wasm_i32x4_eq((v128_t)__a, (v128_t)__b);
}

static __inline__ __m128i __attribute__((__always_inline__, __nodebug__))
_mm_cmpgt_epi8(__m128i __a, __m128i __b)
{
  return (__m128i)wasm_i8x16_gt((v128_t)__a, (v128_t)__b);
}

static __inline__ __m128i __attribute__((__always_inline__, __nodebug__))
_mm_cmpgt_epi16(__m128i __a, __m128i __b)
{
  return (__m128i)wasm_i16x8_gt((v128_t)__a, (v128_t)__b);
}

static __inline__ __m128i __attribute__((__always_inline__, __nodebug__))
_mm_cmpgt_epi32(__m128i __a, __m128i __b)
{
  return (__m128i)wasm_i32x4_gt((v128_t)__a, (v128_t)__b);
}

static __inline__ __m128i __attribute__((__always_inline__, __nodebug__))
_mm_cmplt_epi8(__m128i __a, __m128i __b)
{
  return (__m128i)wasm_i8x16_lt((v128_t)__a, (v128_t)__b);
}

static __inline__ __m128i __attribute__((__always_inline__, __nodebug__))
_mm_cmplt_epi16(__m128i __a, __m128i __b)
{
  return (__m128i)wasm_i16x8_lt((v128_t)__a, (v128_t)__b);
}

static __inline__ __m128i __attribute__((__always_inline__, __nodebug__))
_mm_cmplt_epi32(__m128i __a, __m128i __b)
{
  return (__m128i)wasm_i32x4_lt((v128_t)__a, (v128_t)__b);
}

static __inline__ __m128d __attribute__((__always_inline__, __nodebug__))
_mm_cvtsi64_sd(__m128d __a, long long __b)
{
  // TODO: optimize
  union {
    double x[2];
    __m128d m;
  } m;
  m.m = __a;
  m.x[0] = (double)__b;
  return m.m;
}

static __inline__ long long __attribute__((__always_inline__, __nodebug__))
_mm_cvtsd_si64(__m128d __a)
{
  // TODO: optimize
  double e = __a[0];
  if (isnan(e) || isinf(e)) return 0x8000000000000000LL;
  long long x = llrint(e);
  if (e <= LLONG_MAX && e >= LLONG_MIN && (x != 0 || fabs(e) < 2.f))
    return x;
  else
    return 0x8000000000000000LL;
}

static __inline__ long long __attribute__((__always_inline__, __nodebug__))
_mm_cvttsd_si64(__m128d __a)
{
  // TODO: optimize
  double e = __a[0];
  if (isnan(e) || isinf(e) || e > LLONG_MAX || e < LLONG_MIN) return 0x8000000000000000LL;
  long long x = llrint(e);
  if (x != 0 || fabs(e) < 2.f)
    // Use the trapping instruction here since we have explicit bounds checks
    // above
    return __builtin_wasm_trunc_s_i64_f64(e);
  else
    return 0x8000000000000000LL;
}

static __inline__ __m128 __attribute__((__always_inline__, __nodebug__))
_mm_cvtepi32_ps(__m128i __a)
{
  return (__m128)wasm_f32x4_convert_i32x4(__a);
}

static __inline__ __m128i __attribute__((__always_inline__, __nodebug__))
_mm_cvtps_epi32(__m128 __a)
{
  // TODO: optimize
  union {
    int x[4];
    __m128i m;
  } u;
  for(int i = 0; i < 4; ++i)
  {
    double e = __a[i];
    int x = lrint(e);
    if (e <= INT_MAX && e >= INT_MIN && (x != 0 || fabs(e) < 2.0))
      u.x[i] = x;
    else
      u.x[i] = (int)0x80000000;
  }
  return u.m;
}

static __inline__ __m128i __attribute__((__always_inline__, __nodebug__))
_mm_cvttps_epi32(__m128 __a)
{
  // TODO: optimize
  union {
    int x[4];
    __m128i m;
  } u;
  for(int i = 0; i < 4; ++i)
  {
    float e = __a[i];
    if (e < 2147483648.0f && e >= -2147483648.0f && (lrint(e) != 0 || fabs(e) < 2.0))
      // Use the trapping instruction here since we have explicit bounds checks
      // above.
      u.x[i] = __builtin_wasm_trunc_s_i32_f32(e);
    else
      u.x[i] = (int)0x80000000;
  }
  return u.m;
}

static __inline__ __m128i __attribute__((__always_inline__, __nodebug__))
_mm_cvtsi32_si128(int __a)
{
  return (__m128i)wasm_i32x4_make(__a, 0, 0, 0);
}

static __inline__ __m128i __attribute__((__always_inline__, __nodebug__))
_mm_cvtsi64_si128(long long __a)
{
  return (__m128i)wasm_i64x2_make(__a, 0);
}

static __inline__ int __attribute__((__always_inline__, __nodebug__))
_mm_cvtsi128_si32(__m128i __a)
{
  return wasm_i32x4_extract_lane(__a, 0);
}

static __inline__ long long __attribute__((__always_inline__, __nodebug__))
_mm_cvtsi128_si64(__m128i __a)
{
  return wasm_i64x2_extract_lane(__a, 0);
}

static __inline__ __m128i __attribute__((__always_inline__, __nodebug__))
_mm_load_si128(__m128i const *__p)
{
  return *__p;
}

static __inline__ __m128i __attribute__((__always_inline__, __nodebug__))
_mm_loadu_si128(__m128i const *__p)
{
  // UB-free unaligned access copied from wasm_simd128.h
  struct __mm_loadu_si128_struct {
    __m128i __v;
  } __attribute__((__packed__, __may_alias__));
  return ((struct __mm_loadu_si128_struct*)__p)->__v;
}

static __inline__ __m128i __attribute__((__always_inline__, __nodebug__))
_mm_loadu_si16(void const *__p)
{
  return (__m128i)wasm_v128_load16_lane(__p, wasm_i64x2_const(0, 0), 0);
}

static __inline__ __m128i __attribute__((__always_inline__, __nodebug__))
_mm_loadu_si32(void const *__p)
{
  return (__m128i)wasm_v128_load32_zero(__p);
}

static __inline__ __m128i __attribute__((__always_inline__, __nodebug__))
_mm_loadu_si64(void const *__p)
{
  return (__m128i)wasm_v128_load64_zero(__p);
}

static __inline__ __m128i __attribute__((__always_inline__, __nodebug__))
_mm_loadl_epi64(__m128i const *__p)
{
  return _mm_loadu_si64(__p);
}

static __inline__ __m128i __attribute__((__always_inline__, __nodebug__))
_mm_set_epi64(long long q1, long long q0)
{
  return (__m128i)wasm_i64x2_make(q0, q1);
}

static __inline__ __m128i __attribute__((__always_inline__, __nodebug__))
_mm_set_epi32(int i3, int i2, int i1, int i0)
{
  return (__m128i)wasm_i32x4_make(i0, i1, i2, i3);
}

static __inline__ __m128i __attribute__((__always_inline__, __nodebug__))
_mm_set_epi16(short w7, short w6, short w5, short w4, short w3, short w2, short w1, short w0)
{
  return (__m128i)wasm_i16x8_make(w0, w1, w2, w3, w4, w5, w6, w7);
}

static __inline__ __m128i __attribute__((__always_inline__, __nodebug__))
_mm_set_epi8(char b15, char b14, char b13, char b12, char b11, char b10, char b9, char b8, char b7, char b6, char b5, char b4, char b3, char b2, char b1, char b0)
{
  return (__m128i)wasm_i8x16_make(b0, b1, b2, b3, b4, b5, b6, b7, b8, b9, b10, b11, b12, b13, b14, b15);
}

static __inline__ __m128i __attribute__((__always_inline__, __nodebug__))
_mm_set1_epi64x(long long __q)
{
  return (__m128i)wasm_i64x2_splat(__q);
}

static __inline__ __m128i __attribute__((__always_inline__, __nodebug__))
_mm_set1_epi32(int __i)
{
  return (__m128i)wasm_i32x4_splat(__i);
}

static __inline__ __m128i __attribute__((__always_inline__, __nodebug__))
_mm_set1_epi16(short __w)
{
  return (__m128i)wasm_i16x8_splat(__w);
}

static __inline__ __m128i __attribute__((__always_inline__, __nodebug__))
_mm_set1_epi8(char __b)
{
  return (__m128i)wasm_i8x16_splat(__b);
}

static __inline__ __m128i __attribute__((__always_inline__, __nodebug__))
_mm_setr_epi32(int i0, int i1, int i2, int i3)
{
  return (__m128i)wasm_i32x4_make(i0, i1, i2, i3);
}

static __inline__ __m128i __attribute__((__always_inline__, __nodebug__))
_mm_setr_epi16(short w0, short w1, short w2, short w3, short w4, short w5, short w6, short w7)
{
  return (__m128i)wasm_i16x8_make(w0, w1, w2, w3, w4, w5, w6, w7);
}

static __inline__ __m128i __attribute__((__always_inline__, __nodebug__))
_mm_setr_epi8(char b0, char b1, char b2, char b3, char b4, char b5, char b6, char b7, char b8, char b9, char b10, char b11, char b12, char b13, char b14, char b15)
{
  return (__m128i)wasm_i8x16_make(b0, b1, b2, b3, b4, b5, b6, b7, b8, b9, b10, b11, b12, b13, b14, b15);
}

static __inline__ __m128i __attribute__((__always_inline__, __nodebug__))
_mm_setzero_si128(void)
{
  return wasm_i64x2_const(0, 0);
}

static __inline__ void __attribute__((__always_inline__, __nodebug__))
_mm_store_si128(__m128i *__p, __m128i __b)
{
  *__p = __b;
}

static __inline__ void __attribute__((__always_inline__, __nodebug__))
_mm_storeu_si16(void *__p, __m128i __a)
{
  wasm_v128_store16_lane(__p, (v128_t)__a, 0);
}

static __inline__ void __attribute__((__always_inline__, __nodebug__))
_mm_storeu_si32(void *__p, __m128i __a)
{
  wasm_v128_store32_lane(__p, (v128_t)__a, 0);
}

static __inline__ void __attribute__((__always_inline__, __nodebug__))
_mm_storeu_si64(void *__p, __m128i __a)
{
  wasm_v128_store64_lane(__p, (v128_t)__a, 0);
}

static __inline__ void __attribute__((__always_inline__, __nodebug__))
_mm_storeu_si128(__m128i *__p, __m128i __a)
{
  // UB-free unaligned access copied from wasm_simd128.h
  struct __mm_storeu_si128_struct {
    __m128i __v;
  } __attribute__((__packed__, __may_alias__));
  ((struct __mm_storeu_si128_struct *)__p)->__v = __a;
}

static __inline__ void __attribute__((__always_inline__, __nodebug__))
_mm_maskmoveu_si128(__m128i __d, __m128i __n, char *__p)
{
  // TODO: optimize
  union {
    unsigned char x[16];
    __m128i m;
  } mask, data;
  mask.m = __n;
  data.m = __d;
  for(int i = 0; i < 16; ++i)
    if (mask.x[i] & 0x80)
      __p[i] = data.x[i];
}

static __inline__ void __attribute__((__always_inline__, __nodebug__))
_mm_storel_epi64(__m128i *__p, __m128i __a)
{
  _mm_storeu_si64(__p, __a);
}

static __inline__ void __attribute__((__always_inline__, __nodebug__))
_mm_stream_pd(double *__p, __m128d __a)
{
  // Emscripten/SIMD.js does not have cache hinting.
  _mm_store_pd(__p, __a);
}

static __inline__ void __attribute__((__always_inline__, __nodebug__))
_mm_stream_si128(__m128i *__p, __m128i __a)
{
  // Emscripten/SIMD.js does not have cache hinting.
  _mm_store_si128(__p, __a);
}

static __inline__ void __attribute__((__always_inline__, __nodebug__))
_mm_stream_si32(int *__p, int __a)
{
  // No cache hinting available.
  *__p = __a;
}

static __inline__ void __attribute__((__always_inline__, __nodebug__))
_mm_stream_si64(long long *__p, long long __a)
{
  // No cache hinting available.
  *__p = __a;
}

static __inline__ void __attribute__((__always_inline__, __nodebug__))
_mm_clflush(void const *__p)
{
  // Wasm SIMD does not have cache hinting
}

static __inline__ void __attribute__((__always_inline__, __nodebug__))
_mm_lfence(void)
{
  __sync_synchronize(); // Wasm/SharedArrayBuffer has only a full barrier instruction, which gives a stronger guarantee.
}

static __inline__ void __attribute__((__always_inline__, __nodebug__))
_mm_mfence(void)
{
  __sync_synchronize(); // Wasm/SharedArrayBuffer has only a full barrier instruction, which gives a stronger guarantee.
}

static __inline__ __m128i __attribute__((__always_inline__, __nodebug__))
_mm_packs_epi16(__m128i __a, __m128i __b)
{
  return wasm_i8x16_narrow_i16x8(__a, __b);
}

static __inline__ __m128i __attribute__((__always_inline__, __nodebug__))
_mm_packs_epi32(__m128i __a, __m128i __b)
{
  return wasm_i16x8_narrow_i32x4(__a, __b);
}

static __inline__ __m128i __attribute__((__always_inline__, __nodebug__))
_mm_packus_epi16(__m128i __a, __m128i __b)
{
  return wasm_u8x16_narrow_i16x8(__a, __b);
}

#define _mm_extract_epi16(__a, __imm) wasm_u16x8_extract_lane((v128_t)(__a), (__imm) & 7)
#define _mm_insert_epi16(__a, __b, __imm) wasm_i16x8_replace_lane((__a), (__imm) & 7, (__b))

static __inline__ int __attribute__((__always_inline__, __nodebug__))
_mm_movemask_epi8(__m128i __a)
{
  return (int)wasm_i8x16_bitmask((v128_t)__a);
}

#define _mm_shuffle_epi32(__a, __imm) __extension__ ({ \\
  (__m128i)wasm_i32x4_shuffle((__a), \\
                              _mm_set1_epi32(0), \\
                              ((__imm) & 0x3), (((__imm) & 0xc) >> 2), \\
                              (((__imm) & 0x30) >> 4), (((__imm) & 0xc0) >> 6)); })

#define _mm_shufflelo_epi16(__a, __imm) __extension__ ({ \\
  (__m128i)wasm_i16x8_shuffle((__a), \\
                              _mm_set1_epi16(0), \\
                              ((__imm) & 0x3), (((__imm) & 0xc) >> 2), \\
                              (((__imm) & 0x30) >> 4), (((__imm) & 0xc0) >> 6), \\
                              4, 5, 6, 7); })

#define _mm_shufflehi_epi16(__a, __imm) __extension__ ({ \\
  (__m128i)wasm_i16x8_shuffle((__a), \\
                              _mm_set1_epi16(0), \\
                              0, 1, 2, 3, \\
                              (4 + (((__imm) & 0x03) >> 0)), \\
                              (4 + (((__imm) & 0x0c) >> 2)), \\
                              (4 + (((__imm) & 0x30) >> 4)), \\
                              (4 + (((__imm) & 0xc0) >> 6))); })

static __inline__ __m128i __attribute__((__always_inline__, __nodebug__))
_mm_unpackhi_epi8(__m128i __a, __m128i __b)
{
  return (__m128i)wasm_i8x16_shuffle(__a, __b, 8, 24, 9, 25, 10, 26, 11, 27, 12, 28, 13, 29, 14, 30, 15, 31);
}

static __inline__ __m128i __attribute__((__always_inline__, __nodebug__))
_mm_unpackhi_epi16(__m128i __a, __m128i __b)
{
  return (__m128i)wasm_i16x8_shuffle(__a, __b, 4, 12, 5, 13, 6, 14, 7, 15);
}

static __inline__ __m128i __attribute__((__always_inline__, __nodebug__))
_mm_unpackhi_epi32(__m128i __a, __m128i __b)
{
  return (__m128i)wasm_i32x4_shuffle(__a, __b, 2, 6, 3, 7);
}

static __inline__ __m128i __attribute__((__always_inline__, __nodebug__))
_mm_unpackhi_epi64(__m128i __a, __m128i __b)
{
  return (__m128i)wasm_i64x2_shuffle(__a, __b, 1, 3);
}

static __inline__ __m128i __attribute__((__always_inline__, __nodebug__))
_mm_unpacklo_epi8(__m128i __a, __m128i __b)
{
  return (__m128i)wasm_i8x16_shuffle(__a, __b, 0, 16, 1, 17, 2, 18, 3, 19, 4, 20, 5, 21, 6, 22, 7, 23);
}

static __inline__ __m128i __attribute__((__always_inline__, __nodebug__))
_mm_unpacklo_epi16(__m128i __a, __m128i __b)
{
  return (__m128i)wasm_i16x8_shuffle(__a, __b, 0, 8, 1, 9, 2, 10, 3, 11);
}

static __inline__ __m128i __attribute__((__always_inline__, __nodebug__))
_mm_unpacklo_epi32(__m128i __a, __m128i __b)
{
  return (__m128i)wasm_i32x4_shuffle(__a, __b, 0, 4, 1, 5);
}

static __inline__ __m128i __attribute__((__always_inline__, __nodebug__))
_mm_unpacklo_epi64(__m128i __a, __m128i __b)
{
  return (__m128i)wasm_i64x2_shuffle(__a, __b, 0, 2);
}

static __inline__ __m128i __attribute__((__always_inline__, __nodebug__))
_mm_move_epi64(__m128i __a)
{
  return wasm_i64x2_shuffle(__a, wasm_i64x2_const(0, 0), 0, 2);
}

static __inline__ __m128d __attribute__((__always_inline__, __nodebug__))
_mm_unpackhi_pd(__m128d __a, __m128d __b)
{
  return (__m128d)wasm_i64x2_shuffle((v128_t)__a, (v128_t)__b, 1, 3);
}

static __inline__ __m128d __attribute__((__always_inline__, __nodebug__))
_mm_unpacklo_pd(__m128d __a, __m128d __b)
{
  return (__m128d)wasm_i64x2_shuffle((v128_t)__a, (v128_t)__b, 0, 2);
}

static __inline__ int __attribute__((__always_inline__, __nodebug__))
_mm_movemask_pd(__m128d __a)
{
  return (int)wasm_i64x2_bitmask((v128_t)__a);
}

#define _mm_shuffle_pd(__a, __b, __i) __extension__ ({ \\
  (__m128d) __builtin_shufflevector((__u64x2)(__a), (__u64x2)(__b), \\
                                    (__i) & 1, \\
                                    (((__i) & 2) >> 1) + 2); })

static __inline__ __m128 __attribute__((__always_inline__, __nodebug__))
_mm_castpd_ps(__m128d __a)
{
  return (__m128)__a;
}

static __inline__ __m128i __attribute__((__always_inline__, __nodebug__))
_mm_castpd_si128(__m128d __a)
{
  return (__m128i)__a;
}

static __inline__ __m128d __attribute__((__always_inline__, __nodebug__))
_mm_castps_pd(__m128 __a)
{
  return (__m128d)__a;
}

static __inline__ __m128i __attribute__((__always_inline__, __nodebug__))
_mm_castps_si128(__m128 __a)
{
  return (__m128i)__a;
}

static __inline__ __m128 __attribute__((__always_inline__, __nodebug__))
_mm_castsi128_ps(__m128i __a)
{
  return (__m128)__a;
}

static __inline__ __m128d __attribute__((__always_inline__, __nodebug__))
_mm_castsi128_pd(__m128i __a)
{
  return (__m128d)__a;
}

static __inline__ void __attribute__((__always_inline__, __nodebug__))
_mm_pause(void)
{
  // No pause/wait instruction in Wasm/SIMD.
}

static __inline__ __m128d __attribute__((__always_inline__, __nodebug__))
_mm_undefined_pd()
{
  __m128d val;
  return val;
}

static __inline__ __m128i __attribute__((__always_inline__, __nodebug__))
_mm_undefined_si128()
{
  __m128i val;
  return val;
}

// Must be in the very end as it uses other SSE2 intrinsics
static __inline__ __m128i __attribute__((__always_inline__, __nodebug__))
_mm_sad_epu8(__m128i __a, __m128i __b)
{
  __m128i __diff = _mm_or_si128(_mm_subs_epu8(__a, __b),
                                _mm_subs_epu8(__b, __a));
  __diff = _mm_add_epi16(_mm_srli_epi16(__diff, 8),
                         _mm_and_si128(__diff, _mm_set1_epi16(0x00FF)));
  __diff = _mm_add_epi16(__diff, _mm_slli_epi32(__diff, 16));
  __diff = _mm_add_epi16(__diff, _mm_slli_epi64(__diff, 32));
  return _mm_srli_epi64(__diff, 48);
}

#define _MM_SHUFFLE2(x, y) (((x) << 1) | (y))

#endif /* __emscripten_emmintrin_h__ */
`,"pmmintrin.h":`/*
 * Copyright 2020 The Emscripten Authors.  All rights reserved.
 * Emscripten is available under two separate licenses, the MIT license and the
 * University of Illinois/NCSA Open Source License.  Both these licenses can be
 * found in the LICENSE file.
 */
#ifndef __emscripten_pmmintrin_h__
#define __emscripten_pmmintrin_h__

#ifndef __SSE3__
#error "SSE3 instruction set not enabled"
#endif

#include <emmintrin.h>

static __inline__ __m128i __attribute__((__always_inline__, __nodebug__))
_mm_lddqu_si128(__m128i const *__p)
{
  return _mm_loadu_si128(__p);
}

static __inline__ __m128 __attribute__((__always_inline__, __nodebug__))
_mm_addsub_ps(__m128 __a, __m128 __b)
{
  return _mm_add_ps(__a, _mm_mul_ps(__b, _mm_set_ps(1.f, -1.f, 1.f, -1.f)));
}

static __inline__ __m128 __attribute__((__always_inline__, __nodebug__))
_mm_hadd_ps(__m128 __a, __m128 __b)
{
  return _mm_add_ps(_mm_shuffle_ps(__a, __b, _MM_SHUFFLE(2, 0, 2, 0)), _mm_shuffle_ps(__a, __b, _MM_SHUFFLE(3, 1, 3, 1)));
}

static __inline__ __m128 __attribute__((__always_inline__, __nodebug__))
_mm_hsub_ps(__m128 __a, __m128 __b)
{
  return _mm_sub_ps(_mm_shuffle_ps(__a, __b, _MM_SHUFFLE(2, 0, 2, 0)), _mm_shuffle_ps(__a, __b, _MM_SHUFFLE(3, 1, 3, 1)));
}

static __inline__ __m128 __attribute__((__always_inline__, __nodebug__))
_mm_movehdup_ps(__m128 __a)
{
  return (__m128)wasm_i32x4_shuffle(__a, __a, 1, 1, 3, 3);
}

static __inline__ __m128 __attribute__((__always_inline__, __nodebug__))
_mm_moveldup_ps(__m128 __a)
{
  return (__m128)wasm_i32x4_shuffle(__a, __a, 0, 0, 2, 2);
}

static __inline__ __m128d __attribute__((__always_inline__, __nodebug__))
_mm_addsub_pd(__m128d __a, __m128d __b)
{
  return _mm_add_pd(__a, _mm_mul_pd(__b, _mm_set_pd(1.0, -1.0)));
}

static __inline__ __m128d __attribute__((__always_inline__, __nodebug__))
_mm_hadd_pd(__m128d __a, __m128d __b)
{
  return _mm_add_pd(_mm_shuffle_pd(__a, __b, _MM_SHUFFLE2(0, 0)), _mm_shuffle_pd(__a, __b, _MM_SHUFFLE2(1, 1)));
}

static __inline__ __m128d __attribute__((__always_inline__, __nodebug__))
_mm_hsub_pd(__m128d __a, __m128d __b)
{
  return _mm_sub_pd(_mm_shuffle_pd(__a, __b, _MM_SHUFFLE2(0, 0)), _mm_shuffle_pd(__a, __b, _MM_SHUFFLE2(1, 1)));
}

#define        _mm_loaddup_pd(dp)        _mm_load1_pd(dp)

static __inline__ __m128d __attribute__((__always_inline__, __nodebug__))
_mm_movedup_pd(__m128d __a)
{
  return (__m128d)wasm_i64x2_shuffle(__a, __a, 0, 0);
}

#define _MM_DENORMALS_ZERO_ON   (0x0040)
#define _MM_DENORMALS_ZERO_OFF  (0x0000)
#define _MM_DENORMALS_ZERO_MASK (0x0040)
#define _MM_GET_DENORMALS_ZERO_MODE() (_mm_getcsr() & _MM_DENORMALS_ZERO_MASK)

// Unavailable functions:
// #define _MM_SET_DENORMALS_ZERO_MODE(x) (_mm_setcsr((_mm_getcsr() & ~_MM_DENORMALS_ZERO_MASK) | (x)))
// void _mm_monitor(void const *__p, unsigned __extensions, unsigned __hints);
// void _mm_mwait(unsigned __extensions, unsigned __hints);

#endif /* __emscripten_pmmintrin_h__ */
`,"tmmintrin.h":`/*
 * Copyright 2020 The Emscripten Authors.  All rights reserved.
 * Emscripten is available under two separate licenses, the MIT license and the
 * University of Illinois/NCSA Open Source License.  Both these licenses can be
 * found in the LICENSE file.
 */
#ifndef __emscripten_tmmintrin_h__
#define __emscripten_tmmintrin_h__

#ifndef __SSSE3__
#error "SSSE3 instruction set not enabled"
#endif

#include <pmmintrin.h>

static __inline__ __m128i __attribute__((__always_inline__, __nodebug__))
_mm_abs_epi8(__m128i __a)
{
  return (__m128i)wasm_i8x16_abs((v128_t)__a);
}

static __inline__ __m128i __attribute__((__always_inline__, __nodebug__))
_mm_abs_epi16(__m128i __a)
{
  return (__m128i)wasm_i16x8_abs((v128_t)__a);
}

static __inline__ __m128i __attribute__((__always_inline__, __nodebug__))
_mm_abs_epi32(__m128i __a)
{
  return (__m128i)wasm_i32x4_abs((v128_t)__a);
}

#define _mm_alignr_epi8(__a, __b, __count) \\
    ((__count <= 16) \\
    ? (_mm_or_si128(_mm_bslli_si128((__a), 16 - (((unsigned int)(__count)) & 0xFF)), _mm_bsrli_si128((__b), (((unsigned int)(__count)) & 0xFF)))) \\
    : (_mm_bsrli_si128((__a), (((unsigned int)(__count)) & 0xFF) - 16)))

static __inline__ __m128i __attribute__((__always_inline__, __nodebug__))
_mm_hadd_epi16(__m128i __a, __m128i __b)
{
  return _mm_add_epi16((__m128i)wasm_i16x8_shuffle(__a, __b, 0, 2, 4, 6, 8, 10, 12, 14),
                       (__m128i)wasm_i16x8_shuffle(__a, __b, 1, 3, 5, 7, 9, 11, 13, 15));
}

static __inline__ __m128i __attribute__((__always_inline__, __nodebug__))
_mm_hadd_epi32(__m128i __a, __m128i __b)
{
  return _mm_add_epi32((__m128i)_mm_shuffle_ps((__m128)__a, (__m128)__b, _MM_SHUFFLE(2, 0, 2, 0)),
                       (__m128i)_mm_shuffle_ps((__m128)__a, (__m128)__b, _MM_SHUFFLE(3, 1, 3, 1)));
}

static __inline__ __m128i __attribute__((__always_inline__, __nodebug__))
_mm_hadds_epi16(__m128i __a, __m128i __b)
{
  return _mm_adds_epi16((__m128i)wasm_i16x8_shuffle(__a, __b, 0, 2, 4, 6, 8, 10, 12, 14),
                        (__m128i)wasm_i16x8_shuffle(__a, __b, 1, 3, 5, 7, 9, 11, 13, 15));
}

static __inline__ __m128i __attribute__((__always_inline__, __nodebug__))
_mm_hsub_epi16(__m128i __a, __m128i __b)
{
  return _mm_sub_epi16((__m128i)wasm_i16x8_shuffle(__a, __b, 0, 2, 4, 6, 8, 10, 12, 14),
                       (__m128i)wasm_i16x8_shuffle(__a, __b, 1, 3, 5, 7, 9, 11, 13, 15));
}

static __inline__ __m128i __attribute__((__always_inline__, __nodebug__))
_mm_hsub_epi32(__m128i __a, __m128i __b)
{
  return _mm_sub_epi32((__m128i)_mm_shuffle_ps((__m128)__a, (__m128)__b, _MM_SHUFFLE(2, 0, 2, 0)),
                       (__m128i)_mm_shuffle_ps((__m128)__a, (__m128)__b, _MM_SHUFFLE(3, 1, 3, 1)));
}


static __inline__ __m128i __attribute__((__always_inline__, __nodebug__))
_mm_hsubs_epi16(__m128i __a, __m128i __b)
{
  return _mm_subs_epi16((__m128i)wasm_i16x8_shuffle(__a, __b, 0, 2, 4, 6, 8, 10, 12, 14),
                        (__m128i)wasm_i16x8_shuffle(__a, __b, 1, 3, 5, 7, 9, 11, 13, 15));
}

static __inline__ __m128i __attribute__((__always_inline__, __nodebug__))
_mm_maddubs_epi16(__m128i __a, __m128i __b)
{
  return _mm_adds_epi16(
    _mm_mullo_epi16(
      _mm_and_si128(__a, _mm_set1_epi16(0x00FF)),
      _mm_srai_epi16(_mm_slli_epi16(__b, 8), 8)),
    _mm_mullo_epi16(_mm_srli_epi16(__a, 8), _mm_srai_epi16(__b, 8)));
}

static __inline__ __m128i __attribute__((__always_inline__, __nodebug__))
_mm_mulhrs_epi16(__m128i __a, __m128i __b)
{
  v128_t __lo = wasm_i32x4_mul(wasm_i32x4_widen_low_i16x8((v128_t)__a), wasm_i32x4_widen_low_i16x8((v128_t)__b));
  v128_t __hi = wasm_i32x4_mul(wasm_i32x4_widen_high_i16x8((v128_t)__a), wasm_i32x4_widen_high_i16x8((v128_t)__b));
  const v128_t __inc = wasm_i32x4_splat(0x4000);
  __lo = wasm_i32x4_add(__lo, __inc);
  __hi = wasm_i32x4_add(__hi, __inc);
  __lo = wasm_i32x4_add(__lo, __lo);
  __hi = wasm_i32x4_add(__hi, __hi);
  return (__m128i)wasm_i16x8_shuffle(__lo, __hi, 1, 3, 5, 7, 9, 11, 13, 15);
}

static __inline__ __m128i __attribute__((__always_inline__, __nodebug__))
_mm_shuffle_epi8(__m128i __a, __m128i __b)
{
  return (__m128i)wasm_v8x16_swizzle((v128_t)__a, (v128_t)_mm_and_si128(__b, _mm_set1_epi8(0x8F)));
}

static __inline__ __m128i __attribute__((__always_inline__, __nodebug__))
_mm_sign_epi8(__m128i __a, __m128i __b)
{
  const __m128i __zero = _mm_setzero_si128();
  __a = _mm_andnot_si128(_mm_cmpeq_epi8(__b, __zero), __a);
  const __m128i __mask = _mm_cmpgt_epi8(__zero, __b);
  return _mm_xor_si128(_mm_add_epi8(__a, __mask), __mask);
}

static __inline__ __m128i __attribute__((__always_inline__, __nodebug__))
_mm_sign_epi16(__m128i __a, __m128i __b)
{
  const __m128i __zero = _mm_setzero_si128();
  __a = _mm_andnot_si128(_mm_cmpeq_epi16(__b, __zero), __a);
  const __m128i __mask = _mm_cmpgt_epi16(__zero, __b);
  return _mm_xor_si128(_mm_add_epi16(__a, __mask), __mask);
}

static __inline__ __m128i __attribute__((__always_inline__, __nodebug__))
_mm_sign_epi32(__m128i __a, __m128i __b)
{
  const __m128i __zero = _mm_setzero_si128();
  __a = _mm_andnot_si128(_mm_cmpeq_epi32(__b, __zero), __a);
  const __m128i __mask = _mm_cmpgt_epi32(__zero, __b);
  return _mm_xor_si128(_mm_add_epi32(__a, __mask), __mask);
}

// Unavailable functions:
// _mm_abs_pi8
// _mm_abs_pi16
// _mm_abs_pi32
// _mm_alignr_pi8
// _mm_hadd_pi16
// _mm_hadd_pi32
// _mm_hadds_pi16
// _mm_hsub_pi16
// _mm_hsub_pi32
// _mm_hsubs_pi16
// _mm_maddubs_pi16
// _mm_mulhrs_pi16
// _mm_shuffle_pi8
// _mm_sign_pi8
// _mm_sign_pi16
// _mm_sign_pi32

#endif /* __emscripten_tmmintrin_h__ */
`,"smmintrin.h":`/*
 * Copyright 2020 The Emscripten Authors.  All rights reserved.
 * Emscripten is available under two separate licenses, the MIT license and the
 * University of Illinois/NCSA Open Source License.  Both these licenses can be
 * found in the LICENSE file.
 */
#ifndef __emscripten_smmintrin_h__
#define __emscripten_smmintrin_h__

#ifndef __SSE4_1__
#error "SSE4.1 instruction set not enabled"
#endif

#include <tmmintrin.h>
#include <math.h> // For rint and rintf

#define _mm_blend_epi16(__a, __b, __imm8) __extension__ ({     \\
  (__m128i)__builtin_shufflevector((__i16x8)(__m128i)(__a),    \\
                                   (__i16x8)(__m128i)(__b),    \\
                                   (((__imm8) & 1) ?  8 : 0),  \\
                                   (((__imm8) & 2) ?  9 : 1),  \\
                                   (((__imm8) & 4) ? 10 : 2),  \\
                                   (((__imm8) & 8) ? 11 : 3),  \\
                                   (((__imm8) & 16) ? 12 : 4), \\
                                   (((__imm8) & 32) ? 13 : 5), \\
                                   (((__imm8) & 64) ? 14 : 6), \\
                                   (((__imm8) & 128) ? 15 : 7)); })

#define _mm_blend_pd(__a, __b, __imm8) __extension__ ({         \\
  (__m128d)__builtin_shufflevector((__f64x2)(__m128d)(__a),     \\
                                   (__f64x2)(__m128d)(__b),     \\
                                   (((__imm8) & 0x01) ? 2 : 0), \\
                                   (((__imm8) & 0x02) ? 3 : 1)); })

#define _mm_blend_ps(__a, __b, __imm8) __extension__ ({ \\
  (__m128)__builtin_shufflevector((__f32x4)(__m128)(__a), (__f32x4)(__m128)(__b), \\
                                  (((__imm8) & 0x01) ? 4 : 0), \\
                                  (((__imm8) & 0x02) ? 5 : 1), \\
                                  (((__imm8) & 0x04) ? 6 : 2), \\
                                  (((__imm8) & 0x08) ? 7 : 3)); })

static __inline__ __m128i __attribute__((__always_inline__, __nodebug__))
_mm_blendv_epi8(__m128i __a, __m128i __b, __m128i __mask)
{
  v128_t __M = wasm_i8x16_shr((v128_t)__mask, 7);
  return (__m128i)wasm_v128_bitselect((v128_t)__b, (v128_t)__a, __M);
}

static __inline__ __m128d __attribute__((__always_inline__, __nodebug__))
_mm_blendv_pd(__m128d __a, __m128d __b, __m128d __mask)
{
  v128_t __M = wasm_i64x2_shr((v128_t)__mask, 63);
  return (__m128d)wasm_v128_bitselect((v128_t)__b, (v128_t)__a, __M);
}

static __inline__ __m128 __attribute__((__always_inline__, __nodebug__))
_mm_blendv_ps(__m128 __a, __m128 __b, __m128 __mask)
{
  v128_t __M = wasm_i32x4_shr((v128_t)__mask, 31);
  return (__m128)wasm_v128_bitselect((v128_t)__b, (v128_t)__a, __M);
}

#define _MM_FROUND_TO_NEAREST_INT    0x00
#define _MM_FROUND_TO_NEG_INF        0x01
#define _MM_FROUND_TO_POS_INF        0x02
#define _MM_FROUND_TO_ZERO           0x03
#define _MM_FROUND_CUR_DIRECTION     0x04

#define _MM_FROUND_RAISE_EXC         0x00
#define _MM_FROUND_NO_EXC            0x08

#define _MM_FROUND_NINT      (_MM_FROUND_RAISE_EXC | _MM_FROUND_TO_NEAREST_INT)
#define _MM_FROUND_FLOOR     (_MM_FROUND_RAISE_EXC | _MM_FROUND_TO_NEG_INF)
#define _MM_FROUND_CEIL      (_MM_FROUND_RAISE_EXC | _MM_FROUND_TO_POS_INF)
#define _MM_FROUND_TRUNC     (_MM_FROUND_RAISE_EXC | _MM_FROUND_TO_ZERO)
#define _MM_FROUND_RINT      (_MM_FROUND_RAISE_EXC | _MM_FROUND_CUR_DIRECTION)
#define _MM_FROUND_NEARBYINT (_MM_FROUND_NO_EXC | _MM_FROUND_CUR_DIRECTION)

static __inline__ __m128d __attribute__((__always_inline__, __nodebug__))
_mm_ceil_pd(__m128d __a)
{
  return (__m128d)wasm_f64x2_ceil((v128_t)__a);
}

static __inline__ __m128 __attribute__((__always_inline__, __nodebug__))
_mm_ceil_ps(__m128 __a)
{
  return (__m128)wasm_f32x4_ceil((v128_t)__a);
}

static __inline__ __m128 __attribute__((__always_inline__, __nodebug__))
_mm_ceil_ss(__m128 __a, __m128 __b)
{
  return _mm_move_ss(__a, _mm_ceil_ps(__b));
}

static __inline__ __m128d __attribute__((__always_inline__, __nodebug__))
_mm_ceil_sd(__m128d __a, __m128d __b)
{
  return _mm_move_sd(__a, _mm_ceil_pd(__b));
}

static __inline__ __m128d __attribute__((__always_inline__, __nodebug__))
_mm_floor_pd(__m128d __a)
{
  return (__m128d)wasm_f64x2_floor((v128_t)__a);
}

static __inline__ __m128 __attribute__((__always_inline__, __nodebug__))
_mm_floor_ps(__m128 __a)
{
  return (__m128)wasm_f32x4_floor((v128_t)__a);
}

static __inline__ __m128 __attribute__((__always_inline__, __nodebug__))
_mm_floor_ss(__m128 __a, __m128 __b)
{
  return _mm_move_ss(__a, _mm_floor_ps(__b));
}

static __inline__ __m128d __attribute__((__always_inline__, __nodebug__))
_mm_floor_sd(__m128d __a, __m128d __b)
{
  return _mm_move_sd(__a, _mm_floor_pd(__b));
}

static __inline__ __m128d __attribute__((__always_inline__, __nodebug__))
_mm_round_pd(__m128d __a, int __rounding)
{
  switch(__rounding & 7)
  {
    case _MM_FROUND_TO_NEG_INF: return _mm_floor_pd(__a);
    case _MM_FROUND_TO_POS_INF: return _mm_ceil_pd(__a);
    case _MM_FROUND_TO_ZERO:
      return (__m128d)wasm_f64x2_trunc((v128_t)__a);
    default:
      // _MM_FROUND_TO_NEAREST_INT and _MM_FROUND_CUR_DIRECTION (which is always nearest in Wasm SIMD)
      // SSE implements "Banker's rounding", where even half-ways, e.g. 2.5 are rounded down,
      // and odd numbers e.g. 3.5 are rounded up.
      return (__m128d)wasm_f64x2_nearest((v128_t)__a);
  }
}

static __inline__ __m128 __attribute__((__always_inline__, __nodebug__))
_mm_round_ps(__m128 __a, int __rounding)
{
  switch(__rounding & 7)
  {
    case _MM_FROUND_TO_NEG_INF: return _mm_floor_ps(__a);
    case _MM_FROUND_TO_POS_INF: return _mm_ceil_ps(__a);
    case _MM_FROUND_TO_ZERO:
      return (__m128)wasm_f32x4_trunc((v128_t)__a);
    default:
      // _MM_FROUND_TO_NEAREST_INT and _MM_FROUND_CUR_DIRECTION (which is always nearest in Wasm SIMD)
      // SSE implements "Banker's rounding", where even half-ways, e.g. 2.5 are rounded down,
      // and odd numbers e.g. 3.5 are rounded up.
      return (__m128)wasm_f32x4_nearest((v128_t)__a);
  }
}

static __inline__ __m128 __attribute__((__always_inline__, __nodebug__))
_mm_round_ss(__m128 __a, __m128 __b, int __rounding)
{
  return _mm_move_ss(__a, _mm_round_ps(__b, __rounding));
}

static __inline__ __m128d __attribute__((__always_inline__, __nodebug__))
_mm_round_sd(__m128d __a, __m128d __b, int __rounding)
{
  return _mm_move_sd(__a, _mm_round_pd(__b, __rounding));
}

static __inline__  __m128i __attribute__((__always_inline__, __nodebug__))
_mm_mullo_epi32(__m128i __a, __m128i __b)
{
  return (__m128i)wasm_i32x4_mul(__a, __b);
}

static __inline__  __m128i __attribute__((__always_inline__, __nodebug__))
_mm_mul_epi32(__m128i __a, __m128i __b)
{
  return (__m128i)wasm_i64x2_extmul_low_i32x4(
      (v128_t)_mm_shuffle_epi32(__a, _MM_SHUFFLE(2, 0, 2, 0)),
      (v128_t)_mm_shuffle_epi32(__b, _MM_SHUFFLE(2, 0, 2, 0)));
}

#define _mm_dp_ps(__a, __b, __imm8) __extension__ ({ \\
        __m128 __tmp = _mm_mul_ps(__a, __b); \\
        __m128 __zero = _mm_setzero_ps(); \\
        __tmp = _mm_blend_ps(__zero, __tmp, __imm8 >> 4); \\
        __m128 __sum = _mm_add_ps(__tmp, _mm_shuffle_ps(__tmp, __tmp, _MM_SHUFFLE(2, 3, 0, 1))); \\
        __sum = _mm_add_ps(__sum, _mm_shuffle_ps(__sum, __sum, _MM_SHUFFLE(1, 0, 3, 2))); \\
        _mm_blend_ps(__zero, __sum, __imm8); })

#define _mm_dp_pd(__a, __b, __imm8) __extension__ ({ \\
        __m128d __tmp = _mm_mul_pd(__a, __b); \\
        __m128d __zero = _mm_setzero_pd(); \\
        __tmp = _mm_blend_pd(__zero, __tmp, __imm8 >> 4); \\
        __m128d __sum = _mm_add_pd(__tmp, _mm_shuffle_pd(__tmp, __tmp, _MM_SHUFFLE2(0, 1))); \\
        _mm_blend_pd(__zero, __sum, __imm8); })

#define _mm_stream_load_si128 _mm_load_si128

static __inline__  __m128i __attribute__((__always_inline__, __nodebug__))
_mm_min_epi8(__m128i __a, __m128i __b)
{
  return (__m128i)wasm_i8x16_min(__a, __b);
}

static __inline__  __m128i __attribute__((__always_inline__, __nodebug__))
_mm_max_epi8(__m128i __a, __m128i __b)
{
  return (__m128i)wasm_i8x16_max(__a, __b);
}

static __inline__  __m128i __attribute__((__always_inline__, __nodebug__))
_mm_min_epu16(__m128i __a, __m128i __b)
{
  return (__m128i)wasm_u16x8_min(__a, __b);
}

static __inline__  __m128i __attribute__((__always_inline__, __nodebug__))
_mm_max_epu16(__m128i __a, __m128i __b)
{
  return (__m128i)wasm_u16x8_max(__a, __b);
}

static __inline__  __m128i __attribute__((__always_inline__, __nodebug__))
_mm_min_epi32(__m128i __a, __m128i __b)
{
  return (__m128i)wasm_i32x4_min(__a, __b);
}

static __inline__  __m128i __attribute__((__always_inline__, __nodebug__))
_mm_max_epi32(__m128i __a, __m128i __b)
{
  return (__m128i)wasm_i32x4_max(__a, __b);
}

static __inline__  __m128i __attribute__((__always_inline__, __nodebug__))
_mm_min_epu32(__m128i __a, __m128i __b)
{
  return (__m128i)wasm_u32x4_min(__a, __b);
}

static __inline__  __m128i __attribute__((__always_inline__, __nodebug__))
_mm_max_epu32(__m128i __a, __m128i __b)
{
  return (__m128i)wasm_u32x4_max(__a, __b);
}

#define _mm_insert_ps(__a, __b, __imm8) __extension__ ({       \\
        _Static_assert(__builtin_constant_p(__imm8), "Expected constant"); \\
        __m128 __tmp = __builtin_shufflevector((__f32x4)__a, (__f32x4)__b, \\
                            ((((__imm8) >> 4) & 3) == 0) ? ((((__imm8) >> 6) & 3) + 4) : 0, \\
                            ((((__imm8) >> 4) & 3) == 1) ? ((((__imm8) >> 6) & 3) + 4) : 1, \\
                            ((((__imm8) >> 4) & 3) == 2) ? ((((__imm8) >> 6) & 3) + 4) : 2, \\
                            ((((__imm8) >> 4) & 3) == 3) ? ((((__imm8) >> 6) & 3) + 4) : 3); \\
        (__m128)__builtin_shufflevector(__tmp, _mm_setzero_ps(), \\
                                        (((__imm8) & 1) ? 4 : 0), \\
                                        (((__imm8) & 2) ? 5 : 1), \\
                                        (((__imm8) & 4) ? 6 : 2), \\
                                        (((__imm8) & 8) ? 7 : 3)); })

#define _mm_extract_ps(__a, __imm8)                                                                \\
  __extension__({ wasm_i32x4_extract_lane((v128_t)(__a), (__imm8)&3); })

#define _MM_EXTRACT_FLOAT(D, X, N) (__extension__ ({ __f32x4 __a = (__f32x4)(X); \\
                                                    (D) = __a[N]; }))

#define _MM_MK_INSERTPS_NDX(X, Y, Z) (((X) << 6) | ((Y) << 4) | (Z))

#define _MM_PICK_OUT_PS(X, N) _mm_insert_ps(_mm_setzero_ps(), (X),   \\
                                             _MM_MK_INSERTPS_NDX((N), 0, 0x0e))

#define _mm_insert_epi8(__a, __i, __imm8) __extension__ ({    \\
                                     (__m128i)wasm_i8x16_replace_lane((__a), (__imm8) & 15, (__i)); })

#define _mm_insert_epi32(__a, __i, __imm8) __extension__ ({    \\
                                     (__m128i)wasm_i32x4_replace_lane((__a), (__imm8) & 3, (__i)); })

#define _mm_insert_epi64(__a, __i, __imm8) __extension__ ({    \\
                                     (__m128i)wasm_i64x2_replace_lane((__a), (__imm8) & 1, (__i)); })

#define _mm_extract_epi8(__a, __imm8) __extension__ ({       \\
                                       wasm_u8x16_extract_lane((__a), (__imm8) & 15); })

#define _mm_extract_epi32(__a, __imm8) __extension__ ({       \\
                                       wasm_i32x4_extract_lane((__a), (__imm8) & 3); })

#define _mm_extract_epi64(__a, __imm8) __extension__ ({       \\
                                       wasm_i64x2_extract_lane((__a), (__imm8) & 1); })

static __inline__ int __attribute__((__always_inline__, __nodebug__, DIAGNOSE_SLOW))
_mm_testz_si128(__m128i __a, __m128i __b)
{
  v128_t __m = wasm_v128_and(__a, __b);
  return (wasm_i64x2_extract_lane(__m, 0) | wasm_i64x2_extract_lane(__m, 1)) == 0;
}

static __inline__ int __attribute__((__always_inline__, __nodebug__, DIAGNOSE_SLOW))
_mm_testc_si128(__m128i __a, __m128i __b)
{
  v128_t __m = wasm_v128_andnot(__b, __a);
  return (wasm_i64x2_extract_lane(__m, 0) | wasm_i64x2_extract_lane(__m, 1)) == 0;
}

static __inline__ int __attribute__((__always_inline__, __nodebug__))
_mm_testnzc_si128(__m128i __a, __m128i __b)
{
  v128_t __m1 = wasm_v128_and(__a, __b);
  v128_t __m2 = wasm_v128_andnot(__b, __a);
  return (wasm_i64x2_extract_lane(__m1, 0) | wasm_i64x2_extract_lane(__m1, 1))
      && (wasm_i64x2_extract_lane(__m2, 0) | wasm_i64x2_extract_lane(__m2, 1));
}

static __inline__ int __attribute__((__always_inline__, __nodebug__, DIAGNOSE_SLOW))
_mm_test_all_ones(__m128i __a)
{
  return (wasm_i64x2_extract_lane(__a, 0) & wasm_i64x2_extract_lane(__a, 1)) == 0xFFFFFFFFFFFFFFFFull;
}

static __inline__ int __attribute__((__always_inline__, __nodebug__, DIAGNOSE_SLOW))
_mm_test_all_zeros(__m128i __a, __m128i __mask)
{
  v128_t __m = wasm_v128_and(__a, __mask);
  return (wasm_i64x2_extract_lane(__m, 0) | wasm_i64x2_extract_lane(__m, 1)) == 0;
}

static __inline__ int __attribute__((__always_inline__, __nodebug__, DIAGNOSE_SLOW))
_mm_test_mix_ones_zeros(__m128i __a, __m128i __mask)
{
  v128_t __m = wasm_v128_and(__a, __mask);
  long long __c0 = wasm_i64x2_extract_lane(__m, 0);
  long long __c1 = wasm_i64x2_extract_lane(__m, 1);
  long long __ones = __c0 | __c1;
  long long __zeros = ~(__c0 & __c1);
  return __ones && __zeros;
}

static __inline__ __m128i __attribute__((__always_inline__, __nodebug__))
_mm_cmpeq_epi64(__m128i __a, __m128i __b)
{
  const __m128i __mask = _mm_cmpeq_epi32(__a, __b);
  return _mm_and_si128(__mask, _mm_shuffle_epi32(__mask, _MM_SHUFFLE(2, 3, 0, 1)));
}

static __inline__ __m128i __attribute__((__always_inline__, __nodebug__))
_mm_cvtepi8_epi16(__m128i __a)
{
  return (__m128i)wasm_i16x8_widen_low_i8x16((v128_t)__a);
}

static __inline__ __m128i __attribute__((__always_inline__, __nodebug__))
_mm_cvtepi8_epi32(__m128i __a)
{
  return (__m128i)wasm_i32x4_widen_low_i16x8(wasm_i16x8_widen_low_i8x16((v128_t)__a));
}

static __inline__ __m128i __attribute__((__always_inline__, __nodebug__))
_mm_cvtepi8_epi64(__m128i __a)
{
  const __m128i __exta = _mm_cvtepi8_epi32(__a);
  const __m128i __sign = _mm_cmpgt_epi32(_mm_setzero_si128(), __exta);
  return _mm_unpacklo_epi32(__exta, __sign);
}

static __inline__ __m128i __attribute__((__always_inline__, __nodebug__))
_mm_cvtepi16_epi32(__m128i __a)
{
  return (__m128i)wasm_i32x4_widen_low_i16x8((v128_t)__a);
}

static __inline__ __m128i __attribute__((__always_inline__, __nodebug__))
_mm_cvtepi16_epi64(__m128i __a)
{
  const __m128i __exta = _mm_cvtepi16_epi32(__a);
  const __m128i __sign = _mm_cmpgt_epi32(_mm_setzero_si128(), __exta);
  return _mm_unpacklo_epi32(__exta, __sign);
}

static __inline__ __m128i __attribute__((__always_inline__, __nodebug__))
_mm_cvtepi32_epi64(__m128i __a)
{
  const __m128i __sign = _mm_cmpgt_epi32(_mm_setzero_si128(), __a);
  return _mm_unpacklo_epi32(__a, __sign);
}

static __inline__ __m128i __attribute__((__always_inline__, __nodebug__))
_mm_cvtepu8_epi16(__m128i __a)
{
  return (__m128i)wasm_u16x8_extend_low_u8x16((v128_t)__a);
}

static __inline__ __m128i __attribute__((__always_inline__, __nodebug__))
_mm_cvtepu8_epi32(__m128i __a)
{
  return (__m128i)wasm_u32x4_extend_low_u16x8(wasm_i16x8_widen_low_u8x16((v128_t)__a));
}

static __inline__ __m128i __attribute__((__always_inline__, __nodebug__))
_mm_cvtepu8_epi64(__m128i __a)
{
  const __m128i __zero = _mm_setzero_si128();
  return _mm_unpacklo_epi32(_mm_unpacklo_epi16(_mm_unpacklo_epi8(__a, __zero), __zero), __zero);
}

static __inline__ __m128i __attribute__((__always_inline__, __nodebug__))
_mm_cvtepu16_epi32(__m128i __a)
{
  return (__m128i)wasm_u32x4_extend_low_u16x8((v128_t)__a);
}

static __inline__ __m128i __attribute__((__always_inline__, __nodebug__))
_mm_cvtepu16_epi64(__m128i __a)
{
  const __m128i __zero = _mm_setzero_si128();
  return _mm_unpacklo_epi32(_mm_unpacklo_epi16(__a, __zero), __zero);
}

static __inline__ __m128i __attribute__((__always_inline__, __nodebug__))
_mm_cvtepu32_epi64(__m128i __a)
{
  const __m128i __zero = _mm_setzero_si128();
  return _mm_unpacklo_epi32(__a, __zero);
}

static __inline__ __m128i __attribute__((__always_inline__, __nodebug__))
_mm_packus_epi32(__m128i __a, __m128i __b)
{
  return (__m128i)wasm_u16x8_narrow_i32x4(__a, __b);
}

static __inline__ unsigned short __attribute__((__always_inline__, __nodebug__))
__uabs(int __i)
{
  return (unsigned short)((__i >= 0) ? __i : -__i);
}

static __inline__ __m128i __attribute__((__always_inline__, __nodebug__))
_mm_mpsadbw_epu8(__m128i __a, __m128i __b, int __imm8)
{
  int __aOffset = __imm8 & 4;
  int __bOffset = (__imm8 & 3) << 2;
  unsigned short __ret[8];
  for(int __i = 0; __i < 8; ++__i)
  {
    __ret[__i] = __uabs(((__u8x16)__a)[__i + __aOffset    ] - ((__u8x16)__b)[__bOffset    ])
               + __uabs(((__u8x16)__a)[__i + __aOffset + 1] - ((__u8x16)__b)[__bOffset + 1])
               + __uabs(((__u8x16)__a)[__i + __aOffset + 2] - ((__u8x16)__b)[__bOffset + 2])
               + __uabs(((__u8x16)__a)[__i + __aOffset + 3] - ((__u8x16)__b)[__bOffset + 3]);
  }
  return (__m128i)wasm_v128_load(__ret);
}

static __inline__ __m128i __attribute__((__always_inline__, __nodebug__))
_mm_minpos_epu16(__m128i __a)
{
  unsigned short __min[2] = { 0xFFFF, 0 };
  for(int __i = 0; __i < 8; ++__i)
  {
    unsigned short __v = ((__u16x8)__a)[__i];
    if (__v < __min[0])
    {
      __min[0] = __v;
      __min[1] = __i;
    }
  }
  return (__m128i)wasm_i32x4_make(*(int*)__min, 0, 0, 0);
}

// Clang and GCC compatibility: Both Clang and GCC include SSE4.2 headers from SSE4.1 headers
#ifdef __SSE4_2__
#include <nmmintrin.h>
#endif

#endif /* __emscripten_smmintrin_h__ */
`,"nmmintrin.h":`/*
 * Copyright 2020 The Emscripten Authors.  All rights reserved.
 * Emscripten is available under two separate licenses, the MIT license and the
 * University of Illinois/NCSA Open Source License.  Both these licenses can be
 * found in the LICENSE file.
 */
#ifndef __emscripten_nmmintrin_h__
#define __emscripten_nmmintrin_h__

#ifndef __SSE4_2__
#error "SSE4.2 instruction set not enabled"
#endif

#include <smmintrin.h>

static __inline__ __m128i __attribute__((__always_inline__, __nodebug__))
_mm_cmpgt_epi64(__m128i __a, __m128i __b)
{
  return wasm_i64x2_gt(__a, __b);
}

// Unsupported functions:
// _mm_cmpestra
// _mm_cmpestrc
// _mm_cmpestri
// _mm_cmpestrm
// _mm_cmpestro
// _mm_cmpestrs
// _mm_cmpestrz
// _mm_cmpistra
// _mm_cmpistrc
// _mm_cmpistri
// _mm_cmpistrm
// _mm_cmpistro
// _mm_cmpistrs
// _mm_cmpistrz
// _mm_crc32_u16
// _mm_crc32_u32
// _mm_crc32_u64
// _mm_crc32_u8

#endif /* __emscripten_nmmintrin_h__ */
`,"avxintrin.h":`/*
 * Copyright 2020 The Emscripten Authors.  All rights reserved.
 * Emscripten is available under two separate licenses, the MIT license and the
 * University of Illinois/NCSA Open Source License.  Both these licenses can be
 * found in the LICENSE file.
 */

#ifndef __emscripten_immintrin_h__
#error "Never use <avxintrin.h> directly; include <immintrin.h> instead."
#endif

#ifndef __emscripten_avxintrin_h__
#define __emscripten_avxintrin_h__

#ifndef __AVX__
#error "AVX instruction set not enabled"
#endif

typedef float __m256 __attribute__((__vector_size__(32), __aligned__(32)));
typedef double __m256d __attribute__((__vector_size__(32), __aligned__(32)));
typedef int32_t __m256i __attribute__((__vector_size__(32), __aligned__(32)));

typedef int32_t __m128i_u __attribute__((__vector_size__(16), __aligned__(1)));
typedef int32_t __m256i_u __attribute__((__vector_size__(32), __aligned__(1)));

typedef struct {
  __m128d v0;
  __m128d v1;
} __m256d_internal;

typedef struct {
  __m128 v0;
  __m128 v1;
} __m256_internal;

typedef struct {
    __m128i v0;
    __m128i v1;
} __m256i_internal;

static __inline__ __m256_internal __m256_to_internal(__m256 a) {
  union {
    __m256 in;
    __m256_internal out;
  } ret;
  ret.in = a;
  return ret.out;
}

static __inline__ __m256 __m256_from_internal(__m256_internal a) {
  union {
    __m256_internal in;
    __m256 out;
  } ret;
  ret.in = a;
  return ret.out;
}

static __inline__ __m256d_internal __m256d_to_internal(__m256d a) {
  union {
    __m256d in;
    __m256d_internal out;
  } ret;
  ret.in = a;
  return ret.out;
}

static __inline__ __m256d __m256d_from_internal(__m256d_internal a) {
  union {
    __m256d_internal in;
    __m256d out;
  } ret;
  ret.in = a;
  return ret.out;
}

static __inline__ __m256i_internal __m256i_to_internal(__m256i a) {
  union {
    __m256i in;
    __m256i_internal out;
  } ret;
  ret.in = a;
  return ret.out;
}

static __inline__ __m256i __m256i_from_internal(__m256i_internal a) {
  union {
    __m256i_internal in;
    __m256i out;
  } ret;
  ret.in = a;
  return ret.out;
}

union __m256_data {
  __m256i int_view;
  __m256d double_view;
  __m256 float_view;
  __m128i_u int_u_view;
};

static __inline__ __m256d __attribute__((__always_inline__, __nodebug__))
_mm256_add_pd(__m256d __a, __m256d __b) {
  __m256d_internal ret, a, b;
  a = __m256d_to_internal(__a);
  b = __m256d_to_internal(__b);
  ret.v0 = _mm_add_pd(a.v0, b.v0);
  ret.v1 = _mm_add_pd(a.v1, b.v1);
  return __m256d_from_internal(ret);
}

static __inline__ __m256 __attribute__((__always_inline__, __nodebug__))
_mm256_add_ps(__m256 __a, __m256 __b) {
  __m256_internal ret, a, b;
  a = __m256_to_internal(__a);
  b = __m256_to_internal(__b);
  ret.v0 = _mm_add_ps(a.v0, b.v0);
  ret.v1 = _mm_add_ps(a.v1, b.v1);
  return __m256_from_internal(ret);
}

static __inline__ __m256d __attribute__((__always_inline__, __nodebug__))
_mm256_sub_pd(__m256d __a, __m256d __b) {
  __m256d_internal ret, a, b;
  a = __m256d_to_internal(__a);
  b = __m256d_to_internal(__b);
  ret.v0 = _mm_sub_pd(a.v0, b.v0);
  ret.v1 = _mm_sub_pd(a.v1, b.v1);
  return __m256d_from_internal(ret);
}

static __inline__ __m256 __attribute__((__always_inline__, __nodebug__))
_mm256_sub_ps(__m256 __a, __m256 __b) {
  __m256_internal ret, a, b;
  a = __m256_to_internal(__a);
  b = __m256_to_internal(__b);
  ret.v0 = _mm_sub_ps(a.v0, b.v0);
  ret.v1 = _mm_sub_ps(a.v1, b.v1);
  return __m256_from_internal(ret);
}

static __inline__ __m256d __attribute__((__always_inline__, __nodebug__))
_mm256_addsub_pd(__m256d __a, __m256d __b) {
  __m256d_internal ret, a, b;
  a = __m256d_to_internal(__a);
  b = __m256d_to_internal(__b);
  ret.v0 = _mm_addsub_pd(a.v0, b.v0);
  ret.v1 = _mm_addsub_pd(a.v1, b.v1);
  return __m256d_from_internal(ret);
}

static __inline__ __m256 __attribute__((__always_inline__, __nodebug__))
_mm256_addsub_ps(__m256 __a, __m256 __b) {
  __m256_internal ret, a, b;
  a = __m256_to_internal(__a);
  b = __m256_to_internal(__b);
  ret.v0 = _mm_addsub_ps(a.v0, b.v0);
  ret.v1 = _mm_addsub_ps(a.v1, b.v1);
  return __m256_from_internal(ret);
}

static __inline__ __m256d __attribute__((__always_inline__, __nodebug__))
_mm256_div_pd(__m256d __a, __m256d __b) {
  __m256d_internal ret, a, b;
  a = __m256d_to_internal(__a);
  b = __m256d_to_internal(__b);
  ret.v0 = _mm_div_pd(a.v0, b.v0);
  ret.v1 = _mm_div_pd(a.v1, b.v1);
  return __m256d_from_internal(ret);
}

static __inline__ __m256 __attribute__((__always_inline__, __nodebug__))
_mm256_div_ps(__m256 __a, __m256 __b) {
  __m256_internal ret, a, b;
  a = __m256_to_internal(__a);
  b = __m256_to_internal(__b);
  ret.v0 = _mm_div_ps(a.v0, b.v0);
  ret.v1 = _mm_div_ps(a.v1, b.v1);
  return __m256_from_internal(ret);
}

static __inline__ __m256d __attribute__((__always_inline__, __nodebug__))
_mm256_max_pd(__m256d __a, __m256d __b) {
  __m256d_internal ret, a, b;
  a = __m256d_to_internal(__a);
  b = __m256d_to_internal(__b);
  ret.v0 = _mm_max_pd(a.v0, b.v0);
  ret.v1 = _mm_max_pd(a.v1, b.v1);
  return __m256d_from_internal(ret);
}

static __inline__ __m256 __attribute__((__always_inline__, __nodebug__))
_mm256_max_ps(__m256 __a, __m256 __b) {
  __m256_internal ret, a, b;
  a = __m256_to_internal(__a);
  b = __m256_to_internal(__b);
  ret.v0 = _mm_max_ps(a.v0, b.v0);
  ret.v1 = _mm_max_ps(a.v1, b.v1);
  return __m256_from_internal(ret);
}

static __inline__ __m256d __attribute__((__always_inline__, __nodebug__))
_mm256_min_pd(__m256d __a, __m256d __b) {
  __m256d_internal ret, a, b;
  a = __m256d_to_internal(__a);
  b = __m256d_to_internal(__b);
  ret.v0 = _mm_min_pd(a.v0, b.v0);
  ret.v1 = _mm_min_pd(a.v1, b.v1);
  return __m256d_from_internal(ret);
}

static __inline__ __m256 __attribute__((__always_inline__, __nodebug__))
_mm256_min_ps(__m256 __a, __m256 __b) {
  __m256_internal ret, a, b;
  a = __m256_to_internal(__a);
  b = __m256_to_internal(__b);
  ret.v0 = _mm_min_ps(a.v0, b.v0);
  ret.v1 = _mm_min_ps(a.v1, b.v1);
  return __m256_from_internal(ret);
}

static __inline__ __m256d __attribute__((__always_inline__, __nodebug__))
_mm256_mul_pd(__m256d __a, __m256d __b) {
  __m256d_internal ret, a, b;
  a = __m256d_to_internal(__a);
  b = __m256d_to_internal(__b);
  ret.v0 = _mm_mul_pd(a.v0, b.v0);
  ret.v1 = _mm_mul_pd(a.v1, b.v1);
  return __m256d_from_internal(ret);
}

static __inline__ __m256 __attribute__((__always_inline__, __nodebug__))
_mm256_mul_ps(__m256 __a, __m256 __b) {
  __m256_internal ret, a, b;
  a = __m256_to_internal(__a);
  b = __m256_to_internal(__b);
  ret.v0 = _mm_mul_ps(a.v0, b.v0);
  ret.v1 = _mm_mul_ps(a.v1, b.v1);
  return __m256_from_internal(ret);
}

static __inline__ __m256d __attribute__((__always_inline__, __nodebug__))
_mm256_sqrt_pd(__m256d __a) {
  __m256d_internal ret, a;
  a = __m256d_to_internal(__a);
  ret.v0 = _mm_sqrt_pd(a.v0);
  ret.v1 = _mm_sqrt_pd(a.v1);
  return __m256d_from_internal(ret);
}

static __inline__ __m256 __attribute__((__always_inline__, __nodebug__))
_mm256_sqrt_ps(__m256 __a) {
  __m256_internal ret, a;
  a = __m256_to_internal(__a);
  ret.v0 = _mm_sqrt_ps(a.v0);
  ret.v1 = _mm_sqrt_ps(a.v1);
  return __m256_from_internal(ret);
}

static __inline__ __m256 __attribute__((__always_inline__, __nodebug__))
_mm256_rsqrt_ps(__m256 __a) {
  __m256_internal ret, a;
  a = __m256_to_internal(__a);
  ret.v0 = _mm_rsqrt_ps(a.v0);
  ret.v1 = _mm_rsqrt_ps(a.v1);
  return __m256_from_internal(ret);
}

static __inline__ __m256 __attribute__((__always_inline__, __nodebug__))
_mm256_rcp_ps(__m256 __a) {
  __m256_internal ret, a;
  a = __m256_to_internal(__a);
  ret.v0 = _mm_rcp_ps(a.v0);
  ret.v1 = _mm_rcp_ps(a.v1);
  return __m256_from_internal(ret);
}

static __inline__ __m256d __attribute__((__always_inline__, __nodebug__))
_mm256_round_pd(__m256d __a, int __rounding) {
  __m256d_internal ret, a;
  a = __m256d_to_internal(__a);
  ret.v0 = _mm_round_pd(a.v0, __rounding);
  ret.v1 = _mm_round_pd(a.v1, __rounding);
  return __m256d_from_internal(ret);
}

static __inline__ __m256 __attribute__((__always_inline__, __nodebug__))
_mm256_round_ps(__m256 __a, int __rounding) {
  __m256_internal ret, a;
  a = __m256_to_internal(__a);
  ret.v0 = _mm_round_ps(a.v0, __rounding);
  ret.v1 = _mm_round_ps(a.v1, __rounding);
  return __m256_from_internal(ret);
}

#define _mm256_ceil_pd(V) _mm256_round_pd((V), _MM_FROUND_CEIL)
#define _mm256_floor_pd(V) _mm256_round_pd((V), _MM_FROUND_FLOOR)
#define _mm256_ceil_ps(V) _mm256_round_ps((V), _MM_FROUND_CEIL)
#define _mm256_floor_ps(V) _mm256_round_ps((V), _MM_FROUND_FLOOR)

static __inline__ __m256d
  __attribute__((__always_inline__, __nodebug__)) _mm256_and_pd(__m256d __a,
                                                                __m256d __b) {
  __m256d_internal ret, a, b;
  a = __m256d_to_internal(__a);
  b = __m256d_to_internal(__b);
  ret.v0 = _mm_and_pd(a.v0, b.v0);
  ret.v1 = _mm_and_pd(a.v1, b.v1);
  return __m256d_from_internal(ret);
}

static __inline__ __m256 __attribute__((__always_inline__, __nodebug__))
_mm256_and_ps(__m256 __a, __m256 __b) {
  __m256_internal ret, a, b;
  a = __m256_to_internal(__a);
  b = __m256_to_internal(__b);
  ret.v0 = _mm_and_ps(a.v0, b.v0);
  ret.v1 = _mm_and_ps(a.v1, b.v1);
  return __m256_from_internal(ret);
}

static __inline__ __m256d __attribute__((__always_inline__, __nodebug__))
_mm256_andnot_pd(__m256d __a, __m256d __b) {
  __m256d_internal ret, a, b;
  a = __m256d_to_internal(__a);
  b = __m256d_to_internal(__b);
  ret.v0 = _mm_andnot_pd(a.v0, b.v0);
  ret.v1 = _mm_andnot_pd(a.v1, b.v1);
  return __m256d_from_internal(ret);
}

static __inline__ __m256 __attribute__((__always_inline__, __nodebug__))
_mm256_andnot_ps(__m256 __a, __m256 __b) {
  __m256_internal ret, a, b;
  a = __m256_to_internal(__a);
  b = __m256_to_internal(__b);
  ret.v0 = _mm_andnot_ps(a.v0, b.v0);
  ret.v1 = _mm_andnot_ps(a.v1, b.v1);
  return __m256_from_internal(ret);
}

static __inline__ __m256d __attribute__((__always_inline__, __nodebug__))
_mm256_or_pd(__m256d __a, __m256d __b) {
  __m256d_internal ret, a, b;
  a = __m256d_to_internal(__a);
  b = __m256d_to_internal(__b);
  ret.v0 = _mm_or_pd(a.v0, b.v0);
  ret.v1 = _mm_or_pd(a.v1, b.v1);
  return __m256d_from_internal(ret);
}

static __inline__ __m256 __attribute__((__always_inline__, __nodebug__))
_mm256_or_ps(__m256 __a, __m256 __b) {
  __m256_internal ret, a, b;
  a = __m256_to_internal(__a);
  b = __m256_to_internal(__b);
  ret.v0 = _mm_or_ps(a.v0, b.v0);
  ret.v1 = _mm_or_ps(a.v1, b.v1);
  return __m256_from_internal(ret);
}

static __inline__ __m256d __attribute__((__always_inline__, __nodebug__))
_mm256_xor_pd(__m256d __a, __m256d __b) {
  __m256d_internal ret, a, b;
  a = __m256d_to_internal(__a);
  b = __m256d_to_internal(__b);
  ret.v0 = _mm_xor_pd(a.v0, b.v0);
  ret.v1 = _mm_xor_pd(a.v1, b.v1);
  return __m256d_from_internal(ret);
}

static __inline__ __m256 __attribute__((__always_inline__, __nodebug__))
_mm256_xor_ps(__m256 __a, __m256 __b) {
  __m256_internal ret, a, b;
  a = __m256_to_internal(__a);
  b = __m256_to_internal(__b);
  ret.v0 = _mm_xor_ps(a.v0, b.v0);
  ret.v1 = _mm_xor_ps(a.v1, b.v1);
  return __m256_from_internal(ret);
}

static __inline__ __m256d __attribute__((__always_inline__, __nodebug__))
_mm256_hadd_pd(__m256d __a, __m256d __b) {
  __m256d_internal ret, a, b;
  a = __m256d_to_internal(__a);
  b = __m256d_to_internal(__b);
  ret.v0 = _mm_hadd_pd(a.v0, b.v0);
  ret.v1 = _mm_hadd_pd(a.v1, b.v1);
  return __m256d_from_internal(ret);
}

static __inline__ __m256 __attribute__((__always_inline__, __nodebug__))
_mm256_hadd_ps(__m256 __a, __m256 __b) {
  __m256_internal ret, a, b;
  a = __m256_to_internal(__a);
  b = __m256_to_internal(__b);
  ret.v0 = _mm_hadd_ps(a.v0, b.v0);
  ret.v1 = _mm_hadd_ps(a.v1, b.v1);
  return __m256_from_internal(ret);
}

static __inline__ __m256d __attribute__((__always_inline__, __nodebug__))
_mm256_hsub_pd(__m256d __a, __m256d __b) {
  __m256d_internal ret, a, b;
  a = __m256d_to_internal(__a);
  b = __m256d_to_internal(__b);
  ret.v0 = _mm_hsub_pd(a.v0, b.v0);
  ret.v1 = _mm_hsub_pd(a.v1, b.v1);
  return __m256d_from_internal(ret);
}

static __inline__ __m256 __attribute__((__always_inline__, __nodebug__))
_mm256_hsub_ps(__m256 __a, __m256 __b) {
  __m256_internal ret, a, b;
  a = __m256_to_internal(__a);
  b = __m256_to_internal(__b);
  ret.v0 = _mm_hsub_ps(a.v0, b.v0);
  ret.v1 = _mm_hsub_ps(a.v1, b.v1);
  return __m256_from_internal(ret);
}

static __inline__ __m128d __attribute__((__always_inline__, __nodebug__))
_mm_permutevar_pd(__m128d __a, __m128i __c) {
  return (__m128d)wasm_f64x2_make(
    ((__f64x2)__a)[(wasm_i64x2_extract_lane(__c, 0) >> 1) & 1],
    ((__f64x2)__a)[(wasm_i64x2_extract_lane(__c, 1) >> 1) & 1]);
}

static __inline__ __m256d __attribute__((__always_inline__, __nodebug__))
_mm256_permutevar_pd(__m256d __a, __m256i __c) {
  __m256d_internal ret, a;
  __m256i_internal c;
  a = __m256d_to_internal(__a);
  c = __m256i_to_internal(__c);
  ret.v0 = _mm_permutevar_pd(a.v0, c.v0);
  ret.v1 = _mm_permutevar_pd(a.v1, c.v1);
  return __m256d_from_internal(ret);
}

static __inline__ __m128 __attribute__((__always_inline__, __nodebug__))
_mm_permutevar_ps(__m128 __a, __m128i __c) {
  return (__m128)wasm_f32x4_make(
    ((__f32x4)__a)[wasm_i32x4_extract_lane(__c, 0) & 3],
    ((__f32x4)__a)[wasm_i32x4_extract_lane(__c, 1) & 3],
    ((__f32x4)__a)[wasm_i32x4_extract_lane(__c, 2) & 3],
    ((__f32x4)__a)[wasm_i32x4_extract_lane(__c, 3) & 3]);
}

static __inline__ __m256 __attribute__((__always_inline__, __nodebug__))
_mm256_permutevar_ps(__m256 __a, __m256i __c) {
  __m256_internal ret, a;
  __m256i_internal c;
  a = __m256_to_internal(__a);
  c = __m256i_to_internal(__c);
  ret.v0 = _mm_permutevar_ps(a.v0, c.v0);
  ret.v1 = _mm_permutevar_ps(a.v1, c.v1);
  return __m256_from_internal(ret);
}

#define _mm_permute_pd(__a, __imm)                                             \\
  ((__m128d)wasm_i64x2_shuffle(                                                \\
    (__m128d)(__a), (__m128d)(__a), ((__imm) & 1), (((__imm) >> 1) & 1)))

#define _mm256_permute_pd(__A, __imm)                                          \\
  __extension__({                                                              \\
    __m256d_internal __a = __m256d_to_internal(__A);                             \\
    _mm256_set_m128d(_mm_permute_pd(__a.v1, (__imm) >> 2),                     \\
                     _mm_permute_pd(__a.v0, (__imm)));                         \\
  })

#define _mm_permute_ps(__a, __imm)                                             \\
  ((__m128)wasm_i32x4_shuffle((__m128)(__a),                                   \\
                              (__m128)(__a),                                   \\
                              ((__imm) & 3),                                   \\
                              (((__imm) >> 2) & 3),                            \\
                              (((__imm) >> 4) & 3),                            \\
                              (((__imm) >> 6) & 3)))

#define _mm256_permute_ps(__A, __imm)                                          \\
  __extension__({                                                              \\
    __m256_internal __a = __m256_to_internal(__A);                               \\
    _mm256_set_m128(_mm_permute_ps(__a.v1, (__imm)),                           \\
                    _mm_permute_ps(__a.v0, (__imm)));                          \\
  })

static __inline__ __m128d
__avx_select4d(__m256d __a, __m256d __b, const int imm8) {
  __m256d_internal a, b;
  a = __m256d_to_internal(__a);
  b = __m256d_to_internal(__b);
  switch (imm8 & 0xF) {
    case 0:
    case 4:
      return a.v0;
    case 1:
    case 5:
      return a.v1;
    case 2:
    case 6:
      return b.v0;
    case 3:
    case 7:
      return b.v1;
    default:
      return (__m128d)wasm_i64x2_const_splat(0);
  }
}

static __inline__ __m128 __avx_select4(__m256 __a, __m256 __b, const int imm8) {
  __m256_internal a, b;
  a = __m256_to_internal(__a);
  b = __m256_to_internal(__b);
  switch (imm8 & 0xF) {
    case 0:
    case 4:
      return a.v0;
    case 1:
    case 5:
      return a.v1;
    case 2:
    case 6:
      return b.v0;
    case 3:
    case 7:
      return b.v1;
    default:
      return (__m128)wasm_i64x2_const_splat(0);
  }
}

static __inline__ __m128i
__avx_select4i(__m256i __a, __m256i __b, const int imm8) {
  __m256i_internal a, b;
  a = __m256i_to_internal(__a);
  b = __m256i_to_internal(__b);
  switch (imm8 & 0xF) {
    case 0:
    case 4:
      return a.v0;
    case 1:
    case 5:
      return a.v1;
    case 2:
    case 6:
      return b.v0;
    case 3:
    case 7:
      return b.v1;
    default:
      return wasm_i64x2_const_splat(0);
  }
}

static __inline__ __m256d __attribute__((__always_inline__, __nodebug__))
_mm256_permute2f128_pd(__m256d __a, __m256d __b, const int imm8) {
  __m256d_internal ret;
  ret.v0 = __avx_select4d(__a, __b, imm8);
  ret.v1 = __avx_select4d(__a, __b, imm8 >> 4);
  return __m256d_from_internal(ret);
}

static __inline__ __m256 __attribute__((__always_inline__, __nodebug__))
_mm256_permute2f128_ps(__m256 __a, __m256 __b, const int imm8) {
  __m256_internal ret;
  ret.v0 = __avx_select4(__a, __b, imm8);
  ret.v1 = __avx_select4(__a, __b, imm8 >> 4);
  return __m256_from_internal(ret);
}

static __inline__ __m256i __attribute__((__always_inline__, __nodebug__))
_mm256_permute2f128_si256(__m256i __a, __m256i __b, const int imm8) {
  __m256i_internal ret;
  ret.v0 = __avx_select4i(__a, __b, imm8);
  ret.v1 = __avx_select4i(__a, __b, imm8 >> 4);
  return __m256i_from_internal(ret);
}

#define _mm256_blend_pd(__A, __B, imm8)                                        \\
  __extension__({                                                              \\
    __m256d_internal __a = __m256d_to_internal(__A);                             \\
    __m256d_internal __b = __m256d_to_internal(__B);                             \\
    _mm256_set_m128d(_mm_blend_pd(__a.v1, __b.v1, (imm8) >> 2),                \\
                     _mm_blend_pd(__a.v0, __b.v0, (imm8)));                    \\
  })

#define _mm256_blend_ps(__A, __B, imm)                                         \\
  __extension__({                                                              \\
    __m256_internal __a = __m256_to_internal(__A);                               \\
    __m256_internal __b = __m256_to_internal(__B);                               \\
    _mm256_set_m128(_mm_blend_ps(__a.v1, __b.v1, (imm) >> 4),                  \\
                    _mm_blend_ps(__a.v0, __b.v0, (imm)));                      \\
  })

static __inline__ __m256d __attribute__((__always_inline__, __nodebug__))
_mm256_blendv_pd(__m256d __a, __m256d __b, __m256d __c) {
  __m256d_internal ret, a, b, c;
  a = __m256d_to_internal(__a);
  b = __m256d_to_internal(__b);
  c = __m256d_to_internal(__c);
  ret.v0 = _mm_blendv_pd(a.v0, b.v0, c.v0);
  ret.v1 = _mm_blendv_pd(a.v1, b.v1, c.v1);
  return __m256d_from_internal(ret);
}

static __inline__ __m256 __attribute__((__always_inline__, __nodebug__))
_mm256_blendv_ps(__m256 __a, __m256 __b, __m256 __c) {
  __m256_internal ret, a, b, c;
  a = __m256_to_internal(__a);
  b = __m256_to_internal(__b);
  c = __m256_to_internal(__c);
  ret.v0 = _mm_blendv_ps(a.v0, b.v0, c.v0);
  ret.v1 = _mm_blendv_ps(a.v1, b.v1, c.v1);
  return __m256_from_internal(ret);
}

#define _mm256_dp_ps(__A, __B, imm)                                            \\
  __extension__({                                                              \\
    __m256_internal __a = __m256_to_internal(__A);                               \\
    __m256_internal __b = __m256_to_internal(__B);                               \\
    _mm256_set_m128(_mm_dp_ps(__a.v1, __b.v1, (imm)),                          \\
                    _mm_dp_ps(__a.v0, __b.v0, (imm)));                         \\
  })

#define _mm256_shuffle_ps(__A, __B, mask)                                      \\
  __extension__({                                                              \\
    __m256_internal __a = __m256_to_internal(__A);                               \\
    __m256_internal __b = __m256_to_internal(__B);                               \\
    _mm256_set_m128(_mm_shuffle_ps(__a.v1, __b.v1, (mask)),                    \\
                    _mm_shuffle_ps(__a.v0, __b.v0, (mask)));                   \\
  })

#define _mm256_shuffle_pd(__A, __B, mask)                                      \\
  __extension__({                                                              \\
    __m256d_internal __a = __m256d_to_internal(__A);                             \\
    __m256d_internal __b = __m256d_to_internal(__B);                             \\
    _mm256_set_m128d(_mm_shuffle_pd(__a.v1, __b.v1, (mask) >> 2),              \\
                     _mm_shuffle_pd(__a.v0, __b.v0, (mask)));                  \\
  })

#define _CMP_EQ_OQ 0
#define _CMP_LT_OS 1
#define _CMP_LE_OS 2
#define _CMP_UNORD_Q 3
#define _CMP_NEQ_UQ 4
#define _CMP_NLT_US 5
#define _CMP_NLE_US 6
#define _CMP_ORD_Q 7
#define _CMP_EQ_UQ 8
#define _CMP_NGE_US 9
#define _CMP_NGT_US 10
#define _CMP_FALSE_OQ 11
#define _CMP_NEQ_OQ 12
#define _CMP_GE_OS 13
#define _CMP_GT_OS 14
#define _CMP_TRUE_UQ 15
#define _CMP_EQ_OS 16
#define _CMP_LT_OQ 17
#define _CMP_LE_OQ 18
#define _CMP_UNORD_S 19
#define _CMP_NEQ_US 20
#define _CMP_NLT_UQ 21
#define _CMP_NLE_UQ 22
#define _CMP_ORD_S 23
#define _CMP_EQ_US 24
#define _CMP_NGE_UQ 25
#define _CMP_NGT_UQ 26
#define _CMP_FALSE_OS 27
#define _CMP_NEQ_OS 28
#define _CMP_GE_OQ 29
#define _CMP_GT_OQ 30
#define _CMP_TRUE_US 31

#define _mm_cmp_pd(__a, __b, __imm)                                            \\
  __extension__({                                                              \\
    __m128d __ret;                                                             \\
    switch ((__imm)) {                                                         \\
      case _CMP_EQ_OQ:                                                         \\
      case _CMP_EQ_OS:                                                         \\
        __ret = _mm_cmpeq_pd((__a), (__b));                                    \\
        break;                                                                 \\
      case _CMP_EQ_UQ:                                                         \\
      case _CMP_EQ_US:                                                         \\
        __ret = _mm_or_pd(_mm_cmpeq_pd((__a), (__b)),                          \\
                          _mm_cmpunord_pd((__a), (__b)));                      \\
        break;                                                                 \\
      case _CMP_LT_OS:                                                         \\
      case _CMP_LT_OQ:                                                         \\
        __ret = _mm_cmplt_pd((__a), (__b));                                    \\
        break;                                                                 \\
      case _CMP_LE_OS:                                                         \\
      case _CMP_LE_OQ:                                                         \\
        __ret = _mm_cmple_pd((__a), (__b));                                    \\
        break;                                                                 \\
      case _CMP_UNORD_Q:                                                       \\
      case _CMP_UNORD_S:                                                       \\
        __ret = _mm_cmpunord_pd((__a), (__b));                                 \\
        break;                                                                 \\
      case _CMP_NEQ_UQ:                                                        \\
      case _CMP_NEQ_US:                                                        \\
        __ret = _mm_cmpneq_pd((__a), (__b));                                   \\
        break;                                                                 \\
      case _CMP_NEQ_OQ:                                                        \\
      case _CMP_NEQ_OS:                                                        \\
        __ret = _mm_andnot_pd(_mm_cmpunord_pd((__a), (__b)),                   \\
                              _mm_cmpneq_pd((__a), (__b)));                    \\
        break;                                                                 \\
      case _CMP_NLT_US:                                                        \\
      case _CMP_NLT_UQ:                                                        \\
        __ret = _mm_cmpnlt_pd((__a), (__b));                                   \\
        break;                                                                 \\
      case _CMP_ORD_Q:                                                         \\
      case _CMP_ORD_S:                                                         \\
        __ret = _mm_cmpord_pd((__a), (__b));                                   \\
        break;                                                                 \\
      case _CMP_NGE_US:                                                        \\
      case _CMP_NGE_UQ:                                                        \\
        __ret = _mm_cmpnge_pd((__a), (__b));                                   \\
        break;                                                                 \\
      case _CMP_NGT_US:                                                        \\
      case _CMP_NGT_UQ:                                                        \\
        __ret = _mm_cmpngt_pd((__a), (__b));                                   \\
        break;                                                                 \\
      case _CMP_FALSE_OQ:                                                      \\
      case _CMP_FALSE_OS:                                                      \\
        __ret = _mm_setzero_pd();                                              \\
        break;                                                                 \\
      case _CMP_GE_OS:                                                         \\
      case _CMP_GE_OQ:                                                         \\
        __ret = _mm_cmpge_pd((__a), (__b));                                    \\
        break;                                                                 \\
      case _CMP_GT_OS:                                                         \\
      case _CMP_GT_OQ:                                                         \\
        __ret = _mm_cmpgt_pd((__a), (__b));                                    \\
        break;                                                                 \\
      case _CMP_TRUE_UQ:                                                       \\
      case _CMP_TRUE_US:                                                       \\
        __ret = (__m128d)wasm_i8x16_splat(0xFF);                               \\
        break;                                                                 \\
      case _CMP_NLE_US:                                                        \\
      case _CMP_NLE_UQ:                                                        \\
        __ret = _mm_cmpnle_pd((__a), (__b));                                   \\
        break;                                                                 \\
    }                                                                          \\
    __ret;                                                                     \\
  })

#define _mm_cmp_ps(__a, __b, __imm)                                            \\
  __extension__({                                                              \\
    __m128 __ret;                                                              \\
    switch ((__imm)) {                                                         \\
      case _CMP_EQ_OQ:                                                         \\
      case _CMP_EQ_OS:                                                         \\
        __ret = _mm_cmpeq_ps((__a), (__b));                                    \\
        break;                                                                 \\
      case _CMP_EQ_UQ:                                                         \\
      case _CMP_EQ_US:                                                         \\
        __ret = _mm_or_ps(_mm_cmpeq_ps((__a), (__b)),                          \\
                          _mm_cmpunord_ps((__a), (__b)));                      \\
        break;                                                                 \\
      case _CMP_LT_OS:                                                         \\
      case _CMP_LT_OQ:                                                         \\
        __ret = _mm_cmplt_ps((__a), (__b));                                    \\
        break;                                                                 \\
      case _CMP_LE_OS:                                                         \\
      case _CMP_LE_OQ:                                                         \\
        __ret = _mm_cmple_ps((__a), (__b));                                    \\
        break;                                                                 \\
      case _CMP_UNORD_Q:                                                       \\
      case _CMP_UNORD_S:                                                       \\
        __ret = _mm_cmpunord_ps((__a), (__b));                                 \\
        break;                                                                 \\
      case _CMP_NEQ_UQ:                                                        \\
      case _CMP_NEQ_US:                                                        \\
        __ret = _mm_cmpneq_ps((__a), (__b));                                   \\
        break;                                                                 \\
      case _CMP_NEQ_OQ:                                                        \\
      case _CMP_NEQ_OS:                                                        \\
        __ret = _mm_andnot_ps(_mm_cmpunord_ps((__a), (__b)),                   \\
                              _mm_cmpneq_ps((__a), (__b)));                    \\
        break;                                                                 \\
      case _CMP_NLT_US:                                                        \\
      case _CMP_NLT_UQ:                                                        \\
        __ret = _mm_cmpnlt_ps((__a), (__b));                                   \\
        break;                                                                 \\
      case _CMP_ORD_Q:                                                         \\
      case _CMP_ORD_S:                                                         \\
        __ret = _mm_cmpord_ps((__a), (__b));                                   \\
        break;                                                                 \\
      case _CMP_NGE_US:                                                        \\
      case _CMP_NGE_UQ:                                                        \\
        __ret = _mm_cmpnge_ps((__a), (__b));                                   \\
        break;                                                                 \\
      case _CMP_NGT_US:                                                        \\
      case _CMP_NGT_UQ:                                                        \\
        __ret = _mm_cmpngt_ps((__a), (__b));                                   \\
        break;                                                                 \\
      case _CMP_FALSE_OQ:                                                      \\
      case _CMP_FALSE_OS:                                                      \\
        __ret = _mm_setzero_ps();                                              \\
        break;                                                                 \\
      case _CMP_GE_OS:                                                         \\
      case _CMP_GE_OQ:                                                         \\
        __ret = _mm_cmpge_ps((__a), (__b));                                    \\
        break;                                                                 \\
      case _CMP_GT_OS:                                                         \\
      case _CMP_GT_OQ:                                                         \\
        __ret = _mm_cmpgt_ps((__a), (__b));                                    \\
        break;                                                                 \\
      case _CMP_TRUE_UQ:                                                       \\
      case _CMP_TRUE_US:                                                       \\
        __ret = (__m128)wasm_i8x16_splat(0xFF);                                \\
        break;                                                                 \\
      case _CMP_NLE_US:                                                        \\
      case _CMP_NLE_UQ:                                                        \\
        __ret = _mm_cmpnle_ps((__a), (__b));                                   \\
        break;                                                                 \\
    }                                                                          \\
    __ret;                                                                     \\
  })

#define _mm_cmp_sd(__a, __b, __imm)                                            \\
  __extension__({                                                              \\
    __m128d __ret;                                                             \\
    switch ((__imm)) {                                                         \\
      case _CMP_EQ_OQ:                                                         \\
      case _CMP_EQ_OS:                                                         \\
        __ret = _mm_cmpeq_sd((__a), (__b));                                    \\
        break;                                                                 \\
      case _CMP_EQ_UQ:                                                         \\
      case _CMP_EQ_US:                                                         \\
        __ret = _mm_move_sd((__a),                                             \\
                            _mm_or_pd(_mm_cmpeq_sd((__a), (__b)),              \\
                                      _mm_cmpunord_sd((__a), (__b))));         \\
        break;                                                                 \\
      case _CMP_LT_OS:                                                         \\
      case _CMP_LT_OQ:                                                         \\
        __ret = _mm_cmplt_sd((__a), (__b));                                    \\
        break;                                                                 \\
      case _CMP_LE_OS:                                                         \\
      case _CMP_LE_OQ:                                                         \\
        __ret = _mm_cmple_sd((__a), (__b));                                    \\
        break;                                                                 \\
      case _CMP_UNORD_Q:                                                       \\
      case _CMP_UNORD_S:                                                       \\
        __ret = _mm_cmpunord_sd((__a), (__b));                                 \\
        break;                                                                 \\
      case _CMP_NEQ_UQ:                                                        \\
      case _CMP_NEQ_US:                                                        \\
        __ret = _mm_cmpneq_sd((__a), (__b));                                   \\
        break;                                                                 \\
      case _CMP_NEQ_OQ:                                                        \\
      case _CMP_NEQ_OS:                                                        \\
        __ret = _mm_move_sd((__a),                                             \\
                            _mm_andnot_pd(_mm_cmpunord_sd((__a), (__b)),       \\
                                          _mm_cmpneq_sd((__a), (__b))));       \\
        break;                                                                 \\
      case _CMP_NLT_US:                                                        \\
      case _CMP_NLT_UQ:                                                        \\
        __ret = _mm_cmpnlt_sd((__a), (__b));                                   \\
        break;                                                                 \\
      case _CMP_ORD_Q:                                                         \\
      case _CMP_ORD_S:                                                         \\
        __ret = _mm_cmpord_sd((__a), (__b));                                   \\
        break;                                                                 \\
      case _CMP_NGE_US:                                                        \\
      case _CMP_NGE_UQ:                                                        \\
        __ret = _mm_cmpnge_sd((__a), (__b));                                   \\
        break;                                                                 \\
      case _CMP_NGT_US:                                                        \\
      case _CMP_NGT_UQ:                                                        \\
        __ret = _mm_cmpngt_sd((__a), (__b));                                   \\
        break;                                                                 \\
      case _CMP_FALSE_OQ:                                                      \\
      case _CMP_FALSE_OS:                                                      \\
        __ret = _mm_move_sd((__a), _mm_setzero_pd());                          \\
        break;                                                                 \\
      case _CMP_GE_OS:                                                         \\
      case _CMP_GE_OQ:                                                         \\
        __ret = _mm_cmpge_sd((__a), (__b));                                    \\
        break;                                                                 \\
      case _CMP_GT_OS:                                                         \\
      case _CMP_GT_OQ:                                                         \\
        __ret = _mm_cmpgt_sd((__a), (__b));                                    \\
        break;                                                                 \\
      case _CMP_TRUE_UQ:                                                       \\
      case _CMP_TRUE_US:                                                       \\
        __ret = _mm_move_sd((__a), (__m128d)wasm_i8x16_splat(0xFF));           \\
        break;                                                                 \\
      case _CMP_NLE_US:                                                        \\
      case _CMP_NLE_UQ:                                                        \\
        __ret = _mm_cmpnle_sd((__a), (__b));                                   \\
        break;                                                                 \\
    }                                                                          \\
    __ret;                                                                     \\
  })

#define _mm_cmp_ss(__a, __b, __imm)                                            \\
  __extension__({                                                              \\
    __m128 __ret;                                                              \\
    switch ((__imm)) {                                                         \\
      case _CMP_EQ_OQ:                                                         \\
      case _CMP_EQ_OS:                                                         \\
        __ret = _mm_cmpeq_ss((__a), (__b));                                    \\
        break;                                                                 \\
      case _CMP_EQ_UQ:                                                         \\
      case _CMP_EQ_US:                                                         \\
        __ret = _mm_move_ss((__a),                                             \\
                            _mm_or_ps(_mm_cmpeq_ss((__a), (__b)),              \\
                                      _mm_cmpunord_ss((__a), (__b))));         \\
        break;                                                                 \\
      case _CMP_LT_OS:                                                         \\
      case _CMP_LT_OQ:                                                         \\
        __ret = _mm_cmplt_ss((__a), (__b));                                    \\
        break;                                                                 \\
      case _CMP_LE_OS:                                                         \\
      case _CMP_LE_OQ:                                                         \\
        __ret = _mm_cmple_ss((__a), (__b));                                    \\
        break;                                                                 \\
      case _CMP_UNORD_Q:                                                       \\
      case _CMP_UNORD_S:                                                       \\
        __ret = _mm_cmpunord_ss((__a), (__b));                                 \\
        break;                                                                 \\
      case _CMP_NEQ_UQ:                                                        \\
      case _CMP_NEQ_US:                                                        \\
        __ret = _mm_cmpneq_ss((__a), (__b));                                   \\
        break;                                                                 \\
      case _CMP_NEQ_OQ:                                                        \\
      case _CMP_NEQ_OS:                                                        \\
        __ret = _mm_move_ss((__a),                                             \\
                            _mm_andnot_ps(_mm_cmpunord_ss((__a), (__b)),       \\
                                          _mm_cmpneq_ss((__a), (__b))));       \\
        break;                                                                 \\
      case _CMP_NLT_US:                                                        \\
      case _CMP_NLT_UQ:                                                        \\
        __ret = _mm_cmpnlt_ss((__a), (__b));                                   \\
        break;                                                                 \\
      case _CMP_ORD_Q:                                                         \\
      case _CMP_ORD_S:                                                         \\
        __ret = _mm_cmpord_ss((__a), (__b));                                   \\
        break;                                                                 \\
      case _CMP_NGE_US:                                                        \\
      case _CMP_NGE_UQ:                                                        \\
        __ret = _mm_cmpnge_ss((__a), (__b));                                   \\
        break;                                                                 \\
      case _CMP_NGT_US:                                                        \\
      case _CMP_NGT_UQ:                                                        \\
        __ret = _mm_cmpngt_ss((__a), (__b));                                   \\
        break;                                                                 \\
      case _CMP_FALSE_OQ:                                                      \\
      case _CMP_FALSE_OS:                                                      \\
        __ret = _mm_move_ss((__a), _mm_setzero_ps());                          \\
        break;                                                                 \\
      case _CMP_GE_OS:                                                         \\
      case _CMP_GE_OQ:                                                         \\
        __ret = _mm_cmpge_ss((__a), (__b));                                    \\
        break;                                                                 \\
      case _CMP_GT_OS:                                                         \\
      case _CMP_GT_OQ:                                                         \\
        __ret = _mm_cmpgt_ss((__a), (__b));                                    \\
        break;                                                                 \\
      case _CMP_TRUE_UQ:                                                       \\
      case _CMP_TRUE_US:                                                       \\
        __ret = _mm_move_ss((__a), (__m128)wasm_i8x16_splat(0xFF));            \\
        break;                                                                 \\
      case _CMP_NLE_US:                                                        \\
      case _CMP_NLE_UQ:                                                        \\
        __ret = _mm_cmpnle_ss((__a), (__b));                                   \\
        break;                                                                 \\
    }                                                                          \\
    __ret;                                                                     \\
  })

static __inline__ __m256d __attribute__((__always_inline__, __nodebug__))
_mm256_cmp_pd(__m256d __a, __m256d __b, const int imm8) {
  __m256d_internal ret, a, b;
  a = __m256d_to_internal(__a);
  b = __m256d_to_internal(__b);
  ret.v0 = _mm_cmp_pd(a.v0, b.v0, imm8);
  ret.v1 = _mm_cmp_pd(a.v1, b.v1, imm8);
  return __m256d_from_internal(ret);
}

static __inline__ __m256 __attribute__((__always_inline__, __nodebug__))
_mm256_cmp_ps(__m256 __a, __m256 __b, const int imm8) {
  __m256_internal ret, a, b;
  a = __m256_to_internal(__a);
  b = __m256_to_internal(__b);
  ret.v0 = _mm_cmp_ps(a.v0, b.v0, imm8);
  ret.v1 = _mm_cmp_ps(a.v1, b.v1, imm8);
  return __m256_from_internal(ret);
}

#define _mm256_extract_epi32(__A, N)                                           \\
  __extension__({                                                              \\
    __m256i_internal __a = __m256i_to_internal(__A);                             \\
    ((N) & 0x7) < 4 ? _mm_extract_epi32(__a.v0, (N) & 0x3)                     \\
                    : _mm_extract_epi32(__a.v1, (N) & 0x3);                    \\
  })

#define _mm256_extract_epi16(__A, N)                                           \\
  __extension__({                                                              \\
    __m256i_internal __a = __m256i_to_internal(__A);                             \\
    ((N) & 0xF) < 8 ? _mm_extract_epi16(__a.v0, (N) & 0x7)                     \\
                    : _mm_extract_epi16(__a.v1, (N) & 0x7);                    \\
  })

#define _mm256_extract_epi8(__A, N)                                            \\
  __extension__({                                                              \\
    __m256i_internal __a = __m256i_to_internal(__A);                             \\
    ((N) & 0x1F) < 16 ? _mm_extract_epi8(__a.v0, (N) & 0xF)                    \\
                      : _mm_extract_epi8(__a.v1, (N) & 0xF);                   \\
  })

#define _mm256_extract_epi64(__A, N)                                           \\
  __extension__({                                                              \\
    __m256i_internal __a = __m256i_to_internal(__A);                             \\
    ((N) & 0x3) < 2 ? _mm_extract_epi64(__a.v0, (N) & 0x1)                     \\
                    : _mm_extract_epi64(__a.v1, (N) & 0x1);                    \\
  })

#define _mm256_insert_epi32(__A, __I, N)                                       \\
  __extension__({                                                              \\
    __m256i_internal __a = __m256i_to_internal(__A);                             \\
    int32_t __i = (__I);                                                       \\
    ((N) & 0x7) < 4                                                            \\
      ? _mm256_set_m128i(__a.v1, _mm_insert_epi32(__a.v0, __i, (N) & 0x3))     \\
      : _mm256_set_m128i(_mm_insert_epi32(__a.v1, __i, (N) & 0x3), __a.v0);    \\
  })

#define _mm256_insert_epi16(__A, __I, N)                                       \\
  __extension__({                                                              \\
    __m256i_internal __a = __m256i_to_internal(__A);                             \\
    int16_t __i = (__I);                                                       \\
    ((N) & 0xF) < 8                                                            \\
      ? _mm256_set_m128i(__a.v1, _mm_insert_epi16(__a.v0, __i, (N) & 0x7))     \\
      : _mm256_set_m128i(_mm_insert_epi16(__a.v1, __i, (N) & 0x7), __a.v0);    \\
  })

#define _mm256_insert_epi8(__A, __I, N)                                        \\
  __extension__({                                                              \\
    __m256i_internal __a = __m256i_to_internal(__A);                             \\
    int8_t __i = (__I);                                                        \\
    ((N) & 0x1F) < 16                                                          \\
      ? _mm256_set_m128i(__a.v1, _mm_insert_epi8(__a.v0, __i, (N) & 0xF))      \\
      : _mm256_set_m128i(_mm_insert_epi8(__a.v1, __i, (N) & 0xF), __a.v0);     \\
  })

#define _mm256_insert_epi64(__A, __I, N)                                       \\
  __extension__({                                                              \\
    __m256i_internal __a = __m256i_to_internal(__A);                             \\
    int64_t __i = (__I);                                                       \\
    ((N) & 0x3) < 2                                                            \\
      ? _mm256_set_m128i(__a.v1, _mm_insert_epi64(__a.v0, __i, (N) & 0x1))     \\
      : _mm256_set_m128i(_mm_insert_epi64(__a.v1, __i, (N) & 0x1), __a.v0);    \\
  })

static __inline__ __m256d __attribute__((__always_inline__, __nodebug__))
_mm256_cvtepi32_pd(__m128i __a) {
  __m256d_internal ret;
  ret.v0 = _mm_cvtepi32_pd(__a);
  __m128i __a1 = wasm_i32x4_shuffle(__a, __a, 2, 3, 0, 0);
  ret.v1 = _mm_cvtepi32_pd(__a1);
  return __m256d_from_internal(ret);
}

static __inline__ __m256 __attribute__((__always_inline__, __nodebug__))
_mm256_cvtepi32_ps(__m256i __a) {
  __m256_internal ret;
  __m256i_internal a = __m256i_to_internal(__a);
  ret.v0 = _mm_cvtepi32_ps(a.v0);
  ret.v1 = _mm_cvtepi32_ps(a.v1);
  return __m256_from_internal(ret);
}

static __inline__ __m128 __attribute__((__always_inline__, __nodebug__))
_mm256_cvtpd_ps(__m256d __a) {
  __m256d_internal a = __m256d_to_internal(__a);
  __m128 low = _mm_cvtpd_ps(a.v0);
  __m128 high = _mm_cvtpd_ps(a.v1);
  __m128 ret = (__m128)wasm_i32x4_shuffle(low, high, 0, 1, 4, 5);
  return ret;
}

static __inline__ __m256i __attribute__((__always_inline__, __nodebug__))
_mm256_cvtps_epi32(__m256 __a) {
  __m256i_internal ret;
  __m256_internal a = __m256_to_internal(__a);
  ret.v0 = _mm_cvtps_epi32(a.v0);
  ret.v1 = _mm_cvtps_epi32(a.v1);
  return __m256i_from_internal(ret);
}

static __inline__ __m256d __attribute__((__always_inline__, __nodebug__))
_mm256_cvtps_pd(__m128 __a) {
  __m256d_internal ret;
  ret.v0 = _mm_cvtps_pd(__a);
  __m128 __a1 = (__m128)wasm_i32x4_shuffle(__a, __a, 2, 3, 0, 0);
  ret.v1 = _mm_cvtps_pd(__a1);
  return __m256d_from_internal(ret);
}

static __inline__ __m128i __attribute__((__always_inline__, __nodebug__))
_mm256_cvttpd_epi32(__m256d __a) {
  __m256d_internal a = __m256d_to_internal(__a);
  __m128i low = _mm_cvttpd_epi32(a.v0);
  __m128i high = _mm_cvttpd_epi32(a.v1);
  __m128i ret = wasm_i32x4_shuffle(low, high, 0, 1, 4, 5);
  return ret;
}

static __inline__ __m128i __attribute__((__always_inline__, __nodebug__))
_mm256_cvtpd_epi32(__m256d __a) {
  __m256d_internal a = __m256d_to_internal(__a);
  __m128i low = _mm_cvtpd_epi32(a.v0);
  __m128i high = _mm_cvtpd_epi32(a.v1);
  __m128i ret = wasm_i32x4_shuffle(low, high, 0, 1, 4, 5);
  return ret;
}

static __inline__ __m256i __attribute__((__always_inline__, __nodebug__))
_mm256_cvttps_epi32(__m256 __a) {
  __m256i_internal ret;
  __m256_internal a = __m256_to_internal(__a);
  ret.v0 = _mm_cvttps_epi32(a.v0);
  ret.v1 = _mm_cvttps_epi32(a.v1);
  return __m256i_from_internal(ret);
}

static __inline__ double __attribute__((__always_inline__, __nodebug__))
_mm256_cvtsd_f64(__m256d __a) {
  __m256d_internal a = __m256d_to_internal(__a);
  return _mm_cvtsd_f64(a.v0);
}

static __inline__ int __attribute__((__always_inline__, __nodebug__))
_mm256_cvtsi256_si32(__m256i __a) {
  __m256i_internal a = __m256i_to_internal(__a);
  return _mm_cvtsi128_si32(a.v0);
}

static __inline__ float __attribute__((__always_inline__, __nodebug__))
_mm256_cvtss_f32(__m256 __a) {
  __m256_internal a = __m256_to_internal(__a);
  return _mm_cvtss_f32(a.v0);
}

static __inline__ __m256 __attribute__((__always_inline__, __nodebug__))
_mm256_movehdup_ps(__m256 __a) {
  __m256_internal ret, a;
  a = __m256_to_internal(__a);
  ret.v0 = _mm_movehdup_ps(a.v0);
  ret.v1 = _mm_movehdup_ps(a.v1);
  return __m256_from_internal(ret);
}

static __inline__ __m256 __attribute__((__always_inline__, __nodebug__))
_mm256_moveldup_ps(__m256 __a) {
  __m256_internal ret, a;
  a = __m256_to_internal(__a);
  ret.v0 = _mm_moveldup_ps(a.v0);
  ret.v1 = _mm_moveldup_ps(a.v1);
  return __m256_from_internal(ret);
}

static __inline__ __m256d __attribute__((__always_inline__, __nodebug__))
_mm256_movedup_pd(__m256d __a) {
  __m256d_internal ret, a;
  a = __m256d_to_internal(__a);
  ret.v0 = _mm_movedup_pd(a.v0);
  ret.v1 = _mm_movedup_pd(a.v1);
  return __m256d_from_internal(ret);
}

static __inline__ __m256d __attribute__((__always_inline__, __nodebug__))
_mm256_unpackhi_pd(__m256d __a, __m256d __b) {
  __m256d_internal ret, a, b;
  a = __m256d_to_internal(__a);
  b = __m256d_to_internal(__b);
  ret.v0 = _mm_unpackhi_pd(a.v0, b.v0);
  ret.v1 = _mm_unpackhi_pd(a.v1, b.v1);
  return __m256d_from_internal(ret);
}

static __inline__ __m256d __attribute__((__always_inline__, __nodebug__))
_mm256_unpacklo_pd(__m256d __a, __m256d __b) {
  __m256d_internal ret, a, b;
  a = __m256d_to_internal(__a);
  b = __m256d_to_internal(__b);
  ret.v0 = _mm_unpacklo_pd(a.v0, b.v0);
  ret.v1 = _mm_unpacklo_pd(a.v1, b.v1);
  return __m256d_from_internal(ret);
}

static __inline__ __m256 __attribute__((__always_inline__, __nodebug__))
_mm256_unpackhi_ps(__m256 __a, __m256 __b) {
  __m256_internal ret, a, b;
  a = __m256_to_internal(__a);
  b = __m256_to_internal(__b);
  ret.v0 = _mm_unpackhi_ps(a.v0, b.v0);
  ret.v1 = _mm_unpackhi_ps(a.v1, b.v1);
  return __m256_from_internal(ret);
}

static __inline__ __m256 __attribute__((__always_inline__, __nodebug__))
_mm256_unpacklo_ps(__m256 __a, __m256 __b) {
  __m256_internal ret, a, b;
  a = __m256_to_internal(__a);
  b = __m256_to_internal(__b);
  ret.v0 = _mm_unpacklo_ps(a.v0, b.v0);
  ret.v1 = _mm_unpacklo_ps(a.v1, b.v1);
  return __m256_from_internal(ret);
}

static __inline__ int __attribute__((__always_inline__, __nodebug__))
_mm_testz_pd(__m128d __a, __m128d __b) {
  v128_t __m =
    wasm_u64x2_shr(wasm_v128_not(wasm_v128_and((v128_t)__a, (v128_t)__b)), 63);
  return wasm_i64x2_extract_lane(__m, 0) & wasm_i64x2_extract_lane(__m, 1);
}

static __inline__ int __attribute__((__always_inline__, __nodebug__))
_mm_testc_pd(__m128d __a, __m128d __b) {
  v128_t __m =
    wasm_u64x2_shr(wasm_v128_or(wasm_v128_not((v128_t)__b), (v128_t)__a), 63);
  return wasm_i64x2_extract_lane(__m, 0) & wasm_i64x2_extract_lane(__m, 1);
}

static __inline__ int __attribute__((__always_inline__, __nodebug__))
_mm_testnzc_pd(__m128d __a, __m128d __b) {
  v128_t __m = wasm_u64x2_shr(wasm_v128_and((v128_t)__a, (v128_t)__b), 63);
  v128_t __m2 = wasm_u64x2_shr(wasm_v128_andnot((v128_t)__b, (v128_t)__a), 63);
  return (wasm_i64x2_extract_lane(__m, 0) | wasm_i64x2_extract_lane(__m, 1)) &
         (wasm_i64x2_extract_lane(__m2, 0) | wasm_i64x2_extract_lane(__m2, 1));
}

static __inline__ int __attribute__((__always_inline__, __nodebug__))
_mm_testz_ps(__m128 __a, __m128 __b) {
  v128_t __m =
    wasm_u32x4_shr(wasm_v128_not(wasm_v128_and((v128_t)__a, (v128_t)__b)), 31);
  __m = wasm_v128_and(__m, (v128_t)_mm_movehl_ps((__m128)__m, (__m128)__m));
  __m = wasm_v128_and(__m, _mm_shuffle_epi32(__m, _MM_SHUFFLE(3, 2, 0, 1)));
  return wasm_i32x4_extract_lane(__m, 0);
}

static __inline__ int __attribute__((__always_inline__, __nodebug__))
_mm_testc_ps(__m128 __a, __m128 __b) {
  v128_t __m =
    wasm_u32x4_shr(wasm_v128_or(wasm_v128_not((v128_t)__b), (v128_t)__a), 31);
  __m = wasm_v128_and(__m, (v128_t)_mm_movehl_ps((__m128)__m, (__m128)__m));
  __m = wasm_v128_and(__m, _mm_shuffle_epi32(__m, _MM_SHUFFLE(3, 2, 0, 1)));
  return wasm_i32x4_extract_lane(__m, 0);
}

static __inline__ int __attribute__((__always_inline__, __nodebug__))
_mm_testnzc_ps(__m128 __a, __m128 __b) {
  v128_t __m = wasm_u32x4_shr(wasm_v128_and((v128_t)__a, (v128_t)__b), 31);
  v128_t __m2 = wasm_u32x4_shr(wasm_v128_andnot((v128_t)__b, (v128_t)__a), 31);

  __m = wasm_v128_or(__m, (v128_t)_mm_movehl_ps((__m128)__m, (__m128)__m));
  __m2 = wasm_v128_or(__m2, (v128_t)_mm_movehl_ps((__m128)__m2, (__m128)__m2));
  __m = wasm_v128_or(__m, _mm_shuffle_epi32(__m, _MM_SHUFFLE(3, 2, 0, 1)));
  __m2 = wasm_v128_or(__m2, _mm_shuffle_epi32(__m2, _MM_SHUFFLE(3, 2, 0, 1)));

  return wasm_i32x4_extract_lane(__m, 0) & wasm_i32x4_extract_lane(__m2, 0);
}

static __inline__ int __attribute__((__always_inline__, __nodebug__))
_mm256_testz_pd(__m256d __a, __m256d __b) {
  __m256d_internal a, b;
  a = __m256d_to_internal(__a);
  b = __m256d_to_internal(__b);
  return _mm_testz_pd(a.v0, b.v0) & _mm_testz_pd(a.v1, b.v1);
}

static __inline__ int __attribute__((__always_inline__, __nodebug__))
_mm256_testc_pd(__m256d __a, __m256d __b) {
  __m256d_internal a, b;
  a = __m256d_to_internal(__a);
  b = __m256d_to_internal(__b);
  return _mm_testc_pd(a.v0, b.v0) & _mm_testc_pd(a.v1, b.v1);
}

static __inline__ int __attribute__((__always_inline__, __nodebug__))
_mm256_testnzc_pd(__m256d __a, __m256d __b) {
  __m256d_internal a, b;
  a = __m256d_to_internal(__a);
  b = __m256d_to_internal(__b);
  v128_t __m =
    wasm_u64x2_shr(wasm_v128_and((v128_t)a.v0, (v128_t)b.v0), 63);
  v128_t __m1 =
    wasm_u64x2_shr(wasm_v128_and((v128_t)a.v1, (v128_t)b.v1), 63);
  v128_t __m2 =
    wasm_u64x2_shr(wasm_v128_andnot((v128_t)b.v0, (v128_t)a.v0), 63);
  v128_t __m3 =
    wasm_u64x2_shr(wasm_v128_andnot((v128_t)b.v1, (v128_t)a.v1), 63);
  return wasm_v128_any_true(wasm_v128_or(__m, __m1)) &
         wasm_v128_any_true(wasm_v128_or(__m2, __m3));
}

static __inline__ int __attribute__((__always_inline__, __nodebug__))
_mm256_testz_ps(__m256 __a, __m256 __b) {
  __m256_internal a, b;
  a = __m256_to_internal(__a);
  b = __m256_to_internal(__b);
  return _mm_testz_ps(a.v0, b.v0) & _mm_testz_ps(a.v1, b.v1);
}

static __inline__ int __attribute__((__always_inline__, __nodebug__))
_mm256_testc_ps(__m256 __a, __m256 __b) {
  __m256_internal a, b;
  a = __m256_to_internal(__a);
  b = __m256_to_internal(__b);
  return _mm_testc_ps(a.v0, b.v0) & _mm_testc_ps(a.v1, b.v1);
}

static __inline__ int __attribute__((__always_inline__, __nodebug__))
_mm256_testnzc_ps(__m256 __a, __m256 __b) {
  __m256_internal a, b;
  a = __m256_to_internal(__a);
  b = __m256_to_internal(__b);
  v128_t __m =
    wasm_u32x4_shr(wasm_v128_and((v128_t)a.v0, (v128_t)b.v0), 31);
  v128_t __m1 =
    wasm_u32x4_shr(wasm_v128_and((v128_t)a.v1, (v128_t)b.v1), 31);
  v128_t __m2 =
    wasm_u32x4_shr(wasm_v128_andnot((v128_t)b.v0, (v128_t)a.v0), 31);
  v128_t __m3 =
    wasm_u32x4_shr(wasm_v128_andnot((v128_t)b.v1, (v128_t)a.v1), 31);

  return wasm_v128_any_true(wasm_v128_or(__m, __m1)) &
         wasm_v128_any_true(wasm_v128_or(__m2, __m3));
}

static __inline__ int __attribute__((__always_inline__, __nodebug__))
_mm256_testz_si256(__m256i __a, __m256i __b) {
  __m256i_internal a, b;
  a = __m256i_to_internal(__a);
  b = __m256i_to_internal(__b);
  return _mm_testz_si128(a.v0, b.v0) & _mm_testz_si128(a.v1, b.v1);
}

static __inline__ int __attribute__((__always_inline__, __nodebug__))
_mm256_testc_si256(__m256i __a, __m256i __b) {
  __m256i_internal a, b;
  a = __m256i_to_internal(__a);
  b = __m256i_to_internal(__b);
  return _mm_testc_si128(a.v0, b.v0) & _mm_testc_si128(a.v1, b.v1);
}

static __inline__ int __attribute__((__always_inline__, __nodebug__))
_mm256_testnzc_si256(__m256i __a, __m256i __b) {
  __m256i_internal a, b;
  a = __m256i_to_internal(__a);
  b = __m256i_to_internal(__b);
  v128_t __m = wasm_v128_and(a.v0, b.v0);
  v128_t __m1 = wasm_v128_and(a.v1, b.v1);
  v128_t __m2 = wasm_v128_andnot(b.v0, a.v0);
  v128_t __m3 = wasm_v128_andnot(b.v1, a.v1);
  return wasm_v128_any_true(wasm_v128_or(__m, __m1)) &
         wasm_v128_any_true(wasm_v128_or(__m2, __m3));
}

static __inline__ int __attribute__((__always_inline__, __nodebug__))
_mm256_movemask_pd(__m256d __a) {
  __m256d_internal a = __m256d_to_internal(__a);
  return _mm_movemask_pd(a.v0) | (_mm_movemask_pd(a.v1) << 2);
}

static __inline__ int __attribute__((__always_inline__, __nodebug__))
_mm256_movemask_ps(__m256 __a) {
  __m256_internal a = __m256_to_internal(__a);
  return _mm_movemask_ps(a.v0) | (_mm_movemask_ps(a.v1) << 4);
}

static __inline__ void __attribute__((__always_inline__, __nodebug__))
_mm256_zeroall(void) {
  // Do nothing
  // when porting any assembly code that would have calls to these functions
  // around, that assembly code in the first place will not compile.
}

static __inline__ void __attribute__((__always_inline__, __nodebug__))
_mm256_zeroupper(void) {
  // Do nothing
  // when porting any assembly code that would have calls to these functions
  // around, that assembly code in the first place will not compile.
}

static __inline__ __m128 __attribute__((__always_inline__, __nodebug__))
_mm_broadcast_ss(float const* __a) {
  return (__m128)wasm_v128_load32_splat(__a);
}

static __inline__ __m256d __attribute__((__always_inline__, __nodebug__))
_mm256_broadcast_sd(double const* __a) {
  __m256d_internal ret;
  ret.v1 = ret.v0 = (__m128d)wasm_v128_load64_splat(__a);
  return __m256d_from_internal(ret);
}

static __inline__ __m256 __attribute__((__always_inline__, __nodebug__))
_mm256_broadcast_ss(float const* __a) {
  __m256_internal ret;
  ret.v1 = ret.v0 = _mm_broadcast_ss(__a);
  return __m256_from_internal(ret);
}

static __inline__ __m256d __attribute__((__always_inline__, __nodebug__))
_mm256_broadcast_pd(__m128d const* __a) {
  __m256d_internal ret;
  ret.v1 = ret.v0 = (__m128d)wasm_v128_load(__a);
  return __m256d_from_internal(ret);
}

static __inline__ __m256 __attribute__((__always_inline__, __nodebug__))
_mm256_broadcast_ps(__m128 const* __a) {
  __m256_internal ret;
  ret.v1 = ret.v0 = (__m128)wasm_v128_load(__a);
  return __m256_from_internal(ret);
}

static __inline__ __m256d __attribute__((__always_inline__, __nodebug__))
_mm256_load_pd(double const* __p) {
  __m256d_internal ret;
  ret.v0 = _mm_load_pd(__p);
  ret.v1 = _mm_load_pd(__p + 2);
  return __m256d_from_internal(ret);
}

static __inline__ __m256 __attribute__((__always_inline__, __nodebug__))
_mm256_load_ps(float const* __p) {
  __m256_internal ret;
  ret.v0 = _mm_load_ps(__p);
  ret.v1 = _mm_load_ps(__p + 4);
  return __m256_from_internal(ret);
}

static __inline__ __m256d __attribute__((__always_inline__, __nodebug__))
_mm256_loadu_pd(double const* __p) {
  __m256d_internal ret;
  ret.v0 = _mm_loadu_pd(__p);
  ret.v1 = _mm_loadu_pd(__p + 2);
  return __m256d_from_internal(ret);
}

static __inline__ __m256 __attribute__((__always_inline__, __nodebug__))
_mm256_loadu_ps(float const* __p) {
  __m256_internal ret;
  ret.v0 = _mm_loadu_ps(__p);
  ret.v1 = _mm_loadu_ps(__p + 4);
  return __m256_from_internal(ret);
}

static __inline__ __m256i __attribute__((__always_inline__, __nodebug__))
_mm256_load_si256(__m256i const* __p) {
  __m256i_internal ret;
  ret.v0 = _mm_load_si128((__m128i const*)__p);
  ret.v1 = _mm_load_si128(((__m128i const*)__p) + 1);
  return __m256i_from_internal(ret);
}

static __inline__ __m256i __attribute__((__always_inline__, __nodebug__))
_mm256_loadu_si256(__m256i_u const* __p) {
  __m256i_internal ret;
  ret.v0 = _mm_loadu_si128((__m128i const*)__p);
  ret.v1 = _mm_loadu_si128(((__m128i const*)__p) + 1);
  return __m256i_from_internal(ret);
}

static __inline__ __m256i __attribute__((__always_inline__, __nodebug__))
_mm256_lddqu_si256(__m256i_u const* __p) {
  __m256i_internal ret;
  ret.v0 = _mm_lddqu_si128((__m128i const*)__p);
  ret.v1 = _mm_lddqu_si128(((__m128i const*)__p) + 1);
  return __m256i_from_internal(ret);
}

static __inline__ void __attribute__((__always_inline__, __nodebug__))
_mm256_store_pd(double* __p, __m256d __a) {
  __m256d_internal a = __m256d_to_internal(__a);
  _mm_store_pd(__p, a.v0);
  _mm_store_pd(__p + 2, a.v1);
}

static __inline__ void __attribute__((__always_inline__, __nodebug__))
_mm256_store_ps(float* __p, __m256 __a) {
  __m256_internal a = __m256_to_internal(__a);
  _mm_store_ps(__p, a.v0);
  _mm_store_ps(__p + 4, a.v1);
}

static __inline__ void __attribute__((__always_inline__, __nodebug__))
_mm256_storeu_pd(double* __p, __m256d __a) {
  __m256d_internal a = __m256d_to_internal(__a);
  _mm_storeu_pd(__p, a.v0);
  _mm_storeu_pd(__p + 2, a.v1);
}

static __inline__ void __attribute__((__always_inline__, __nodebug__))
_mm256_storeu_ps(float* __p, __m256 __a) {
  __m256_internal a = __m256_to_internal(__a);
  _mm_storeu_ps(__p, a.v0);
  _mm_storeu_ps(__p + 4, a.v1);
}

static __inline__ void __attribute__((__always_inline__, __nodebug__))
_mm256_store_si256(__m256i* __p, __m256i __a) {
  __m256i_internal a = __m256i_to_internal(__a);
  _mm_store_si128((__m128i*)__p, a.v0);
  _mm_store_si128(((__m128i*)__p) + 1, a.v1);
}

static __inline__ void __attribute__((__always_inline__, __nodebug__))
_mm256_storeu_si256(__m256i_u* __p, __m256i __a) {
  __m256i_internal a = __m256i_to_internal(__a);
  _mm_storeu_si128((__m128i*)__p, a.v0);
  _mm_storeu_si128(((__m128i*)__p) + 1, a.v1);
}

static __inline__ __m128d __attribute__((__always_inline__, __nodebug__))
_mm_maskload_pd(double const* __p, __m128i __m) {
  // This may cause an out-of-bounds memory load since we first load and
  // then mask, but since there are no segmentation faults in Wasm memory
  // accesses, that is ok (as long as we are within the heap bounds -
  // a negligible limitation in practice)
  return _mm_and_pd(_mm_load_pd(__p), (__m128d)wasm_i64x2_shr(__m, 63));
}

static __inline__ __m256d __attribute__((__always_inline__, __nodebug__))
_mm256_maskload_pd(double const* __p, __m256i __m) {
  __m256d_internal ret;
  __m256i_internal m = __m256i_to_internal(__m);
  ret.v0 = _mm_maskload_pd(__p, m.v0);
  ret.v1 = _mm_maskload_pd(__p + 2, m.v1);
  return __m256d_from_internal(ret);
}

static __inline__ __m128 __attribute__((__always_inline__, __nodebug__))
_mm_maskload_ps(float const* __p, __m128i __m) {
  // This may cause an out-of-bounds memory load since we first load and
  // then mask, but since there are no segmentation faults in Wasm memory
  // accesses, that is ok (as long as we are within the heap bounds -
  // a negligible limitation in practice)
  return _mm_and_ps(_mm_load_ps(__p), (__m128)_mm_srai_epi32(__m, 31));
}

static __inline__ __m256 __attribute__((__always_inline__, __nodebug__))
_mm256_maskload_ps(float const* __p, __m256i __m) {
  __m256_internal ret;
  __m256i_internal m = __m256i_to_internal(__m);
  ret.v0 = _mm_maskload_ps(__p, m.v0);
  ret.v1 = _mm_maskload_ps(__p + 4, m.v1);
  return __m256_from_internal(ret);
}

static __inline__ void
  __attribute__((__always_inline__, __nodebug__, DIAGNOSE_SLOW))
  _mm_maskstore_ps(float* __p, __m128i __m, __m128 __a) {
  if ((wasm_i32x4_extract_lane(__m, 0) & 0x80000000ull) != 0)
    __p[0] = wasm_f32x4_extract_lane((v128_t)__a, 0);
  if ((wasm_i32x4_extract_lane(__m, 1) & 0x80000000ull) != 0)
    __p[1] = wasm_f32x4_extract_lane((v128_t)__a, 1);
  if ((wasm_i32x4_extract_lane(__m, 2) & 0x80000000ull) != 0)
    __p[2] = wasm_f32x4_extract_lane((v128_t)__a, 2);
  if ((wasm_i32x4_extract_lane(__m, 3) & 0x80000000ull) != 0)
    __p[3] = wasm_f32x4_extract_lane((v128_t)__a, 3);
}

static __inline__ void __attribute__((__always_inline__, __nodebug__))
_mm256_maskstore_ps(float* __p, __m256i __m, __m256 __a) {
  __m256_internal a = __m256_to_internal(__a);
  __m256i_internal m = __m256i_to_internal(__m);
  _mm_maskstore_ps(__p, m.v0, a.v0);
  _mm_maskstore_ps(__p + 4, m.v1, a.v1);
}

static __inline__ void
  __attribute__((__always_inline__, __nodebug__, DIAGNOSE_SLOW))
  _mm_maskstore_pd(double* __p, __m128i __m, __m128d __a) {
  if ((wasm_i64x2_extract_lane(__m, 0) & 0x8000000000000000ull) != 0)
    __p[0] = wasm_f64x2_extract_lane((v128_t)__a, 0);
  if ((wasm_i64x2_extract_lane(__m, 1) & 0x8000000000000000ull) != 0)
    __p[1] = wasm_f64x2_extract_lane((v128_t)__a, 1);
}

static __inline__ void __attribute__((__always_inline__, __nodebug__))
_mm256_maskstore_pd(double* __p, __m256i __m, __m256d __a) {
  __m256i_internal m = __m256i_to_internal(__m);
  __m256d_internal a = __m256d_to_internal(__a);
  _mm_maskstore_pd(__p, m.v0, a.v0);
  _mm_maskstore_pd(__p + 2, m.v1, a.v1);
}

static __inline__ void __attribute__((__always_inline__, __nodebug__))
_mm256_stream_si256(void* __a, __m256i __b) {
  __m256i_internal b = __m256i_to_internal(__b);
  _mm_stream_si128((__m128i*)__a, b.v0);
  _mm_stream_si128(((__m128i*)__a) + 1, b.v1);
}

static __inline__ void __attribute__((__always_inline__, __nodebug__))
_mm256_stream_pd(void* __a, __m256d __b) {
  __m256d_internal b = __m256d_to_internal(__b);
  _mm_stream_pd((double*)__a, b.v0);
  _mm_stream_pd(((double*)__a) + 2, b.v1);
}

static __inline__ void __attribute__((__always_inline__, __nodebug__))
_mm256_stream_ps(void* __p, __m256 __a) {
  __m256_internal a = __m256_to_internal(__a);
  _mm_stream_ps((float*)__p, a.v0);
  _mm_stream_ps(((float*)__p) + 4, a.v1);
}

static __inline__ __m256d __attribute__((__always_inline__, __nodebug__))
_mm256_undefined_pd(void) {
  __m256d val;
  return val;
}

static __inline__ __m256 __attribute__((__always_inline__, __nodebug__))
_mm256_undefined_ps(void) {
  __m256 val;
  return val;
}

static __inline__ __m256i __attribute__((__always_inline__, __nodebug__))
_mm256_undefined_si256(void) {
  __m256i val;
  return val;
}

static __inline__ __m256d __attribute__((__always_inline__, __nodebug__))
_mm256_set_pd(double __a, double __b, double __c, double __d) {
  __m256d_internal ret;
  ret.v0 = _mm_set_pd(__c, __d);
  ret.v1 = _mm_set_pd(__a, __b);
  return __m256d_from_internal(ret);
}

static __inline__ __m256 __attribute__((__always_inline__, __nodebug__))
_mm256_set_ps(float __a,
              float __b,
              float __c,
              float __d,
              float __e,
              float __f,
              float __g,
              float __h) {
  __m256_internal ret;
  ret.v0 = _mm_set_ps(__e, __f, __g, __h);
  ret.v1 = _mm_set_ps(__a, __b, __c, __d);
  return __m256_from_internal(ret);
}

static __inline__ __m256i __attribute__((__always_inline__, __nodebug__))
_mm256_set_epi32(int __i0,
                 int __i1,
                 int __i2,
                 int __i3,
                 int __i4,
                 int __i5,
                 int __i6,
                 int __i7) {
  __m256i_internal ret;
  ret.v0 = _mm_set_epi32(__i4, __i5, __i6, __i7);
  ret.v1 = _mm_set_epi32(__i0, __i1, __i2, __i3);
  return __m256i_from_internal(ret);
}

static __inline__ __m256i __attribute__((__always_inline__, __nodebug__))
_mm256_set_epi16(short __w15,
                 short __w14,
                 short __w13,
                 short __w12,
                 short __w11,
                 short __w10,
                 short __w09,
                 short __w08,
                 short __w07,
                 short __w06,
                 short __w05,
                 short __w04,
                 short __w03,
                 short __w02,
                 short __w01,
                 short __w00) {
  __m256i_internal ret;
  ret.v0 =
    _mm_set_epi16(__w07, __w06, __w05, __w04, __w03, __w02, __w01, __w00);
  ret.v1 =
    _mm_set_epi16(__w15, __w14, __w13, __w12, __w11, __w10, __w09, __w08);
  return __m256i_from_internal(ret);
}

static __inline__ __m256i __attribute__((__always_inline__, __nodebug__))
_mm256_set_epi8(char __b31,
                char __b30,
                char __b29,
                char __b28,
                char __b27,
                char __b26,
                char __b25,
                char __b24,
                char __b23,
                char __b22,
                char __b21,
                char __b20,
                char __b19,
                char __b18,
                char __b17,
                char __b16,
                char __b15,
                char __b14,
                char __b13,
                char __b12,
                char __b11,
                char __b10,
                char __b09,
                char __b08,
                char __b07,
                char __b06,
                char __b05,
                char __b04,
                char __b03,
                char __b02,
                char __b01,
                char __b00) {
  __m256i_internal ret;
  ret.v0 = _mm_set_epi8(__b15,
                        __b14,
                        __b13,
                        __b12,
                        __b11,
                        __b10,
                        __b09,
                        __b08,
                        __b07,
                        __b06,
                        __b05,
                        __b04,
                        __b03,
                        __b02,
                        __b01,
                        __b00);
  ret.v1 = _mm_set_epi8(__b31,
                        __b30,
                        __b29,
                        __b28,
                        __b27,
                        __b26,
                        __b25,
                        __b24,
                        __b23,
                        __b22,
                        __b21,
                        __b20,
                        __b19,
                        __b18,
                        __b17,
                        __b16);
  return __m256i_from_internal(ret);
}

static __inline__ __m256i __attribute__((__always_inline__, __nodebug__))
_mm256_set_epi64x(long long __a, long long __b, long long __c, long long __d) {
  __m256i_internal ret;
  ret.v0 = _mm_set_epi64x(__c, __d);
  ret.v1 = _mm_set_epi64x(__a, __b);
  return __m256i_from_internal(ret);
}

static __inline__ __m256d __attribute__((__always_inline__, __nodebug__))
_mm256_setr_pd(double __a, double __b, double __c, double __d) {
  return _mm256_set_pd(__d, __c, __b, __a);
}

static __inline__ __m256 __attribute__((__always_inline__, __nodebug__))
_mm256_setr_ps(float __a,
               float __b,
               float __c,
               float __d,
               float __e,
               float __f,
               float __g,
               float __h) {
  return _mm256_set_ps(__h, __g, __f, __e, __d, __c, __b, __a);
}

static __inline__ __m256i __attribute__((__always_inline__, __nodebug__))
_mm256_setr_epi32(int __i0,
                  int __i1,
                  int __i2,
                  int __i3,
                  int __i4,
                  int __i5,
                  int __i6,
                  int __i7) {
  return _mm256_set_epi32(__i7, __i6, __i5, __i4, __i3, __i2, __i1, __i0);
}

static __inline__ __m256i __attribute__((__always_inline__, __nodebug__))
_mm256_setr_epi16(short __w15,
                  short __w14,
                  short __w13,
                  short __w12,
                  short __w11,
                  short __w10,
                  short __w09,
                  short __w08,
                  short __w07,
                  short __w06,
                  short __w05,
                  short __w04,
                  short __w03,
                  short __w02,
                  short __w01,
                  short __w00) {
  return _mm256_set_epi16(__w00,
                          __w01,
                          __w02,
                          __w03,
                          __w04,
                          __w05,
                          __w06,
                          __w07,
                          __w08,
                          __w09,
                          __w10,
                          __w11,
                          __w12,
                          __w13,
                          __w14,
                          __w15);
}

static __inline__ __m256i __attribute__((__always_inline__, __nodebug__))
_mm256_setr_epi8(char __b31,
                 char __b30,
                 char __b29,
                 char __b28,
                 char __b27,
                 char __b26,
                 char __b25,
                 char __b24,
                 char __b23,
                 char __b22,
                 char __b21,
                 char __b20,
                 char __b19,
                 char __b18,
                 char __b17,
                 char __b16,
                 char __b15,
                 char __b14,
                 char __b13,
                 char __b12,
                 char __b11,
                 char __b10,
                 char __b09,
                 char __b08,
                 char __b07,
                 char __b06,
                 char __b05,
                 char __b04,
                 char __b03,
                 char __b02,
                 char __b01,
                 char __b00) {
  return _mm256_set_epi8(__b00,
                         __b01,
                         __b02,
                         __b03,
                         __b04,
                         __b05,
                         __b06,
                         __b07,
                         __b08,
                         __b09,
                         __b10,
                         __b11,
                         __b12,
                         __b13,
                         __b14,
                         __b15,
                         __b16,
                         __b17,
                         __b18,
                         __b19,
                         __b20,
                         __b21,
                         __b22,
                         __b23,
                         __b24,
                         __b25,
                         __b26,
                         __b27,
                         __b28,
                         __b29,
                         __b30,
                         __b31);
}

static __inline__ __m256i __attribute__((__always_inline__, __nodebug__))
_mm256_setr_epi64x(long long __a, long long __b, long long __c, long long __d) {
  return _mm256_set_epi64x(__d, __c, __b, __a);
}

static __inline__ __m256d __attribute__((__always_inline__, __nodebug__))
_mm256_set1_pd(double __w) {
  __m256d_internal ret;
  ret.v1 = ret.v0 = (__m128d)wasm_f64x2_splat(__w);
  return __m256d_from_internal(ret);
}

static __inline__ __m256 __attribute__((__always_inline__, __nodebug__))
_mm256_set1_ps(float __w) {
  __m256_internal ret;
  ret.v1 = ret.v0 = (__m128)wasm_f32x4_splat(__w);
  return __m256_from_internal(ret);
}

static __inline__ __m256i __attribute__((__always_inline__, __nodebug__))
_mm256_set1_epi32(int __i) {
  __m256i_internal ret;
  ret.v1 = ret.v0 = wasm_i32x4_splat(__i);
  return __m256i_from_internal(ret);
}

static __inline__ __m256i __attribute__((__always_inline__, __nodebug__))
_mm256_set1_epi16(short __w) {
  __m256i_internal ret;
  ret.v1 = ret.v0 = wasm_i16x8_splat(__w);
  return __m256i_from_internal(ret);
}

static __inline__ __m256i __attribute__((__always_inline__, __nodebug__))
_mm256_set1_epi8(char __b) {
  __m256i_internal ret;
  ret.v1 = ret.v0 = wasm_i8x16_splat(__b);
  return __m256i_from_internal(ret);
}

static __inline__ __m256i __attribute__((__always_inline__, __nodebug__))
_mm256_set1_epi64x(long long __q) {
  __m256i_internal ret;
  ret.v1 = ret.v0 = wasm_i64x2_splat(__q);
  return __m256i_from_internal(ret);
}

static __inline__ __m256d __attribute__((__always_inline__, __nodebug__))
_mm256_setzero_pd(void) {
  __m256d_internal ret;
  ret.v1 = ret.v0 = _mm_setzero_pd();
  return __m256d_from_internal(ret);
}

static __inline__ __m256 __attribute__((__always_inline__, __nodebug__))
_mm256_setzero_ps(void) {
  __m256_internal ret;
  ret.v1 = ret.v0 = _mm_setzero_ps();
  return __m256_from_internal(ret);
}

static __inline__ __m256i __attribute__((__always_inline__, __nodebug__))
_mm256_setzero_si256(void) {
  __m256i_internal ret;
  ret.v1 = ret.v0 = _mm_setzero_si128();
  return __m256i_from_internal(ret);
}

static __inline__ __m256 __attribute__((__always_inline__, __nodebug__))
_mm256_castpd_ps(__m256d __a) {
  union __m256_data ret;
  ret.double_view = __a;
  return ret.float_view;
}

static __inline__ __m256i __attribute__((__always_inline__, __nodebug__))
_mm256_castpd_si256(__m256d __a) {
  union __m256_data ret;
  ret.double_view = __a;
  return ret.int_view;
}

static __inline__ __m256d __attribute__((__always_inline__, __nodebug__))
_mm256_castps_pd(__m256 __a) {
  union __m256_data ret;
  ret.float_view = __a;
  return ret.double_view;
}

static __inline__ __m256i __attribute__((__always_inline__, __nodebug__))
_mm256_castps_si256(__m256 __a) {
  union __m256_data ret;
  ret.float_view = __a;
  return ret.int_view;
}

static __inline__ __m256 __attribute__((__always_inline__, __nodebug__))
_mm256_castsi256_ps(__m256i __a) {
  union __m256_data ret;
  ret.int_view = __a;
  return ret.float_view;
}

static __inline__ __m256d __attribute__((__always_inline__, __nodebug__))
_mm256_castsi256_pd(__m256i __a) {
  union __m256_data ret;
  ret.int_view = __a;
  return ret.double_view;
}

static __inline__ __m128d __attribute__((__always_inline__, __nodebug__))
_mm256_castpd256_pd128(__m256d __a) {
  __m256d_internal a = __m256d_to_internal(__a);
  return a.v0;
}

static __inline__ __m128 __attribute__((__always_inline__, __nodebug__))
_mm256_castps256_ps128(__m256 __a) {
  __m256_internal a = __m256_to_internal(__a);
  return a.v0;
}

static __inline__ __m128i __attribute__((__always_inline__, __nodebug__))
_mm256_castsi256_si128(__m256i __a) {
  __m256i_internal a = __m256i_to_internal(__a);
  return a.v0;
}

static __inline__ __m256d __attribute__((__always_inline__, __nodebug__))
_mm256_castpd128_pd256(__m128d __a) {
  __m256d_internal ret;
  ret.v0 = __a;
  ret.v1 = _mm_setzero_pd();
  return __m256d_from_internal(ret);
}

static __inline__ __m256 __attribute__((__always_inline__, __nodebug__))
_mm256_castps128_ps256(__m128 __a) {
  __m256_internal ret;
  ret.v0 = __a;
  ret.v1 = _mm_setzero_ps();
  return __m256_from_internal(ret);
}

static __inline__ __m256i __attribute__((__always_inline__, __nodebug__))
_mm256_castsi128_si256(__m128i __a) {
  __m256i_internal ret;
  ret.v0 = __a;
  ret.v1 = _mm_setzero_si128();
  return __m256i_from_internal(ret);
}

static __inline__ __m256d __attribute__((__always_inline__, __nodebug__))
_mm256_zextpd128_pd256(__m128d __a) {
  __m256d_internal ret;
  ret.v0 = __a;
  ret.v1 = _mm_setzero_pd();
  return __m256d_from_internal(ret);
}

static __inline__ __m256 __attribute__((__always_inline__, __nodebug__))
_mm256_zextps128_ps256(__m128 __a) {
  __m256_internal ret;
  ret.v0 = __a;
  ret.v1 = _mm_setzero_ps();
  return __m256_from_internal(ret);
}

static __inline__ __m256i __attribute__((__always_inline__, __nodebug__))
_mm256_zextsi128_si256(__m128i __a) {
  __m256i_internal ret;
  ret.v0 = __a;
  ret.v1 = _mm_setzero_si128();
  return __m256i_from_internal(ret);
}

static __inline__ __m256 __attribute__((__always_inline__, __nodebug__))
_mm256_insertf128_ps(__m256 __a, __m128 __b, const int imm8) {
  __m256_internal ret = __m256_to_internal(__a);
  if (imm8 & 0x1) {
    ret.v1 = __b;
  } else {
    ret.v0 = __b;
  }
  return __m256_from_internal(ret);
}

static __inline__ __m256d __attribute__((__always_inline__, __nodebug__))
_mm256_insertf128_pd(__m256d __a, __m128d __b, const int imm8) {
  __m256d_internal ret = __m256d_to_internal(__a);
  if (imm8 & 0x1) {
    ret.v1 = __b;
  } else {
    ret.v0 = __b;
  }
  return __m256d_from_internal(ret);
}

static __inline__ __m256i __attribute__((__always_inline__, __nodebug__))
_mm256_insertf128_si256(__m256i __a, __m128i __b, const int imm8) {
  __m256i_internal ret = __m256i_to_internal(__a);
  if (imm8 & 0x1) {
    ret.v1 = __b;
  } else {
    ret.v0 = __b;
  }
  return __m256i_from_internal(ret);
}

static __inline__ __m128 __attribute__((__always_inline__, __nodebug__))
_mm256_extractf128_ps(__m256 __a, const int imm8) {
  __m256_internal a = __m256_to_internal(__a);
  if (imm8 & 0x1) {
    return a.v1;
  } else {
    return a.v0;
  }
}

static __inline__ __m128d __attribute__((__always_inline__, __nodebug__))
_mm256_extractf128_pd(__m256d __a, const int imm8) {
  __m256d_internal a = __m256d_to_internal(__a);
  if (imm8 & 0x1) {
    return a.v1;
  } else {
    return a.v0;
  }
}

static __inline__ __m128i __attribute__((__always_inline__, __nodebug__))
_mm256_extractf128_si256(__m256i __a, const int imm8) {
  __m256i_internal a = __m256i_to_internal(__a);
  if (imm8 & 0x1) {
    return a.v1;
  } else {
    return a.v0;
  }
}

static __inline__ __m256 __attribute__((__always_inline__, __nodebug__))
_mm256_set_m128(__m128 __hi, __m128 __lo) {
  __m256_internal ret;
  ret.v0 = __lo;
  ret.v1 = __hi;
  return __m256_from_internal(ret);
}

static __inline__ __m256d __attribute__((__always_inline__, __nodebug__))
_mm256_set_m128d(__m128d __hi, __m128d __lo) {
  __m256d_internal ret;
  ret.v0 = __lo;
  ret.v1 = __hi;
  return __m256d_from_internal(ret);
}

static __inline__ __m256i __attribute__((__always_inline__, __nodebug__))
_mm256_set_m128i(__m128i __hi, __m128i __lo) {
  __m256i_internal ret;
  ret.v0 = __lo;
  ret.v1 = __hi;
  return __m256i_from_internal(ret);
}

static __inline__ __m256 __attribute__((__always_inline__, __nodebug__))
_mm256_setr_m128(__m128 __lo, __m128 __hi) {
  return _mm256_set_m128(__hi, __lo);
}

static __inline__ __m256d __attribute__((__always_inline__, __nodebug__))
_mm256_setr_m128d(__m128d __lo, __m128d __hi) {
  return (__m256d)_mm256_set_m128d(__hi, __lo);
}

static __inline__ __m256i __attribute__((__always_inline__, __nodebug__))
_mm256_setr_m128i(__m128i __lo, __m128i __hi) {
  return (__m256i)_mm256_set_m128i(__hi, __lo);
}

static __inline__ __m256 __attribute__((__always_inline__, __nodebug__))
_mm256_loadu2_m128(float const* __addr_hi, float const* __addr_lo) {
  return _mm256_set_m128(_mm_loadu_ps(__addr_hi), _mm_loadu_ps(__addr_lo));
}

static __inline__ __m256d __attribute__((__always_inline__, __nodebug__))
_mm256_loadu2_m128d(double const* __addr_hi, double const* __addr_lo) {
  return _mm256_set_m128d(_mm_loadu_pd(__addr_hi), _mm_loadu_pd(__addr_lo));
}

static __inline__ __m256i __attribute__((__always_inline__, __nodebug__))
_mm256_loadu2_m128i(__m128i_u const* __addr_hi, __m128i_u const* __addr_lo) {
  return _mm256_set_m128i(_mm_loadu_si128((__m128i const*)__addr_hi),
                          _mm_loadu_si128((__m128i const*)__addr_lo));
}

static __inline__ void __attribute__((__always_inline__, __nodebug__))
_mm256_storeu2_m128(float* __addr_hi, float* __addr_lo, __m256 __a) {
  __m256_internal a = __m256_to_internal(__a);
  _mm_storeu_ps(__addr_lo, a.v0);
  _mm_storeu_ps(__addr_hi, a.v1);
}

static __inline__ void __attribute__((__always_inline__, __nodebug__))
_mm256_storeu2_m128d(double* __addr_hi, double* __addr_lo, __m256d __a) {
  __m256d_internal a = __m256d_to_internal(__a);
  _mm_storeu_pd(__addr_lo, a.v0);
  _mm_storeu_pd(__addr_hi, a.v1);
}

static __inline__ void __attribute__((__always_inline__, __nodebug__))
_mm256_storeu2_m128i(__m128i_u* __addr_hi, __m128i_u* __addr_lo, __m256i __a) {
  __m256i_internal a = __m256i_to_internal(__a);
  _mm_storeu_si128((__m128i*)__addr_lo, a.v0);
  _mm_storeu_si128((__m128i*)__addr_hi, a.v1);
}

#endif /* __emscripten_avxintrin_h__ */
`,"avx2intrin.h":`/*
 * Copyright 2024 The Emscripten Authors.  All rights reserved.
 * Emscripten is available under two separate licenses, the MIT license and the
 * University of Illinois/NCSA Open Source License.  Both these licenses can be
 * found in the LICENSE file.
 */

#ifndef __emscripten_immintrin_h__
#error "Never use <avx2intrin.h> directly; include <immintrin.h> instead."
#endif

#ifndef __emscripten_avx2intrin_h__
#define __emscripten_avx2intrin_h__

#ifndef __AVX2__
#error "AVX2 instruction set not enabled"
#endif

#define _mm256_mpsadbw_epu8(__A, __B, __imm)                                   \\
  __extension__({                                                              \\
    __m256i_internal __a = __m256i_to_internal(__A);                           \\
    __m256i_internal __b = __m256i_to_internal(__B);                           \\
    _mm256_set_m128i(_mm_mpsadbw_epu8(__a.v1, __b.v1, (__imm) >> 3),           \\
                     _mm_mpsadbw_epu8(__a.v0, __b.v0, (__imm)));               \\
  })

static __inline__ __m256i __attribute__((__always_inline__, __nodebug__))
_mm256_abs_epi8(__m256i __a) {
  __m256i_internal ret, a;
  a = __m256i_to_internal(__a);
  ret.v0 = _mm_abs_epi8(a.v0);
  ret.v1 = _mm_abs_epi8(a.v1);
  return __m256i_from_internal(ret);
}

static __inline__ __m256i __attribute__((__always_inline__, __nodebug__))
_mm256_abs_epi16(__m256i __a) {
  __m256i_internal ret, a;
  a = __m256i_to_internal(__a);
  ret.v0 = _mm_abs_epi16(a.v0);
  ret.v1 = _mm_abs_epi16(a.v1);
  return __m256i_from_internal(ret);
}

static __inline__ __m256i __attribute__((__always_inline__, __nodebug__))
_mm256_abs_epi32(__m256i __a) {
  __m256i_internal ret, a;
  a = __m256i_to_internal(__a);
  ret.v0 = _mm_abs_epi32(a.v0);
  ret.v1 = _mm_abs_epi32(a.v1);
  return __m256i_from_internal(ret);
}

static __inline__ __m256i __attribute__((__always_inline__, __nodebug__))
_mm256_packs_epi16(__m256i __a, __m256i __b) {
  __m256i_internal ret, a, b;
  a = __m256i_to_internal(__a);
  b = __m256i_to_internal(__b);
  ret.v0 = _mm_packs_epi16(a.v0, b.v0);
  ret.v1 = _mm_packs_epi16(a.v1, b.v1);
  return __m256i_from_internal(ret);
}

static __inline__ __m256i __attribute__((__always_inline__, __nodebug__))
_mm256_packs_epi32(__m256i __a, __m256i __b) {
  __m256i_internal ret, a, b;
  a = __m256i_to_internal(__a);
  b = __m256i_to_internal(__b);
  ret.v0 = _mm_packs_epi32(a.v0, b.v0);
  ret.v1 = _mm_packs_epi32(a.v1, b.v1);
  return __m256i_from_internal(ret);
}

static __inline__ __m256i __attribute__((__always_inline__, __nodebug__))
_mm256_packus_epi16(__m256i __a, __m256i __b) {
  __m256i_internal ret, a, b;
  a = __m256i_to_internal(__a);
  b = __m256i_to_internal(__b);
  ret.v0 = _mm_packus_epi16(a.v0, b.v0);
  ret.v1 = _mm_packus_epi16(a.v1, b.v1);
  return __m256i_from_internal(ret);
}

static __inline__ __m256i __attribute__((__always_inline__, __nodebug__))
_mm256_packus_epi32(__m256i __a, __m256i __b) {
  __m256i_internal ret, a, b;
  a = __m256i_to_internal(__a);
  b = __m256i_to_internal(__b);
  ret.v0 = _mm_packus_epi32(a.v0, b.v0);
  ret.v1 = _mm_packus_epi32(a.v1, b.v1);
  return __m256i_from_internal(ret);
}

static __inline__ __m256i __attribute__((__always_inline__, __nodebug__))
_mm256_add_epi8(__m256i __a, __m256i __b) {
  __m256i_internal ret, a, b;
  a = __m256i_to_internal(__a);
  b = __m256i_to_internal(__b);
  ret.v0 = _mm_add_epi8(a.v0, b.v0);
  ret.v1 = _mm_add_epi8(a.v1, b.v1);
  return __m256i_from_internal(ret);
}

static __inline__ __m256i __attribute__((__always_inline__, __nodebug__))
_mm256_add_epi16(__m256i __a, __m256i __b) {
  __m256i_internal ret, a, b;
  a = __m256i_to_internal(__a);
  b = __m256i_to_internal(__b);
  ret.v0 = _mm_add_epi16(a.v0, b.v0);
  ret.v1 = _mm_add_epi16(a.v1, b.v1);
  return __m256i_from_internal(ret);
}

static __inline__ __m256i __attribute__((__always_inline__, __nodebug__))
_mm256_add_epi32(__m256i __a, __m256i __b) {
  __m256i_internal ret, a, b;
  a = __m256i_to_internal(__a);
  b = __m256i_to_internal(__b);
  ret.v0 = _mm_add_epi32(a.v0, b.v0);
  ret.v1 = _mm_add_epi32(a.v1, b.v1);
  return __m256i_from_internal(ret);
}

static __inline__ __m256i __attribute__((__always_inline__, __nodebug__))
_mm256_add_epi64(__m256i __a, __m256i __b) {
  __m256i_internal ret, a, b;
  a = __m256i_to_internal(__a);
  b = __m256i_to_internal(__b);
  ret.v0 = _mm_add_epi64(a.v0, b.v0);
  ret.v1 = _mm_add_epi64(a.v1, b.v1);
  return __m256i_from_internal(ret);
}

static __inline__ __m256i __attribute__((__always_inline__, __nodebug__))
_mm256_adds_epi8(__m256i __a, __m256i __b) {
  __m256i_internal ret, a, b;
  a = __m256i_to_internal(__a);
  b = __m256i_to_internal(__b);
  ret.v0 = _mm_adds_epi8(a.v0, b.v0);
  ret.v1 = _mm_adds_epi8(a.v1, b.v1);
  return __m256i_from_internal(ret);
}

static __inline__ __m256i __attribute__((__always_inline__, __nodebug__))
_mm256_adds_epi16(__m256i __a, __m256i __b) {
  __m256i_internal ret, a, b;
  a = __m256i_to_internal(__a);
  b = __m256i_to_internal(__b);
  ret.v0 = _mm_adds_epi16(a.v0, b.v0);
  ret.v1 = _mm_adds_epi16(a.v1, b.v1);
  return __m256i_from_internal(ret);
}

static __inline__ __m256i __attribute__((__always_inline__, __nodebug__))
_mm256_adds_epu8(__m256i __a, __m256i __b) {
  __m256i_internal ret, a, b;
  a = __m256i_to_internal(__a);
  b = __m256i_to_internal(__b);
  ret.v0 = _mm_adds_epu8(a.v0, b.v0);
  ret.v1 = _mm_adds_epu8(a.v1, b.v1);
  return __m256i_from_internal(ret);
}

static __inline__ __m256i __attribute__((__always_inline__, __nodebug__))
_mm256_adds_epu16(__m256i __a, __m256i __b) {
  __m256i_internal ret, a, b;
  a = __m256i_to_internal(__a);
  b = __m256i_to_internal(__b);
  ret.v0 = _mm_adds_epu16(a.v0, b.v0);
  ret.v1 = _mm_adds_epu16(a.v1, b.v1);
  return __m256i_from_internal(ret);
}

#define _mm256_alignr_epi8(__A, __B, __imm)                                    \\
  __extension__({                                                              \\
    __m256i_internal __a = __m256i_to_internal(__A);                             \\
    __m256i_internal __b = __m256i_to_internal(__B);                             \\
    _mm256_set_m128i(_mm_alignr_epi8(__a.v1, __b.v1, (__imm)),                 \\
                     _mm_alignr_epi8(__a.v0, __b.v0, (__imm)));                \\
  })

static __inline__ __m256i __attribute__((__always_inline__, __nodebug__))
_mm256_and_si256(__m256i __a, __m256i __b) {
  __m256i_internal ret, a, b;
  a = __m256i_to_internal(__a);
  b = __m256i_to_internal(__b);
  ret.v0 = _mm_and_si128(a.v0, b.v0);
  ret.v1 = _mm_and_si128(a.v1, b.v1);
  return __m256i_from_internal(ret);
}

static __inline__ __m256i __attribute__((__always_inline__, __nodebug__))
_mm256_andnot_si256(__m256i __a, __m256i __b) {
  __m256i_internal ret, a, b;
  a = __m256i_to_internal(__a);
  b = __m256i_to_internal(__b);
  ret.v0 = _mm_andnot_si128(a.v0, b.v0);
  ret.v1 = _mm_andnot_si128(a.v1, b.v1);
  return __m256i_from_internal(ret);
}

static __inline__ __m256i __attribute__((__always_inline__, __nodebug__))
_mm256_avg_epu8(__m256i __a, __m256i __b) {
  __m256i_internal ret, a, b;
  a = __m256i_to_internal(__a);
  b = __m256i_to_internal(__b);
  ret.v0 = _mm_avg_epu8(a.v0, b.v0);
  ret.v1 = _mm_avg_epu8(a.v1, b.v1);
  return __m256i_from_internal(ret);
}

static __inline__ __m256i __attribute__((__always_inline__, __nodebug__))
_mm256_avg_epu16(__m256i __a, __m256i __b) {
  __m256i_internal ret, a, b;
  a = __m256i_to_internal(__a);
  b = __m256i_to_internal(__b);
  ret.v0 = _mm_avg_epu16(a.v0, b.v0);
  ret.v1 = _mm_avg_epu16(a.v1, b.v1);
  return __m256i_from_internal(ret);
}

static __inline__ __m256i __attribute__((__always_inline__, __nodebug__))
_mm256_blendv_epi8(__m256i __a, __m256i __b, __m256i __mask) {
  __m256i_internal ret, a, b, mask;
  a = __m256i_to_internal(__a);
  b = __m256i_to_internal(__b);
  mask = __m256i_to_internal(__mask);
  ret.v0 = _mm_blendv_epi8(a.v0, b.v0, mask.v0);
  ret.v1 = _mm_blendv_epi8(a.v1, b.v1, mask.v1);
  return __m256i_from_internal(ret);
}

#define _mm256_blend_epi16(__A, __B, __imm)                                    \\
  __extension__({                                                              \\
    __m256i_internal __a = __m256i_to_internal(__A);                             \\
    __m256i_internal __b = __m256i_to_internal(__B);                             \\
    _mm256_set_m128i(_mm_blend_epi16(__a.v1, __b.v1, (__imm)),                 \\
                     _mm_blend_epi16(__a.v0, __b.v0, (__imm)));                \\
  })

static __inline__ __m256i __attribute__((__always_inline__, __nodebug__))
_mm256_cmpeq_epi8(__m256i __a, __m256i __b) {
  __m256i_internal ret, a, b;
  a = __m256i_to_internal(__a);
  b = __m256i_to_internal(__b);
  ret.v0 = _mm_cmpeq_epi8(a.v0, b.v0);
  ret.v1 = _mm_cmpeq_epi8(a.v1, b.v1);
  return __m256i_from_internal(ret);
}

static __inline__ __m256i __attribute__((__always_inline__, __nodebug__))
_mm256_cmpeq_epi16(__m256i __a, __m256i __b) {
  __m256i_internal ret, a, b;
  a = __m256i_to_internal(__a);
  b = __m256i_to_internal(__b);
  ret.v0 = _mm_cmpeq_epi16(a.v0, b.v0);
  ret.v1 = _mm_cmpeq_epi16(a.v1, b.v1);
  return __m256i_from_internal(ret);
}

static __inline__ __m256i __attribute__((__always_inline__, __nodebug__))
_mm256_cmpeq_epi32(__m256i __a, __m256i __b) {
  __m256i_internal ret, a, b;
  a = __m256i_to_internal(__a);
  b = __m256i_to_internal(__b);
  ret.v0 = _mm_cmpeq_epi32(a.v0, b.v0);
  ret.v1 = _mm_cmpeq_epi32(a.v1, b.v1);
  return __m256i_from_internal(ret);
}

static __inline__ __m256i __attribute__((__always_inline__, __nodebug__))
_mm256_cmpeq_epi64(__m256i __a, __m256i __b) {
  __m256i_internal ret, a, b;
  a = __m256i_to_internal(__a);
  b = __m256i_to_internal(__b);
  ret.v0 = _mm_cmpeq_epi64(a.v0, b.v0);
  ret.v1 = _mm_cmpeq_epi64(a.v1, b.v1);
  return __m256i_from_internal(ret);
}

static __inline__ __m256i __attribute__((__always_inline__, __nodebug__))
_mm256_cmpgt_epi8(__m256i __a, __m256i __b) {
  __m256i_internal ret, a, b;
  a = __m256i_to_internal(__a);
  b = __m256i_to_internal(__b);
  ret.v0 = _mm_cmpgt_epi8(a.v0, b.v0);
  ret.v1 = _mm_cmpgt_epi8(a.v1, b.v1);
  return __m256i_from_internal(ret);
}

static __inline__ __m256i __attribute__((__always_inline__, __nodebug__))
_mm256_cmpgt_epi16(__m256i __a, __m256i __b) {
  __m256i_internal ret, a, b;
  a = __m256i_to_internal(__a);
  b = __m256i_to_internal(__b);
  ret.v0 = _mm_cmpgt_epi16(a.v0, b.v0);
  ret.v1 = _mm_cmpgt_epi16(a.v1, b.v1);
  return __m256i_from_internal(ret);
}

static __inline__ __m256i __attribute__((__always_inline__, __nodebug__))
_mm256_cmpgt_epi32(__m256i __a, __m256i __b) {
  __m256i_internal ret, a, b;
  a = __m256i_to_internal(__a);
  b = __m256i_to_internal(__b);
  ret.v0 = _mm_cmpgt_epi32(a.v0, b.v0);
  ret.v1 = _mm_cmpgt_epi32(a.v1, b.v1);
  return __m256i_from_internal(ret);
}

static __inline__ __m256i __attribute__((__always_inline__, __nodebug__))
_mm256_cmpgt_epi64(__m256i __a, __m256i __b) {
  __m256i_internal ret, a, b;
  a = __m256i_to_internal(__a);
  b = __m256i_to_internal(__b);
  ret.v0 = _mm_cmpgt_epi64(a.v0, b.v0);
  ret.v1 = _mm_cmpgt_epi64(a.v1, b.v1);
  return __m256i_from_internal(ret);
}

static __inline__ __m256i __attribute__((__always_inline__, __nodebug__))
_mm256_hadd_epi16(__m256i __a, __m256i __b) {
  __m256i_internal ret, a, b;
  a = __m256i_to_internal(__a);
  b = __m256i_to_internal(__b);
  ret.v0 = _mm_hadd_epi16(a.v0, b.v0);
  ret.v1 = _mm_hadd_epi16(a.v1, b.v1);
  return __m256i_from_internal(ret);
}

static __inline__ __m256i __attribute__((__always_inline__, __nodebug__))
_mm256_hadd_epi32(__m256i __a, __m256i __b) {
  __m256i_internal ret, a, b;
  a = __m256i_to_internal(__a);
  b = __m256i_to_internal(__b);
  ret.v0 = _mm_hadd_epi32(a.v0, b.v0);
  ret.v1 = _mm_hadd_epi32(a.v1, b.v1);
  return __m256i_from_internal(ret);
}

static __inline__ __m256i __attribute__((__always_inline__, __nodebug__))
_mm256_hadds_epi16(__m256i __a, __m256i __b) {
  __m256i_internal ret, a, b;
  a = __m256i_to_internal(__a);
  b = __m256i_to_internal(__b);
  ret.v0 = _mm_hadds_epi16(a.v0, b.v0);
  ret.v1 = _mm_hadds_epi16(a.v1, b.v1);
  return __m256i_from_internal(ret);
}

static __inline__ __m256i __attribute__((__always_inline__, __nodebug__))
_mm256_hsub_epi16(__m256i __a, __m256i __b) {
  __m256i_internal ret, a, b;
  a = __m256i_to_internal(__a);
  b = __m256i_to_internal(__b);
  ret.v0 = _mm_hsub_epi16(a.v0, b.v0);
  ret.v1 = _mm_hsub_epi16(a.v1, b.v1);
  return __m256i_from_internal(ret);
}

static __inline__ __m256i __attribute__((__always_inline__, __nodebug__))
_mm256_hsub_epi32(__m256i __a, __m256i __b) {
  __m256i_internal ret, a, b;
  a = __m256i_to_internal(__a);
  b = __m256i_to_internal(__b);
  ret.v0 = _mm_hsub_epi32(a.v0, b.v0);
  ret.v1 = _mm_hsub_epi32(a.v1, b.v1);
  return __m256i_from_internal(ret);
}

static __inline__ __m256i __attribute__((__always_inline__, __nodebug__))
_mm256_hsubs_epi16(__m256i __a, __m256i __b) {
  __m256i_internal ret, a, b;
  a = __m256i_to_internal(__a);
  b = __m256i_to_internal(__b);
  ret.v0 = _mm_hsubs_epi16(a.v0, b.v0);
  ret.v1 = _mm_hsubs_epi16(a.v1, b.v1);
  return __m256i_from_internal(ret);
}

static __inline__ __m256i __attribute__((__always_inline__, __nodebug__))
_mm256_maddubs_epi16(__m256i __a, __m256i __b) {
  __m256i_internal ret, a, b;
  a = __m256i_to_internal(__a);
  b = __m256i_to_internal(__b);
  ret.v0 = _mm_maddubs_epi16(a.v0, b.v0);
  ret.v1 = _mm_maddubs_epi16(a.v1, b.v1);
  return __m256i_from_internal(ret);
}

static __inline__ __m256i __attribute__((__always_inline__, __nodebug__))
_mm256_madd_epi16(__m256i __a, __m256i __b) {
  __m256i_internal ret, a, b;
  a = __m256i_to_internal(__a);
  b = __m256i_to_internal(__b);
  ret.v0 = _mm_madd_epi16(a.v0, b.v0);
  ret.v1 = _mm_madd_epi16(a.v1, b.v1);
  return __m256i_from_internal(ret);
}

static __inline__ __m256i __attribute__((__always_inline__, __nodebug__))
_mm256_max_epi8(__m256i __a, __m256i __b) {
  __m256i_internal ret, a, b;
  a = __m256i_to_internal(__a);
  b = __m256i_to_internal(__b);
  ret.v0 = _mm_max_epi8(a.v0, b.v0);
  ret.v1 = _mm_max_epi8(a.v1, b.v1);
  return __m256i_from_internal(ret);
}

static __inline__ __m256i __attribute__((__always_inline__, __nodebug__))
_mm256_max_epi16(__m256i __a, __m256i __b) {
  __m256i_internal ret, a, b;
  a = __m256i_to_internal(__a);
  b = __m256i_to_internal(__b);
  ret.v0 = _mm_max_epi16(a.v0, b.v0);
  ret.v1 = _mm_max_epi16(a.v1, b.v1);
  return __m256i_from_internal(ret);
}

static __inline__ __m256i __attribute__((__always_inline__, __nodebug__))
_mm256_max_epi32(__m256i __a, __m256i __b) {
  __m256i_internal ret, a, b;
  a = __m256i_to_internal(__a);
  b = __m256i_to_internal(__b);
  ret.v0 = _mm_max_epi32(a.v0, b.v0);
  ret.v1 = _mm_max_epi32(a.v1, b.v1);
  return __m256i_from_internal(ret);
}

static __inline__ __m256i __attribute__((__always_inline__, __nodebug__))
_mm256_max_epu8(__m256i __a, __m256i __b) {
  __m256i_internal ret, a, b;
  a = __m256i_to_internal(__a);
  b = __m256i_to_internal(__b);
  ret.v0 = _mm_max_epu8(a.v0, b.v0);
  ret.v1 = _mm_max_epu8(a.v1, b.v1);
  return __m256i_from_internal(ret);
}

static __inline__ __m256i __attribute__((__always_inline__, __nodebug__))
_mm256_max_epu16(__m256i __a, __m256i __b) {
  __m256i_internal ret, a, b;
  a = __m256i_to_internal(__a);
  b = __m256i_to_internal(__b);
  ret.v0 = _mm_max_epu16(a.v0, b.v0);
  ret.v1 = _mm_max_epu16(a.v1, b.v1);
  return __m256i_from_internal(ret);
}

static __inline__ __m256i __attribute__((__always_inline__, __nodebug__))
_mm256_max_epu32(__m256i __a, __m256i __b) {
  __m256i_internal ret, a, b;
  a = __m256i_to_internal(__a);
  b = __m256i_to_internal(__b);
  ret.v0 = _mm_max_epu32(a.v0, b.v0);
  ret.v1 = _mm_max_epu32(a.v1, b.v1);
  return __m256i_from_internal(ret);
}

static __inline__ __m256i __attribute__((__always_inline__, __nodebug__))
_mm256_min_epi8(__m256i __a, __m256i __b) {
  __m256i_internal ret, a, b;
  a = __m256i_to_internal(__a);
  b = __m256i_to_internal(__b);
  ret.v0 = _mm_min_epi8(a.v0, b.v0);
  ret.v1 = _mm_min_epi8(a.v1, b.v1);
  return __m256i_from_internal(ret);
}

static __inline__ __m256i __attribute__((__always_inline__, __nodebug__))
_mm256_min_epi16(__m256i __a, __m256i __b) {
  __m256i_internal ret, a, b;
  a = __m256i_to_internal(__a);
  b = __m256i_to_internal(__b);
  ret.v0 = _mm_min_epi16(a.v0, b.v0);
  ret.v1 = _mm_min_epi16(a.v1, b.v1);
  return __m256i_from_internal(ret);
}

static __inline__ __m256i __attribute__((__always_inline__, __nodebug__))
_mm256_min_epi32(__m256i __a, __m256i __b) {
  __m256i_internal ret, a, b;
  a = __m256i_to_internal(__a);
  b = __m256i_to_internal(__b);
  ret.v0 = _mm_min_epi32(a.v0, b.v0);
  ret.v1 = _mm_min_epi32(a.v1, b.v1);
  return __m256i_from_internal(ret);
}

static __inline__ __m256i __attribute__((__always_inline__, __nodebug__))
_mm256_min_epu8(__m256i __a, __m256i __b) {
  __m256i_internal ret, a, b;
  a = __m256i_to_internal(__a);
  b = __m256i_to_internal(__b);
  ret.v0 = _mm_min_epu8(a.v0, b.v0);
  ret.v1 = _mm_min_epu8(a.v1, b.v1);
  return __m256i_from_internal(ret);
}

static __inline__ __m256i __attribute__((__always_inline__, __nodebug__))
_mm256_min_epu16(__m256i __a, __m256i __b) {
  __m256i_internal ret, a, b;
  a = __m256i_to_internal(__a);
  b = __m256i_to_internal(__b);
  ret.v0 = _mm_min_epu16(a.v0, b.v0);
  ret.v1 = _mm_min_epu16(a.v1, b.v1);
  return __m256i_from_internal(ret);
}

static __inline__ __m256i __attribute__((__always_inline__, __nodebug__))
_mm256_min_epu32(__m256i __a, __m256i __b) {
  __m256i_internal ret, a, b;
  a = __m256i_to_internal(__a);
  b = __m256i_to_internal(__b);
  ret.v0 = _mm_min_epu32(a.v0, b.v0);
  ret.v1 = _mm_min_epu32(a.v1, b.v1);
  return __m256i_from_internal(ret);
}

static __inline__ int __attribute__((__always_inline__, __nodebug__))
_mm256_movemask_epi8(__m256i __a) {
  __m256i_internal a = __m256i_to_internal(__a);
  return (_mm_movemask_epi8(a.v1) << 16) | _mm_movemask_epi8(a.v0);
}

static __inline__ __m256i __attribute__((__always_inline__, __nodebug__))
_mm256_cvtepi8_epi16(__m128i __a) {
  __m256i_internal ret;
  ret.v0 = _mm_cvtepi8_epi16(__a);
  ret.v1 = _mm_cvtepi8_epi16(_mm_shuffle_epi32(__a, 0x4E));
  return __m256i_from_internal(ret);
}

static __inline__ __m256i __attribute__((__always_inline__, __nodebug__))
_mm256_cvtepi8_epi32(__m128i __a) {
  __m256i_internal ret;
  ret.v0 = _mm_cvtepi8_epi32(__a);
  ret.v1 = _mm_cvtepi8_epi32(_mm_shuffle_epi32(__a, 0xE1));
  return __m256i_from_internal(ret);
}

static __inline__ __m256i __attribute__((__always_inline__, __nodebug__))
_mm256_cvtepi8_epi64(__m128i __a) {
  __m256i_internal ret;
  ret.v0 = _mm_cvtepi8_epi64(__a);
  ret.v1 = _mm_cvtepi8_epi64(_mm_srli_epi32(__a, 16));
  return __m256i_from_internal(ret);
}

static __inline__ __m256i __attribute__((__always_inline__, __nodebug__))
_mm256_cvtepi16_epi32(__m128i __a) {
  __m256i_internal ret;
  ret.v0 = _mm_cvtepi16_epi32(__a);
  ret.v1 = _mm_cvtepi16_epi32(_mm_shuffle_epi32(__a, 0x4E));
  return __m256i_from_internal(ret);
}

static __inline__ __m256i __attribute__((__always_inline__, __nodebug__))
_mm256_cvtepi16_epi64(__m128i __a) {
  __m256i_internal ret;
  ret.v0 = _mm_cvtepi16_epi64(__a);
  ret.v1 = _mm_cvtepi16_epi64(_mm_shuffle_epi32(__a, 0xE1));
  return __m256i_from_internal(ret);
}

static __inline__ __m256i __attribute__((__always_inline__, __nodebug__))
_mm256_cvtepi32_epi64(__m128i __a) {
  __m256i_internal ret;
  ret.v0 = _mm_cvtepi32_epi64(__a);
  ret.v1 = _mm_cvtepi32_epi64(_mm_shuffle_epi32(__a, 0x4E));
  return __m256i_from_internal(ret);
}

static __inline__ __m256i __attribute__((__always_inline__, __nodebug__))
_mm256_cvtepu8_epi16(__m128i __a) {
  __m256i_internal ret;
  ret.v0 = _mm_cvtepu8_epi16(__a);
  ret.v1 = _mm_cvtepu8_epi16(_mm_shuffle_epi32(__a, 0x4E));
  return __m256i_from_internal(ret);
}

static __inline__ __m256i __attribute__((__always_inline__, __nodebug__))
_mm256_cvtepu8_epi32(__m128i __a) {
  __m256i_internal ret;
  ret.v0 = _mm_cvtepu8_epi32(__a);
  ret.v1 = _mm_cvtepu8_epi32(_mm_shuffle_epi32(__a, 0xE1));
  return __m256i_from_internal(ret);
}

static __inline__ __m256i __attribute__((__always_inline__, __nodebug__))
_mm256_cvtepu8_epi64(__m128i __a) {
  __m256i_internal ret;
  ret.v0 = _mm_cvtepu8_epi64(__a);
  ret.v1 = _mm_cvtepu8_epi64(_mm_srli_epi32(__a, 16));
  return __m256i_from_internal(ret);
}

static __inline__ __m256i __attribute__((__always_inline__, __nodebug__))
_mm256_cvtepu16_epi32(__m128i __a) {
  __m256i_internal ret;
  ret.v0 = _mm_cvtepu16_epi32(__a);
  ret.v1 = _mm_cvtepu16_epi32(_mm_shuffle_epi32(__a, 0x4E));
  return __m256i_from_internal(ret);
}

static __inline__ __m256i __attribute__((__always_inline__, __nodebug__))
_mm256_cvtepu16_epi64(__m128i __a) {
  __m256i_internal ret;
  ret.v0 = _mm_cvtepu16_epi64(__a);
  ret.v1 = _mm_cvtepu16_epi64(_mm_shuffle_epi32(__a, 0xE1));
  return __m256i_from_internal(ret);
}

static __inline__ __m256i __attribute__((__always_inline__, __nodebug__))
_mm256_cvtepu32_epi64(__m128i __a) {
  __m256i_internal ret;
  ret.v0 = _mm_cvtepu32_epi64(__a);
  ret.v1 = _mm_cvtepu32_epi64(_mm_shuffle_epi32(__a, 0x4E));
  return __m256i_from_internal(ret);
}

static __inline__ __m256i __attribute__((__always_inline__, __nodebug__))
_mm256_mul_epi32(__m256i __a, __m256i __b) {
  __m256i_internal ret, a, b;
  a = __m256i_to_internal(__a);
  b = __m256i_to_internal(__b);
  ret.v0 = _mm_mul_epi32(a.v0, b.v0);
  ret.v1 = _mm_mul_epi32(a.v1, b.v1);
  return __m256i_from_internal(ret);
}

static __inline__ __m256i __attribute__((__always_inline__, __nodebug__))
_mm256_mulhrs_epi16(__m256i __a, __m256i __b) {
  __m256i_internal ret, a, b;
  a = __m256i_to_internal(__a);
  b = __m256i_to_internal(__b);
  ret.v0 = _mm_mulhrs_epi16(a.v0, b.v0);
  ret.v1 = _mm_mulhrs_epi16(a.v1, b.v1);
  return __m256i_from_internal(ret);
}

static __inline__ __m256i __attribute__((__always_inline__, __nodebug__))
_mm256_mulhi_epu16(__m256i __a, __m256i __b) {
  __m256i_internal ret, a, b;
  a = __m256i_to_internal(__a);
  b = __m256i_to_internal(__b);
  ret.v0 = _mm_mulhi_epu16(a.v0, b.v0);
  ret.v1 = _mm_mulhi_epu16(a.v1, b.v1);
  return __m256i_from_internal(ret);
}

static __inline__ __m256i __attribute__((__always_inline__, __nodebug__))
_mm256_mulhi_epi16(__m256i __a, __m256i __b) {
  __m256i_internal ret, a, b;
  a = __m256i_to_internal(__a);
  b = __m256i_to_internal(__b);
  ret.v0 = _mm_mulhi_epi16(a.v0, b.v0);
  ret.v1 = _mm_mulhi_epi16(a.v1, b.v1);
  return __m256i_from_internal(ret);
}

static __inline__ __m256i __attribute__((__always_inline__, __nodebug__))
_mm256_mullo_epi16(__m256i __a, __m256i __b) {
  __m256i_internal ret, a, b;
  a = __m256i_to_internal(__a);
  b = __m256i_to_internal(__b);
  ret.v0 = _mm_mullo_epi16(a.v0, b.v0);
  ret.v1 = _mm_mullo_epi16(a.v1, b.v1);
  return __m256i_from_internal(ret);
}

static __inline__ __m256i __attribute__((__always_inline__, __nodebug__))
_mm256_mullo_epi32(__m256i __a, __m256i __b) {
  __m256i_internal ret, a, b;
  a = __m256i_to_internal(__a);
  b = __m256i_to_internal(__b);
  ret.v0 = _mm_mullo_epi32(a.v0, b.v0);
  ret.v1 = _mm_mullo_epi32(a.v1, b.v1);
  return __m256i_from_internal(ret);
}

static __inline__ __m256i __attribute__((__always_inline__, __nodebug__))
_mm256_mul_epu32(__m256i __a, __m256i __b) {
  __m256i_internal ret, a, b;
  a = __m256i_to_internal(__a);
  b = __m256i_to_internal(__b);
  ret.v0 = _mm_mul_epu32(a.v0, b.v0);
  ret.v1 = _mm_mul_epu32(a.v1, b.v1);
  return __m256i_from_internal(ret);
}

static __inline__ __m256i __attribute__((__always_inline__, __nodebug__))
_mm256_or_si256(__m256i __a, __m256i __b) {
  __m256i_internal ret, a, b;
  a = __m256i_to_internal(__a);
  b = __m256i_to_internal(__b);
  ret.v0 = _mm_or_si128(a.v0, b.v0);
  ret.v1 = _mm_or_si128(a.v1, b.v1);
  return __m256i_from_internal(ret);
}

static __inline__ __m256i __attribute__((__always_inline__, __nodebug__))
_mm256_sad_epu8(__m256i __a, __m256i __b) {
  __m256i_internal ret, a, b;
  a = __m256i_to_internal(__a);
  b = __m256i_to_internal(__b);
  ret.v0 = _mm_sad_epu8(a.v0, b.v0);
  ret.v1 = _mm_sad_epu8(a.v1, b.v1);
  return __m256i_from_internal(ret);
}

static __inline__ __m256i __attribute__((__always_inline__, __nodebug__))
_mm256_shuffle_epi8(__m256i __a, __m256i __b) {
  __m256i_internal ret, a, b;
  a = __m256i_to_internal(__a);
  b = __m256i_to_internal(__b);
  ret.v0 = _mm_shuffle_epi8(a.v0, b.v0);
  ret.v1 = _mm_shuffle_epi8(a.v1, b.v1);
  return __m256i_from_internal(ret);
}

#define _mm256_shuffle_epi32(__A, __imm)                                       \\
  __extension__({                                                              \\
    __m256i_internal __a = __m256i_to_internal(__A);                             \\
    _mm256_set_m128i(_mm_shuffle_epi32(__a.v1, (__imm)),                       \\
                     _mm_shuffle_epi32(__a.v0, (__imm)));                      \\
  })

#define _mm256_shufflehi_epi16(__A, __imm)                                     \\
  __extension__({                                                              \\
    __m256i_internal __a = __m256i_to_internal(__A);                             \\
    _mm256_set_m128i(_mm_shufflehi_epi16(__a.v1, (__imm)),                     \\
                     _mm_shufflehi_epi16(__a.v0, (__imm)));                    \\
  })

#define _mm256_shufflelo_epi16(__A, __imm)                                     \\
  __extension__({                                                              \\
    __m256i_internal __a = __m256i_to_internal(__A);                             \\
    _mm256_set_m128i(_mm_shufflelo_epi16(__a.v1, (__imm)),                     \\
                     _mm_shufflelo_epi16(__a.v0, (__imm)));                    \\
  })

static __inline__ __m256i __attribute__((__always_inline__, __nodebug__))
_mm256_sign_epi8(__m256i __a, __m256i __b) {
  __m256i_internal ret, a, b;
  a = __m256i_to_internal(__a);
  b = __m256i_to_internal(__b);
  ret.v0 = _mm_sign_epi8(a.v0, b.v0);
  ret.v1 = _mm_sign_epi8(a.v1, b.v1);
  return __m256i_from_internal(ret);
}

static __inline__ __m256i __attribute__((__always_inline__, __nodebug__))
_mm256_sign_epi16(__m256i __a, __m256i __b) {
  __m256i_internal ret, a, b;
  a = __m256i_to_internal(__a);
  b = __m256i_to_internal(__b);
  ret.v0 = _mm_sign_epi16(a.v0, b.v0);
  ret.v1 = _mm_sign_epi16(a.v1, b.v1);
  return __m256i_from_internal(ret);
}

static __inline__ __m256i __attribute__((__always_inline__, __nodebug__))
_mm256_sign_epi32(__m256i __a, __m256i __b) {
  __m256i_internal ret, a, b;
  a = __m256i_to_internal(__a);
  b = __m256i_to_internal(__b);
  ret.v0 = _mm_sign_epi32(a.v0, b.v0);
  ret.v1 = _mm_sign_epi32(a.v1, b.v1);
  return __m256i_from_internal(ret);
}

#define _mm256_slli_si256(__A, __imm)                                          \\
  __extension__({                                                              \\
    __m256i_internal __a = __m256i_to_internal(__A);                             \\
    _mm256_set_m128i(_mm_slli_si128(__a.v1, (__imm)),                          \\
                     _mm_slli_si128(__a.v0, (__imm)));                         \\
  })

#define _mm256_bslli_epi128(__A, __imm) _mm256_slli_si256(__A, __imm)

static __inline__ __m256i __attribute__((__always_inline__, __nodebug__))
_mm256_slli_epi16(__m256i __a, int __count) {
  __m256i_internal ret, a;
  a = __m256i_to_internal(__a);
  ret.v0 = _mm_slli_epi16(a.v0, __count);
  ret.v1 = _mm_slli_epi16(a.v1, __count);
  return __m256i_from_internal(ret);
}

static __inline__ __m256i __attribute__((__always_inline__, __nodebug__))
_mm256_sll_epi16(__m256i __a, __m128i __count) {
  __m256i_internal ret, a;
  a = __m256i_to_internal(__a);
  ret.v0 = _mm_sll_epi16(a.v0, __count);
  ret.v1 = _mm_sll_epi16(a.v1, __count);
  return __m256i_from_internal(ret);
}

static __inline__ __m256i __attribute__((__always_inline__, __nodebug__))
_mm256_slli_epi32(__m256i __a, int __count) {
  __m256i_internal ret, a;
  a = __m256i_to_internal(__a);
  ret.v0 = _mm_slli_epi32(a.v0, __count);
  ret.v1 = _mm_slli_epi32(a.v1, __count);
  return __m256i_from_internal(ret);
}

static __inline__ __m256i __attribute__((__always_inline__, __nodebug__))
_mm256_sll_epi32(__m256i __a, __m128i __count) {
  __m256i_internal ret, a;
  a = __m256i_to_internal(__a);
  ret.v0 = _mm_sll_epi32(a.v0, __count);
  ret.v1 = _mm_sll_epi32(a.v1, __count);
  return __m256i_from_internal(ret);
}

static __inline__ __m256i __attribute__((__always_inline__, __nodebug__))
_mm256_slli_epi64(__m256i __a, int __count) {
  __m256i_internal ret, a;
  a = __m256i_to_internal(__a);
  ret.v0 = _mm_slli_epi64(a.v0, __count);
  ret.v1 = _mm_slli_epi64(a.v1, __count);
  return __m256i_from_internal(ret);
}

static __inline__ __m256i __attribute__((__always_inline__, __nodebug__))
_mm256_sll_epi64(__m256i __a, __m128i __count) {
  __m256i_internal ret, a;
  a = __m256i_to_internal(__a);
  ret.v0 = _mm_sll_epi64(a.v0, __count);
  ret.v1 = _mm_sll_epi64(a.v1, __count);
  return __m256i_from_internal(ret);
}

static __inline__ __m256i __attribute__((__always_inline__, __nodebug__))
_mm256_srai_epi16(__m256i __a, int __count) {
  __m256i_internal ret, a;
  a = __m256i_to_internal(__a);
  ret.v0 = _mm_srai_epi16(a.v0, __count);
  ret.v1 = _mm_srai_epi16(a.v1, __count);
  return __m256i_from_internal(ret);
}

static __inline__ __m256i __attribute__((__always_inline__, __nodebug__))
_mm256_sra_epi16(__m256i __a, __m128i __count) {
  __m256i_internal ret, a;
  a = __m256i_to_internal(__a);
  ret.v0 = _mm_sra_epi16(a.v0, __count);
  ret.v1 = _mm_sra_epi16(a.v1, __count);
  return __m256i_from_internal(ret);
}

static __inline__ __m256i __attribute__((__always_inline__, __nodebug__))
_mm256_srai_epi32(__m256i __a, int __count) {
  __m256i_internal ret, a;
  a = __m256i_to_internal(__a);
  ret.v0 = _mm_srai_epi32(a.v0, __count);
  ret.v1 = _mm_srai_epi32(a.v1, __count);
  return __m256i_from_internal(ret);
}

static __inline__ __m256i __attribute__((__always_inline__, __nodebug__))
_mm256_sra_epi32(__m256i __a, __m128i __count) {
  __m256i_internal ret, a;
  a = __m256i_to_internal(__a);
  ret.v0 = _mm_sra_epi32(a.v0, __count);
  ret.v1 = _mm_sra_epi32(a.v1, __count);
  return __m256i_from_internal(ret);
}

#define _mm256_srli_si256(__A, __imm)                                          \\
  __extension__({                                                              \\
    __m256i_internal __a = __m256i_to_internal(__A);                             \\
    _mm256_set_m128i(_mm_srli_si128(__a.v1, (__imm)),                          \\
                     _mm_srli_si128(__a.v0, (__imm)));                         \\
  })

#define _mm256_bsrli_epi128(a, imm) _mm256_srli_si256(a, imm)

static __inline__ __m256i __attribute__((__always_inline__, __nodebug__))
_mm256_srli_epi16(__m256i __a, int __count) {
  __m256i_internal ret, a;
  a = __m256i_to_internal(__a);
  ret.v0 = _mm_srli_epi16(a.v0, __count);
  ret.v1 = _mm_srli_epi16(a.v1, __count);
  return __m256i_from_internal(ret);
}

static __inline__ __m256i __attribute__((__always_inline__, __nodebug__))
_mm256_srl_epi16(__m256i __a, __m128i __count) {
  __m256i_internal ret, a;
  a = __m256i_to_internal(__a);
  ret.v0 = _mm_srl_epi16(a.v0, __count);
  ret.v1 = _mm_srl_epi16(a.v1, __count);
  return __m256i_from_internal(ret);
}

static __inline__ __m256i __attribute__((__always_inline__, __nodebug__))
_mm256_srli_epi32(__m256i __a, int __count) {
  __m256i_internal ret, a;
  a = __m256i_to_internal(__a);
  ret.v0 = _mm_srli_epi32(a.v0, __count);
  ret.v1 = _mm_srli_epi32(a.v1, __count);
  return __m256i_from_internal(ret);
}

static __inline__ __m256i __attribute__((__always_inline__, __nodebug__))
_mm256_srl_epi32(__m256i __a, __m128i __count) {
  __m256i_internal ret, a;
  a = __m256i_to_internal(__a);
  ret.v0 = _mm_srl_epi32(a.v0, __count);
  ret.v1 = _mm_srl_epi32(a.v1, __count);
  return __m256i_from_internal(ret);
}

static __inline__ __m256i __attribute__((__always_inline__, __nodebug__))
_mm256_srli_epi64(__m256i __a, int __count) {
  __m256i_internal ret, a;
  a = __m256i_to_internal(__a);
  ret.v0 = _mm_srli_epi64(a.v0, __count);
  ret.v1 = _mm_srli_epi64(a.v1, __count);
  return __m256i_from_internal(ret);
}

static __inline__ __m256i __attribute__((__always_inline__, __nodebug__))
_mm256_srl_epi64(__m256i __a, __m128i __count) {
  __m256i_internal ret, a;
  a = __m256i_to_internal(__a);
  ret.v0 = _mm_srl_epi64(a.v0, __count);
  ret.v1 = _mm_srl_epi64(a.v1, __count);
  return __m256i_from_internal(ret);
}

static __inline__ __m256i __attribute__((__always_inline__, __nodebug__))
_mm256_sub_epi8(__m256i __a, __m256i __b) {
  __m256i_internal ret, a, b;
  a = __m256i_to_internal(__a);
  b = __m256i_to_internal(__b);
  ret.v0 = _mm_sub_epi8(a.v0, b.v0);
  ret.v1 = _mm_sub_epi8(a.v1, b.v1);
  return __m256i_from_internal(ret);
}

static __inline__ __m256i __attribute__((__always_inline__, __nodebug__))
_mm256_sub_epi16(__m256i __a, __m256i __b) {
  __m256i_internal ret, a, b;
  a = __m256i_to_internal(__a);
  b = __m256i_to_internal(__b);
  ret.v0 = _mm_sub_epi16(a.v0, b.v0);
  ret.v1 = _mm_sub_epi16(a.v1, b.v1);
  return __m256i_from_internal(ret);
}

static __inline__ __m256i __attribute__((__always_inline__, __nodebug__))
_mm256_sub_epi32(__m256i __a, __m256i __b) {
  __m256i_internal ret, a, b;
  a = __m256i_to_internal(__a);
  b = __m256i_to_internal(__b);
  ret.v0 = _mm_sub_epi32(a.v0, b.v0);
  ret.v1 = _mm_sub_epi32(a.v1, b.v1);
  return __m256i_from_internal(ret);
}

static __inline__ __m256i __attribute__((__always_inline__, __nodebug__))
_mm256_sub_epi64(__m256i __a, __m256i __b) {
  __m256i_internal ret, a, b;
  a = __m256i_to_internal(__a);
  b = __m256i_to_internal(__b);
  ret.v0 = _mm_sub_epi64(a.v0, b.v0);
  ret.v1 = _mm_sub_epi64(a.v1, b.v1);
  return __m256i_from_internal(ret);
}

static __inline__ __m256i __attribute__((__always_inline__, __nodebug__))
_mm256_subs_epi8(__m256i __a, __m256i __b) {
  __m256i_internal ret, a, b;
  a = __m256i_to_internal(__a);
  b = __m256i_to_internal(__b);
  ret.v0 = _mm_subs_epi8(a.v0, b.v0);
  ret.v1 = _mm_subs_epi8(a.v1, b.v1);
  return __m256i_from_internal(ret);
}

static __inline__ __m256i __attribute__((__always_inline__, __nodebug__))
_mm256_subs_epi16(__m256i __a, __m256i __b) {
  __m256i_internal ret, a, b;
  a = __m256i_to_internal(__a);
  b = __m256i_to_internal(__b);
  ret.v0 = _mm_subs_epi16(a.v0, b.v0);
  ret.v1 = _mm_subs_epi16(a.v1, b.v1);
  return __m256i_from_internal(ret);
}

static __inline__ __m256i __attribute__((__always_inline__, __nodebug__))
_mm256_subs_epu8(__m256i __a, __m256i __b) {
  __m256i_internal ret, a, b;
  a = __m256i_to_internal(__a);
  b = __m256i_to_internal(__b);
  ret.v0 = _mm_subs_epu8(a.v0, b.v0);
  ret.v1 = _mm_subs_epu8(a.v1, b.v1);
  return __m256i_from_internal(ret);
}

static __inline__ __m256i __attribute__((__always_inline__, __nodebug__))
_mm256_subs_epu16(__m256i __a, __m256i __b) {
  __m256i_internal ret, a, b;
  a = __m256i_to_internal(__a);
  b = __m256i_to_internal(__b);
  ret.v0 = _mm_subs_epu16(a.v0, b.v0);
  ret.v1 = _mm_subs_epu16(a.v1, b.v1);
  return __m256i_from_internal(ret);
}

static __inline__ __m256i __attribute__((__always_inline__, __nodebug__))
_mm256_unpackhi_epi8(__m256i __a, __m256i __b) {
  __m256i_internal ret, a, b;
  a = __m256i_to_internal(__a);
  b = __m256i_to_internal(__b);
  ret.v0 = _mm_unpackhi_epi8(a.v0, b.v0);
  ret.v1 = _mm_unpackhi_epi8(a.v1, b.v1);
  return __m256i_from_internal(ret);
}

static __inline__ __m256i __attribute__((__always_inline__, __nodebug__))
_mm256_unpackhi_epi16(__m256i __a, __m256i __b) {
  __m256i_internal ret, a, b;
  a = __m256i_to_internal(__a);
  b = __m256i_to_internal(__b);
  ret.v0 = _mm_unpackhi_epi16(a.v0, b.v0);
  ret.v1 = _mm_unpackhi_epi16(a.v1, b.v1);
  return __m256i_from_internal(ret);
}

static __inline__ __m256i __attribute__((__always_inline__, __nodebug__))
_mm256_unpackhi_epi32(__m256i __a, __m256i __b) {
  __m256i_internal ret, a, b;
  a = __m256i_to_internal(__a);
  b = __m256i_to_internal(__b);
  ret.v0 = _mm_unpackhi_epi32(a.v0, b.v0);
  ret.v1 = _mm_unpackhi_epi32(a.v1, b.v1);
  return __m256i_from_internal(ret);
}

static __inline__ __m256i __attribute__((__always_inline__, __nodebug__))
_mm256_unpackhi_epi64(__m256i __a, __m256i __b) {
  __m256i_internal ret, a, b;
  a = __m256i_to_internal(__a);
  b = __m256i_to_internal(__b);
  ret.v0 = _mm_unpackhi_epi64(a.v0, b.v0);
  ret.v1 = _mm_unpackhi_epi64(a.v1, b.v1);
  return __m256i_from_internal(ret);
}

static __inline__ __m256i __attribute__((__always_inline__, __nodebug__))
_mm256_unpacklo_epi8(__m256i __a, __m256i __b) {
  __m256i_internal ret, a, b;
  a = __m256i_to_internal(__a);
  b = __m256i_to_internal(__b);
  ret.v0 = _mm_unpacklo_epi8(a.v0, b.v0);
  ret.v1 = _mm_unpacklo_epi8(a.v1, b.v1);
  return __m256i_from_internal(ret);
}

static __inline__ __m256i __attribute__((__always_inline__, __nodebug__))
_mm256_unpacklo_epi16(__m256i __a, __m256i __b) {
  __m256i_internal ret, a, b;
  a = __m256i_to_internal(__a);
  b = __m256i_to_internal(__b);
  ret.v0 = _mm_unpacklo_epi16(a.v0, b.v0);
  ret.v1 = _mm_unpacklo_epi16(a.v1, b.v1);
  return __m256i_from_internal(ret);
}

static __inline__ __m256i __attribute__((__always_inline__, __nodebug__))
_mm256_unpacklo_epi32(__m256i __a, __m256i __b) {
  __m256i_internal ret, a, b;
  a = __m256i_to_internal(__a);
  b = __m256i_to_internal(__b);
  ret.v0 = _mm_unpacklo_epi32(a.v0, b.v0);
  ret.v1 = _mm_unpacklo_epi32(a.v1, b.v1);
  return __m256i_from_internal(ret);
}

static __inline__ __m256i __attribute__((__always_inline__, __nodebug__))
_mm256_unpacklo_epi64(__m256i __a, __m256i __b) {
  __m256i_internal ret, a, b;
  a = __m256i_to_internal(__a);
  b = __m256i_to_internal(__b);
  ret.v0 = _mm_unpacklo_epi64(a.v0, b.v0);
  ret.v1 = _mm_unpacklo_epi64(a.v1, b.v1);
  return __m256i_from_internal(ret);
}

static __inline__ __m256i __attribute__((__always_inline__, __nodebug__))
_mm256_xor_si256(__m256i __a, __m256i __b) {
  __m256i_internal ret, a, b;
  a = __m256i_to_internal(__a);
  b = __m256i_to_internal(__b);
  ret.v0 = _mm_xor_si128(a.v0, b.v0);
  ret.v1 = _mm_xor_si128(a.v1, b.v1);
  return __m256i_from_internal(ret);
}

static __inline__ __m256i __attribute__((__always_inline__, __nodebug__))
_mm256_stream_load_si256(const void* __V) {
  __m256i_internal ret;
  ret.v0 = _mm_stream_load_si128((const __m128i*)__V);
  ret.v1 = _mm_stream_load_si128((const __m128i*)(((const uint8_t*)__V) + 16));
  return __m256i_from_internal(ret);
}

static __inline__ __m128 __attribute__((__always_inline__, __nodebug__))
_mm_broadcastss_ps(__m128 __a) {
  return (__m128)wasm_i32x4_shuffle(__a, __a, 0, 0, 0, 0);
}

static __inline__ __m128d __attribute__((__always_inline__, __nodebug__))
_mm_broadcastsd_pd(__m128d __a) {
  return (__m128d)wasm_i64x2_shuffle(__a, __a, 0, 0);
}

static __inline__ __m256 __attribute__((__always_inline__, __nodebug__))
_mm256_broadcastss_ps(__m128 __a) {
  __m256_internal ret;
  ret.v1 = ret.v0 = _mm_broadcastss_ps(__a);
  return __m256_from_internal(ret);
}

static __inline__ __m256d __attribute__((__always_inline__, __nodebug__))
_mm256_broadcastsd_pd(__m128d __a) {
  __m256d_internal ret;
  ret.v1 = ret.v0 = _mm_broadcastsd_pd(__a);
  return __m256d_from_internal(ret);
}

static __inline__ __m256i __attribute__((__always_inline__, __nodebug__))
_mm256_broadcastsi128_si256(__m128i __a) {
  __m256i_internal ret;
  ret.v1 = ret.v0 = __a;
  return __m256i_from_internal(ret);
}

#define _mm_broadcastsi128_si256(X) _mm256_broadcastsi128_si256(X)

#define _mm_blend_epi32(__a, __b, __imm8)                                      \\
  __extension__({                                                              \\
    (__m128i) __builtin_shufflevector((__i32x4)(__m128i)(__a),                 \\
                                      (__i32x4)(__m128i)(__b),                 \\
                                      (((__imm8) & 0x01) ? 4 : 0),             \\
                                      (((__imm8) & 0x02) ? 5 : 1),             \\
                                      (((__imm8) & 0x04) ? 6 : 2),             \\
                                      (((__imm8) & 0x08) ? 7 : 3));            \\
  })

#define _mm256_blend_epi32(__A, __B, __imm)                                    \\
  __extension__({                                                              \\
    __m256i_internal __a = __m256i_to_internal(__A);                             \\
    __m256i_internal __b = __m256i_to_internal(__B);                             \\
    _mm256_set_m128i(_mm_blend_epi32(__a.v1, __b.v1, (__imm) >> 4),            \\
                     _mm_blend_epi32(__a.v0, __b.v0, (__imm)));                \\
  })

static __inline__ __m128i __attribute__((__always_inline__, __nodebug__))
_mm_broadcastb_epi8(__m128i __a) {
  return (__m128i)wasm_i8x16_shuffle(
    __a, __a, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
}

static __inline__ __m128i __attribute__((__always_inline__, __nodebug__))
_mm_broadcastw_epi16(__m128i __a) {
  return (__m128i)wasm_i16x8_shuffle(__a, __a, 0, 0, 0, 0, 0, 0, 0, 0);
}

static __inline__ __m128i __attribute__((__always_inline__, __nodebug__))
_mm_broadcastd_epi32(__m128i __a) {
  return (__m128i)wasm_i32x4_shuffle(__a, __a, 0, 0, 0, 0);
}

static __inline__ __m128i __attribute__((__always_inline__, __nodebug__))
_mm_broadcastq_epi64(__m128i __a) {
  return (__m128i)wasm_i64x2_shuffle(__a, __a, 0, 0);
}

static __inline__ __m256i __attribute__((__always_inline__, __nodebug__))
_mm256_broadcastb_epi8(__m128i __a) {
  __m256i_internal ret;
  ret.v1 = ret.v0 = _mm_broadcastb_epi8(__a);
  return __m256i_from_internal(ret);
}

static __inline__ __m256i __attribute__((__always_inline__, __nodebug__))
_mm256_broadcastw_epi16(__m128i __a) {
  __m256i_internal ret;
  ret.v1 = ret.v0 = _mm_broadcastw_epi16(__a);
  return __m256i_from_internal(ret);
}

static __inline__ __m256i __attribute__((__always_inline__, __nodebug__))
_mm256_broadcastd_epi32(__m128i __a) {
  __m256i_internal ret;
  ret.v1 = ret.v0 = _mm_broadcastd_epi32(__a);
  return __m256i_from_internal(ret);
}

static __inline__ __m256i __attribute__((__always_inline__, __nodebug__))
_mm256_broadcastq_epi64(__m128i __a) {
  __m256i_internal ret;
  ret.v1 = ret.v0 = _mm_broadcastq_epi64(__a);
  return __m256i_from_internal(ret);
}

static __inline__ __m256i
  __attribute__((__always_inline__, __nodebug__, DIAGNOSE_SLOW))
  _mm256_permutevar8x32_epi32(__m256i __a, __m256i __b) {
  __m256i_internal ret, a, b;
  a = __m256i_to_internal(__a);
  b = __m256i_to_internal(__b);
  int index[8];
  int lane[8];
  for (int i = 0; i < 4; i++) {
    index[i] = ((__i32x4)b.v0)[i] & 7;
    index[i + 4] = ((__i32x4)b.v1)[i] & 7;
  }

  for (int j = 0; j < 8; j++) {
    lane[j] = index[j] < 4 ? ((__i32x4)(a.v0))[index[j]]
                           : ((__i32x4)(a.v1))[index[j] - 4];
  }

  ret.v0 = (__m128i)wasm_i32x4_make(lane[0], lane[1], lane[2], lane[3]);
  ret.v1 = (__m128i)wasm_i32x4_make(lane[4], lane[5], lane[6], lane[7]);
  return __m256i_from_internal(ret);
}

#define _mm256_permute4x64_pd(__A, __imm)                                      \\
  __extension__({                                                              \\
    __m256d_internal __a = __m256d_to_internal(__A);                             \\
    _mm256_set_m128d(                                                          \\
      (__m128d)wasm_i64x2_shuffle(                                             \\
        __a.v0, __a.v1, (((__imm) >> 4) & 3), (((__imm) >> 6) & 3)),           \\
      (__m128d)wasm_i64x2_shuffle(                                             \\
        __a.v0, __a.v1, ((__imm) & 3), (((__imm) >> 2) & 3)));                 \\
  })

static __inline__ __m256
  __attribute__((__always_inline__, __nodebug__, DIAGNOSE_SLOW))
  _mm256_permutevar8x32_ps(__m256 __a, __m256i __b) {
  __m256_internal ret;
  __m256_internal a = __m256_to_internal(__a);
  __m256i_internal b = __m256i_to_internal(__b);
  int index[8];
  float lane[8];
  for (int i = 0; i < 4; i++) {
    index[i] = ((__i32x4)b.v0)[i] & 7;
    index[i + 4] = ((__i32x4)b.v1)[i] & 7;
  }
  for (int j = 0; j < 8; j++) {
    lane[j] = index[j] < 4 ? ((__f32x4)(a.v0))[index[j]]
                           : ((__f32x4)(a.v1))[index[j] - 4];
  }
  ret.v0 = (__m128)wasm_f32x4_make(lane[0], lane[1], lane[2], lane[3]);
  ret.v1 = (__m128)wasm_f32x4_make(lane[4], lane[5], lane[6], lane[7]);
  return __m256_from_internal(ret);
}

#define _mm256_permute4x64_epi64(__A, __imm)                                   \\
  __extension__({                                                              \\
    __m256i_internal __a = __m256i_to_internal(__A);                             \\
    _mm256_set_m128i(                                                          \\
      wasm_i64x2_shuffle(                                                      \\
        __a.v0, __a.v1, (((__imm) >> 4) & 3), (((__imm) >> 6) & 3)),           \\
      wasm_i64x2_shuffle(                                                      \\
        __a.v0, __a.v1, ((__imm) & 3), (((__imm) >> 2) & 3)));                 \\
  })

static __inline__ __m256i
  __attribute__((__always_inline__, __nodebug__, DIAGNOSE_SLOW))
  _mm256_permute2x128_si256(__m256i __a, __m256i __b, const int imm8) {
  __m256i_internal ret;
  ret.v0 = __avx_select4i(__a, __b, imm8);
  ret.v1 = __avx_select4i(__a, __b, imm8 >> 4);
  return __m256i_from_internal(ret);
}

static __inline__ __m128i __attribute__((__always_inline__, __nodebug__))
_mm256_extracti128_si256(__m256i __a, const int imm8) {
  __m256i_internal a = __m256i_to_internal(__a);
  if (imm8 & 0x1) {
    return a.v1;
  } else {
    return a.v0;
  }
}

static __inline__ __m256i __attribute__((__always_inline__, __nodebug__))
_mm256_inserti128_si256(__m256i __a, __m128i __b, const int imm8) {
  __m256i_internal ret = __m256i_to_internal(__a);
  if (imm8 & 0x1) {
    ret.v1 = __b;
  } else {
    ret.v0 = __b;
  }
  return __m256i_from_internal(ret);
}

static __inline__ __m128i __attribute__((__always_inline__, __nodebug__))
_mm_maskload_epi32(int32_t const* __p, __m128i __m) {
  int32_t lane[4];
  for (size_t i = 0; i < 4; i++) {
    uint32_t mask = ((__i32x4)__m)[i];
    lane[i] = ((mask >> 31) & 0x1) ? __p[i] : 0;
  }
  return (__m128i)wasm_i32x4_make(lane[0], lane[1], lane[2], lane[3]);
}

static __inline__ __m128i __attribute__((__always_inline__, __nodebug__))
_mm_maskload_epi64(int64_t const* __p, __m128i __m) {
  int64_t lane[2];
  for (size_t i = 0; i < 2; i++) {
    uint64_t mask = ((__i64x2)__m)[i];
    lane[i] = ((mask >> 63) & 0x1) ? __p[i] : 0;
  }
  return (__m128i)wasm_i64x2_make(lane[0], lane[1]);
}

static __inline__ __m256i __attribute__((__always_inline__, __nodebug__))
_mm256_maskload_epi32(int const* __p, __m256i __m) {
  __m256i_internal ret, m;
  m = __m256i_to_internal(__m);
  ret.v0 = _mm_maskload_epi32(__p, m.v0);
  ret.v1 = _mm_maskload_epi32(((int32_t*)__p) + 4, m.v1);
  return __m256i_from_internal(ret);
}

static __inline__ __m256i __attribute__((__always_inline__, __nodebug__))
_mm256_maskload_epi64(long long const* __p, __m256i __m) {
  __m256i_internal ret, m;
  m = __m256i_to_internal(__m);
  ret.v0 = _mm_maskload_epi64(__p, m.v0);
  ret.v1 = _mm_maskload_epi64(((int64_t*)__p) + 2, m.v1);
  return __m256i_from_internal(ret);
}

static __inline__ void
  __attribute__((__always_inline__, __nodebug__, DIAGNOSE_SLOW))
  _mm_maskstore_epi32(int* __p, __m128i __m, __m128i __a) {
  if ((wasm_i32x4_extract_lane(__m, 0) & 0x80000000ull) != 0)
    __p[0] = wasm_i32x4_extract_lane((v128_t)__a, 0);
  if ((wasm_i32x4_extract_lane(__m, 1) & 0x80000000ull) != 0)
    __p[1] = wasm_i32x4_extract_lane((v128_t)__a, 1);
  if ((wasm_i32x4_extract_lane(__m, 2) & 0x80000000ull) != 0)
    __p[2] = wasm_i32x4_extract_lane((v128_t)__a, 2);
  if ((wasm_i32x4_extract_lane(__m, 3) & 0x80000000ull) != 0)
    __p[3] = wasm_i32x4_extract_lane((v128_t)__a, 3);
}

static __inline__ void
  __attribute__((__always_inline__, __nodebug__, DIAGNOSE_SLOW))
  _mm_maskstore_epi64(long long* __p, __m128i __m, __m128i __a) {
  if ((wasm_i64x2_extract_lane(__m, 0) & 0x8000000000000000ull) != 0)
    __p[0] = wasm_i64x2_extract_lane((v128_t)__a, 0);
  if ((wasm_i64x2_extract_lane(__m, 1) & 0x8000000000000000ull) != 0)
    __p[1] = wasm_i64x2_extract_lane((v128_t)__a, 1);
}

static __inline__ void __attribute__((__always_inline__, __nodebug__))
_mm256_maskstore_epi32(int* __p, __m256i __m, __m256i __a) {
  __m256i_internal m, a;
  m = __m256i_to_internal(__m);
  a = __m256i_to_internal(__a);
  _mm_maskstore_epi32(__p, m.v0, a.v0);
  _mm_maskstore_epi32(((int32_t*)__p) + 4, m.v1, a.v1);
}

static __inline__ void __attribute__((__always_inline__, __nodebug__))
_mm256_maskstore_epi64(long long* __p, __m256i __m, __m256i __a) {
  __m256i_internal m, a;
  m = __m256i_to_internal(__m);
  a = __m256i_to_internal(__a);
  _mm_maskstore_epi64(__p, m.v0, a.v0);
  _mm_maskstore_epi64(((int64_t*)__p) + 2, m.v1, a.v1);
}

static __inline__ __m128i
  __attribute__((__always_inline__, __nodebug__, DIAGNOSE_SLOW))
  _mm_sllv_epi32(__m128i __a, __m128i __count) {
  int32_t lane[4];
  for (size_t i = 0; i < 4; i++) {
    uint32_t shift = ((__u32x4)__count)[i];
    lane[i] = shift < 32 ? ((__u32x4)__a)[i] << shift : 0;
  }
  return (__m128i)wasm_i32x4_make(lane[0], lane[1], lane[2], lane[3]);
}

static __inline__ __m256i
  __attribute__((__always_inline__, __nodebug__, DIAGNOSE_SLOW))
  _mm256_sllv_epi32(__m256i __a, __m256i __count) {
  __m256i_internal ret, a, count;
  a = __m256i_to_internal(__a);
  count = __m256i_to_internal(__count);
  ret.v0 = _mm_sllv_epi32(a.v0, count.v0);
  ret.v1 = _mm_sllv_epi32(a.v1, count.v1);
  return __m256i_from_internal(ret);
}

static __inline__ __m128i
  __attribute__((__always_inline__, __nodebug__, DIAGNOSE_SLOW))
  _mm_sllv_epi64(__m128i __a, __m128i __count) {

  int64_t lane[2];
  for (size_t i = 0; i < 2; i++) {
    uint64_t shift = (uint64_t)((__u64x2)__count)[i];
    lane[i] = shift < 64 ? ((__u64x2)__a)[i] << shift : 0;
  }
  return (__m128i)wasm_i64x2_make(lane[0], lane[1]);
}

static __inline__ __m256i
  __attribute__((__always_inline__, __nodebug__, DIAGNOSE_SLOW))
  _mm256_sllv_epi64(__m256i __a, __m256i __count) {
  __m256i_internal ret, a, count;
  a = __m256i_to_internal(__a);
  count = __m256i_to_internal(__count);
  ret.v0 = _mm_sllv_epi64(a.v0, count.v0);
  ret.v1 = _mm_sllv_epi64(a.v1, count.v1);
  return __m256i_from_internal(ret);
}

static __inline__ __m128i
  __attribute__((__always_inline__, __nodebug__, DIAGNOSE_SLOW))
  _mm_srav_epi32(__m128i __a, __m128i __count) {
  int32_t lane[4];
  for (size_t i = 0; i < 4; i++) {
    uint32_t shift = ((__u32x4)__count)[i];
    shift = shift < 31 ? shift : 31;
    lane[i] = ((__i32x4)__a)[i] >> shift;
  }
  return (__m128i)wasm_i32x4_make(lane[0], lane[1], lane[2], lane[3]);
}

static __inline__ __m256i
  __attribute__((__always_inline__, __nodebug__, DIAGNOSE_SLOW))
  _mm256_srav_epi32(__m256i __a, __m256i __count) {
  __m256i_internal ret, a, count;
  a = __m256i_to_internal(__a);
  count = __m256i_to_internal(__count);
  ret.v0 = _mm_srav_epi32(a.v0, count.v0);
  ret.v1 = _mm_srav_epi32(a.v1, count.v1);
  return __m256i_from_internal(ret);
}

static __inline__ __m128i
  __attribute__((__always_inline__, __nodebug__, DIAGNOSE_SLOW))
  _mm_srlv_epi32(__m128i __a, __m128i __count) {
  int32_t lane[4];
  for (size_t i = 0; i < 4; i++) {
    uint32_t shift = ((__u32x4)__count)[i];
    lane[i] = shift < 32 ? ((__u32x4)__a)[i] >> shift : 0;
  }
  return (__m128i)wasm_i32x4_make(lane[0], lane[1], lane[2], lane[3]);
}

static __inline__ __m256i
  __attribute__((__always_inline__, __nodebug__, DIAGNOSE_SLOW))
  _mm256_srlv_epi32(__m256i __a, __m256i __count) {
  __m256i_internal ret, a, count;
  a = __m256i_to_internal(__a);
  count = __m256i_to_internal(__count);
  ret.v0 = _mm_srlv_epi32(a.v0, count.v0);
  ret.v1 = _mm_srlv_epi32(a.v1, count.v1);
  return __m256i_from_internal(ret);
}

static __inline__ __m128i
  __attribute__((__always_inline__, __nodebug__, DIAGNOSE_SLOW))
  _mm_srlv_epi64(__m128i __a, __m128i __count) {
  int64_t lane[2];
  for (size_t i = 0; i < 2; i++) {
    uint64_t shift = ((__u64x2)__count)[i];
    lane[i] = shift < 64 ? ((__u64x2)__a)[i] >> shift : 0;
  }
  return (__m128i)wasm_i64x2_make(lane[0], lane[1]);
}

static __inline__ __m256i
  __attribute__((__always_inline__, __nodebug__, DIAGNOSE_SLOW))
  _mm256_srlv_epi64(__m256i __a, __m256i __count) {
  __m256i_internal ret, a, count;
  a = __m256i_to_internal(__a);
  count = __m256i_to_internal(__count);
  ret.v0 = _mm_srlv_epi64(a.v0, count.v0);
  ret.v1 = _mm_srlv_epi64(a.v1, count.v1);
  return __m256i_from_internal(ret);
}

static __inline__ __m128d
  __attribute__((__always_inline__, __nodebug__, DIAGNOSE_SLOW))
  _mm_mask_i32gather_pd(__m128d src,
                        const double* base_addr,
                        __m128i vindex,
                        __m128d mask,
                        const int scale) {
  double lane[2];
  for (size_t i = 0; i < 2; i++) {
    if ((((__i64x2)mask)[i] >> 63) & 0x1) {
      double* addr =
        (double*)((uint8_t*)base_addr + (int64_t)(((__i32x4)vindex)[i]) *
                                          (uint64_t)((uint32_t)scale));
      lane[i] = *addr;
    } else {
      lane[i] = ((__f64x2)src)[i];
    }
  }
  return (__m128d)wasm_f64x2_make(lane[0], lane[1]);
}

static __inline__ __m256d
  __attribute__((__always_inline__, __nodebug__, DIAGNOSE_SLOW))
  _mm256_mask_i32gather_pd(__m256d __src,
                           const double* base_addr,
                           __m128i vindex,
                           __m256d __mask,
                           const int scale) {
  __m256d_internal ret, src, mask;
  src = __m256d_to_internal(__src);
  mask = __m256d_to_internal(__mask);
  ret.v0 = _mm_mask_i32gather_pd(src.v0, base_addr, vindex, mask.v0, scale);
  __m128i vindex1 = (__m128i)wasm_i32x4_shuffle(vindex, vindex, 2, 3, 0, 1);
  ret.v1 = _mm_mask_i32gather_pd(src.v1, base_addr, vindex1, mask.v1, scale);
  return __m256d_from_internal(ret);
}

static __inline__ __m128d
  __attribute__((__always_inline__, __nodebug__, DIAGNOSE_SLOW))
  _mm_mask_i64gather_pd(__m128d src,
                        const double* base_addr,
                        __m128i vindex,
                        __m128d mask,
                        const int scale) {
  double lane[2];
  for (size_t i = 0; i < 2; i++) {
    if ((((__i64x2)mask)[i] >> 63) & 0x1) {
      double* addr =
        (double*)((uint8_t*)base_addr +
                  ((__i64x2)vindex)[i] * (uint64_t)((uint32_t)scale));
      lane[i] = *addr;
    } else {
      lane[i] = ((__f64x2)src)[i];
    }
  }
  return (__m128d)wasm_f64x2_make(lane[0], lane[1]);
}

static __inline__ __m256d
  __attribute__((__always_inline__, __nodebug__, DIAGNOSE_SLOW))
  _mm256_mask_i64gather_pd(__m256d __src,
                           const double* base_addr,
                           __m256i __vindex,
                           __m256d __mask,
                           const int scale) {
  __m256d_internal ret, src, mask;
  __m256i_internal vindex = __m256i_to_internal(__vindex);
  src = __m256d_to_internal(__src);
  mask = __m256d_to_internal(__mask);
  ret.v0 = _mm_mask_i64gather_pd(src.v0, base_addr, vindex.v0, mask.v0, scale);
  ret.v1 = _mm_mask_i64gather_pd(src.v1, base_addr, vindex.v1, mask.v1, scale);
  return __m256d_from_internal(ret);
}

static __inline__ __m128
  __attribute__((__always_inline__, __nodebug__, DIAGNOSE_SLOW))
  _mm_mask_i32gather_ps(__m128 src,
                        const float* base_addr,
                        __m128i vindex,
                        __m128 mask,
                        const int scale) {
  float lane[4];
  for (size_t i = 0; i < 4; i++) {
    if ((((__i32x4)mask)[i] >> 31) & 0x1) {
      float* addr =
        (float*)((uint8_t*)base_addr +
                 (int64_t)(((__i32x4)vindex)[i]) * (uint64_t)((uint32_t)scale));
      lane[i] = *addr;
    } else {
      lane[i] = ((__f32x4)src)[i];
    }
  }
  return (__m128)wasm_f32x4_make(lane[0], lane[1], lane[2], lane[3]);
}

static __inline__ __m256
  __attribute__((__always_inline__, __nodebug__, DIAGNOSE_SLOW))
  _mm256_mask_i32gather_ps(__m256 __src,
                           const float* base_addr,
                           __m256i __vindex,
                           __m256 __mask,
                           const int scale) {
  __m256_internal ret, src, mask;
  __m256i_internal vindex = __m256i_to_internal(__vindex);
  src = __m256_to_internal(__src);
  mask = __m256_to_internal(__mask);
  ret.v0 = _mm_mask_i32gather_ps(src.v0, base_addr, vindex.v0, mask.v0, scale);
  ret.v1 = _mm_mask_i32gather_ps(src.v1, base_addr, vindex.v1, mask.v1, scale);
  return __m256_from_internal(ret);
}

static __inline__ __m128
  __attribute__((__always_inline__, __nodebug__, DIAGNOSE_SLOW))
  _mm_mask_i64gather_ps(__m128 src,
                        const float* base_addr,
                        __m128i vindex,
                        __m128 mask,
                        const int scale) {
  float lane[2];
  for (size_t i = 0; i < 2; i++) {
    if ((((__i32x4)mask)[i] >> 31) & 0x1) {
      float* addr =
        (float*)((uint8_t*)base_addr +
                 ((__i64x2)vindex)[i] * (uint64_t)((uint32_t)scale));
      lane[i] = *addr;
    } else {
      lane[i] = ((__f32x4)src)[i];
    }
  }
  return (__m128)wasm_f32x4_make(lane[0], lane[1], 0, 0);
}

static __inline__ __m128
  __attribute__((__always_inline__, __nodebug__, DIAGNOSE_SLOW))
  _mm256_mask_i64gather_ps(__m128 src,
                           const float* base_addr,
                           __m256i __vindex,
                           __m128 mask,
                           const int scale) {
  __m256i_internal vindex = __m256i_to_internal(__vindex);
  float lane[4];
  __m128i current_vindex;
  for (size_t i = 0; i < 4; i++) {
    current_vindex = i < 2 ? vindex.v0 : vindex.v1;
    if ((((__i32x4)mask)[i] >> 31) & 0x1) {
      float* addr =
        (float*)((uint8_t*)base_addr + ((__i64x2)current_vindex)[i & 1] *
                                         (uint64_t)((uint32_t)scale));
      lane[i] = *addr;
    } else {
      lane[i] = ((__f32x4)src)[i];
    }
  }
  return (__m128)wasm_f32x4_make(lane[0], lane[1], lane[2], lane[3]);
}

static __inline__ __m128i
  __attribute__((__always_inline__, __nodebug__, DIAGNOSE_SLOW))
  _mm_mask_i32gather_epi32(__m128i src,
                           const int* base_addr,
                           __m128i vindex,
                           __m128i mask,
                           const int scale) {
  int32_t lane[4];
  for (size_t i = 0; i < 4; i++) {
    if ((((__i32x4)mask)[i] >> 31) & 0x1) {
      int32_t* addr =
        (int32_t*)((uint8_t*)base_addr + (int64_t)(((__i32x4)vindex)[i]) *
                                           (uint64_t)((uint32_t)scale));
      lane[i] = *addr;
    } else {
      lane[i] = ((__i32x4)src)[i];
    }
  }
  return (__m128i)wasm_i32x4_make(lane[0], lane[1], lane[2], lane[3]);
}

static __inline__ __m256i
  __attribute__((__always_inline__, __nodebug__, DIAGNOSE_SLOW))
  _mm256_mask_i32gather_epi32(__m256i __src,
                              const int* base_addr,
                              __m256i __vindex,
                              __m256i __mask,
                              const int scale) {
  __m256i_internal ret, src, vindex, mask;
  src = __m256i_to_internal(__src);
  vindex = __m256i_to_internal(__vindex);
  mask = __m256i_to_internal(__mask);
  ret.v0 =
    _mm_mask_i32gather_epi32(src.v0, base_addr, vindex.v0, mask.v0, scale);
  ret.v1 =
    _mm_mask_i32gather_epi32(src.v1, base_addr, vindex.v1, mask.v1, scale);
  return __m256i_from_internal(ret);
}

static __inline__ __m128i
  __attribute__((__always_inline__, __nodebug__, DIAGNOSE_SLOW))
  _mm_mask_i64gather_epi32(__m128i src,
                           const int* base_addr,
                           __m128i vindex,
                           __m128i mask,
                           const int scale) {
  int32_t lane[2];
  for (size_t i = 0; i < 2; i++) {
    if ((((__i32x4)mask)[i] >> 31) & 0x1) {
      int32_t* addr =
        (int32_t*)((uint8_t*)base_addr +
                   ((__i64x2)vindex)[i] * (uint64_t)((uint32_t)scale));
      lane[i] = *addr;
    } else {
      lane[i] = ((__i32x4)src)[i];
    }
  }
  return (__m128i)wasm_i32x4_make(lane[0], lane[1], 0, 0);
}

static __inline__ __m128i
  __attribute__((__always_inline__, __nodebug__, DIAGNOSE_SLOW))
  _mm256_mask_i64gather_epi32(__m128i src,
                              const int* base_addr,
                              __m256i __vindex,
                              __m128i mask,
                              const int scale) {
  __m256i_internal vindex = __m256i_to_internal(__vindex);
  int32_t lane[4];
  __m128i current_vindex;
  for (size_t i = 0; i < 4; i++) {
    current_vindex = i < 2 ? vindex.v0 : vindex.v1;
    if ((((__i32x4)mask)[i] >> 31) & 0x1) {
      int32_t* addr =
        (int32_t*)((uint8_t*)base_addr + ((__i64x2)current_vindex)[i & 1] *
                                           (uint64_t)((uint32_t)scale));
      lane[i] = *addr;
    } else {
      lane[i] = ((__i32x4)src)[i];
    }
  }
  return (__m128i)wasm_i32x4_make(lane[0], lane[1], lane[2], lane[3]);
}

static __inline__ __m128i
  __attribute__((__always_inline__, __nodebug__, DIAGNOSE_SLOW))
  _mm_mask_i32gather_epi64(__m128i src,
                           const long long* base_addr,
                           __m128i vindex,
                           __m128i mask,
                           const int scale) {
  int64_t lane[2];
  for (size_t i = 0; i < 2; i++) {
    if ((((__i64x2)mask)[i] >> 63) & 0x1) {
      int64_t* addr =
        (int64_t*)((uint8_t*)base_addr + (int64_t)(((__i32x4)vindex)[i]) *
                                           (uint64_t)((uint32_t)scale));
      lane[i] = *addr;
    } else {
      lane[i] = ((__i64x2)src)[i];
    }
  }
  return (__m128i)wasm_i64x2_make(lane[0], lane[1]);
}

static __inline__ __m256i
  __attribute__((__always_inline__, __nodebug__, DIAGNOSE_SLOW))
  _mm256_mask_i32gather_epi64(__m256i __src,
                              const long long* base_addr,
                              __m128i vindex,
                              __m256i __mask,
                              const int scale) {
  __m256i_internal ret, src, mask;
  src = __m256i_to_internal(__src);
  mask = __m256i_to_internal(__mask);
  ret.v0 = _mm_mask_i32gather_epi64(src.v0, base_addr, vindex, mask.v0, scale);
  __m128i vindex1 = (__m128i)wasm_i32x4_shuffle(vindex, vindex, 2, 3, 0, 1);
  ret.v1 = _mm_mask_i32gather_epi64(src.v1, base_addr, vindex1, mask.v1, scale);
  return __m256i_from_internal(ret);
}

static __inline__ __m128i
  __attribute__((__always_inline__, __nodebug__, DIAGNOSE_SLOW))
  _mm_mask_i64gather_epi64(__m128i src,
                           const long long* base_addr,
                           __m128i vindex,
                           __m128i mask,
                           const int scale) {
  int64_t lane[2];
  for (size_t i = 0; i < 2; i++) {
    if ((((__i64x2)mask)[i] >> 63) & 0x1) {
      int64_t* addr =
        (int64_t*)((uint8_t*)base_addr +
                   ((__i64x2)vindex)[i] * (uint64_t)((uint32_t)scale));
      lane[i] = *addr;
    } else {
      lane[i] = ((__i64x2)src)[i];
    }
  }
  return (__m128i)wasm_i64x2_make(lane[0], lane[1]);
}

static __inline__ __m256i
  __attribute__((__always_inline__, __nodebug__, DIAGNOSE_SLOW))
  _mm256_mask_i64gather_epi64(__m256i __src,
                              const long long* base_addr,
                              __m256i __vindex,
                              __m256i __mask,
                              const int scale) {
  __m256i_internal ret, src, vindex, mask;
  src = __m256i_to_internal(__src);
  vindex = __m256i_to_internal(__vindex);
  mask = __m256i_to_internal(__mask);
  ret.v0 =
    _mm_mask_i64gather_epi64(src.v0, base_addr, vindex.v0, mask.v0, scale);
  ret.v1 =
    _mm_mask_i64gather_epi64(src.v1, base_addr, vindex.v1, mask.v1, scale);
  return __m256i_from_internal(ret);
}

static __inline__ __m128d
  __attribute__((__always_inline__, __nodebug__, DIAGNOSE_SLOW))
  _mm_i32gather_pd(const double* base_addr, __m128i vindex, const int scale) {
  double* lane[2];
  for (size_t i = 0; i < 2; i++) {
    lane[i] = (double*)((uint8_t*)base_addr + (int64_t)(((__i32x4)vindex)[i]) *
                                                (uint64_t)((uint32_t)scale));
  }
  return (__m128d)wasm_f64x2_make(*lane[0], *lane[1]);
}

static __inline__ __m256d
  __attribute__((__always_inline__, __nodebug__, DIAGNOSE_SLOW))
  _mm256_i32gather_pd(const double* base_addr,
                      __m128i vindex,
                      const int scale) {
  __m256d_internal ret;
  double* lane[4];
  for (size_t i = 0; i < 4; i++) {
    lane[i] = (double*)((uint8_t*)base_addr + (int64_t)(((__i32x4)vindex)[i]) *
                                                (uint64_t)((uint32_t)scale));
  }
  ret.v0 = (__m128d)wasm_f64x2_make(*lane[0], *lane[1]);
  ret.v1 = (__m128d)wasm_f64x2_make(*lane[2], *lane[3]);
  return __m256d_from_internal(ret);
}

static __inline__ __m128d
  __attribute__((__always_inline__, __nodebug__, DIAGNOSE_SLOW))
  _mm_i64gather_pd(const double* base_addr, __m128i vindex, const int scale) {
  double* lane[2];
  for (size_t i = 0; i < 2; i++) {
    lane[i] = (double*)((uint8_t*)base_addr +
                        ((__i64x2)vindex)[i] * (uint64_t)((uint32_t)scale));
  }
  return (__m128d)wasm_f64x2_make(*lane[0], *lane[1]);
}

static __inline__ __m256d
  __attribute__((__always_inline__, __nodebug__, DIAGNOSE_SLOW))
  _mm256_i64gather_pd(const double* base_addr,
                      __m256i __vindex,
                      const int scale) {
  __m256d_internal ret;
  __m256i_internal vindex = __m256i_to_internal(__vindex);
  ret.v0 = _mm_i64gather_pd(base_addr, vindex.v0, scale);
  ret.v1 = _mm_i64gather_pd(base_addr, vindex.v1, scale);
  return __m256d_from_internal(ret);
}

static __inline__ __m128
  __attribute__((__always_inline__, __nodebug__, DIAGNOSE_SLOW))
  _mm_i32gather_ps(const float* base_addr, __m128i vindex, const int scale) {
  float* lane[4];
  for (size_t i = 0; i < 4; i++) {
    lane[i] = (float*)((uint8_t*)base_addr + (int64_t)(((__i32x4)vindex)[i]) *
                                               (uint64_t)((uint32_t)scale));
  }
  return (__m128)wasm_f32x4_make(*lane[0], *lane[1], *lane[2], *lane[3]);
}

static __inline__ __m256
  __attribute__((__always_inline__, __nodebug__, DIAGNOSE_SLOW))
  _mm256_i32gather_ps(const float* base_addr, __m256i __vindex, const int scale) {
  __m256_internal ret;
  __m256i_internal vindex = __m256i_to_internal(__vindex);
  ret.v0 = _mm_i32gather_ps(base_addr, vindex.v0, scale);
  ret.v1 = _mm_i32gather_ps(base_addr, vindex.v1, scale);
  return __m256_from_internal(ret);
}

static __inline__ __m128
  __attribute__((__always_inline__, __nodebug__, DIAGNOSE_SLOW))
  _mm_i64gather_ps(const float* base_addr, __m128i vindex, const int scale) {
  float* lane[2];
  for (size_t i = 0; i < 2; i++) {
    lane[i] = (float*)((uint8_t*)base_addr +
                       ((__i64x2)vindex)[i] * (uint64_t)((uint32_t)scale));
  }
  return (__m128)wasm_f32x4_make(*lane[0], *lane[1], 0, 0);
}

static __inline__ __m128
  __attribute__((__always_inline__, __nodebug__, DIAGNOSE_SLOW))
  _mm256_i64gather_ps(const float* base_addr, __m256i __vindex, const int scale) {
  __m256i_internal vindex = __m256i_to_internal(__vindex);
  float* lane[4];
  __m128i current_vindex;
  for (size_t i = 0; i < 4; i++) {
    current_vindex = i < 2 ? vindex.v0 : vindex.v1;
    lane[i] = (float*)((uint8_t*)base_addr + ((__i64x2)current_vindex)[i & 1] *
                                               (uint64_t)((uint32_t)scale));
  }
  return (__m128)wasm_f32x4_make(*lane[0], *lane[1], *lane[2], *lane[3]);
}

static __inline__ __m128i
  __attribute__((__always_inline__, __nodebug__, DIAGNOSE_SLOW))
  _mm_i32gather_epi32(const int* base_addr, __m128i vindex, const int scale) {
  int32_t* lane[4];
  for (size_t i = 0; i < 4; i++) {
    lane[i] = (int32_t*)((uint8_t*)base_addr + (int64_t)(((__i32x4)vindex)[i]) *
                                                 (uint64_t)((uint32_t)scale));
  }
  return (__m128i)wasm_i32x4_make(*lane[0], *lane[1], *lane[2], *lane[3]);
}

static __inline__ __m256i
  __attribute__((__always_inline__, __nodebug__, DIAGNOSE_SLOW))
  _mm256_i32gather_epi32(const int* base_addr,
                         __m256i __vindex,
                         const int scale) {
  __m256i_internal ret;
  __m256i_internal vindex = __m256i_to_internal(__vindex);
  ret.v0 = _mm_i32gather_epi32(base_addr, vindex.v0, scale);
  ret.v1 = _mm_i32gather_epi32(base_addr, vindex.v1, scale);
  return __m256i_from_internal(ret);
}

static __inline__ __m128i
  __attribute__((__always_inline__, __nodebug__, DIAGNOSE_SLOW))
  _mm_i64gather_epi32(const int* base_addr, __m128i vindex, const int scale) {
  int32_t* lane[2];
  for (size_t i = 0; i < 2; i++) {
    lane[i] = (int32_t*)((uint8_t*)base_addr +
                         ((__i64x2)vindex)[i] * (uint64_t)((uint32_t)scale));
  }
  return (__m128i)wasm_i32x4_make(*lane[0], *lane[1], 0, 0);
}

static __inline__ __m128i
  __attribute__((__always_inline__, __nodebug__, DIAGNOSE_SLOW))
  _mm256_i64gather_epi32(const int* base_addr,
                         __m256i __vindex,
                         const int scale) {
  __m256i_internal vindex = __m256i_to_internal(__vindex);
  int32_t* lane[4];
  __m128i current_vindex;
  for (size_t i = 0; i < 4; i++) {
    current_vindex = i < 2 ? vindex.v0 : vindex.v1;
    lane[i] =
      (int32_t*)((uint8_t*)base_addr + ((__i64x2)current_vindex)[i & 1] *
                                         (uint64_t)((uint32_t)scale));
  }
  return (__m128i)wasm_i32x4_make(*lane[0], *lane[1], *lane[2], *lane[3]);
}

static __inline__ __m128i
  __attribute__((__always_inline__, __nodebug__, DIAGNOSE_SLOW))
  _mm_i32gather_epi64(const long long* base_addr,
                      __m128i vindex,
                      const int scale) {
  int64_t* lane[2];
  for (size_t i = 0; i < 2; i++) {
    lane[i] = (int64_t*)((uint8_t*)base_addr + (int64_t)(((__i32x4)vindex)[i]) *
                                                 (uint64_t)((uint32_t)scale));
  }
  return (__m128i)wasm_i64x2_make(*lane[0], *lane[1]);
}

static __inline__ __m256i
  __attribute__((__always_inline__, __nodebug__, DIAGNOSE_SLOW))
  _mm256_i32gather_epi64(const long long* base_addr,
                         __m128i vindex,
                         const int scale) {

  __m256i_internal ret;
  int64_t* lane[4];
  for (size_t i = 0; i < 4; i++) {
    lane[i] = (int64_t*)((uint8_t*)base_addr + (int64_t)(((__i32x4)vindex)[i]) *
                                                 (uint64_t)((uint32_t)scale));
  }
  ret.v0 = (__m128i)wasm_i64x2_make(*lane[0], *lane[1]);
  ret.v1 = (__m128i)wasm_i64x2_make(*lane[2], *lane[3]);
  return __m256i_from_internal(ret);
}

static __inline__ __m128i
  __attribute__((__always_inline__, __nodebug__, DIAGNOSE_SLOW))
  _mm_i64gather_epi64(const long long* base_addr,
                      __m128i vindex,
                      const int scale) {
  int64_t* lane[2];
  for (size_t i = 0; i < 2; i++) {
    lane[i] = (int64_t*)((uint8_t*)base_addr +
                         ((__i64x2)vindex)[i] * (uint64_t)((uint32_t)scale));
  }
  return (__m128i)wasm_i64x2_make(*lane[0], *lane[1]);
}

static __inline__ __m256i
  __attribute__((__always_inline__, __nodebug__, DIAGNOSE_SLOW))
  _mm256_i64gather_epi64(const long long* base_addr,
                         __m256i __vindex,
                         const int scale) {
  __m256i_internal ret, vindex;
  vindex = __m256i_to_internal(__vindex);
  ret.v0 = _mm_i64gather_epi64(base_addr, vindex.v0, scale);
  ret.v1 = _mm_i64gather_epi64(base_addr, vindex.v1, scale);
  return __m256i_from_internal(ret);
}

#endif /* __emscripten_avx2intrin_h__ */
`,"wasm_simd128.h":`/*===---- wasm_simd128.h - WebAssembly portable SIMD intrinsics ------------===
 *
 * Part of the LLVM Project, under the Apache License v2.0 with LLVM Exceptions.
 * See https://llvm.org/LICENSE.txt for license information.
 * SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception
 *
 *===-----------------------------------------------------------------------===
 */

#ifndef __WASM_SIMD128_H
#define __WASM_SIMD128_H

#include <stdbool.h>
#include <stdint.h>

// User-facing type
typedef int32_t v128_t __attribute__((__vector_size__(16), __aligned__(16)));

// Internal types determined by clang builtin definitions
typedef int32_t __v128_u __attribute__((__vector_size__(16), __aligned__(1)));
typedef signed char __i8x16
    __attribute__((__vector_size__(16), __aligned__(16)));
typedef unsigned char __u8x16
    __attribute__((__vector_size__(16), __aligned__(16)));
typedef short __i16x8 __attribute__((__vector_size__(16), __aligned__(16)));
typedef unsigned short __u16x8
    __attribute__((__vector_size__(16), __aligned__(16)));
typedef int __i32x4 __attribute__((__vector_size__(16), __aligned__(16)));
typedef unsigned int __u32x4
    __attribute__((__vector_size__(16), __aligned__(16)));
typedef long long __i64x2 __attribute__((__vector_size__(16), __aligned__(16)));
typedef unsigned long long __u64x2
    __attribute__((__vector_size__(16), __aligned__(16)));
typedef float __f32x4 __attribute__((__vector_size__(16), __aligned__(16)));
typedef double __f64x2 __attribute__((__vector_size__(16), __aligned__(16)));
typedef __fp16 __f16x8 __attribute__((__vector_size__(16), __aligned__(16)));

typedef signed char __i8x8 __attribute__((__vector_size__(8), __aligned__(8)));
typedef unsigned char __u8x8
    __attribute__((__vector_size__(8), __aligned__(8)));
typedef short __i16x4 __attribute__((__vector_size__(8), __aligned__(8)));
typedef unsigned short __u16x4
    __attribute__((__vector_size__(8), __aligned__(8)));
typedef int __i32x2 __attribute__((__vector_size__(8), __aligned__(8)));
typedef unsigned int __u32x2
    __attribute__((__vector_size__(8), __aligned__(8)));
typedef float __f32x2 __attribute__((__vector_size__(8), __aligned__(8)));

#define __DEFAULT_FN_ATTRS                                                     \\
  __attribute__((__always_inline__, __nodebug__, __target__("simd128"),        \\
                 __min_vector_width__(128)))

#define __REQUIRE_CONSTANT(c)                                                  \\
  __attribute__((__diagnose_if__(!__builtin_constant_p(c),                     \\
                                 #c " must be constant", "error")))

static __inline__ v128_t __DEFAULT_FN_ATTRS wasm_v128_load(const void *__mem) {
  // UB-free unaligned access copied from xmmintrin.h
  struct __wasm_v128_load_struct {
    __v128_u __v;
  } __attribute__((__packed__, __may_alias__));
  return ((const struct __wasm_v128_load_struct *)__mem)->__v;
}

static __inline__ v128_t __DEFAULT_FN_ATTRS
wasm_v128_load8_splat(const void *__mem) {
  struct __wasm_v128_load8_splat_struct {
    uint8_t __v;
  } __attribute__((__packed__, __may_alias__));
  uint8_t __v = ((const struct __wasm_v128_load8_splat_struct *)__mem)->__v;
  return (v128_t)(__u8x16){__v, __v, __v, __v, __v, __v, __v, __v,
                           __v, __v, __v, __v, __v, __v, __v, __v};
}

static __inline__ v128_t __DEFAULT_FN_ATTRS
wasm_v128_load16_splat(const void *__mem) {
  struct __wasm_v128_load16_splat_struct {
    uint16_t __v;
  } __attribute__((__packed__, __may_alias__));
  uint16_t __v = ((const struct __wasm_v128_load16_splat_struct *)__mem)->__v;
  return (v128_t)(__u16x8){__v, __v, __v, __v, __v, __v, __v, __v};
}

static __inline__ v128_t __DEFAULT_FN_ATTRS
wasm_v128_load32_splat(const void *__mem) {
  struct __wasm_v128_load32_splat_struct {
    uint32_t __v;
  } __attribute__((__packed__, __may_alias__));
  uint32_t __v = ((const struct __wasm_v128_load32_splat_struct *)__mem)->__v;
  return (v128_t)(__u32x4){__v, __v, __v, __v};
}

static __inline__ v128_t __DEFAULT_FN_ATTRS
wasm_v128_load64_splat(const void *__mem) {
  struct __wasm_v128_load64_splat_struct {
    uint64_t __v;
  } __attribute__((__packed__, __may_alias__));
  uint64_t __v = ((const struct __wasm_v128_load64_splat_struct *)__mem)->__v;
  return (v128_t)(__u64x2){__v, __v};
}

static __inline__ v128_t __DEFAULT_FN_ATTRS
wasm_i16x8_load8x8(const void *__mem) {
  struct __wasm_i16x8_load8x8_struct {
    __i8x8 __v;
  } __attribute__((__packed__, __may_alias__));
  __i8x8 __v = ((const struct __wasm_i16x8_load8x8_struct *)__mem)->__v;
  return (v128_t) __builtin_convertvector(__v, __i16x8);
}

static __inline__ v128_t __DEFAULT_FN_ATTRS
wasm_u16x8_load8x8(const void *__mem) {
  struct __wasm_u16x8_load8x8_struct {
    __u8x8 __v;
  } __attribute__((__packed__, __may_alias__));
  __u8x8 __v = ((const struct __wasm_u16x8_load8x8_struct *)__mem)->__v;
  return (v128_t) __builtin_convertvector(__v, __u16x8);
}

static __inline__ v128_t __DEFAULT_FN_ATTRS
wasm_i32x4_load16x4(const void *__mem) {
  struct __wasm_i32x4_load16x4_struct {
    __i16x4 __v;
  } __attribute__((__packed__, __may_alias__));
  __i16x4 __v = ((const struct __wasm_i32x4_load16x4_struct *)__mem)->__v;
  return (v128_t) __builtin_convertvector(__v, __i32x4);
}

static __inline__ v128_t __DEFAULT_FN_ATTRS
wasm_u32x4_load16x4(const void *__mem) {
  struct __wasm_u32x4_load16x4_struct {
    __u16x4 __v;
  } __attribute__((__packed__, __may_alias__));
  __u16x4 __v = ((const struct __wasm_u32x4_load16x4_struct *)__mem)->__v;
  return (v128_t) __builtin_convertvector(__v, __u32x4);
}

static __inline__ v128_t __DEFAULT_FN_ATTRS
wasm_i64x2_load32x2(const void *__mem) {
  struct __wasm_i64x2_load32x2_struct {
    __i32x2 __v;
  } __attribute__((__packed__, __may_alias__));
  __i32x2 __v = ((const struct __wasm_i64x2_load32x2_struct *)__mem)->__v;
  return (v128_t) __builtin_convertvector(__v, __i64x2);
}

static __inline__ v128_t __DEFAULT_FN_ATTRS
wasm_u64x2_load32x2(const void *__mem) {
  struct __wasm_u64x2_load32x2_struct {
    __u32x2 __v;
  } __attribute__((__packed__, __may_alias__));
  __u32x2 __v = ((const struct __wasm_u64x2_load32x2_struct *)__mem)->__v;
  return (v128_t) __builtin_convertvector(__v, __u64x2);
}

static __inline__ v128_t __DEFAULT_FN_ATTRS
wasm_v128_load32_zero(const void *__mem) {
  struct __wasm_v128_load32_zero_struct {
    int32_t __v;
  } __attribute__((__packed__, __may_alias__));
  int32_t __v = ((const struct __wasm_v128_load32_zero_struct *)__mem)->__v;
  return (v128_t)(__i32x4){__v, 0, 0, 0};
}

static __inline__ v128_t __DEFAULT_FN_ATTRS
wasm_v128_load64_zero(const void *__mem) {
  struct __wasm_v128_load64_zero_struct {
    int64_t __v;
  } __attribute__((__packed__, __may_alias__));
  int64_t __v = ((const struct __wasm_v128_load64_zero_struct *)__mem)->__v;
  return (v128_t)(__i64x2){__v, 0};
}

static __inline__ v128_t __DEFAULT_FN_ATTRS wasm_v128_load8_lane(
    const void *__mem, v128_t __vec, int __i) __REQUIRE_CONSTANT(__i) {
  struct __wasm_v128_load8_lane_struct {
    int8_t __v;
  } __attribute__((__packed__, __may_alias__));
  int8_t __v = ((const struct __wasm_v128_load8_lane_struct *)__mem)->__v;
  __i8x16 __ret = (__i8x16)__vec;
  __ret[__i] = __v;
  return (v128_t)__ret;
}

static __inline__ v128_t __DEFAULT_FN_ATTRS wasm_v128_load16_lane(
    const void *__mem, v128_t __vec, int __i) __REQUIRE_CONSTANT(__i) {
  struct __wasm_v128_load16_lane_struct {
    int16_t __v;
  } __attribute__((__packed__, __may_alias__));
  int16_t __v = ((const struct __wasm_v128_load16_lane_struct *)__mem)->__v;
  __i16x8 __ret = (__i16x8)__vec;
  __ret[__i] = __v;
  return (v128_t)__ret;
}

static __inline__ v128_t __DEFAULT_FN_ATTRS wasm_v128_load32_lane(
    const void *__mem, v128_t __vec, int __i) __REQUIRE_CONSTANT(__i) {
  struct __wasm_v128_load32_lane_struct {
    int32_t __v;
  } __attribute__((__packed__, __may_alias__));
  int32_t __v = ((const struct __wasm_v128_load32_lane_struct *)__mem)->__v;
  __i32x4 __ret = (__i32x4)__vec;
  __ret[__i] = __v;
  return (v128_t)__ret;
}

static __inline__ v128_t __DEFAULT_FN_ATTRS wasm_v128_load64_lane(
    const void *__mem, v128_t __vec, int __i) __REQUIRE_CONSTANT(__i) {
  struct __wasm_v128_load64_lane_struct {
    int64_t __v;
  } __attribute__((__packed__, __may_alias__));
  int64_t __v = ((const struct __wasm_v128_load64_lane_struct *)__mem)->__v;
  __i64x2 __ret = (__i64x2)__vec;
  __ret[__i] = __v;
  return (v128_t)__ret;
}

static __inline__ void __DEFAULT_FN_ATTRS wasm_v128_store(void *__mem,
                                                          v128_t __a) {
  // UB-free unaligned access copied from xmmintrin.h
  struct __wasm_v128_store_struct {
    __v128_u __v;
  } __attribute__((__packed__, __may_alias__));
  ((struct __wasm_v128_store_struct *)__mem)->__v = __a;
}

static __inline__ void __DEFAULT_FN_ATTRS wasm_v128_store8_lane(void *__mem,
                                                                v128_t __vec,
                                                                int __i)
    __REQUIRE_CONSTANT(__i) {
  struct __wasm_v128_store8_lane_struct {
    int8_t __v;
  } __attribute__((__packed__, __may_alias__));
  ((struct __wasm_v128_store8_lane_struct *)__mem)->__v = ((__i8x16)__vec)[__i];
}

static __inline__ void __DEFAULT_FN_ATTRS wasm_v128_store16_lane(void *__mem,
                                                                 v128_t __vec,
                                                                 int __i)
    __REQUIRE_CONSTANT(__i) {
  struct __wasm_v128_store16_lane_struct {
    int16_t __v;
  } __attribute__((__packed__, __may_alias__));
  ((struct __wasm_v128_store16_lane_struct *)__mem)->__v =
      ((__i16x8)__vec)[__i];
}

static __inline__ void __DEFAULT_FN_ATTRS wasm_v128_store32_lane(void *__mem,
                                                                 v128_t __vec,
                                                                 int __i)
    __REQUIRE_CONSTANT(__i) {
  struct __wasm_v128_store32_lane_struct {
    int32_t __v;
  } __attribute__((__packed__, __may_alias__));
  ((struct __wasm_v128_store32_lane_struct *)__mem)->__v =
      ((__i32x4)__vec)[__i];
}

static __inline__ void __DEFAULT_FN_ATTRS wasm_v128_store64_lane(void *__mem,
                                                                 v128_t __vec,
                                                                 int __i)
    __REQUIRE_CONSTANT(__i) {
  struct __wasm_v128_store64_lane_struct {
    int64_t __v;
  } __attribute__((__packed__, __may_alias__));
  ((struct __wasm_v128_store64_lane_struct *)__mem)->__v =
      ((__i64x2)__vec)[__i];
}

static __inline__ v128_t __DEFAULT_FN_ATTRS
wasm_i8x16_make(int8_t __c0, int8_t __c1, int8_t __c2, int8_t __c3, int8_t __c4,
                int8_t __c5, int8_t __c6, int8_t __c7, int8_t __c8, int8_t __c9,
                int8_t __c10, int8_t __c11, int8_t __c12, int8_t __c13,
                int8_t __c14, int8_t __c15) {
  return (v128_t)(__i8x16){__c0,  __c1,  __c2,  __c3, __c4,  __c5,
                           __c6,  __c7,  __c8,  __c9, __c10, __c11,
                           __c12, __c13, __c14, __c15};
}

static __inline__ v128_t __DEFAULT_FN_ATTRS
wasm_u8x16_make(uint8_t __c0, uint8_t __c1, uint8_t __c2, uint8_t __c3,
                uint8_t __c4, uint8_t __c5, uint8_t __c6, uint8_t __c7,
                uint8_t __c8, uint8_t __c9, uint8_t __c10, uint8_t __c11,
                uint8_t __c12, uint8_t __c13, uint8_t __c14, uint8_t __c15) {
  return (v128_t)(__u8x16){__c0,  __c1,  __c2,  __c3, __c4,  __c5,
                           __c6,  __c7,  __c8,  __c9, __c10, __c11,
                           __c12, __c13, __c14, __c15};
}

static __inline__ v128_t __DEFAULT_FN_ATTRS
wasm_i16x8_make(int16_t __c0, int16_t __c1, int16_t __c2, int16_t __c3,
                int16_t __c4, int16_t __c5, int16_t __c6, int16_t __c7) {
  return (v128_t)(__i16x8){__c0, __c1, __c2, __c3, __c4, __c5, __c6, __c7};
}

static __inline__ v128_t __DEFAULT_FN_ATTRS
wasm_u16x8_make(uint16_t __c0, uint16_t __c1, uint16_t __c2, uint16_t __c3,
                uint16_t __c4, uint16_t __c5, uint16_t __c6, uint16_t __c7) {
  return (v128_t)(__u16x8){__c0, __c1, __c2, __c3, __c4, __c5, __c6, __c7};
}

static __inline__ v128_t __DEFAULT_FN_ATTRS wasm_i32x4_make(int32_t __c0,
                                                            int32_t __c1,
                                                            int32_t __c2,
                                                            int32_t __c3) {
  return (v128_t)(__i32x4){__c0, __c1, __c2, __c3};
}

static __inline__ v128_t __DEFAULT_FN_ATTRS wasm_u32x4_make(uint32_t __c0,
                                                            uint32_t __c1,
                                                            uint32_t __c2,
                                                            uint32_t __c3) {
  return (v128_t)(__u32x4){__c0, __c1, __c2, __c3};
}

static __inline__ v128_t __DEFAULT_FN_ATTRS wasm_i64x2_make(int64_t __c0,
                                                            int64_t __c1) {
  return (v128_t)(__i64x2){__c0, __c1};
}

static __inline__ v128_t __DEFAULT_FN_ATTRS wasm_u64x2_make(uint64_t __c0,
                                                            uint64_t __c1) {
  return (v128_t)(__u64x2){__c0, __c1};
}

static __inline__ v128_t __DEFAULT_FN_ATTRS wasm_f32x4_make(float __c0,
                                                            float __c1,
                                                            float __c2,
                                                            float __c3) {
  return (v128_t)(__f32x4){__c0, __c1, __c2, __c3};
}

static __inline__ v128_t __DEFAULT_FN_ATTRS wasm_f64x2_make(double __c0,
                                                            double __c1) {
  return (v128_t)(__f64x2){__c0, __c1};
}

static __inline__ v128_t __DEFAULT_FN_ATTRS
wasm_i8x16_const(int8_t __c0, int8_t __c1, int8_t __c2, int8_t __c3,
                 int8_t __c4, int8_t __c5, int8_t __c6, int8_t __c7,
                 int8_t __c8, int8_t __c9, int8_t __c10, int8_t __c11,
                 int8_t __c12, int8_t __c13, int8_t __c14, int8_t __c15)
    __REQUIRE_CONSTANT(__c0) __REQUIRE_CONSTANT(__c1) __REQUIRE_CONSTANT(__c2)
        __REQUIRE_CONSTANT(__c3) __REQUIRE_CONSTANT(__c4)
            __REQUIRE_CONSTANT(__c5) __REQUIRE_CONSTANT(__c6)
                __REQUIRE_CONSTANT(__c7) __REQUIRE_CONSTANT(__c8)
                    __REQUIRE_CONSTANT(__c9) __REQUIRE_CONSTANT(__c10)
                        __REQUIRE_CONSTANT(__c11) __REQUIRE_CONSTANT(__c12)
                            __REQUIRE_CONSTANT(__c13) __REQUIRE_CONSTANT(__c14)
                                __REQUIRE_CONSTANT(__c15) {
  return (v128_t)(__i8x16){__c0,  __c1,  __c2,  __c3, __c4,  __c5,
                           __c6,  __c7,  __c8,  __c9, __c10, __c11,
                           __c12, __c13, __c14, __c15};
}

static __inline__ v128_t __DEFAULT_FN_ATTRS
wasm_u8x16_const(uint8_t __c0, uint8_t __c1, uint8_t __c2, uint8_t __c3,
                 uint8_t __c4, uint8_t __c5, uint8_t __c6, uint8_t __c7,
                 uint8_t __c8, uint8_t __c9, uint8_t __c10, uint8_t __c11,
                 uint8_t __c12, uint8_t __c13, uint8_t __c14, uint8_t __c15)
    __REQUIRE_CONSTANT(__c0) __REQUIRE_CONSTANT(__c1) __REQUIRE_CONSTANT(__c2)
        __REQUIRE_CONSTANT(__c3) __REQUIRE_CONSTANT(__c4)
            __REQUIRE_CONSTANT(__c5) __REQUIRE_CONSTANT(__c6)
                __REQUIRE_CONSTANT(__c7) __REQUIRE_CONSTANT(__c8)
                    __REQUIRE_CONSTANT(__c9) __REQUIRE_CONSTANT(__c10)
                        __REQUIRE_CONSTANT(__c11) __REQUIRE_CONSTANT(__c12)
                            __REQUIRE_CONSTANT(__c13) __REQUIRE_CONSTANT(__c14)
                                __REQUIRE_CONSTANT(__c15) {
  return (v128_t)(__u8x16){__c0,  __c1,  __c2,  __c3, __c4,  __c5,
                           __c6,  __c7,  __c8,  __c9, __c10, __c11,
                           __c12, __c13, __c14, __c15};
}

static __inline__ v128_t __DEFAULT_FN_ATTRS
wasm_i16x8_const(int16_t __c0, int16_t __c1, int16_t __c2, int16_t __c3,
                 int16_t __c4, int16_t __c5, int16_t __c6, int16_t __c7)
    __REQUIRE_CONSTANT(__c0) __REQUIRE_CONSTANT(__c1) __REQUIRE_CONSTANT(__c2)
        __REQUIRE_CONSTANT(__c3) __REQUIRE_CONSTANT(__c4)
            __REQUIRE_CONSTANT(__c5) __REQUIRE_CONSTANT(__c6)
                __REQUIRE_CONSTANT(__c7) {
  return (v128_t)(__i16x8){__c0, __c1, __c2, __c3, __c4, __c5, __c6, __c7};
}

static __inline__ v128_t __DEFAULT_FN_ATTRS
wasm_u16x8_const(uint16_t __c0, uint16_t __c1, uint16_t __c2, uint16_t __c3,
                 uint16_t __c4, uint16_t __c5, uint16_t __c6, uint16_t __c7)
    __REQUIRE_CONSTANT(__c0) __REQUIRE_CONSTANT(__c1) __REQUIRE_CONSTANT(__c2)
        __REQUIRE_CONSTANT(__c3) __REQUIRE_CONSTANT(__c4)
            __REQUIRE_CONSTANT(__c5) __REQUIRE_CONSTANT(__c6)
                __REQUIRE_CONSTANT(__c7) {
  return (v128_t)(__u16x8){__c0, __c1, __c2, __c3, __c4, __c5, __c6, __c7};
}

static __inline__ v128_t __DEFAULT_FN_ATTRS
wasm_i32x4_const(int32_t __c0, int32_t __c1, int32_t __c2, int32_t __c3)
    __REQUIRE_CONSTANT(__c0) __REQUIRE_CONSTANT(__c1) __REQUIRE_CONSTANT(__c2)
        __REQUIRE_CONSTANT(__c3) {
  return (v128_t)(__i32x4){__c0, __c1, __c2, __c3};
}

static __inline__ v128_t __DEFAULT_FN_ATTRS
wasm_u32x4_const(uint32_t __c0, uint32_t __c1, uint32_t __c2, uint32_t __c3)
    __REQUIRE_CONSTANT(__c0) __REQUIRE_CONSTANT(__c1) __REQUIRE_CONSTANT(__c2)
        __REQUIRE_CONSTANT(__c3) {
  return (v128_t)(__u32x4){__c0, __c1, __c2, __c3};
}

static __inline__ v128_t __DEFAULT_FN_ATTRS wasm_i64x2_const(int64_t __c0,
                                                             int64_t __c1)
    __REQUIRE_CONSTANT(__c0) __REQUIRE_CONSTANT(__c1) {
  return (v128_t)(__i64x2){__c0, __c1};
}

static __inline__ v128_t __DEFAULT_FN_ATTRS wasm_u64x2_const(uint64_t __c0,
                                                             uint64_t __c1)
    __REQUIRE_CONSTANT(__c0) __REQUIRE_CONSTANT(__c1) {
  return (v128_t)(__u64x2){__c0, __c1};
}

static __inline__ v128_t __DEFAULT_FN_ATTRS
wasm_f32x4_const(float __c0, float __c1, float __c2, float __c3)
    __REQUIRE_CONSTANT(__c0) __REQUIRE_CONSTANT(__c1) __REQUIRE_CONSTANT(__c2)
        __REQUIRE_CONSTANT(__c3) {
  return (v128_t)(__f32x4){__c0, __c1, __c2, __c3};
}

static __inline__ v128_t __DEFAULT_FN_ATTRS wasm_f64x2_const(double __c0,
                                                             double __c1)
    __REQUIRE_CONSTANT(__c0) __REQUIRE_CONSTANT(__c1) {
  return (v128_t)(__f64x2){__c0, __c1};
}

static __inline__ v128_t __DEFAULT_FN_ATTRS wasm_i8x16_const_splat(int8_t __c)
    __REQUIRE_CONSTANT(__c) {
  return (v128_t)(__i8x16){__c, __c, __c, __c, __c, __c, __c, __c,
                           __c, __c, __c, __c, __c, __c, __c, __c};
}

static __inline__ v128_t __DEFAULT_FN_ATTRS wasm_u8x16_const_splat(uint8_t __c)
    __REQUIRE_CONSTANT(__c) {
  return (v128_t)(__u8x16){__c, __c, __c, __c, __c, __c, __c, __c,
                           __c, __c, __c, __c, __c, __c, __c, __c};
}

static __inline__ v128_t __DEFAULT_FN_ATTRS wasm_i16x8_const_splat(int16_t __c)
    __REQUIRE_CONSTANT(__c) {
  return (v128_t)(__i16x8){__c, __c, __c, __c, __c, __c, __c, __c};
}

static __inline__ v128_t __DEFAULT_FN_ATTRS wasm_u16x8_const_splat(uint16_t __c)
    __REQUIRE_CONSTANT(__c) {
  return (v128_t)(__u16x8){__c, __c, __c, __c, __c, __c, __c, __c};
}

static __inline__ v128_t __DEFAULT_FN_ATTRS wasm_i32x4_const_splat(int32_t __c)
    __REQUIRE_CONSTANT(__c) {
  return (v128_t)(__i32x4){__c, __c, __c, __c};
}

static __inline__ v128_t __DEFAULT_FN_ATTRS wasm_u32x4_const_splat(uint32_t __c)
    __REQUIRE_CONSTANT(__c) {
  return (v128_t)(__u32x4){__c, __c, __c, __c};
}

static __inline__ v128_t __DEFAULT_FN_ATTRS wasm_i64x2_const_splat(int64_t __c)
    __REQUIRE_CONSTANT(__c) {
  return (v128_t)(__i64x2){__c, __c};
}

static __inline__ v128_t __DEFAULT_FN_ATTRS wasm_u64x2_const_splat(uint64_t __c)
    __REQUIRE_CONSTANT(__c) {
  return (v128_t)(__u64x2){__c, __c};
}

static __inline__ v128_t __DEFAULT_FN_ATTRS wasm_f32x4_const_splat(float __c)
    __REQUIRE_CONSTANT(__c) {
  return (v128_t)(__f32x4){__c, __c, __c, __c};
}

static __inline__ v128_t __DEFAULT_FN_ATTRS wasm_f64x2_const_splat(double __c)
    __REQUIRE_CONSTANT(__c) {
  return (v128_t)(__f64x2){__c, __c};
}

static __inline__ v128_t __DEFAULT_FN_ATTRS wasm_i8x16_splat(int8_t __a) {
  return (v128_t)(__i8x16){__a, __a, __a, __a, __a, __a, __a, __a,
                           __a, __a, __a, __a, __a, __a, __a, __a};
}

static __inline__ v128_t __DEFAULT_FN_ATTRS wasm_u8x16_splat(uint8_t __a) {
  return (v128_t)(__u8x16){__a, __a, __a, __a, __a, __a, __a, __a,
                           __a, __a, __a, __a, __a, __a, __a, __a};
}

static __inline__ int8_t __DEFAULT_FN_ATTRS wasm_i8x16_extract_lane(v128_t __a,
                                                                    int __i)
    __REQUIRE_CONSTANT(__i) {
  return ((__i8x16)__a)[__i];
}

static __inline__ uint8_t __DEFAULT_FN_ATTRS wasm_u8x16_extract_lane(v128_t __a,
                                                                     int __i)
    __REQUIRE_CONSTANT(__i) {
  return ((__u8x16)__a)[__i];
}

static __inline__ v128_t __DEFAULT_FN_ATTRS wasm_i8x16_replace_lane(v128_t __a,
                                                                    int __i,
                                                                    int8_t __b)
    __REQUIRE_CONSTANT(__i) {
  __i8x16 __v = (__i8x16)__a;
  __v[__i] = __b;
  return (v128_t)__v;
}

static __inline__ v128_t __DEFAULT_FN_ATTRS wasm_u8x16_replace_lane(v128_t __a,
                                                                    int __i,
                                                                    uint8_t __b)
    __REQUIRE_CONSTANT(__i) {
  __u8x16 __v = (__u8x16)__a;
  __v[__i] = __b;
  return (v128_t)__v;
}

static __inline__ v128_t __DEFAULT_FN_ATTRS wasm_i16x8_splat(int16_t __a) {
  return (v128_t)(__i16x8){__a, __a, __a, __a, __a, __a, __a, __a};
}

static __inline__ v128_t __DEFAULT_FN_ATTRS wasm_u16x8_splat(uint16_t __a) {
  return (v128_t)(__u16x8){__a, __a, __a, __a, __a, __a, __a, __a};
}

static __inline__ int16_t __DEFAULT_FN_ATTRS wasm_i16x8_extract_lane(v128_t __a,
                                                                     int __i)
    __REQUIRE_CONSTANT(__i) {
  return ((__i16x8)__a)[__i];
}

static __inline__ uint16_t __DEFAULT_FN_ATTRS
wasm_u16x8_extract_lane(v128_t __a, int __i) __REQUIRE_CONSTANT(__i) {
  return ((__u16x8)__a)[__i];
}

static __inline__ v128_t __DEFAULT_FN_ATTRS wasm_i16x8_replace_lane(v128_t __a,
                                                                    int __i,
                                                                    int16_t __b)
    __REQUIRE_CONSTANT(__i) {
  __i16x8 __v = (__i16x8)__a;
  __v[__i] = __b;
  return (v128_t)__v;
}

static __inline__ v128_t __DEFAULT_FN_ATTRS wasm_u16x8_replace_lane(
    v128_t __a, int __i, uint16_t __b) __REQUIRE_CONSTANT(__i) {
  __u16x8 __v = (__u16x8)__a;
  __v[__i] = __b;
  return (v128_t)__v;
}

static __inline__ v128_t __DEFAULT_FN_ATTRS wasm_i32x4_splat(int32_t __a) {
  return (v128_t)(__i32x4){__a, __a, __a, __a};
}

static __inline__ v128_t __DEFAULT_FN_ATTRS wasm_u32x4_splat(uint32_t __a) {
  return (v128_t)(__u32x4){__a, __a, __a, __a};
}

static __inline__ int32_t __DEFAULT_FN_ATTRS wasm_i32x4_extract_lane(v128_t __a,
                                                                     int __i)
    __REQUIRE_CONSTANT(__i) {
  return ((__i32x4)__a)[__i];
}

static __inline__ uint32_t __DEFAULT_FN_ATTRS
wasm_u32x4_extract_lane(v128_t __a, int __i) __REQUIRE_CONSTANT(__i) {
  return ((__u32x4)__a)[__i];
}

static __inline__ v128_t __DEFAULT_FN_ATTRS wasm_i32x4_replace_lane(v128_t __a,
                                                                    int __i,
                                                                    int32_t __b)
    __REQUIRE_CONSTANT(__i) {
  __i32x4 __v = (__i32x4)__a;
  __v[__i] = __b;
  return (v128_t)__v;
}

static __inline__ v128_t __DEFAULT_FN_ATTRS wasm_u32x4_replace_lane(
    v128_t __a, int __i, uint32_t __b) __REQUIRE_CONSTANT(__i) {
  __u32x4 __v = (__u32x4)__a;
  __v[__i] = __b;
  return (v128_t)__v;
}

static __inline__ v128_t __DEFAULT_FN_ATTRS wasm_i64x2_splat(int64_t __a) {
  return (v128_t)(__i64x2){__a, __a};
}

static __inline__ v128_t __DEFAULT_FN_ATTRS wasm_u64x2_splat(uint64_t __a) {
  return (v128_t)(__u64x2){__a, __a};
}

static __inline__ int64_t __DEFAULT_FN_ATTRS wasm_i64x2_extract_lane(v128_t __a,
                                                                     int __i)
    __REQUIRE_CONSTANT(__i) {
  return ((__i64x2)__a)[__i];
}

static __inline__ uint64_t __DEFAULT_FN_ATTRS
wasm_u64x2_extract_lane(v128_t __a, int __i) __REQUIRE_CONSTANT(__i) {
  return ((__u64x2)__a)[__i];
}

static __inline__ v128_t __DEFAULT_FN_ATTRS wasm_i64x2_replace_lane(v128_t __a,
                                                                    int __i,
                                                                    int64_t __b)
    __REQUIRE_CONSTANT(__i) {
  __i64x2 __v = (__i64x2)__a;
  __v[__i] = __b;
  return (v128_t)__v;
}

static __inline__ v128_t __DEFAULT_FN_ATTRS wasm_u64x2_replace_lane(
    v128_t __a, int __i, uint64_t __b) __REQUIRE_CONSTANT(__i) {
  __u64x2 __v = (__u64x2)__a;
  __v[__i] = __b;
  return (v128_t)__v;
}

static __inline__ v128_t __DEFAULT_FN_ATTRS wasm_f32x4_splat(float __a) {
  return (v128_t)(__f32x4){__a, __a, __a, __a};
}

static __inline__ float __DEFAULT_FN_ATTRS wasm_f32x4_extract_lane(v128_t __a,
                                                                   int __i)
    __REQUIRE_CONSTANT(__i) {
  return ((__f32x4)__a)[__i];
}

static __inline__ v128_t __DEFAULT_FN_ATTRS wasm_f32x4_replace_lane(v128_t __a,
                                                                    int __i,
                                                                    float __b)
    __REQUIRE_CONSTANT(__i) {
  __f32x4 __v = (__f32x4)__a;
  __v[__i] = __b;
  return (v128_t)__v;
}

static __inline__ v128_t __DEFAULT_FN_ATTRS wasm_f64x2_splat(double __a) {
  return (v128_t)(__f64x2){__a, __a};
}

static __inline__ double __DEFAULT_FN_ATTRS wasm_f64x2_extract_lane(v128_t __a,
                                                                    int __i)
    __REQUIRE_CONSTANT(__i) {
  return ((__f64x2)__a)[__i];
}

static __inline__ v128_t __DEFAULT_FN_ATTRS wasm_f64x2_replace_lane(v128_t __a,
                                                                    int __i,
                                                                    double __b)
    __REQUIRE_CONSTANT(__i) {
  __f64x2 __v = (__f64x2)__a;
  __v[__i] = __b;
  return (v128_t)__v;
}

static __inline__ v128_t __DEFAULT_FN_ATTRS wasm_i8x16_eq(v128_t __a,
                                                          v128_t __b) {
  return (v128_t)((__i8x16)__a == (__i8x16)__b);
}

static __inline__ v128_t __DEFAULT_FN_ATTRS wasm_i8x16_ne(v128_t __a,
                                                          v128_t __b) {
  return (v128_t)((__i8x16)__a != (__i8x16)__b);
}

static __inline__ v128_t __DEFAULT_FN_ATTRS wasm_i8x16_lt(v128_t __a,
                                                          v128_t __b) {
  return (v128_t)((__i8x16)__a < (__i8x16)__b);
}

static __inline__ v128_t __DEFAULT_FN_ATTRS wasm_u8x16_lt(v128_t __a,
                                                          v128_t __b) {
  return (v128_t)((__u8x16)__a < (__u8x16)__b);
}

static __inline__ v128_t __DEFAULT_FN_ATTRS wasm_i8x16_gt(v128_t __a,
                                                          v128_t __b) {
  return (v128_t)((__i8x16)__a > (__i8x16)__b);
}

static __inline__ v128_t __DEFAULT_FN_ATTRS wasm_u8x16_gt(v128_t __a,
                                                          v128_t __b) {
  return (v128_t)((__u8x16)__a > (__u8x16)__b);
}

static __inline__ v128_t __DEFAULT_FN_ATTRS wasm_i8x16_le(v128_t __a,
                                                          v128_t __b) {
  return (v128_t)((__i8x16)__a <= (__i8x16)__b);
}

static __inline__ v128_t __DEFAULT_FN_ATTRS wasm_u8x16_le(v128_t __a,
                                                          v128_t __b) {
  return (v128_t)((__u8x16)__a <= (__u8x16)__b);
}

static __inline__ v128_t __DEFAULT_FN_ATTRS wasm_i8x16_ge(v128_t __a,
                                                          v128_t __b) {
  return (v128_t)((__i8x16)__a >= (__i8x16)__b);
}

static __inline__ v128_t __DEFAULT_FN_ATTRS wasm_u8x16_ge(v128_t __a,
                                                          v128_t __b) {
  return (v128_t)((__u8x16)__a >= (__u8x16)__b);
}

static __inline__ v128_t __DEFAULT_FN_ATTRS wasm_i16x8_eq(v128_t __a,
                                                          v128_t __b) {
  return (v128_t)((__i16x8)__a == (__i16x8)__b);
}

static __inline__ v128_t __DEFAULT_FN_ATTRS wasm_i16x8_ne(v128_t __a,
                                                          v128_t __b) {
  return (v128_t)((__u16x8)__a != (__u16x8)__b);
}

static __inline__ v128_t __DEFAULT_FN_ATTRS wasm_i16x8_lt(v128_t __a,
                                                          v128_t __b) {
  return (v128_t)((__i16x8)__a < (__i16x8)__b);
}

static __inline__ v128_t __DEFAULT_FN_ATTRS wasm_u16x8_lt(v128_t __a,
                                                          v128_t __b) {
  return (v128_t)((__u16x8)__a < (__u16x8)__b);
}

static __inline__ v128_t __DEFAULT_FN_ATTRS wasm_i16x8_gt(v128_t __a,
                                                          v128_t __b) {
  return (v128_t)((__i16x8)__a > (__i16x8)__b);
}

static __inline__ v128_t __DEFAULT_FN_ATTRS wasm_u16x8_gt(v128_t __a,
                                                          v128_t __b) {
  return (v128_t)((__u16x8)__a > (__u16x8)__b);
}

static __inline__ v128_t __DEFAULT_FN_ATTRS wasm_i16x8_le(v128_t __a,
                                                          v128_t __b) {
  return (v128_t)((__i16x8)__a <= (__i16x8)__b);
}

static __inline__ v128_t __DEFAULT_FN_ATTRS wasm_u16x8_le(v128_t __a,
                                                          v128_t __b) {
  return (v128_t)((__u16x8)__a <= (__u16x8)__b);
}

static __inline__ v128_t __DEFAULT_FN_ATTRS wasm_i16x8_ge(v128_t __a,
                                                          v128_t __b) {
  return (v128_t)((__i16x8)__a >= (__i16x8)__b);
}

static __inline__ v128_t __DEFAULT_FN_ATTRS wasm_u16x8_ge(v128_t __a,
                                                          v128_t __b) {
  return (v128_t)((__u16x8)__a >= (__u16x8)__b);
}

static __inline__ v128_t __DEFAULT_FN_ATTRS wasm_i32x4_eq(v128_t __a,
                                                          v128_t __b) {
  return (v128_t)((__i32x4)__a == (__i32x4)__b);
}

static __inline__ v128_t __DEFAULT_FN_ATTRS wasm_i32x4_ne(v128_t __a,
                                                          v128_t __b) {
  return (v128_t)((__i32x4)__a != (__i32x4)__b);
}

static __inline__ v128_t __DEFAULT_FN_ATTRS wasm_i32x4_lt(v128_t __a,
                                                          v128_t __b) {
  return (v128_t)((__i32x4)__a < (__i32x4)__b);
}

static __inline__ v128_t __DEFAULT_FN_ATTRS wasm_u32x4_lt(v128_t __a,
                                                          v128_t __b) {
  return (v128_t)((__u32x4)__a < (__u32x4)__b);
}

static __inline__ v128_t __DEFAULT_FN_ATTRS wasm_i32x4_gt(v128_t __a,
                                                          v128_t __b) {
  return (v128_t)((__i32x4)__a > (__i32x4)__b);
}

static __inline__ v128_t __DEFAULT_FN_ATTRS wasm_u32x4_gt(v128_t __a,
                                                          v128_t __b) {
  return (v128_t)((__u32x4)__a > (__u32x4)__b);
}

static __inline__ v128_t __DEFAULT_FN_ATTRS wasm_i32x4_le(v128_t __a,
                                                          v128_t __b) {
  return (v128_t)((__i32x4)__a <= (__i32x4)__b);
}

static __inline__ v128_t __DEFAULT_FN_ATTRS wasm_u32x4_le(v128_t __a,
                                                          v128_t __b) {
  return (v128_t)((__u32x4)__a <= (__u32x4)__b);
}

static __inline__ v128_t __DEFAULT_FN_ATTRS wasm_i32x4_ge(v128_t __a,
                                                          v128_t __b) {
  return (v128_t)((__i32x4)__a >= (__i32x4)__b);
}

static __inline__ v128_t __DEFAULT_FN_ATTRS wasm_u32x4_ge(v128_t __a,
                                                          v128_t __b) {
  return (v128_t)((__u32x4)__a >= (__u32x4)__b);
}

static __inline__ v128_t __DEFAULT_FN_ATTRS wasm_i64x2_eq(v128_t __a,
                                                          v128_t __b) {
  return (v128_t)((__i64x2)__a == (__i64x2)__b);
}

static __inline__ v128_t __DEFAULT_FN_ATTRS wasm_i64x2_ne(v128_t __a,
                                                          v128_t __b) {
  return (v128_t)((__i64x2)__a != (__i64x2)__b);
}

static __inline__ v128_t __DEFAULT_FN_ATTRS wasm_i64x2_lt(v128_t __a,
                                                          v128_t __b) {
  return (v128_t)((__i64x2)__a < (__i64x2)__b);
}

static __inline__ v128_t __DEFAULT_FN_ATTRS wasm_i64x2_gt(v128_t __a,
                                                          v128_t __b) {
  return (v128_t)((__i64x2)__a > (__i64x2)__b);
}

static __inline__ v128_t __DEFAULT_FN_ATTRS wasm_i64x2_le(v128_t __a,
                                                          v128_t __b) {
  return (v128_t)((__i64x2)__a <= (__i64x2)__b);
}

static __inline__ v128_t __DEFAULT_FN_ATTRS wasm_i64x2_ge(v128_t __a,
                                                          v128_t __b) {
  return (v128_t)((__i64x2)__a >= (__i64x2)__b);
}

static __inline__ v128_t __DEFAULT_FN_ATTRS wasm_f32x4_eq(v128_t __a,
                                                          v128_t __b) {
  return (v128_t)((__f32x4)__a == (__f32x4)__b);
}

static __inline__ v128_t __DEFAULT_FN_ATTRS wasm_f32x4_ne(v128_t __a,
                                                          v128_t __b) {
  return (v128_t)((__f32x4)__a != (__f32x4)__b);
}

static __inline__ v128_t __DEFAULT_FN_ATTRS wasm_f32x4_lt(v128_t __a,
                                                          v128_t __b) {
  return (v128_t)((__f32x4)__a < (__f32x4)__b);
}

static __inline__ v128_t __DEFAULT_FN_ATTRS wasm_f32x4_gt(v128_t __a,
                                                          v128_t __b) {
  return (v128_t)((__f32x4)__a > (__f32x4)__b);
}

static __inline__ v128_t __DEFAULT_FN_ATTRS wasm_f32x4_le(v128_t __a,
                                                          v128_t __b) {
  return (v128_t)((__f32x4)__a <= (__f32x4)__b);
}

static __inline__ v128_t __DEFAULT_FN_ATTRS wasm_f32x4_ge(v128_t __a,
                                                          v128_t __b) {
  return (v128_t)((__f32x4)__a >= (__f32x4)__b);
}

static __inline__ v128_t __DEFAULT_FN_ATTRS wasm_f64x2_eq(v128_t __a,
                                                          v128_t __b) {
  return (v128_t)((__f64x2)__a == (__f64x2)__b);
}

static __inline__ v128_t __DEFAULT_FN_ATTRS wasm_f64x2_ne(v128_t __a,
                                                          v128_t __b) {
  return (v128_t)((__f64x2)__a != (__f64x2)__b);
}

static __inline__ v128_t __DEFAULT_FN_ATTRS wasm_f64x2_lt(v128_t __a,
                                                          v128_t __b) {
  return (v128_t)((__f64x2)__a < (__f64x2)__b);
}

static __inline__ v128_t __DEFAULT_FN_ATTRS wasm_f64x2_gt(v128_t __a,
                                                          v128_t __b) {
  return (v128_t)((__f64x2)__a > (__f64x2)__b);
}

static __inline__ v128_t __DEFAULT_FN_ATTRS wasm_f64x2_le(v128_t __a,
                                                          v128_t __b) {
  return (v128_t)((__f64x2)__a <= (__f64x2)__b);
}

static __inline__ v128_t __DEFAULT_FN_ATTRS wasm_f64x2_ge(v128_t __a,
                                                          v128_t __b) {
  return (v128_t)((__f64x2)__a >= (__f64x2)__b);
}

static __inline__ v128_t __DEFAULT_FN_ATTRS wasm_v128_not(v128_t __a) {
  return ~__a;
}

static __inline__ v128_t __DEFAULT_FN_ATTRS wasm_v128_and(v128_t __a,
                                                          v128_t __b) {
  return __a & __b;
}

static __inline__ v128_t __DEFAULT_FN_ATTRS wasm_v128_or(v128_t __a,
                                                         v128_t __b) {
  return __a | __b;
}

static __inline__ v128_t __DEFAULT_FN_ATTRS wasm_v128_xor(v128_t __a,
                                                          v128_t __b) {
  return __a ^ __b;
}

static __inline__ v128_t __DEFAULT_FN_ATTRS wasm_v128_andnot(v128_t __a,
                                                             v128_t __b) {
  return __a & ~__b;
}

static __inline__ bool __DEFAULT_FN_ATTRS wasm_v128_any_true(v128_t __a) {
  return __builtin_wasm_any_true_v128((__i8x16)__a);
}

static __inline__ v128_t __DEFAULT_FN_ATTRS wasm_v128_bitselect(v128_t __a,
                                                                v128_t __b,
                                                                v128_t __mask) {
  return (v128_t)__builtin_wasm_bitselect((__i32x4)__a, (__i32x4)__b,
                                          (__i32x4)__mask);
}

static __inline__ v128_t __DEFAULT_FN_ATTRS wasm_i8x16_abs(v128_t __a) {
  return (v128_t)__builtin_wasm_abs_i8x16((__i8x16)__a);
}

static __inline__ v128_t __DEFAULT_FN_ATTRS wasm_i8x16_neg(v128_t __a) {
  return (v128_t)(-(__u8x16)__a);
}

static __inline__ bool __DEFAULT_FN_ATTRS wasm_i8x16_all_true(v128_t __a) {
  return __builtin_wasm_all_true_i8x16((__i8x16)__a);
}

static __inline__ uint32_t __DEFAULT_FN_ATTRS wasm_i8x16_bitmask(v128_t __a) {
  return __builtin_wasm_bitmask_i8x16((__i8x16)__a);
}

static __inline__ v128_t __DEFAULT_FN_ATTRS wasm_i8x16_popcnt(v128_t __a) {
  return (v128_t)__builtin_elementwise_popcount((__i8x16)__a);
}

static __inline__ v128_t __DEFAULT_FN_ATTRS wasm_i8x16_shl(v128_t __a,
                                                           uint32_t __b) {
  return (v128_t)((__i8x16)__a << (__b & 0x7));
}

static __inline__ v128_t __DEFAULT_FN_ATTRS wasm_i8x16_shr(v128_t __a,
                                                           uint32_t __b) {
  return (v128_t)((__i8x16)__a >> (__b & 0x7));
}

static __inline__ v128_t __DEFAULT_FN_ATTRS wasm_u8x16_shr(v128_t __a,
                                                           uint32_t __b) {
  return (v128_t)((__u8x16)__a >> (__b & 0x7));
}

static __inline__ v128_t __DEFAULT_FN_ATTRS wasm_i8x16_add(v128_t __a,
                                                           v128_t __b) {
  return (v128_t)((__u8x16)__a + (__u8x16)__b);
}

static __inline__ v128_t __DEFAULT_FN_ATTRS wasm_i8x16_add_sat(v128_t __a,
                                                               v128_t __b) {
  return (v128_t)__builtin_elementwise_add_sat((__i8x16)__a, (__i8x16)__b);
}

static __inline__ v128_t __DEFAULT_FN_ATTRS wasm_u8x16_add_sat(v128_t __a,
                                                               v128_t __b) {
  return (v128_t)__builtin_elementwise_add_sat((__u8x16)__a, (__u8x16)__b);
}

static __inline__ v128_t __DEFAULT_FN_ATTRS wasm_i8x16_sub(v128_t __a,
                                                           v128_t __b) {
  return (v128_t)((__u8x16)__a - (__u8x16)__b);
}

static __inline__ v128_t __DEFAULT_FN_ATTRS wasm_i8x16_sub_sat(v128_t __a,
                                                               v128_t __b) {
  return (v128_t)__builtin_elementwise_sub_sat((__i8x16)__a, (__i8x16)__b);
}

static __inline__ v128_t __DEFAULT_FN_ATTRS wasm_u8x16_sub_sat(v128_t __a,
                                                               v128_t __b) {
  return (v128_t)__builtin_elementwise_sub_sat((__u8x16)__a, (__u8x16)__b);
}

static __inline__ v128_t __DEFAULT_FN_ATTRS wasm_i8x16_min(v128_t __a,
                                                           v128_t __b) {
  return (v128_t)__builtin_elementwise_min((__i8x16)__a, (__i8x16)__b);
}

static __inline__ v128_t __DEFAULT_FN_ATTRS wasm_u8x16_min(v128_t __a,
                                                           v128_t __b) {
  return (v128_t)__builtin_elementwise_min((__u8x16)__a, (__u8x16)__b);
}

static __inline__ v128_t __DEFAULT_FN_ATTRS wasm_i8x16_max(v128_t __a,
                                                           v128_t __b) {
  return (v128_t)__builtin_elementwise_max((__i8x16)__a, (__i8x16)__b);
}

static __inline__ v128_t __DEFAULT_FN_ATTRS wasm_u8x16_max(v128_t __a,
                                                           v128_t __b) {
  return (v128_t)__builtin_elementwise_max((__u8x16)__a, (__u8x16)__b);
}

static __inline__ v128_t __DEFAULT_FN_ATTRS wasm_u8x16_avgr(v128_t __a,
                                                            v128_t __b) {
  return (v128_t)__builtin_wasm_avgr_u_i8x16((__u8x16)__a, (__u8x16)__b);
}

static __inline__ v128_t __DEFAULT_FN_ATTRS wasm_i16x8_abs(v128_t __a) {
  return (v128_t)__builtin_wasm_abs_i16x8((__i16x8)__a);
}

static __inline__ v128_t __DEFAULT_FN_ATTRS wasm_i16x8_neg(v128_t __a) {
  return (v128_t)(-(__u16x8)__a);
}

static __inline__ bool __DEFAULT_FN_ATTRS wasm_i16x8_all_true(v128_t __a) {
  return __builtin_wasm_all_true_i16x8((__i16x8)__a);
}

static __inline__ uint32_t __DEFAULT_FN_ATTRS wasm_i16x8_bitmask(v128_t __a) {
  return __builtin_wasm_bitmask_i16x8((__i16x8)__a);
}

static __inline__ v128_t __DEFAULT_FN_ATTRS wasm_i16x8_shl(v128_t __a,
                                                           uint32_t __b) {
  return (v128_t)((__i16x8)__a << (__b & 0xF));
}

static __inline__ v128_t __DEFAULT_FN_ATTRS wasm_i16x8_shr(v128_t __a,
                                                           uint32_t __b) {
  return (v128_t)((__i16x8)__a >> (__b & 0xF));
}

static __inline__ v128_t __DEFAULT_FN_ATTRS wasm_u16x8_shr(v128_t __a,
                                                           uint32_t __b) {
  return (v128_t)((__u16x8)__a >> (__b & 0xF));
}

static __inline__ v128_t __DEFAULT_FN_ATTRS wasm_i16x8_add(v128_t __a,
                                                           v128_t __b) {
  return (v128_t)((__u16x8)__a + (__u16x8)__b);
}

static __inline__ v128_t __DEFAULT_FN_ATTRS wasm_i16x8_add_sat(v128_t __a,
                                                               v128_t __b) {
  return (v128_t)__builtin_elementwise_add_sat((__i16x8)__a, (__i16x8)__b);
}

static __inline__ v128_t __DEFAULT_FN_ATTRS wasm_u16x8_add_sat(v128_t __a,
                                                               v128_t __b) {
  return (v128_t)__builtin_elementwise_add_sat((__u16x8)__a, (__u16x8)__b);
}

static __inline__ v128_t __DEFAULT_FN_ATTRS wasm_i16x8_sub(v128_t __a,
                                                           v128_t __b) {
  return (v128_t)((__i16x8)__a - (__i16x8)__b);
}

static __inline__ v128_t __DEFAULT_FN_ATTRS wasm_i16x8_sub_sat(v128_t __a,
                                                               v128_t __b) {
  return (v128_t)__builtin_elementwise_sub_sat((__i16x8)__a, (__i16x8)__b);
}

static __inline__ v128_t __DEFAULT_FN_ATTRS wasm_u16x8_sub_sat(v128_t __a,
                                                               v128_t __b) {
  return (v128_t)__builtin_elementwise_sub_sat((__u16x8)__a, (__u16x8)__b);
}

static __inline__ v128_t __DEFAULT_FN_ATTRS wasm_i16x8_mul(v128_t __a,
                                                           v128_t __b) {
  return (v128_t)((__u16x8)__a * (__u16x8)__b);
}

static __inline__ v128_t __DEFAULT_FN_ATTRS wasm_i16x8_min(v128_t __a,
                                                           v128_t __b) {
  return (v128_t)__builtin_elementwise_min((__i16x8)__a, (__i16x8)__b);
}

static __inline__ v128_t __DEFAULT_FN_ATTRS wasm_u16x8_min(v128_t __a,
                                                           v128_t __b) {
  return (v128_t)__builtin_elementwise_min((__u16x8)__a, (__u16x8)__b);
}

static __inline__ v128_t __DEFAULT_FN_ATTRS wasm_i16x8_max(v128_t __a,
                                                           v128_t __b) {
  return (v128_t)__builtin_elementwise_max((__i16x8)__a, (__i16x8)__b);
}

static __inline__ v128_t __DEFAULT_FN_ATTRS wasm_u16x8_max(v128_t __a,
                                                           v128_t __b) {
  return (v128_t)__builtin_elementwise_max((__u16x8)__a, (__u16x8)__b);
}

static __inline__ v128_t __DEFAULT_FN_ATTRS wasm_u16x8_avgr(v128_t __a,
                                                            v128_t __b) {
  return (v128_t)__builtin_wasm_avgr_u_i16x8((__u16x8)__a, (__u16x8)__b);
}

static __inline__ v128_t __DEFAULT_FN_ATTRS wasm_i32x4_abs(v128_t __a) {
  return (v128_t)__builtin_wasm_abs_i32x4((__i32x4)__a);
}

static __inline__ v128_t __DEFAULT_FN_ATTRS wasm_i32x4_neg(v128_t __a) {
  return (v128_t)(-(__u32x4)__a);
}

static __inline__ bool __DEFAULT_FN_ATTRS wasm_i32x4_all_true(v128_t __a) {
  return __builtin_wasm_all_true_i32x4((__i32x4)__a);
}

static __inline__ uint32_t __DEFAULT_FN_ATTRS wasm_i32x4_bitmask(v128_t __a) {
  return __builtin_wasm_bitmask_i32x4((__i32x4)__a);
}

static __inline__ v128_t __DEFAULT_FN_ATTRS wasm_i32x4_shl(v128_t __a,
                                                           uint32_t __b) {
  return (v128_t)((__i32x4)__a << (__b & 0x1F));
}

static __inline__ v128_t __DEFAULT_FN_ATTRS wasm_i32x4_shr(v128_t __a,
                                                           uint32_t __b) {
  return (v128_t)((__i32x4)__a >> (__b & 0x1F));
}

static __inline__ v128_t __DEFAULT_FN_ATTRS wasm_u32x4_shr(v128_t __a,
                                                           uint32_t __b) {
  return (v128_t)((__u32x4)__a >> (__b & 0x1F));
}

static __inline__ v128_t __DEFAULT_FN_ATTRS wasm_i32x4_add(v128_t __a,
                                                           v128_t __b) {
  return (v128_t)((__u32x4)__a + (__u32x4)__b);
}

static __inline__ v128_t __DEFAULT_FN_ATTRS wasm_i32x4_sub(v128_t __a,
                                                           v128_t __b) {
  return (v128_t)((__u32x4)__a - (__u32x4)__b);
}

static __inline__ v128_t __DEFAULT_FN_ATTRS wasm_i32x4_mul(v128_t __a,
                                                           v128_t __b) {
  return (v128_t)((__u32x4)__a * (__u32x4)__b);
}

static __inline__ v128_t __DEFAULT_FN_ATTRS wasm_i32x4_min(v128_t __a,
                                                           v128_t __b) {
  return (v128_t)__builtin_elementwise_min((__i32x4)__a, (__i32x4)__b);
}

static __inline__ v128_t __DEFAULT_FN_ATTRS wasm_u32x4_min(v128_t __a,
                                                           v128_t __b) {
  return (v128_t)__builtin_elementwise_min((__u32x4)__a, (__u32x4)__b);
}

static __inline__ v128_t __DEFAULT_FN_ATTRS wasm_i32x4_max(v128_t __a,
                                                           v128_t __b) {
  return (v128_t)__builtin_elementwise_max((__i32x4)__a, (__i32x4)__b);
}

static __inline__ v128_t __DEFAULT_FN_ATTRS wasm_u32x4_max(v128_t __a,
                                                           v128_t __b) {
  return (v128_t)__builtin_elementwise_max((__u32x4)__a, (__u32x4)__b);
}

static __inline__ v128_t __DEFAULT_FN_ATTRS wasm_i32x4_dot_i16x8(v128_t __a,
                                                                 v128_t __b) {
  return (v128_t)__builtin_wasm_dot_s_i32x4_i16x8((__i16x8)__a, (__i16x8)__b);
}

static __inline__ v128_t __DEFAULT_FN_ATTRS wasm_i64x2_abs(v128_t __a) {
  return (v128_t)__builtin_wasm_abs_i64x2((__i64x2)__a);
}

static __inline__ v128_t __DEFAULT_FN_ATTRS wasm_i64x2_neg(v128_t __a) {
  return (v128_t)(-(__u64x2)__a);
}

static __inline__ bool __DEFAULT_FN_ATTRS wasm_i64x2_all_true(v128_t __a) {
  return __builtin_wasm_all_true_i64x2((__i64x2)__a);
}

static __inline__ uint32_t __DEFAULT_FN_ATTRS wasm_i64x2_bitmask(v128_t __a) {
  return __builtin_wasm_bitmask_i64x2((__i64x2)__a);
}

static __inline__ v128_t __DEFAULT_FN_ATTRS wasm_i64x2_shl(v128_t __a,
                                                           uint32_t __b) {
  return (v128_t)((__i64x2)__a << ((int64_t)__b & 0x3F));
}

static __inline__ v128_t __DEFAULT_FN_ATTRS wasm_i64x2_shr(v128_t __a,
                                                           uint32_t __b) {
  return (v128_t)((__i64x2)__a >> ((int64_t)__b & 0x3F));
}

static __inline__ v128_t __DEFAULT_FN_ATTRS wasm_u64x2_shr(v128_t __a,
                                                           uint32_t __b) {
  return (v128_t)((__u64x2)__a >> ((int64_t)__b & 0x3F));
}

static __inline__ v128_t __DEFAULT_FN_ATTRS wasm_i64x2_add(v128_t __a,
                                                           v128_t __b) {
  return (v128_t)((__u64x2)__a + (__u64x2)__b);
}

static __inline__ v128_t __DEFAULT_FN_ATTRS wasm_i64x2_sub(v128_t __a,
                                                           v128_t __b) {
  return (v128_t)((__u64x2)__a - (__u64x2)__b);
}

static __inline__ v128_t __DEFAULT_FN_ATTRS wasm_i64x2_mul(v128_t __a,
                                                           v128_t __b) {
  return (v128_t)((__u64x2)__a * (__u64x2)__b);
}

static __inline__ v128_t __DEFAULT_FN_ATTRS wasm_f32x4_abs(v128_t __a) {
  return (v128_t)__builtin_wasm_abs_f32x4((__f32x4)__a);
}

static __inline__ v128_t __DEFAULT_FN_ATTRS wasm_f32x4_neg(v128_t __a) {
  return (v128_t)(-(__f32x4)__a);
}

static __inline__ v128_t __DEFAULT_FN_ATTRS wasm_f32x4_sqrt(v128_t __a) {
  return (v128_t)__builtin_wasm_sqrt_f32x4((__f32x4)__a);
}

static __inline__ v128_t __DEFAULT_FN_ATTRS wasm_f32x4_ceil(v128_t __a) {
  return (v128_t)__builtin_wasm_ceil_f32x4((__f32x4)__a);
}

static __inline__ v128_t __DEFAULT_FN_ATTRS wasm_f32x4_floor(v128_t __a) {
  return (v128_t)__builtin_wasm_floor_f32x4((__f32x4)__a);
}

static __inline__ v128_t __DEFAULT_FN_ATTRS wasm_f32x4_trunc(v128_t __a) {
  return (v128_t)__builtin_wasm_trunc_f32x4((__f32x4)__a);
}

static __inline__ v128_t __DEFAULT_FN_ATTRS wasm_f32x4_nearest(v128_t __a) {
  return (v128_t)__builtin_wasm_nearest_f32x4((__f32x4)__a);
}

static __inline__ v128_t __DEFAULT_FN_ATTRS wasm_f32x4_add(v128_t __a,
                                                           v128_t __b) {
  return (v128_t)((__f32x4)__a + (__f32x4)__b);
}

static __inline__ v128_t __DEFAULT_FN_ATTRS wasm_f32x4_sub(v128_t __a,
                                                           v128_t __b) {
  return (v128_t)((__f32x4)__a - (__f32x4)__b);
}

static __inline__ v128_t __DEFAULT_FN_ATTRS wasm_f32x4_mul(v128_t __a,
                                                           v128_t __b) {
  return (v128_t)((__f32x4)__a * (__f32x4)__b);
}

static __inline__ v128_t __DEFAULT_FN_ATTRS wasm_f32x4_div(v128_t __a,
                                                           v128_t __b) {
  return (v128_t)((__f32x4)__a / (__f32x4)__b);
}

static __inline__ v128_t __DEFAULT_FN_ATTRS wasm_f32x4_min(v128_t __a,
                                                           v128_t __b) {
  return (v128_t)__builtin_wasm_min_f32x4((__f32x4)__a, (__f32x4)__b);
}

static __inline__ v128_t __DEFAULT_FN_ATTRS wasm_f32x4_max(v128_t __a,
                                                           v128_t __b) {
  return (v128_t)__builtin_wasm_max_f32x4((__f32x4)__a, (__f32x4)__b);
}

static __inline__ v128_t __DEFAULT_FN_ATTRS wasm_f32x4_pmin(v128_t __a,
                                                            v128_t __b) {
  return (v128_t)__builtin_wasm_pmin_f32x4((__f32x4)__a, (__f32x4)__b);
}

static __inline__ v128_t __DEFAULT_FN_ATTRS wasm_f32x4_pmax(v128_t __a,
                                                            v128_t __b) {
  return (v128_t)__builtin_wasm_pmax_f32x4((__f32x4)__a, (__f32x4)__b);
}

static __inline__ v128_t __DEFAULT_FN_ATTRS wasm_f64x2_abs(v128_t __a) {
  return (v128_t)__builtin_wasm_abs_f64x2((__f64x2)__a);
}

static __inline__ v128_t __DEFAULT_FN_ATTRS wasm_f64x2_neg(v128_t __a) {
  return (v128_t)(-(__f64x2)__a);
}

static __inline__ v128_t __DEFAULT_FN_ATTRS wasm_f64x2_sqrt(v128_t __a) {
  return (v128_t)__builtin_wasm_sqrt_f64x2((__f64x2)__a);
}

static __inline__ v128_t __DEFAULT_FN_ATTRS wasm_f64x2_ceil(v128_t __a) {
  return (v128_t)__builtin_wasm_ceil_f64x2((__f64x2)__a);
}

static __inline__ v128_t __DEFAULT_FN_ATTRS wasm_f64x2_floor(v128_t __a) {
  return (v128_t)__builtin_wasm_floor_f64x2((__f64x2)__a);
}

static __inline__ v128_t __DEFAULT_FN_ATTRS wasm_f64x2_trunc(v128_t __a) {
  return (v128_t)__builtin_wasm_trunc_f64x2((__f64x2)__a);
}

static __inline__ v128_t __DEFAULT_FN_ATTRS wasm_f64x2_nearest(v128_t __a) {
  return (v128_t)__builtin_wasm_nearest_f64x2((__f64x2)__a);
}

static __inline__ v128_t __DEFAULT_FN_ATTRS wasm_f64x2_add(v128_t __a,
                                                           v128_t __b) {
  return (v128_t)((__f64x2)__a + (__f64x2)__b);
}

static __inline__ v128_t __DEFAULT_FN_ATTRS wasm_f64x2_sub(v128_t __a,
                                                           v128_t __b) {
  return (v128_t)((__f64x2)__a - (__f64x2)__b);
}

static __inline__ v128_t __DEFAULT_FN_ATTRS wasm_f64x2_mul(v128_t __a,
                                                           v128_t __b) {
  return (v128_t)((__f64x2)__a * (__f64x2)__b);
}

static __inline__ v128_t __DEFAULT_FN_ATTRS wasm_f64x2_div(v128_t __a,
                                                           v128_t __b) {
  return (v128_t)((__f64x2)__a / (__f64x2)__b);
}

static __inline__ v128_t __DEFAULT_FN_ATTRS wasm_f64x2_min(v128_t __a,
                                                           v128_t __b) {
  return (v128_t)__builtin_wasm_min_f64x2((__f64x2)__a, (__f64x2)__b);
}

static __inline__ v128_t __DEFAULT_FN_ATTRS wasm_f64x2_max(v128_t __a,
                                                           v128_t __b) {
  return (v128_t)__builtin_wasm_max_f64x2((__f64x2)__a, (__f64x2)__b);
}

static __inline__ v128_t __DEFAULT_FN_ATTRS wasm_f64x2_pmin(v128_t __a,
                                                            v128_t __b) {
  return (v128_t)__builtin_wasm_pmin_f64x2((__f64x2)__a, (__f64x2)__b);
}

static __inline__ v128_t __DEFAULT_FN_ATTRS wasm_f64x2_pmax(v128_t __a,
                                                            v128_t __b) {
  return (v128_t)__builtin_wasm_pmax_f64x2((__f64x2)__a, (__f64x2)__b);
}

static __inline__ v128_t __DEFAULT_FN_ATTRS
wasm_i32x4_trunc_sat_f32x4(v128_t __a) {
  return (v128_t)__builtin_wasm_trunc_saturate_s_i32x4_f32x4((__f32x4)__a);
}

static __inline__ v128_t __DEFAULT_FN_ATTRS
wasm_u32x4_trunc_sat_f32x4(v128_t __a) {
  return (v128_t)__builtin_wasm_trunc_saturate_u_i32x4_f32x4((__f32x4)__a);
}

static __inline__ v128_t __DEFAULT_FN_ATTRS
wasm_f32x4_convert_i32x4(v128_t __a) {
  return (v128_t) __builtin_convertvector((__i32x4)__a, __f32x4);
}

static __inline__ v128_t __DEFAULT_FN_ATTRS
wasm_f32x4_convert_u32x4(v128_t __a) {
  return (v128_t) __builtin_convertvector((__u32x4)__a, __f32x4);
}

static __inline__ v128_t __DEFAULT_FN_ATTRS
wasm_f64x2_convert_low_i32x4(v128_t __a) {
  return (v128_t) __builtin_convertvector((__i32x2){__a[0], __a[1]}, __f64x2);
}

static __inline__ v128_t __DEFAULT_FN_ATTRS
wasm_f64x2_convert_low_u32x4(v128_t __a) {
  return (v128_t) __builtin_convertvector((__u32x2){__a[0], __a[1]}, __f64x2);
}

static __inline__ v128_t __DEFAULT_FN_ATTRS
wasm_i32x4_trunc_sat_f64x2_zero(v128_t __a) {
  return (v128_t)__builtin_wasm_trunc_sat_s_zero_f64x2_i32x4((__f64x2)__a);
}

static __inline__ v128_t __DEFAULT_FN_ATTRS
wasm_u32x4_trunc_sat_f64x2_zero(v128_t __a) {
  return (v128_t)__builtin_wasm_trunc_sat_u_zero_f64x2_i32x4((__f64x2)__a);
}

static __inline__ v128_t __DEFAULT_FN_ATTRS
wasm_f32x4_demote_f64x2_zero(v128_t __a) {
  return (v128_t) __builtin_convertvector(
      __builtin_shufflevector((__f64x2)__a, (__f64x2){0, 0}, 0, 1, 2, 3),
      __f32x4);
}

static __inline__ v128_t __DEFAULT_FN_ATTRS
wasm_f64x2_promote_low_f32x4(v128_t __a) {
  return (v128_t) __builtin_convertvector(
      (__f32x2){((__f32x4)__a)[0], ((__f32x4)__a)[1]}, __f64x2);
}

#define wasm_i8x16_shuffle(__a, __b, __c0, __c1, __c2, __c3, __c4, __c5, __c6, \\
                           __c7, __c8, __c9, __c10, __c11, __c12, __c13,       \\
                           __c14, __c15)                                       \\
  ((v128_t)__builtin_wasm_shuffle_i8x16(                                       \\
      (__i8x16)(__a), (__i8x16)(__b), __c0, __c1, __c2, __c3, __c4, __c5,      \\
      __c6, __c7, __c8, __c9, __c10, __c11, __c12, __c13, __c14, __c15))

#define wasm_i16x8_shuffle(__a, __b, __c0, __c1, __c2, __c3, __c4, __c5, __c6, \\
                           __c7)                                               \\
  ((v128_t)__builtin_wasm_shuffle_i8x16(                                       \\
      (__i8x16)(__a), (__i8x16)(__b), (__c0)*2, (__c0)*2 + 1, (__c1)*2,        \\
      (__c1)*2 + 1, (__c2)*2, (__c2)*2 + 1, (__c3)*2, (__c3)*2 + 1, (__c4)*2,  \\
      (__c4)*2 + 1, (__c5)*2, (__c5)*2 + 1, (__c6)*2, (__c6)*2 + 1, (__c7)*2,  \\
      (__c7)*2 + 1))

#define wasm_i32x4_shuffle(__a, __b, __c0, __c1, __c2, __c3)                   \\
  ((v128_t)__builtin_wasm_shuffle_i8x16(                                       \\
      (__i8x16)(__a), (__i8x16)(__b), (__c0)*4, (__c0)*4 + 1, (__c0)*4 + 2,    \\
      (__c0)*4 + 3, (__c1)*4, (__c1)*4 + 1, (__c1)*4 + 2, (__c1)*4 + 3,        \\
      (__c2)*4, (__c2)*4 + 1, (__c2)*4 + 2, (__c2)*4 + 3, (__c3)*4,            \\
      (__c3)*4 + 1, (__c3)*4 + 2, (__c3)*4 + 3))

#define wasm_i64x2_shuffle(__a, __b, __c0, __c1)                               \\
  ((v128_t)__builtin_wasm_shuffle_i8x16(                                       \\
      (__i8x16)(__a), (__i8x16)(__b), (__c0)*8, (__c0)*8 + 1, (__c0)*8 + 2,    \\
      (__c0)*8 + 3, (__c0)*8 + 4, (__c0)*8 + 5, (__c0)*8 + 6, (__c0)*8 + 7,    \\
      (__c1)*8, (__c1)*8 + 1, (__c1)*8 + 2, (__c1)*8 + 3, (__c1)*8 + 4,        \\
      (__c1)*8 + 5, (__c1)*8 + 6, (__c1)*8 + 7))

static __inline__ v128_t __DEFAULT_FN_ATTRS wasm_i8x16_swizzle(v128_t __a,
                                                               v128_t __b) {
  return (v128_t)__builtin_wasm_swizzle_i8x16((__i8x16)__a, (__i8x16)__b);
}

static __inline__ v128_t __DEFAULT_FN_ATTRS
wasm_i8x16_narrow_i16x8(v128_t __a, v128_t __b) {
  return (v128_t)__builtin_wasm_narrow_s_i8x16_i16x8((__i16x8)__a,
                                                     (__i16x8)__b);
}

static __inline__ v128_t __DEFAULT_FN_ATTRS
wasm_u8x16_narrow_i16x8(v128_t __a, v128_t __b) {
  return (v128_t)__builtin_wasm_narrow_u_i8x16_i16x8((__i16x8)__a,
                                                     (__i16x8)__b);
}

static __inline__ v128_t __DEFAULT_FN_ATTRS
wasm_i16x8_narrow_i32x4(v128_t __a, v128_t __b) {
  return (v128_t)__builtin_wasm_narrow_s_i16x8_i32x4((__i32x4)__a,
                                                     (__i32x4)__b);
}

static __inline__ v128_t __DEFAULT_FN_ATTRS
wasm_u16x8_narrow_i32x4(v128_t __a, v128_t __b) {
  return (v128_t)__builtin_wasm_narrow_u_i16x8_i32x4((__i32x4)__a,
                                                     (__i32x4)__b);
}

static __inline__ v128_t __DEFAULT_FN_ATTRS
wasm_i16x8_extend_low_i8x16(v128_t __a) {
  return (v128_t) __builtin_convertvector(
      (__i8x8){((__i8x16)__a)[0], ((__i8x16)__a)[1], ((__i8x16)__a)[2],
               ((__i8x16)__a)[3], ((__i8x16)__a)[4], ((__i8x16)__a)[5],
               ((__i8x16)__a)[6], ((__i8x16)__a)[7]},
      __i16x8);
}

static __inline__ v128_t __DEFAULT_FN_ATTRS
wasm_i16x8_extend_high_i8x16(v128_t __a) {
  return (v128_t) __builtin_convertvector(
      (__i8x8){((__i8x16)__a)[8], ((__i8x16)__a)[9], ((__i8x16)__a)[10],
               ((__i8x16)__a)[11], ((__i8x16)__a)[12], ((__i8x16)__a)[13],
               ((__i8x16)__a)[14], ((__i8x16)__a)[15]},
      __i16x8);
}

static __inline__ v128_t __DEFAULT_FN_ATTRS
wasm_u16x8_extend_low_u8x16(v128_t __a) {
  return (v128_t) __builtin_convertvector(
      (__u8x8){((__u8x16)__a)[0], ((__u8x16)__a)[1], ((__u8x16)__a)[2],
               ((__u8x16)__a)[3], ((__u8x16)__a)[4], ((__u8x16)__a)[5],
               ((__u8x16)__a)[6], ((__u8x16)__a)[7]},
      __u16x8);
}

static __inline__ v128_t __DEFAULT_FN_ATTRS
wasm_u16x8_extend_high_u8x16(v128_t __a) {
  return (v128_t) __builtin_convertvector(
      (__u8x8){((__u8x16)__a)[8], ((__u8x16)__a)[9], ((__u8x16)__a)[10],
               ((__u8x16)__a)[11], ((__u8x16)__a)[12], ((__u8x16)__a)[13],
               ((__u8x16)__a)[14], ((__u8x16)__a)[15]},
      __u16x8);
}

static __inline__ v128_t __DEFAULT_FN_ATTRS
wasm_i32x4_extend_low_i16x8(v128_t __a) {
  return (v128_t) __builtin_convertvector(
      (__i16x4){((__i16x8)__a)[0], ((__i16x8)__a)[1], ((__i16x8)__a)[2],
                ((__i16x8)__a)[3]},
      __i32x4);
}

static __inline__ v128_t __DEFAULT_FN_ATTRS
wasm_i32x4_extend_high_i16x8(v128_t __a) {
  return (v128_t) __builtin_convertvector(
      (__i16x4){((__i16x8)__a)[4], ((__i16x8)__a)[5], ((__i16x8)__a)[6],
                ((__i16x8)__a)[7]},
      __i32x4);
}

static __inline__ v128_t __DEFAULT_FN_ATTRS
wasm_u32x4_extend_low_u16x8(v128_t __a) {
  return (v128_t) __builtin_convertvector(
      (__u16x4){((__u16x8)__a)[0], ((__u16x8)__a)[1], ((__u16x8)__a)[2],
                ((__u16x8)__a)[3]},
      __u32x4);
}

static __inline__ v128_t __DEFAULT_FN_ATTRS
wasm_u32x4_extend_high_u16x8(v128_t __a) {
  return (v128_t) __builtin_convertvector(
      (__u16x4){((__u16x8)__a)[4], ((__u16x8)__a)[5], ((__u16x8)__a)[6],
                ((__u16x8)__a)[7]},
      __u32x4);
}

static __inline__ v128_t __DEFAULT_FN_ATTRS
wasm_i64x2_extend_low_i32x4(v128_t __a) {
  return (v128_t) __builtin_convertvector(
      (__i32x2){((__i32x4)__a)[0], ((__i32x4)__a)[1]}, __i64x2);
}

static __inline__ v128_t __DEFAULT_FN_ATTRS
wasm_i64x2_extend_high_i32x4(v128_t __a) {
  return (v128_t) __builtin_convertvector(
      (__i32x2){((__i32x4)__a)[2], ((__i32x4)__a)[3]}, __i64x2);
}

static __inline__ v128_t __DEFAULT_FN_ATTRS
wasm_u64x2_extend_low_u32x4(v128_t __a) {
  return (v128_t) __builtin_convertvector(
      (__u32x2){((__u32x4)__a)[0], ((__u32x4)__a)[1]}, __u64x2);
}

static __inline__ v128_t __DEFAULT_FN_ATTRS
wasm_u64x2_extend_high_u32x4(v128_t __a) {
  return (v128_t) __builtin_convertvector(
      (__u32x2){((__u32x4)__a)[2], ((__u32x4)__a)[3]}, __u64x2);
}

static __inline__ v128_t __DEFAULT_FN_ATTRS
wasm_i16x8_extadd_pairwise_i8x16(v128_t __a) {
  return (v128_t)__builtin_wasm_extadd_pairwise_i8x16_s_i16x8((__i8x16)__a);
}

static __inline__ v128_t __DEFAULT_FN_ATTRS
wasm_u16x8_extadd_pairwise_u8x16(v128_t __a) {
  return (v128_t)__builtin_wasm_extadd_pairwise_i8x16_u_i16x8((__u8x16)__a);
}

static __inline__ v128_t __DEFAULT_FN_ATTRS
wasm_i32x4_extadd_pairwise_i16x8(v128_t __a) {
  return (v128_t)__builtin_wasm_extadd_pairwise_i16x8_s_i32x4((__i16x8)__a);
}

static __inline__ v128_t __DEFAULT_FN_ATTRS
wasm_u32x4_extadd_pairwise_u16x8(v128_t __a) {
  return (v128_t)__builtin_wasm_extadd_pairwise_i16x8_u_i32x4((__u16x8)__a);
}

static __inline__ v128_t __DEFAULT_FN_ATTRS
wasm_i16x8_extmul_low_i8x16(v128_t __a, v128_t __b) {
  return (v128_t)((__i16x8)wasm_i16x8_extend_low_i8x16(__a) *
                  (__i16x8)wasm_i16x8_extend_low_i8x16(__b));
}

static __inline__ v128_t __DEFAULT_FN_ATTRS
wasm_i16x8_extmul_high_i8x16(v128_t __a, v128_t __b) {
  return (v128_t)((__i16x8)wasm_i16x8_extend_high_i8x16(__a) *
                  (__i16x8)wasm_i16x8_extend_high_i8x16(__b));
}

static __inline__ v128_t __DEFAULT_FN_ATTRS
wasm_u16x8_extmul_low_u8x16(v128_t __a, v128_t __b) {
  return (v128_t)((__u16x8)wasm_u16x8_extend_low_u8x16(__a) *
                  (__u16x8)wasm_u16x8_extend_low_u8x16(__b));
}

static __inline__ v128_t __DEFAULT_FN_ATTRS
wasm_u16x8_extmul_high_u8x16(v128_t __a, v128_t __b) {
  return (v128_t)((__u16x8)wasm_u16x8_extend_high_u8x16(__a) *
                  (__u16x8)wasm_u16x8_extend_high_u8x16(__b));
}

static __inline__ v128_t __DEFAULT_FN_ATTRS
wasm_i32x4_extmul_low_i16x8(v128_t __a, v128_t __b) {
  return (v128_t)((__i32x4)wasm_i32x4_extend_low_i16x8(__a) *
                  (__i32x4)wasm_i32x4_extend_low_i16x8(__b));
}

static __inline__ v128_t __DEFAULT_FN_ATTRS
wasm_i32x4_extmul_high_i16x8(v128_t __a, v128_t __b) {
  return (v128_t)((__i32x4)wasm_i32x4_extend_high_i16x8(__a) *
                  (__i32x4)wasm_i32x4_extend_high_i16x8(__b));
}

static __inline__ v128_t __DEFAULT_FN_ATTRS
wasm_u32x4_extmul_low_u16x8(v128_t __a, v128_t __b) {
  return (v128_t)((__u32x4)wasm_u32x4_extend_low_u16x8(__a) *
                  (__u32x4)wasm_u32x4_extend_low_u16x8(__b));
}

static __inline__ v128_t __DEFAULT_FN_ATTRS
wasm_u32x4_extmul_high_u16x8(v128_t __a, v128_t __b) {
  return (v128_t)((__u32x4)wasm_u32x4_extend_high_u16x8(__a) *
                  (__u32x4)wasm_u32x4_extend_high_u16x8(__b));
}

static __inline__ v128_t __DEFAULT_FN_ATTRS
wasm_i64x2_extmul_low_i32x4(v128_t __a, v128_t __b) {
  return (v128_t)((__i64x2)wasm_i64x2_extend_low_i32x4(__a) *
                  (__i64x2)wasm_i64x2_extend_low_i32x4(__b));
}

static __inline__ v128_t __DEFAULT_FN_ATTRS
wasm_i64x2_extmul_high_i32x4(v128_t __a, v128_t __b) {
  return (v128_t)((__i64x2)wasm_i64x2_extend_high_i32x4(__a) *
                  (__i64x2)wasm_i64x2_extend_high_i32x4(__b));
}

static __inline__ v128_t __DEFAULT_FN_ATTRS
wasm_u64x2_extmul_low_u32x4(v128_t __a, v128_t __b) {
  return (v128_t)((__u64x2)wasm_u64x2_extend_low_u32x4(__a) *
                  (__u64x2)wasm_u64x2_extend_low_u32x4(__b));
}

static __inline__ v128_t __DEFAULT_FN_ATTRS
wasm_u64x2_extmul_high_u32x4(v128_t __a, v128_t __b) {
  return (v128_t)((__u64x2)wasm_u64x2_extend_high_u32x4(__a) *
                  (__u64x2)wasm_u64x2_extend_high_u32x4(__b));
}

static __inline__ v128_t __DEFAULT_FN_ATTRS wasm_i16x8_q15mulr_sat(v128_t __a,
                                                                   v128_t __b) {
  return (v128_t)__builtin_wasm_q15mulr_sat_s_i16x8((__i16x8)__a, (__i16x8)__b);
}

// Old intrinsic names supported to ease transitioning to the standard names. Do
// not use these; they will be removed in the near future.

#define __DEPRECATED_FN_ATTRS(__replacement)                                   \\
  __DEFAULT_FN_ATTRS __attribute__(                                            \\
      (deprecated("use " __replacement " instead", __replacement)))

#define __WASM_STR(X) #X

#ifdef __DEPRECATED
#define __DEPRECATED_WASM_MACRO(__name, __replacement)                         \\
  _Pragma(__WASM_STR(GCC warning(                                              \\
      "'" __name "' is deprecated: use '" __replacement "' instead")))
#else
#define __DEPRECATED_WASM_MACRO(__name, __replacement)
#endif

static __inline__ v128_t __DEPRECATED_FN_ATTRS("wasm_v128_load8_splat")
wasm_v8x16_load_splat(const void *__mem) {
  return wasm_v128_load8_splat(__mem);
}

static __inline__ v128_t __DEPRECATED_FN_ATTRS("wasm_v128_load16_splat")
wasm_v16x8_load_splat(const void *__mem) {
  return wasm_v128_load16_splat(__mem);
}

static __inline__ v128_t __DEPRECATED_FN_ATTRS("wasm_v128_load32_splat")
wasm_v32x4_load_splat(const void *__mem) {
  return wasm_v128_load32_splat(__mem);
}

static __inline__ v128_t __DEPRECATED_FN_ATTRS("wasm_v128_load64_splat")
wasm_v64x2_load_splat(const void *__mem) {
  return wasm_v128_load64_splat(__mem);
}

static __inline__ v128_t __DEPRECATED_FN_ATTRS("wasm_i16x8_load8x8")
wasm_i16x8_load_8x8(const void *__mem) {
  return wasm_i16x8_load8x8(__mem);
}

static __inline__ v128_t __DEPRECATED_FN_ATTRS("wasm_u16x8_load8x8")
wasm_u16x8_load_8x8(const void *__mem) {
  return wasm_u16x8_load8x8(__mem);
}

static __inline__ v128_t __DEPRECATED_FN_ATTRS("wasm_i32x4_load16x4")
wasm_i32x4_load_16x4(const void *__mem) {
  return wasm_i32x4_load16x4(__mem);
}

static __inline__ v128_t __DEPRECATED_FN_ATTRS("wasm_u32x4_load16x4")
wasm_u32x4_load_16x4(const void *__mem) {
  return wasm_u32x4_load16x4(__mem);
}

static __inline__ v128_t __DEPRECATED_FN_ATTRS("wasm_i64x2_load32x2")
wasm_i64x2_load_32x2(const void *__mem) {
  return wasm_i64x2_load32x2(__mem);
}

static __inline__ v128_t __DEPRECATED_FN_ATTRS("wasm_u64x2_load32x2")
wasm_u64x2_load_32x2(const void *__mem) {
  return wasm_u64x2_load32x2(__mem);
}

#define wasm_v8x16_shuffle(__a, __b, __c0, __c1, __c2, __c3, __c4, __c5, __c6, \\
                           __c7, __c8, __c9, __c10, __c11, __c12, __c13,       \\
                           __c14, __c15)                                       \\
  __DEPRECATED_WASM_MACRO("wasm_v8x16_shuffle", "wasm_i8x16_shuffle")          \\
  wasm_i8x16_shuffle(__a, __b, __c0, __c1, __c2, __c3, __c4, __c5, __c6, __c7, \\
                     __c8, __c9, __c10, __c11, __c12, __c13, __c14, __c15)

#define wasm_v16x8_shuffle(__a, __b, __c0, __c1, __c2, __c3, __c4, __c5, __c6, \\
                           __c7)                                               \\
  __DEPRECATED_WASM_MACRO("wasm_v16x8_shuffle", "wasm_i16x8_shuffle")          \\
  wasm_i16x8_shuffle(__a, __b, __c0, __c1, __c2, __c3, __c4, __c5, __c6, __c7)

#define wasm_v32x4_shuffle(__a, __b, __c0, __c1, __c2, __c3)                   \\
  __DEPRECATED_WASM_MACRO("wasm_v32x4_shuffle", "wasm_i32x4_shuffle")          \\
  wasm_i32x4_shuffle(__a, __b, __c0, __c1, __c2, __c3)

#define wasm_v64x2_shuffle(__a, __b, __c0, __c1)                               \\
  __DEPRECATED_WASM_MACRO("wasm_v64x2_shuffle", "wasm_i64x2_shuffle")          \\
  wasm_i64x2_shuffle(__a, __b, __c0, __c1)

// Relaxed SIMD intrinsics

#define __RELAXED_FN_ATTRS                                                     \\
  __attribute__((__always_inline__, __nodebug__, __target__("relaxed-simd"),   \\
                 __min_vector_width__(128)))

static __inline__ v128_t __RELAXED_FN_ATTRS
wasm_f32x4_relaxed_madd(v128_t __a, v128_t __b, v128_t __c) {
  return (v128_t)__builtin_wasm_relaxed_madd_f32x4((__f32x4)__a, (__f32x4)__b,
                                                   (__f32x4)__c);
}

static __inline__ v128_t __RELAXED_FN_ATTRS
wasm_f32x4_relaxed_nmadd(v128_t __a, v128_t __b, v128_t __c) {
  return (v128_t)__builtin_wasm_relaxed_nmadd_f32x4((__f32x4)__a, (__f32x4)__b,
                                                    (__f32x4)__c);
}

static __inline__ v128_t __RELAXED_FN_ATTRS
wasm_f64x2_relaxed_madd(v128_t __a, v128_t __b, v128_t __c) {
  return (v128_t)__builtin_wasm_relaxed_madd_f64x2((__f64x2)__a, (__f64x2)__b,
                                                   (__f64x2)__c);
}

static __inline__ v128_t __RELAXED_FN_ATTRS
wasm_f64x2_relaxed_nmadd(v128_t __a, v128_t __b, v128_t __c) {
  return (v128_t)__builtin_wasm_relaxed_nmadd_f64x2((__f64x2)__a, (__f64x2)__b,
                                                    (__f64x2)__c);
}

static __inline__ v128_t __RELAXED_FN_ATTRS
wasm_i8x16_relaxed_laneselect(v128_t __a, v128_t __b, v128_t __m) {
  return (v128_t)__builtin_wasm_relaxed_laneselect_i8x16(
      (__i8x16)__a, (__i8x16)__b, (__i8x16)__m);
}

static __inline__ v128_t __RELAXED_FN_ATTRS
wasm_i16x8_relaxed_laneselect(v128_t __a, v128_t __b, v128_t __m) {
  return (v128_t)__builtin_wasm_relaxed_laneselect_i16x8(
      (__i16x8)__a, (__i16x8)__b, (__i16x8)__m);
}

static __inline__ v128_t __RELAXED_FN_ATTRS
wasm_i32x4_relaxed_laneselect(v128_t __a, v128_t __b, v128_t __m) {
  return (v128_t)__builtin_wasm_relaxed_laneselect_i32x4(
      (__i32x4)__a, (__i32x4)__b, (__i32x4)__m);
}

static __inline__ v128_t __RELAXED_FN_ATTRS
wasm_i64x2_relaxed_laneselect(v128_t __a, v128_t __b, v128_t __m) {
  return (v128_t)__builtin_wasm_relaxed_laneselect_i64x2(
      (__i64x2)__a, (__i64x2)__b, (__i64x2)__m);
}

static __inline__ v128_t __RELAXED_FN_ATTRS
wasm_i8x16_relaxed_swizzle(v128_t __a, v128_t __s) {
  return (v128_t)__builtin_wasm_relaxed_swizzle_i8x16((__i8x16)__a,
                                                      (__i8x16)__s);
}

static __inline__ v128_t __RELAXED_FN_ATTRS wasm_f32x4_relaxed_min(v128_t __a,
                                                                   v128_t __b) {
  return (v128_t)__builtin_wasm_relaxed_min_f32x4((__f32x4)__a, (__f32x4)__b);
}

static __inline__ v128_t __RELAXED_FN_ATTRS wasm_f32x4_relaxed_max(v128_t __a,
                                                                   v128_t __b) {
  return (v128_t)__builtin_wasm_relaxed_max_f32x4((__f32x4)__a, (__f32x4)__b);
}

static __inline__ v128_t __RELAXED_FN_ATTRS wasm_f64x2_relaxed_min(v128_t __a,
                                                                   v128_t __b) {
  return (v128_t)__builtin_wasm_relaxed_min_f64x2((__f64x2)__a, (__f64x2)__b);
}

static __inline__ v128_t __RELAXED_FN_ATTRS wasm_f64x2_relaxed_max(v128_t __a,
                                                                   v128_t __b) {
  return (v128_t)__builtin_wasm_relaxed_max_f64x2((__f64x2)__a, (__f64x2)__b);
}

static __inline__ v128_t __RELAXED_FN_ATTRS
wasm_i32x4_relaxed_trunc_f32x4(v128_t __a) {
  return (v128_t)__builtin_wasm_relaxed_trunc_s_i32x4_f32x4((__f32x4)__a);
}

static __inline__ v128_t __RELAXED_FN_ATTRS
wasm_u32x4_relaxed_trunc_f32x4(v128_t __a) {
  return (v128_t)__builtin_wasm_relaxed_trunc_u_i32x4_f32x4((__f32x4)__a);
}

static __inline__ v128_t __RELAXED_FN_ATTRS
wasm_i32x4_relaxed_trunc_f64x2_zero(v128_t __a) {
  return (v128_t)__builtin_wasm_relaxed_trunc_s_zero_i32x4_f64x2((__f64x2)__a);
}

static __inline__ v128_t __RELAXED_FN_ATTRS
wasm_u32x4_relaxed_trunc_f64x2_zero(v128_t __a) {
  return (v128_t)__builtin_wasm_relaxed_trunc_u_zero_i32x4_f64x2((__f64x2)__a);
}

static __inline__ v128_t __RELAXED_FN_ATTRS
wasm_i16x8_relaxed_q15mulr(v128_t __a, v128_t __b) {
  return (v128_t)__builtin_wasm_relaxed_q15mulr_s_i16x8((__i16x8)__a,
                                                        (__i16x8)__b);
}

static __inline__ v128_t __RELAXED_FN_ATTRS
wasm_i16x8_relaxed_dot_i8x16_i7x16(v128_t __a, v128_t __b) {
  return (v128_t)__builtin_wasm_relaxed_dot_i8x16_i7x16_s_i16x8((__i8x16)__a,
                                                                (__i8x16)__b);
}

static __inline__ v128_t __RELAXED_FN_ATTRS
wasm_i32x4_relaxed_dot_i8x16_i7x16_add(v128_t __a, v128_t __b, v128_t __c) {
  return (v128_t)__builtin_wasm_relaxed_dot_i8x16_i7x16_add_s_i32x4(
      (__i8x16)__a, (__i8x16)__b, (__i32x4)__c);
}

// FP16 intrinsics
#define __FP16_FN_ATTRS                                                        \\
  __attribute__((__always_inline__, __nodebug__, __target__("fp16"),           \\
                 __min_vector_width__(128)))

static __inline__ v128_t __FP16_FN_ATTRS wasm_f16x8_splat(float __a) {
  return (v128_t)__builtin_wasm_splat_f16x8(__a);
}

#ifdef __wasm_fp16__
// TODO Replace the following macros with regular C functions and use normal
// target-independent vector code like the other replace/extract instructions.

#define wasm_f16x8_extract_lane(__a, __i)                                      \\
  (__builtin_wasm_extract_lane_f16x8((__f16x8)(__a), __i))

#define wasm_f16x8_replace_lane(__a, __i, __b)                                 \\
  ((v128_t)__builtin_wasm_replace_lane_f16x8((__f16x8)(__a), __i, __b))

#endif

static __inline__ v128_t __FP16_FN_ATTRS wasm_f16x8_abs(v128_t __a) {
  return (v128_t)__builtin_wasm_abs_f16x8((__f16x8)__a);
}

static __inline__ v128_t __FP16_FN_ATTRS wasm_f16x8_neg(v128_t __a) {
  return (v128_t)(-(__f16x8)__a);
}

static __inline__ v128_t __FP16_FN_ATTRS wasm_f16x8_sqrt(v128_t __a) {
  return (v128_t)__builtin_wasm_sqrt_f16x8((__f16x8)__a);
}

static __inline__ v128_t __FP16_FN_ATTRS wasm_f16x8_ceil(v128_t __a) {
  return (v128_t)__builtin_wasm_ceil_f16x8((__f16x8)__a);
}

static __inline__ v128_t __FP16_FN_ATTRS wasm_f16x8_floor(v128_t __a) {
  return (v128_t)__builtin_wasm_floor_f16x8((__f16x8)__a);
}

static __inline__ v128_t __FP16_FN_ATTRS wasm_f16x8_trunc(v128_t __a) {
  return (v128_t)__builtin_wasm_trunc_f16x8((__f16x8)__a);
}

static __inline__ v128_t __FP16_FN_ATTRS wasm_f16x8_nearest(v128_t __a) {
  return (v128_t)__builtin_wasm_nearest_f16x8((__f16x8)__a);
}

static __inline__ v128_t __FP16_FN_ATTRS wasm_f16x8_eq(v128_t __a, v128_t __b) {
  return (v128_t)((__f16x8)__a == (__f16x8)__b);
}

static __inline__ v128_t __FP16_FN_ATTRS wasm_f16x8_ne(v128_t __a, v128_t __b) {
  return (v128_t)((__f16x8)__a != (__f16x8)__b);
}

static __inline__ v128_t __FP16_FN_ATTRS wasm_f16x8_lt(v128_t __a, v128_t __b) {
  return (v128_t)((__f16x8)__a < (__f16x8)__b);
}

static __inline__ v128_t __FP16_FN_ATTRS wasm_f16x8_gt(v128_t __a, v128_t __b) {
  return (v128_t)((__f16x8)__a > (__f16x8)__b);
}

static __inline__ v128_t __FP16_FN_ATTRS wasm_f16x8_le(v128_t __a, v128_t __b) {
  return (v128_t)((__f16x8)__a <= (__f16x8)__b);
}

static __inline__ v128_t __FP16_FN_ATTRS wasm_f16x8_ge(v128_t __a, v128_t __b) {
  return (v128_t)((__f16x8)__a >= (__f16x8)__b);
}

static __inline__ v128_t __FP16_FN_ATTRS wasm_f16x8_add(v128_t __a,
                                                        v128_t __b) {
  return (v128_t)((__f16x8)__a + (__f16x8)__b);
}

static __inline__ v128_t __FP16_FN_ATTRS wasm_f16x8_sub(v128_t __a,
                                                        v128_t __b) {
  return (v128_t)((__f16x8)__a - (__f16x8)__b);
}

static __inline__ v128_t __FP16_FN_ATTRS wasm_f16x8_mul(v128_t __a,
                                                        v128_t __b) {
  return (v128_t)((__f16x8)__a * (__f16x8)__b);
}

static __inline__ v128_t __FP16_FN_ATTRS wasm_f16x8_div(v128_t __a,
                                                        v128_t __b) {
  return (v128_t)((__f16x8)__a / (__f16x8)__b);
}

static __inline__ v128_t __FP16_FN_ATTRS wasm_f16x8_min(v128_t __a,
                                                        v128_t __b) {
  return (v128_t)__builtin_wasm_min_f16x8((__f16x8)__a, (__f16x8)__b);
}

static __inline__ v128_t __FP16_FN_ATTRS wasm_f16x8_max(v128_t __a,
                                                        v128_t __b) {
  return (v128_t)__builtin_wasm_max_f16x8((__f16x8)__a, (__f16x8)__b);
}

static __inline__ v128_t __FP16_FN_ATTRS wasm_f16x8_pmin(v128_t __a,
                                                         v128_t __b) {
  return (v128_t)__builtin_wasm_pmin_f16x8((__f16x8)__a, (__f16x8)__b);
}

static __inline__ v128_t __FP16_FN_ATTRS wasm_f16x8_pmax(v128_t __a,
                                                         v128_t __b) {
  return (v128_t)__builtin_wasm_pmax_f16x8((__f16x8)__a, (__f16x8)__b);
}

static __inline__ v128_t __FP16_FN_ATTRS
wasm_i16x8_trunc_sat_f16x8(v128_t __a) {
  return (v128_t)__builtin_wasm_trunc_saturate_s_i16x8_f16x8((__f16x8)__a);
}

static __inline__ v128_t __FP16_FN_ATTRS
wasm_u16x8_trunc_sat_f16x8(v128_t __a) {
  return (v128_t)__builtin_wasm_trunc_saturate_u_i16x8_f16x8((__f16x8)__a);
}

static __inline__ v128_t __FP16_FN_ATTRS wasm_f16x8_convert_i16x8(v128_t __a) {
  return (v128_t) __builtin_convertvector((__i16x8)__a, __f16x8);
}

static __inline__ v128_t __FP16_FN_ATTRS wasm_f16x8_convert_u16x8(v128_t __a) {
  return (v128_t) __builtin_convertvector((__u16x8)__a, __f16x8);
}

static __inline__ v128_t __FP16_FN_ATTRS wasm_f16x8_relaxed_madd(v128_t __a,
                                                                 v128_t __b,
                                                                 v128_t __c) {
  return (v128_t)__builtin_wasm_relaxed_madd_f16x8((__f16x8)__a, (__f16x8)__b,
                                                   (__f16x8)__c);
}

static __inline__ v128_t __FP16_FN_ATTRS wasm_f16x8_relaxed_nmadd(v128_t __a,
                                                                  v128_t __b,
                                                                  v128_t __c) {
  return (v128_t)__builtin_wasm_relaxed_nmadd_f16x8((__f16x8)__a, (__f16x8)__b,
                                                    (__f16x8)__c);
}

// Deprecated intrinsics

static __inline__ v128_t __DEPRECATED_FN_ATTRS("wasm_i8x16_swizzle")
wasm_v8x16_swizzle(v128_t __a, v128_t __b) {
  return wasm_i8x16_swizzle(__a, __b);
}

static __inline__ bool __DEPRECATED_FN_ATTRS("wasm_v128_any_true")
wasm_i8x16_any_true(v128_t __a) {
  return wasm_v128_any_true(__a);
}

static __inline__ bool __DEPRECATED_FN_ATTRS("wasm_v128_any_true")
wasm_i16x8_any_true(v128_t __a) {
  return wasm_v128_any_true(__a);
}

static __inline__ bool __DEPRECATED_FN_ATTRS("wasm_v128_any_true")
wasm_i32x4_any_true(v128_t __a) {
  return wasm_v128_any_true(__a);
}

static __inline__ v128_t __DEPRECATED_FN_ATTRS("wasm_i8x16_add_sat")
wasm_i8x16_add_saturate(v128_t __a, v128_t __b) {
  return wasm_i8x16_add_sat(__a, __b);
}

static __inline__ v128_t __DEPRECATED_FN_ATTRS("wasm_u8x16_add_sat")
wasm_u8x16_add_saturate(v128_t __a, v128_t __b) {
  return wasm_u8x16_add_sat(__a, __b);
}

static __inline__ v128_t __DEPRECATED_FN_ATTRS("wasm_i8x16_sub_sat")
wasm_i8x16_sub_saturate(v128_t __a, v128_t __b) {
  return wasm_i8x16_sub_sat(__a, __b);
}

static __inline__ v128_t __DEPRECATED_FN_ATTRS("wasm_u8x16_sub_sat")
wasm_u8x16_sub_saturate(v128_t __a, v128_t __b) {
  return wasm_u8x16_sub_sat(__a, __b);
}

static __inline__ v128_t __DEPRECATED_FN_ATTRS("wasm_i16x8_add_sat")
wasm_i16x8_add_saturate(v128_t __a, v128_t __b) {
  return wasm_i16x8_add_sat(__a, __b);
}

static __inline__ v128_t __DEPRECATED_FN_ATTRS("wasm_u16x8_add_sat")
wasm_u16x8_add_saturate(v128_t __a, v128_t __b) {
  return wasm_u16x8_add_sat(__a, __b);
}

static __inline__ v128_t __DEPRECATED_FN_ATTRS("wasm_i16x8_sub_sat")
wasm_i16x8_sub_saturate(v128_t __a, v128_t __b) {
  return wasm_i16x8_sub_sat(__a, __b);
}

static __inline__ v128_t __DEPRECATED_FN_ATTRS("wasm_u16x8_sub_sat")
wasm_u16x8_sub_saturate(v128_t __a, v128_t __b) {
  return wasm_u16x8_sub_sat(__a, __b);
}

static __inline__ v128_t __DEPRECATED_FN_ATTRS("wasm_i16x8_extend_low_i8x16")
wasm_i16x8_widen_low_i8x16(v128_t __a) {
  return wasm_i16x8_extend_low_i8x16(__a);
}

static __inline__ v128_t __DEPRECATED_FN_ATTRS("wasm_i16x8_extend_high_i8x16")
wasm_i16x8_widen_high_i8x16(v128_t __a) {
  return wasm_i16x8_extend_high_i8x16(__a);
}

static __inline__ v128_t __DEPRECATED_FN_ATTRS("wasm_u16x8_extend_low_u8x16")
wasm_i16x8_widen_low_u8x16(v128_t __a) {
  return wasm_u16x8_extend_low_u8x16(__a);
}

static __inline__ v128_t __DEPRECATED_FN_ATTRS("wasm_u16x8_extend_high_u8x16")
wasm_i16x8_widen_high_u8x16(v128_t __a) {
  return wasm_u16x8_extend_high_u8x16(__a);
}

static __inline__ v128_t __DEPRECATED_FN_ATTRS("wasm_i32x4_extend_low_i16x8")
wasm_i32x4_widen_low_i16x8(v128_t __a) {
  return wasm_i32x4_extend_low_i16x8(__a);
}

static __inline__ v128_t __DEPRECATED_FN_ATTRS("wasm_i32x4_extend_high_i16x8")
wasm_i32x4_widen_high_i16x8(v128_t __a) {
  return wasm_i32x4_extend_high_i16x8(__a);
}

static __inline__ v128_t __DEPRECATED_FN_ATTRS("wasm_u32x4_extend_low_u16x8")
wasm_i32x4_widen_low_u16x8(v128_t __a) {
  return wasm_u32x4_extend_low_u16x8(__a);
}

static __inline__ v128_t __DEPRECATED_FN_ATTRS("wasm_u32x4_extend_high_u16x8")
wasm_i32x4_widen_high_u16x8(v128_t __a) {
  return wasm_u32x4_extend_high_u16x8(__a);
}

static __inline__ v128_t __DEPRECATED_FN_ATTRS("wasm_i32x4_trunc_sat_f32x4")
wasm_i32x4_trunc_saturate_f32x4(v128_t __a) {
  return wasm_i32x4_trunc_sat_f32x4(__a);
}

static __inline__ v128_t __DEPRECATED_FN_ATTRS("wasm_u32x4_trunc_sat_f32x4")
wasm_u32x4_trunc_saturate_f32x4(v128_t __a) {
  return wasm_u32x4_trunc_sat_f32x4(__a);
}

// Undefine helper macros
#undef __DEFAULT_FN_ATTRS
#undef __DEPRECATED_FN_ATTRS

#endif // __WASM_SIMD128_H
`,"mm_malloc.h":`/*===---- mm_malloc.h - Allocating and Freeing Aligned Memory Blocks -------===
 *
 * Part of the LLVM Project, under the Apache License v2.0 with LLVM Exceptions.
 * See https://llvm.org/LICENSE.txt for license information.
 * SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception
 *
 *===-----------------------------------------------------------------------===
 */

#ifndef __MM_MALLOC_H
#define __MM_MALLOC_H

#include <stdlib.h>

#ifdef _WIN32
#include <malloc.h>
#else
#ifndef __cplusplus
extern int posix_memalign(void **__memptr, size_t __alignment, size_t __size);
#else
// Some systems (e.g. those with GNU libc) declare posix_memalign with an
// exception specifier. Via an "egregious workaround" in
// Sema::CheckEquivalentExceptionSpec, Clang accepts the following as a valid
// redeclaration of glibc's declaration.
extern "C" int posix_memalign(void **__memptr, size_t __alignment, size_t __size);
#endif
#endif

#if !(defined(_WIN32) && defined(_mm_malloc))
static __inline__ void *__attribute__((__always_inline__, __nodebug__,
                                       __malloc__, __alloc_size__(1),
                                       __alloc_align__(2)))
_mm_malloc(size_t __size, size_t __align) {
  if (__align == 1) {
    return malloc(__size);
  }

  if (!(__align & (__align - 1)) && __align < sizeof(void *))
    __align = sizeof(void *);

  void *__mallocedMemory;
#if defined(__MINGW32__)
  __mallocedMemory = __mingw_aligned_malloc(__size, __align);
#elif defined(_WIN32)
  __mallocedMemory = _aligned_malloc(__size, __align);
#else
  if (posix_memalign(&__mallocedMemory, __align, __size))
    return 0;
#endif

  return __mallocedMemory;
}

static __inline__ void __attribute__((__always_inline__, __nodebug__))
_mm_free(void *__p)
{
#if defined(__MINGW32__)
  __mingw_aligned_free(__p);
#elif defined(_WIN32)
  _aligned_free(__p);
#else
  free(__p);
#endif
}
#endif

#endif /* __MM_MALLOC_H */
`}),pe=`__wasm_idle_simd_target.h`;function me(e){return`${e.replace(/\/+$/,``)}/include/wasm-idle/simd`}function he(e=``,t=!0){let n=me(e);return[`-msimd128`,...de,`-include`,`${n}/${pe}`,...t?[`-isystem`,n]:[]]}function ge(e,t=``){let n=me(t),r=n.split(`/`).filter(Boolean);for(let t=1;t<=r.length;t++)e.mkdirTree(`${n.startsWith(`/`)?`/`:``}${r.slice(0,t).join(`/`)}`);let i=new TextEncoder;e.mkdirTree(`${n}/emscripten`);for(let[t,r]of Object.entries(fe)){let a=t===`xmmintrin.h`?`emscripten/${t}`:t;e.writeFile(`${n}/${a}`,i.encode(r))}e.writeFile(`${n}/xmmintrin.h`,i.encode(`#ifndef __wasm_idle_xmmintrin_h__
#define __wasm_idle_xmmintrin_h__
#include "emscripten/xmmintrin.h"
#undef _mm_malloc
#undef _mm_free
#include <mm_malloc.h>
#endif
`)),e.writeFile(`${n}/x86intrin.h`,i.encode(`#ifndef __wasm_idle_x86intrin_h__
#define __wasm_idle_x86intrin_h__
/* Wasm compatibility for SSE through AVX2; native x86-only intrinsics are excluded. */
#include <immintrin.h>
#endif
`)),e.writeFile(`${n}/${pe}`,i.encode(`#ifndef __wasm_idle_simd_target_h__
#define __wasm_idle_simd_target_h__
#ifndef __wasm_simd128__
#undef __SSE__
#undef __SSE2__
#undef __SSE3__
#undef __SSSE3__
#undef __SSE4_1__
#undef __SSE4_2__
#undef __AVX__
#undef __AVX2__
#endif
#endif
`))}const _e=Object.freeze({"builtins.h":`/*===---- builtins.h - Standard header for extra builtins -----------------===*\\
 *
 * Part of the LLVM Project, under the Apache License v2.0 with LLVM Exceptions.
 * See https://llvm.org/LICENSE.txt for license information.
 * SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception
 *
\\*===----------------------------------------------------------------------===*/

/// Some legacy compilers have builtin definitions in a file named builtins.h.
/// This header file has been added to allow compatibility with code that was
/// written for those compilers. Code may have an include line for this file
/// and to avoid an error an empty file with this name is provided.
#ifndef __BUILTINS_H
#define __BUILTINS_H

#if defined(__MVS__) && __has_include_next(<builtins.h>)
#include_next <builtins.h>
#endif /* __MVS__ */
#endif /* __BUILTINS_H */
`,"float.h":`/*===---- float.h - Characteristics of floating point types ----------------===
 *
 * Part of the LLVM Project, under the Apache License v2.0 with LLVM Exceptions.
 * See https://llvm.org/LICENSE.txt for license information.
 * SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception
 *
 *===-----------------------------------------------------------------------===
 */

#if defined(__MVS__) && __has_include_next(<float.h>)
#include <__float_header_macro.h>
#include_next <float.h>
#else

#if !defined(__need_infinity_nan)
#define __need_float_float
#if (defined(__STDC_VERSION__) && __STDC_VERSION__ >= 202311L) ||              \\
    !defined(__STRICT_ANSI__)
#define __need_infinity_nan
#endif
#include <__float_header_macro.h>
#endif

#ifdef __need_float_float
/* If we're on MinGW, fall back to the system's float.h, which might have
 * additional definitions provided for Windows.
 * For more details see http://msdn.microsoft.com/en-us/library/y0ybw9fy.aspx
 *
 * Also fall back on AIX to allow additional definitions and
 * implementation-defined values.
 */
#if (defined(__MINGW32__) || defined(_MSC_VER) || defined(_AIX)) &&            \\
    __STDC_HOSTED__ && __has_include_next(<float.h>)

#  include_next <float.h>

#endif

#include <__float_float.h>
#undef __need_float_float
#endif

#ifdef __need_infinity_nan
#include <__float_infinity_nan.h>
#undef __need_infinity_nan
#endif

#endif /* __MVS__ */
`,"__float_float.h":`/*===---- __float_float.h --------------------------------------------------===
 *
 * Part of the LLVM Project, under the Apache License v2.0 with LLVM Exceptions.
 * See https://llvm.org/LICENSE.txt for license information.
 * SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception
 *
 *===-----------------------------------------------------------------------===
 */

#ifndef __CLANG_FLOAT_FLOAT_H
#define __CLANG_FLOAT_FLOAT_H

#if (defined(__MINGW32__) || defined(_MSC_VER) || defined(_AIX)) &&            \\
    __STDC_HOSTED__

/* Undefine anything that we'll be redefining below. */
#  undef FLT_EVAL_METHOD
#  undef FLT_ROUNDS
#  undef FLT_RADIX
#  undef FLT_MANT_DIG
#  undef DBL_MANT_DIG
#  undef LDBL_MANT_DIG
#if (defined(__STDC_VERSION__) && __STDC_VERSION__ >= 199901L) ||              \\
    !defined(__STRICT_ANSI__) ||                                               \\
    (defined(__cplusplus) && __cplusplus >= 201103L) ||                        \\
    (__STDC_HOSTED__ && defined(_AIX) && defined(_ALL_SOURCE))
#    undef DECIMAL_DIG
#  endif
#  undef FLT_DIG
#  undef DBL_DIG
#  undef LDBL_DIG
#  undef FLT_MIN_EXP
#  undef DBL_MIN_EXP
#  undef LDBL_MIN_EXP
#  undef FLT_MIN_10_EXP
#  undef DBL_MIN_10_EXP
#  undef LDBL_MIN_10_EXP
#  undef FLT_MAX_EXP
#  undef DBL_MAX_EXP
#  undef LDBL_MAX_EXP
#  undef FLT_MAX_10_EXP
#  undef DBL_MAX_10_EXP
#  undef LDBL_MAX_10_EXP
#  undef FLT_MAX
#  undef DBL_MAX
#  undef LDBL_MAX
#  undef FLT_EPSILON
#  undef DBL_EPSILON
#  undef LDBL_EPSILON
#  undef FLT_MIN
#  undef DBL_MIN
#  undef LDBL_MIN
#if (defined(__STDC_VERSION__) && __STDC_VERSION__ >= 201112L) ||              \\
    !defined(__STRICT_ANSI__) ||                                               \\
    (defined(__cplusplus) && __cplusplus >= 201703L) ||                        \\
    (__STDC_HOSTED__ && defined(_AIX) && defined(_ALL_SOURCE))
#    undef FLT_TRUE_MIN
#    undef DBL_TRUE_MIN
#    undef LDBL_TRUE_MIN
#    undef FLT_DECIMAL_DIG
#    undef DBL_DECIMAL_DIG
#    undef LDBL_DECIMAL_DIG
#    undef FLT_HAS_SUBNORM
#    undef DBL_HAS_SUBNORM
#    undef LDBL_HAS_SUBNORM
#  endif
#if (defined(__STDC_VERSION__) && __STDC_VERSION__ >= 202311L) ||              \\
    !defined(__STRICT_ANSI__)
#    undef FLT_NORM_MAX
#    undef DBL_NORM_MAX
#    undef LDBL_NORM_MAX
#endif
#endif

#if (defined(__STDC_VERSION__) && __STDC_VERSION__ >= 202311L) ||              \\
    !defined(__STRICT_ANSI__)
#  undef FLT_SNAN
#  undef DBL_SNAN
#  undef LDBL_SNAN
#endif

/* Characteristics of floating point types, C99 5.2.4.2.2 */

#if (defined(__STDC_VERSION__) && __STDC_VERSION__ >= 199901L) ||              \\
    (defined(__cplusplus) && __cplusplus >= 201103L)
#define FLT_EVAL_METHOD __FLT_EVAL_METHOD__
#endif
#define FLT_ROUNDS (__builtin_flt_rounds())
#define FLT_RADIX __FLT_RADIX__

#define FLT_MANT_DIG __FLT_MANT_DIG__
#define DBL_MANT_DIG __DBL_MANT_DIG__
#define LDBL_MANT_DIG __LDBL_MANT_DIG__

#if (defined(__STDC_VERSION__) && __STDC_VERSION__ >= 199901L) ||              \\
    !defined(__STRICT_ANSI__) ||                                               \\
    (defined(__cplusplus) && __cplusplus >= 201103L) ||                        \\
    (__STDC_HOSTED__ && defined(_AIX) && defined(_ALL_SOURCE))
#  define DECIMAL_DIG __DECIMAL_DIG__
#endif

#define FLT_DIG __FLT_DIG__
#define DBL_DIG __DBL_DIG__
#define LDBL_DIG __LDBL_DIG__

#define FLT_MIN_EXP __FLT_MIN_EXP__
#define DBL_MIN_EXP __DBL_MIN_EXP__
#define LDBL_MIN_EXP __LDBL_MIN_EXP__

#define FLT_MIN_10_EXP __FLT_MIN_10_EXP__
#define DBL_MIN_10_EXP __DBL_MIN_10_EXP__
#define LDBL_MIN_10_EXP __LDBL_MIN_10_EXP__

#define FLT_MAX_EXP __FLT_MAX_EXP__
#define DBL_MAX_EXP __DBL_MAX_EXP__
#define LDBL_MAX_EXP __LDBL_MAX_EXP__

#define FLT_MAX_10_EXP __FLT_MAX_10_EXP__
#define DBL_MAX_10_EXP __DBL_MAX_10_EXP__
#define LDBL_MAX_10_EXP __LDBL_MAX_10_EXP__

#define FLT_MAX __FLT_MAX__
#define DBL_MAX __DBL_MAX__
#define LDBL_MAX __LDBL_MAX__

#define FLT_EPSILON __FLT_EPSILON__
#define DBL_EPSILON __DBL_EPSILON__
#define LDBL_EPSILON __LDBL_EPSILON__

#define FLT_MIN __FLT_MIN__
#define DBL_MIN __DBL_MIN__
#define LDBL_MIN __LDBL_MIN__

#if (defined(__STDC_VERSION__) && __STDC_VERSION__ >= 201112L) ||              \\
    !defined(__STRICT_ANSI__) ||                                               \\
    (defined(__cplusplus) && __cplusplus >= 201703L) ||                        \\
    (__STDC_HOSTED__ && defined(_AIX) && defined(_ALL_SOURCE))
#  define FLT_TRUE_MIN __FLT_DENORM_MIN__
#  define DBL_TRUE_MIN __DBL_DENORM_MIN__
#  define LDBL_TRUE_MIN __LDBL_DENORM_MIN__
#  define FLT_DECIMAL_DIG __FLT_DECIMAL_DIG__
#  define DBL_DECIMAL_DIG __DBL_DECIMAL_DIG__
#  define LDBL_DECIMAL_DIG __LDBL_DECIMAL_DIG__
#  define FLT_HAS_SUBNORM __FLT_HAS_DENORM__
#  define DBL_HAS_SUBNORM __DBL_HAS_DENORM__
#  define LDBL_HAS_SUBNORM __LDBL_HAS_DENORM__
#endif

#if (defined(__STDC_VERSION__) && __STDC_VERSION__ >= 202311L) ||              \\
    !defined(__STRICT_ANSI__)
   /* C23 5.2.5.3.2p28 */
#  define FLT_SNAN (__builtin_nansf(""))
#  define DBL_SNAN (__builtin_nans(""))
#  define LDBL_SNAN (__builtin_nansl(""))

   /* C23 5.2.5.3.3p32 */
#  define FLT_NORM_MAX __FLT_NORM_MAX__
#  define DBL_NORM_MAX __DBL_NORM_MAX__
#  define LDBL_NORM_MAX __LDBL_NORM_MAX__
#endif

#ifdef __STDC_WANT_IEC_60559_TYPES_EXT__
#  define FLT16_MANT_DIG    __FLT16_MANT_DIG__
#  define FLT16_DECIMAL_DIG __FLT16_DECIMAL_DIG__
#  define FLT16_DIG         __FLT16_DIG__
#  define FLT16_MIN_EXP     __FLT16_MIN_EXP__
#  define FLT16_MIN_10_EXP  __FLT16_MIN_10_EXP__
#  define FLT16_MAX_EXP     __FLT16_MAX_EXP__
#  define FLT16_MAX_10_EXP  __FLT16_MAX_10_EXP__
#  define FLT16_MAX         __FLT16_MAX__
#  define FLT16_EPSILON     __FLT16_EPSILON__
#  define FLT16_MIN         __FLT16_MIN__
#  define FLT16_TRUE_MIN    __FLT16_TRUE_MIN__
#endif /* __STDC_WANT_IEC_60559_TYPES_EXT__ */

#endif /* __CLANG_FLOAT_FLOAT_H */
`,"__float_header_macro.h":`/*===---- __float_header_macro.h -------------------------------------------===
 *
 * Part of the LLVM Project, under the Apache License v2.0 with LLVM Exceptions.
 * See https://llvm.org/LICENSE.txt for license information.
 * SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception
 *
 *===-----------------------------------------------------------------------===
 */

#ifndef __CLANG_FLOAT_H
#define __CLANG_FLOAT_H
#endif /* __CLANG_FLOAT_H */
`,"__float_infinity_nan.h":`/*===---- __float_infinity_nan.h -------------------------------------------===
 *
 * Part of the LLVM Project, under the Apache License v2.0 with LLVM Exceptions.
 * See https://llvm.org/LICENSE.txt for license information.
 * SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception
 *
 *===-----------------------------------------------------------------------===
 */

#ifndef __CLANG_FLOAT_INFINITY_NAN_H
#define __CLANG_FLOAT_INFINITY_NAN_H

/* C23 5.2.5.3.3p29-30 */
#undef INFINITY
#undef NAN

#define INFINITY (__builtin_inff())
#define NAN (__builtin_nanf(""))

#endif /* __CLANG_FLOAT_INFINITY_NAN_H */
`,"inttypes.h":`/*===---- inttypes.h - Standard header for integer printf macros ----------===*\\
 *
 * Part of the LLVM Project, under the Apache License v2.0 with LLVM Exceptions.
 * See https://llvm.org/LICENSE.txt for license information.
 * SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception
 *
\\*===----------------------------------------------------------------------===*/

#ifndef __CLANG_INTTYPES_H
// AIX system headers need inttypes.h to be re-enterable while _STD_TYPES_T
// is defined until an inclusion of it without _STD_TYPES_T occurs, in which
// case the header guard macro is defined.
#if !defined(_AIX) || !defined(_STD_TYPES_T)
#define __CLANG_INTTYPES_H
#endif
#if defined(__MVS__) && __has_include_next(<inttypes.h>)
#include_next <inttypes.h>
#else

#if defined(_MSC_VER) && _MSC_VER < 1800
#error MSVC does not have inttypes.h prior to Visual Studio 2013
#endif

#include_next <inttypes.h>

#if defined(_MSC_VER) && _MSC_VER < 1900
/* MSVC headers define int32_t as int, but PRIx32 as "lx" instead of "x".
 * This triggers format warnings, so fix it up here. */
#undef PRId32
#undef PRIdLEAST32
#undef PRIdFAST32
#undef PRIi32
#undef PRIiLEAST32
#undef PRIiFAST32
#undef PRIo32
#undef PRIoLEAST32
#undef PRIoFAST32
#undef PRIu32
#undef PRIuLEAST32
#undef PRIuFAST32
#undef PRIx32
#undef PRIxLEAST32
#undef PRIxFAST32
#undef PRIX32
#undef PRIXLEAST32
#undef PRIXFAST32

#undef SCNd32
#undef SCNdLEAST32
#undef SCNdFAST32
#undef SCNi32
#undef SCNiLEAST32
#undef SCNiFAST32
#undef SCNo32
#undef SCNoLEAST32
#undef SCNoFAST32
#undef SCNu32
#undef SCNuLEAST32
#undef SCNuFAST32
#undef SCNx32
#undef SCNxLEAST32
#undef SCNxFAST32

#define PRId32 "d"
#define PRIdLEAST32 "d"
#define PRIdFAST32 "d"
#define PRIi32 "i"
#define PRIiLEAST32 "i"
#define PRIiFAST32 "i"
#define PRIo32 "o"
#define PRIoLEAST32 "o"
#define PRIoFAST32 "o"
#define PRIu32 "u"
#define PRIuLEAST32 "u"
#define PRIuFAST32 "u"
#define PRIx32 "x"
#define PRIxLEAST32 "x"
#define PRIxFAST32 "x"
#define PRIX32 "X"
#define PRIXLEAST32 "X"
#define PRIXFAST32 "X"

#define SCNd32 "d"
#define SCNdLEAST32 "d"
#define SCNdFAST32 "d"
#define SCNi32 "i"
#define SCNiLEAST32 "i"
#define SCNiFAST32 "i"
#define SCNo32 "o"
#define SCNoLEAST32 "o"
#define SCNoFAST32 "o"
#define SCNu32 "u"
#define SCNuLEAST32 "u"
#define SCNuFAST32 "u"
#define SCNx32 "x"
#define SCNxLEAST32 "x"
#define SCNxFAST32 "x"
#endif

#endif /* __MVS__ */
#endif /* __CLANG_INTTYPES_H */
`,"iso646.h":`/*===---- iso646.h - Standard header for alternate spellings of operators---===
 *
 * Part of the LLVM Project, under the Apache License v2.0 with LLVM Exceptions.
 * See https://llvm.org/LICENSE.txt for license information.
 * SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception
 *
 *===-----------------------------------------------------------------------===
 */

#ifndef __ISO646_H
#define __ISO646_H
#if defined(__MVS__) && __has_include_next(<iso646.h>)
#include_next <iso646.h>
#else

#ifndef __cplusplus
#define and    &&
#define and_eq &=
#define bitand &
#define bitor  |
#define compl  ~
#define not    !
#define not_eq !=
#define or     ||
#define or_eq  |=
#define xor    ^
#define xor_eq ^=
#endif

#endif /* __MVS__ */
#endif /* __ISO646_H */
`,"limits.h":`/*===---- limits.h - Standard header for integer sizes --------------------===*\\
 *
 * Part of the LLVM Project, under the Apache License v2.0 with LLVM Exceptions.
 * See https://llvm.org/LICENSE.txt for license information.
 * SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception
 *
\\*===----------------------------------------------------------------------===*/

#ifndef __CLANG_LIMITS_H
#define __CLANG_LIMITS_H

#if defined(__MVS__) && __has_include_next(<limits.h>)
#include_next <limits.h>
#else

/* The system's limits.h may, in turn, try to #include_next GCC's limits.h.
   Avert this #include_next madness. */
#if defined __GNUC__ && !defined _GCC_LIMITS_H_
#define _GCC_LIMITS_H_
#endif

/* System headers include a number of constants from POSIX in <limits.h>.
   Include it if we're hosted. */
#if __STDC_HOSTED__ && __has_include_next(<limits.h>)
#include_next <limits.h>
#endif

/* Many system headers try to "help us out" by defining these.  No really, we
   know how big each datatype is. */
#undef  SCHAR_MIN
#undef  SCHAR_MAX
#undef  UCHAR_MAX
#undef  SHRT_MIN
#undef  SHRT_MAX
#undef  USHRT_MAX
#undef  INT_MIN
#undef  INT_MAX
#undef  UINT_MAX
#undef  LONG_MIN
#undef  LONG_MAX
#undef  ULONG_MAX

#undef  CHAR_BIT
#undef  CHAR_MIN
#undef  CHAR_MAX

/* C90/99 5.2.4.2.1 */
#define SCHAR_MAX __SCHAR_MAX__
#define SHRT_MAX  __SHRT_MAX__
#define INT_MAX   __INT_MAX__
#define LONG_MAX  __LONG_MAX__

#define SCHAR_MIN (-__SCHAR_MAX__-1)
#define SHRT_MIN  (-__SHRT_MAX__ -1)
#define INT_MIN   (-__INT_MAX__  -1)
#define LONG_MIN  (-__LONG_MAX__ -1L)

#define UCHAR_MAX (__SCHAR_MAX__*2  +1)
#if __SHRT_WIDTH__ < __INT_WIDTH__
#define USHRT_MAX (__SHRT_MAX__ * 2 + 1)
#else
#define USHRT_MAX (__SHRT_MAX__ * 2U + 1U)
#endif
#define UINT_MAX  (__INT_MAX__  *2U +1U)
#define ULONG_MAX (__LONG_MAX__ *2UL+1UL)

#ifndef MB_LEN_MAX
#define MB_LEN_MAX 1
#endif

#define CHAR_BIT  __CHAR_BIT__

/* C23 5.2.4.2.1 */
#if defined(__STDC_VERSION__) && __STDC_VERSION__ >= 202311L
#define BOOL_WIDTH   __BOOL_WIDTH__
#define CHAR_WIDTH   CHAR_BIT
#define SCHAR_WIDTH  CHAR_BIT
#define UCHAR_WIDTH  CHAR_BIT
#define USHRT_WIDTH  __SHRT_WIDTH__
#define SHRT_WIDTH   __SHRT_WIDTH__
#define UINT_WIDTH   __INT_WIDTH__
#define INT_WIDTH    __INT_WIDTH__
#define ULONG_WIDTH  __LONG_WIDTH__
#define LONG_WIDTH   __LONG_WIDTH__
#define ULLONG_WIDTH __LLONG_WIDTH__
#define LLONG_WIDTH  __LLONG_WIDTH__

#define BITINT_MAXWIDTH __BITINT_MAXWIDTH__
#endif

#ifdef __CHAR_UNSIGNED__  /* -funsigned-char */
#define CHAR_MIN 0
#define CHAR_MAX UCHAR_MAX
#else
#define CHAR_MIN SCHAR_MIN
#define CHAR_MAX __SCHAR_MAX__
#endif

/* C99 5.2.4.2.1: Added long long.
   C++11 18.3.3.2: same contents as the Standard C Library header <limits.h>.
 */
#if (defined(__STDC_VERSION__) && __STDC_VERSION__ >= 199901L) ||              \\
    (defined(__cplusplus) && __cplusplus >= 201103L)

#undef  LLONG_MIN
#undef  LLONG_MAX
#undef  ULLONG_MAX

#define LLONG_MAX  __LONG_LONG_MAX__
#define LLONG_MIN  (-__LONG_LONG_MAX__-1LL)
#define ULLONG_MAX (__LONG_LONG_MAX__*2ULL+1ULL)
#endif

/* LONG_LONG_MIN/LONG_LONG_MAX/ULONG_LONG_MAX are a GNU extension. Android's
   bionic also defines them. It's too bad that we don't have something like
   #pragma poison that could be used to deprecate a macro - the code should just
   use LLONG_MAX and friends.
 */
#if (defined(__GNU_LIBRARY__) ? defined(__USE_GNU)                             \\
                              : !defined(__STRICT_ANSI__)) ||                  \\
    defined(__BIONIC__)

#undef   LONG_LONG_MIN
#undef   LONG_LONG_MAX
#undef   ULONG_LONG_MAX

#define LONG_LONG_MAX  __LONG_LONG_MAX__
#define LONG_LONG_MIN  (-__LONG_LONG_MAX__-1LL)
#define ULONG_LONG_MAX (__LONG_LONG_MAX__*2ULL+1ULL)
#endif

#endif /* __MVS__ */
#endif /* __CLANG_LIMITS_H */
`,"stdalign.h":`/*===---- stdalign.h - Standard header for alignment ------------------------===
 *
 * Part of the LLVM Project, under the Apache License v2.0 with LLVM Exceptions.
 * See https://llvm.org/LICENSE.txt for license information.
 * SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception
 *
 *===-----------------------------------------------------------------------===
 */

#ifndef __STDALIGN_H
#define __STDALIGN_H

#if defined(__cplusplus) ||                                                    \\
    (defined(__STDC_VERSION__) && __STDC_VERSION__ < 202311L)
#ifndef __cplusplus
#define alignas _Alignas
#define alignof _Alignof
#endif

#define __alignas_is_defined 1
#define __alignof_is_defined 1
#endif /* __STDC_VERSION__ */

#endif /* __STDALIGN_H */
`,"stdarg.h":`/*===---- stdarg.h - Variable argument handling ----------------------------===
 *
 * Part of the LLVM Project, under the Apache License v2.0 with LLVM Exceptions.
 * See https://llvm.org/LICENSE.txt for license information.
 * SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception
 *
 *===-----------------------------------------------------------------------===
 */

/*
 * This header is designed to be included multiple times. If any of the __need_
 * macros are defined, then only that subset of interfaces are provided. This
 * can be useful for POSIX headers that need to not expose all of stdarg.h, but
 * need to use some of its interfaces. Otherwise this header provides all of
 * the expected interfaces.
 *
 * When clang modules are enabled, this header is a textual header to support
 * the multiple include behavior. As such, it doesn't directly declare anything
 * so that it doesn't add duplicate declarations to all of its includers'
 * modules.
 */
#if defined(__MVS__) && __has_include_next(<stdarg.h>)
#undef __need___va_list
#undef __need_va_list
#undef __need_va_arg
#undef __need___va_copy
#undef __need_va_copy
#include <__stdarg_header_macro.h>
#include_next <stdarg.h>

#else
#if !defined(__need___va_list) && !defined(__need_va_list) &&                  \\
    !defined(__need_va_arg) && !defined(__need___va_copy) &&                   \\
    !defined(__need_va_copy)
#define __need___va_list
#define __need_va_list
#define __need_va_arg
#define __need___va_copy
/* GCC always defines __va_copy, but does not define va_copy unless in c99 mode
 * or -ansi is not specified, since it was not part of C90.
 */
#if (defined(__STDC_VERSION__) && __STDC_VERSION__ >= 199901L) ||              \\
    (defined(__cplusplus) && __cplusplus >= 201103L) ||                        \\
    !defined(__STRICT_ANSI__)
#define __need_va_copy
#endif
#include <__stdarg_header_macro.h>
#endif

#ifdef __need___va_list
#include <__stdarg___gnuc_va_list.h>
#undef __need___va_list
#endif /* defined(__need___va_list) */

#ifdef __need_va_list
#include <__stdarg_va_list.h>
#undef __need_va_list
#endif /* defined(__need_va_list) */

#ifdef __need_va_arg
#include <__stdarg_va_arg.h>
#undef __need_va_arg
#endif /* defined(__need_va_arg) */

#ifdef __need___va_copy
#include <__stdarg___va_copy.h>
#undef __need___va_copy
#endif /* defined(__need___va_copy) */

#ifdef __need_va_copy
#include <__stdarg_va_copy.h>
#undef __need_va_copy
#endif /* defined(__need_va_copy) */

#endif /* __MVS__ */
`,"__stdarg___gnuc_va_list.h":`/*===---- __stdarg___gnuc_va_list.h - Definition of __gnuc_va_list ---------===
 *
 * Part of the LLVM Project, under the Apache License v2.0 with LLVM Exceptions.
 * See https://llvm.org/LICENSE.txt for license information.
 * SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception
 *
 *===-----------------------------------------------------------------------===
 */

#ifndef __GNUC_VA_LIST
#define __GNUC_VA_LIST
typedef __builtin_va_list __gnuc_va_list;
#endif
`,"__stdarg___va_copy.h":`/*===---- __stdarg___va_copy.h - Definition of __va_copy -------------------===
 *
 * Part of the LLVM Project, under the Apache License v2.0 with LLVM Exceptions.
 * See https://llvm.org/LICENSE.txt for license information.
 * SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception
 *
 *===-----------------------------------------------------------------------===
 */

#ifndef __va_copy
#define __va_copy(d, s) __builtin_va_copy(d, s)
#endif
`,"__stdarg_header_macro.h":`/*===---- __stdarg_header_macro.h ------------------------------------------===
 *
 * Part of the LLVM Project, under the Apache License v2.0 with LLVM Exceptions.
 * See https://llvm.org/LICENSE.txt for license information.
 * SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception
 *
 *===-----------------------------------------------------------------------===
 */

#ifndef __STDARG_H
#define __STDARG_H
#endif
`,"__stdarg_va_arg.h":`/*===---- __stdarg_va_arg.h - Definitions of va_start, va_arg, va_end-------===
 *
 * Part of the LLVM Project, under the Apache License v2.0 with LLVM Exceptions.
 * See https://llvm.org/LICENSE.txt for license information.
 * SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception
 *
 *===-----------------------------------------------------------------------===
 */

#ifndef va_arg

#if defined(__STDC_VERSION__) && __STDC_VERSION__ >= 202311L
/* C23 uses a special builtin. */
#define va_start(...) __builtin_c23_va_start(__VA_ARGS__)
#else
/* Versions before C23 do require the second parameter. */
#define va_start(ap, param) __builtin_va_start(ap, param)
#endif
#define va_end(ap) __builtin_va_end(ap)
#define va_arg(ap, type) __builtin_va_arg(ap, type)

#endif
`,"__stdarg_va_copy.h":`/*===---- __stdarg_va_copy.h - Definition of va_copy------------------------===
 *
 * Part of the LLVM Project, under the Apache License v2.0 with LLVM Exceptions.
 * See https://llvm.org/LICENSE.txt for license information.
 * SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception
 *
 *===-----------------------------------------------------------------------===
 */

#ifndef va_copy
#define va_copy(dest, src) __builtin_va_copy(dest, src)
#endif
`,"__stdarg_va_list.h":`/*===---- __stdarg_va_list.h - Definition of va_list -----------------------===
 *
 * Part of the LLVM Project, under the Apache License v2.0 with LLVM Exceptions.
 * See https://llvm.org/LICENSE.txt for license information.
 * SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception
 *
 *===-----------------------------------------------------------------------===
 */

#ifndef _VA_LIST
#define _VA_LIST
typedef __builtin_va_list va_list;
#endif
`,"stdatomic.h":`/*===---- stdatomic.h - Standard header for atomic types and operations -----===
 *
 * Part of the LLVM Project, under the Apache License v2.0 with LLVM Exceptions.
 * See https://llvm.org/LICENSE.txt for license information.
 * SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception
 *
 *===-----------------------------------------------------------------------===
 */

#ifndef __CLANG_STDATOMIC_H
#define __CLANG_STDATOMIC_H

/* If we're hosted, fall back to the system's stdatomic.h. FreeBSD, for
 * example, already has a Clang-compatible stdatomic.h header.
 *
 * Exclude the MSVC path as well as the MSVC header as of the 14.31.30818
 * explicitly disallows \`stdatomic.h\` in the C mode via an \`#error\`.  Fallback
 * to the clang resource header until that is fully supported.  The
 * \`stdatomic.h\` header requires C++23 or newer.
 */
#if __STDC_HOSTED__ &&                                                         \\
    __has_include_next(<stdatomic.h>) &&                                       \\
    (!defined(_MSC_VER) || (defined(__cplusplus) && __cplusplus >= 202002L))
# include_next <stdatomic.h>
#else

#include <stddef.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

/* 7.17.1 Introduction */

#define ATOMIC_BOOL_LOCK_FREE       __CLANG_ATOMIC_BOOL_LOCK_FREE
#define ATOMIC_CHAR_LOCK_FREE       __CLANG_ATOMIC_CHAR_LOCK_FREE
#if defined(__STDC_VERSION__) && __STDC_VERSION__ >= 202311L
#define ATOMIC_CHAR8_T_LOCK_FREE    __CLANG_ATOMIC_CHAR8_T_LOCK_FREE
#endif
#define ATOMIC_CHAR16_T_LOCK_FREE   __CLANG_ATOMIC_CHAR16_T_LOCK_FREE
#define ATOMIC_CHAR32_T_LOCK_FREE   __CLANG_ATOMIC_CHAR32_T_LOCK_FREE
#define ATOMIC_WCHAR_T_LOCK_FREE    __CLANG_ATOMIC_WCHAR_T_LOCK_FREE
#define ATOMIC_SHORT_LOCK_FREE      __CLANG_ATOMIC_SHORT_LOCK_FREE
#define ATOMIC_INT_LOCK_FREE        __CLANG_ATOMIC_INT_LOCK_FREE
#define ATOMIC_LONG_LOCK_FREE       __CLANG_ATOMIC_LONG_LOCK_FREE
#define ATOMIC_LLONG_LOCK_FREE      __CLANG_ATOMIC_LLONG_LOCK_FREE
#define ATOMIC_POINTER_LOCK_FREE    __CLANG_ATOMIC_POINTER_LOCK_FREE

/* 7.17.2 Initialization */
#if (defined(__STDC_VERSION__) && __STDC_VERSION__ < 202311L) ||               \\
    defined(__cplusplus)
/* ATOMIC_VAR_INIT was removed in C23, but still remains in C++23. */
#define ATOMIC_VAR_INIT(value) (value)
#endif

#if ((defined(__STDC_VERSION__) && __STDC_VERSION__ >= 201710L &&              \\
      __STDC_VERSION__ < 202311L) ||                                           \\
     (defined(__cplusplus) && __cplusplus >= 202002L)) &&                      \\
    !defined(_CLANG_DISABLE_CRT_DEPRECATION_WARNINGS)
/* ATOMIC_VAR_INIT was deprecated in C17 and C++20. */
#pragma clang deprecated(ATOMIC_VAR_INIT)
#endif
#define atomic_init __c11_atomic_init

/* 7.17.3 Order and consistency */

typedef enum memory_order {
  memory_order_relaxed = __ATOMIC_RELAXED,
  memory_order_consume = __ATOMIC_CONSUME,
  memory_order_acquire = __ATOMIC_ACQUIRE,
  memory_order_release = __ATOMIC_RELEASE,
  memory_order_acq_rel = __ATOMIC_ACQ_REL,
  memory_order_seq_cst = __ATOMIC_SEQ_CST
} memory_order;

#define kill_dependency(y) (y)

/* 7.17.4 Fences */

/* These should be provided by the libc implementation. */
void atomic_thread_fence(memory_order);
void atomic_signal_fence(memory_order);

#define atomic_thread_fence(order) __c11_atomic_thread_fence(order)
#define atomic_signal_fence(order) __c11_atomic_signal_fence(order)

/* 7.17.5 Lock-free property */

#define atomic_is_lock_free(obj) __c11_atomic_is_lock_free(sizeof(*(obj)))

/* 7.17.6 Atomic integer types */

#ifdef __cplusplus
typedef _Atomic(bool)               atomic_bool;
#else
typedef _Atomic(_Bool)              atomic_bool;
#endif
typedef _Atomic(char)               atomic_char;
typedef _Atomic(signed char)        atomic_schar;
typedef _Atomic(unsigned char)      atomic_uchar;
typedef _Atomic(short)              atomic_short;
typedef _Atomic(unsigned short)     atomic_ushort;
typedef _Atomic(int)                atomic_int;
typedef _Atomic(unsigned int)       atomic_uint;
typedef _Atomic(long)               atomic_long;
typedef _Atomic(unsigned long)      atomic_ulong;
typedef _Atomic(long long)          atomic_llong;
typedef _Atomic(unsigned long long) atomic_ullong;
#if defined(__STDC_VERSION__) && __STDC_VERSION__ >= 202311L
typedef _Atomic(unsigned char)      atomic_char8_t;
#endif
typedef _Atomic(uint_least16_t)     atomic_char16_t;
typedef _Atomic(uint_least32_t)     atomic_char32_t;
typedef _Atomic(wchar_t)            atomic_wchar_t;
typedef _Atomic(int_least8_t)       atomic_int_least8_t;
typedef _Atomic(uint_least8_t)      atomic_uint_least8_t;
typedef _Atomic(int_least16_t)      atomic_int_least16_t;
typedef _Atomic(uint_least16_t)     atomic_uint_least16_t;
typedef _Atomic(int_least32_t)      atomic_int_least32_t;
typedef _Atomic(uint_least32_t)     atomic_uint_least32_t;
typedef _Atomic(int_least64_t)      atomic_int_least64_t;
typedef _Atomic(uint_least64_t)     atomic_uint_least64_t;
typedef _Atomic(int_fast8_t)        atomic_int_fast8_t;
typedef _Atomic(uint_fast8_t)       atomic_uint_fast8_t;
typedef _Atomic(int_fast16_t)       atomic_int_fast16_t;
typedef _Atomic(uint_fast16_t)      atomic_uint_fast16_t;
typedef _Atomic(int_fast32_t)       atomic_int_fast32_t;
typedef _Atomic(uint_fast32_t)      atomic_uint_fast32_t;
typedef _Atomic(int_fast64_t)       atomic_int_fast64_t;
typedef _Atomic(uint_fast64_t)      atomic_uint_fast64_t;
typedef _Atomic(intptr_t)           atomic_intptr_t;
typedef _Atomic(uintptr_t)          atomic_uintptr_t;
typedef _Atomic(size_t)             atomic_size_t;
typedef _Atomic(ptrdiff_t)          atomic_ptrdiff_t;
typedef _Atomic(intmax_t)           atomic_intmax_t;
typedef _Atomic(uintmax_t)          atomic_uintmax_t;

/* 7.17.7 Operations on atomic types */

#define atomic_store(object, desired) __c11_atomic_store(object, desired, __ATOMIC_SEQ_CST)
#define atomic_store_explicit __c11_atomic_store

#define atomic_load(object) __c11_atomic_load(object, __ATOMIC_SEQ_CST)
#define atomic_load_explicit __c11_atomic_load

#define atomic_exchange(object, desired) __c11_atomic_exchange(object, desired, __ATOMIC_SEQ_CST)
#define atomic_exchange_explicit __c11_atomic_exchange

#define atomic_compare_exchange_strong(object, expected, desired) __c11_atomic_compare_exchange_strong(object, expected, desired, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST)
#define atomic_compare_exchange_strong_explicit __c11_atomic_compare_exchange_strong

#define atomic_compare_exchange_weak(object, expected, desired) __c11_atomic_compare_exchange_weak(object, expected, desired, __ATOMIC_SEQ_CST, __ATOMIC_SEQ_CST)
#define atomic_compare_exchange_weak_explicit __c11_atomic_compare_exchange_weak

#define atomic_fetch_add(object, operand) __c11_atomic_fetch_add(object, operand, __ATOMIC_SEQ_CST)
#define atomic_fetch_add_explicit __c11_atomic_fetch_add

#define atomic_fetch_sub(object, operand) __c11_atomic_fetch_sub(object, operand, __ATOMIC_SEQ_CST)
#define atomic_fetch_sub_explicit __c11_atomic_fetch_sub

#define atomic_fetch_or(object, operand) __c11_atomic_fetch_or(object, operand, __ATOMIC_SEQ_CST)
#define atomic_fetch_or_explicit __c11_atomic_fetch_or

#define atomic_fetch_xor(object, operand) __c11_atomic_fetch_xor(object, operand, __ATOMIC_SEQ_CST)
#define atomic_fetch_xor_explicit __c11_atomic_fetch_xor

#define atomic_fetch_and(object, operand) __c11_atomic_fetch_and(object, operand, __ATOMIC_SEQ_CST)
#define atomic_fetch_and_explicit __c11_atomic_fetch_and

/* 7.17.8 Atomic flag type and operations */

typedef struct atomic_flag { atomic_bool _Value; } atomic_flag;

#ifdef __cplusplus
#define ATOMIC_FLAG_INIT {false}
#else
#define ATOMIC_FLAG_INIT { 0 }
#endif

/* These should be provided by the libc implementation. */
#ifdef __cplusplus
bool atomic_flag_test_and_set(volatile atomic_flag *);
bool atomic_flag_test_and_set_explicit(volatile atomic_flag *, memory_order);
#else
_Bool atomic_flag_test_and_set(volatile atomic_flag *);
_Bool atomic_flag_test_and_set_explicit(volatile atomic_flag *, memory_order);
#endif
void atomic_flag_clear(volatile atomic_flag *);
void atomic_flag_clear_explicit(volatile atomic_flag *, memory_order);

#define atomic_flag_test_and_set(object) __c11_atomic_exchange(&(object)->_Value, 1, __ATOMIC_SEQ_CST)
#define atomic_flag_test_and_set_explicit(object, order) __c11_atomic_exchange(&(object)->_Value, 1, order)

#define atomic_flag_clear(object) __c11_atomic_store(&(object)->_Value, 0, __ATOMIC_SEQ_CST)
#define atomic_flag_clear_explicit(object, order) __c11_atomic_store(&(object)->_Value, 0, order)

#ifdef __cplusplus
}
#endif

#endif /* __STDC_HOSTED__ */
#endif /* __CLANG_STDATOMIC_H */

`,"stdbool.h":`/*===---- stdbool.h - Standard header for booleans -------------------------===
 *
 * Part of the LLVM Project, under the Apache License v2.0 with LLVM Exceptions.
 * See https://llvm.org/LICENSE.txt for license information.
 * SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception
 *
 *===-----------------------------------------------------------------------===
 */

#ifndef __STDBOOL_H
#define __STDBOOL_H

#define __bool_true_false_are_defined 1

#if defined(__MVS__) && __has_include_next(<stdbool.h>)
#include_next <stdbool.h>
#else

#if defined(__STDC_VERSION__) && __STDC_VERSION__ > 201710L
/* FIXME: We should be issuing a deprecation warning here, but cannot yet due
 * to system headers which include this header file unconditionally.
 */
#elif !defined(__cplusplus)
#define bool _Bool
#define true 1
#define false 0
#elif defined(__GNUC__) && !defined(__STRICT_ANSI__)
/* Define _Bool as a GNU extension. */
#define _Bool bool
#if defined(__cplusplus) && __cplusplus < 201103L
/* For C++98, define bool, false, true as a GNU extension. */
#define bool bool
#define false false
#define true true
#endif
#endif

#endif /* __MVS__ */
#endif /* __STDBOOL_H */
`,"stdcountof.h":`/*===---- stdcountof.h - Standard header for countof -----------------------===
 *
 * Part of the LLVM Project, under the Apache License v2.0 with LLVM Exceptions.
 * See https://llvm.org/LICENSE.txt for license information.
 * SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception
 *
 *===-----------------------------------------------------------------------===
 */

#ifndef __STDCOUNTOF_H
#define __STDCOUNTOF_H

#define countof _Countof

#endif /* __STDCOUNTOF_H */
`,"stdckdint.h":`/*===---- stdckdint.h - Standard header for checking integer----------------===
 *
 * Part of the LLVM Project, under the Apache License v2.0 with LLVM Exceptions.
 * See https://llvm.org/LICENSE.txt for license information.
 * SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception
 *
 *===-----------------------------------------------------------------------===
 */

#ifndef __STDCKDINT_H
#define __STDCKDINT_H

/* If we're hosted, fall back to the system's stdckdint.h. FreeBSD, for
 * example, already has a Clang-compatible stdckdint.h header.
 *
 * The \`stdckdint.h\` header requires C 23 or newer.
 */
#if __STDC_HOSTED__ && __has_include_next(<stdckdint.h>)
#include_next <stdckdint.h>
#else

/* C23 7.20.1 Defines several macros for performing checked integer arithmetic*/

#define __STDC_VERSION_STDCKDINT_H__ 202311L

// Both A and B shall be any integer type other than "plain" char, bool, a bit-
// precise integer type, or an enumerated type, and they need not be the same.

// R shall be a modifiable lvalue of any integer type other than "plain" char,
// bool, a bit-precise integer type, or an enumerated type. It shouldn't be
// short type, either. Otherwise, it may be unable to hold two the result of
// operating two 'int's.

// A diagnostic message will be produced if A or B are not suitable integer
// types, or if R is not a modifiable lvalue of a suitable integer type or R
// is short type.
#define ckd_add(R, A, B) __builtin_add_overflow((A), (B), (R))
#define ckd_sub(R, A, B) __builtin_sub_overflow((A), (B), (R))
#define ckd_mul(R, A, B) __builtin_mul_overflow((A), (B), (R))

#endif /* __STDC_HOSTED__ */
#endif /* __STDCKDINT_H */
`,"stddef.h":`/*===---- stddef.h - Basic type definitions --------------------------------===
 *
 * Part of the LLVM Project, under the Apache License v2.0 with LLVM Exceptions.
 * See https://llvm.org/LICENSE.txt for license information.
 * SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception
 *
 *===-----------------------------------------------------------------------===
 */

/*
 * This header is designed to be included multiple times. If any of the __need_
 * macros are defined, then only that subset of interfaces are provided. This
 * can be useful for POSIX headers that need to not expose all of stddef.h, but
 * need to use some of its interfaces. Otherwise this header provides all of
 * the expected interfaces.
 *
 * When clang modules are enabled, this header is a textual header to support
 * the multiple include behavior. As such, it doesn't directly declare anything
 * so that it doesn't add duplicate declarations to all of its includers'
 * modules.
 */
#if defined(__MVS__) && __has_include_next(<stddef.h>)
#undef __need_ptrdiff_t
#undef __need_size_t
#undef __need_rsize_t
#undef __need_wchar_t
#undef __need_NULL
#undef __need_nullptr_t
#undef __need_unreachable
#undef __need_max_align_t
#undef __need_offsetof
#undef __need_wint_t
#include <__stddef_header_macro.h>
#include_next <stddef.h>

#else

#if !defined(__need_ptrdiff_t) && !defined(__need_size_t) &&                   \\
    !defined(__need_rsize_t) && !defined(__need_wchar_t) &&                    \\
    !defined(__need_NULL) && !defined(__need_nullptr_t) &&                     \\
    !defined(__need_unreachable) && !defined(__need_max_align_t) &&            \\
    !defined(__need_offsetof) && !defined(__need_wint_t)
#define __need_ptrdiff_t
#define __need_size_t
/* ISO9899:2011 7.20 (C11 Annex K): Define rsize_t if __STDC_WANT_LIB_EXT1__ is
 * enabled. */
#if defined(__STDC_WANT_LIB_EXT1__) && __STDC_WANT_LIB_EXT1__ >= 1
#define __need_rsize_t
#endif
#define __need_wchar_t
#if !defined(__STDDEF_H) || __has_feature(modules)
/*
 * __stddef_null.h is special when building without modules: if __need_NULL is
 * set, then it will unconditionally redefine NULL. To avoid stepping on client
 * definitions of NULL, __need_NULL should only be set the first time this
 * header is included, that is when __STDDEF_H is not defined. However, when
 * building with modules, this header is a textual header and needs to
 * unconditionally include __stdef_null.h to support multiple submodules
 * exporting _Builtin_stddef.null. Take module SM with submodules A and B, whose
 * headers both include stddef.h When SM.A builds, __STDDEF_H will be defined.
 * When SM.B builds, the definition from SM.A will leak when building without
 * local submodule visibility. stddef.h wouldn't include __stddef_null.h, and
 * SM.B wouldn't import _Builtin_stddef.null, and SM.B's \`export *\` wouldn't
 * export NULL as expected. When building with modules, always include
 * __stddef_null.h so that everything works as expected.
 */
#define __need_NULL
#endif
#if (defined(__STDC_VERSION__) && __STDC_VERSION__ >= 202311L) ||              \\
    defined(__cplusplus)
#define __need_nullptr_t
#endif
#if defined(__STDC_VERSION__) && __STDC_VERSION__ >= 202311L
#define __need_unreachable
#endif
#if (defined(__STDC_VERSION__) && __STDC_VERSION__ >= 201112L) ||              \\
    (defined(__cplusplus) && __cplusplus >= 201103L)
#define __need_max_align_t
#endif
#define __need_offsetof
/* wint_t is provided by <wchar.h> and not <stddef.h>. It's here
 * for compatibility, but must be explicitly requested. Therefore
 * __need_wint_t is intentionally not defined here. */
#include <__stddef_header_macro.h>
#endif

#if defined(__need_ptrdiff_t)
#include <__stddef_ptrdiff_t.h>
#undef __need_ptrdiff_t
#endif /* defined(__need_ptrdiff_t) */

#if defined(__need_size_t)
#include <__stddef_size_t.h>
#undef __need_size_t
#endif /*defined(__need_size_t) */

#if defined(__need_rsize_t)
#include <__stddef_rsize_t.h>
#undef __need_rsize_t
#endif /* defined(__need_rsize_t) */

#if defined(__need_wchar_t)
#include <__stddef_wchar_t.h>
#undef __need_wchar_t
#endif /* defined(__need_wchar_t) */

#if defined(__need_NULL)
#include <__stddef_null.h>
#undef __need_NULL
#endif /* defined(__need_NULL) */

#if defined(__need_nullptr_t)
#include <__stddef_nullptr_t.h>
#undef __need_nullptr_t
#endif /* defined(__need_nullptr_t) */

#if defined(__need_unreachable)
#include <__stddef_unreachable.h>
#undef __need_unreachable
#endif /* defined(__need_unreachable) */

#if defined(__need_max_align_t)
#include <__stddef_max_align_t.h>
#undef __need_max_align_t
#endif /* defined(__need_max_align_t) */

#if defined(__need_offsetof)
#include <__stddef_offsetof.h>
#undef __need_offsetof
#endif /* defined(__need_offsetof) */

/* Some C libraries expect to see a wint_t here. Others (notably MinGW) will use
__WINT_TYPE__ directly; accommodate both by requiring __need_wint_t */
#if defined(__need_wint_t)
#include <__stddef_wint_t.h>
#undef __need_wint_t
#endif /* __need_wint_t */

#endif /* __MVS__ */
`,"stddefer.h":`/*===---- stddefer.h - Standard header for 'defer' -------------------------===
 *
 * Part of the LLVM Project, under the Apache License v2.0 with LLVM Exceptions.
 * See https://llvm.org/LICENSE.txt for license information.
 * SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception
 *
 *===-----------------------------------------------------------------------===
 */

#ifndef __CLANG_STDDEFER_H
#define __CLANG_STDDEFER_H

/* Provide 'defer' if '_Defer' is supported. */
#ifdef __STDC_DEFER_TS25755__
#define __STDC_VERSION_STDDEFER_H__ 202602L
#define defer _Defer
#endif

#endif /* __CLANG_STDDEFER_H */
`,"__stddef_header_macro.h":`/*===---- __stddef_header_macro.h ------------------------------------------===
 *
 * Part of the LLVM Project, under the Apache License v2.0 with LLVM Exceptions.
 * See https://llvm.org/LICENSE.txt for license information.
 * SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception
 *
 *===-----------------------------------------------------------------------===
 */

#ifndef __STDDEF_H
#define __STDDEF_H
#endif
`,"__stddef_max_align_t.h":`/*===---- __stddef_max_align_t.h - Definition of max_align_t ---------------===
 *
 * Part of the LLVM Project, under the Apache License v2.0 with LLVM Exceptions.
 * See https://llvm.org/LICENSE.txt for license information.
 * SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception
 *
 *===-----------------------------------------------------------------------===
 */

#ifndef __CLANG_MAX_ALIGN_T_DEFINED
#define __CLANG_MAX_ALIGN_T_DEFINED

#if defined(_MSC_VER)
typedef double max_align_t;
#elif defined(__APPLE__)
typedef long double max_align_t;
#else
// Define 'max_align_t' to match the GCC definition.
typedef struct {
  long long __clang_max_align_nonce1
      __attribute__((__aligned__(__alignof__(long long))));
  long double __clang_max_align_nonce2
      __attribute__((__aligned__(__alignof__(long double))));
} max_align_t;
#endif

#endif
`,"__stddef_null.h":`/*===---- __stddef_null.h - Definition of NULL -----------------------------===
 *
 * Part of the LLVM Project, under the Apache License v2.0 with LLVM Exceptions.
 * See https://llvm.org/LICENSE.txt for license information.
 * SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception
 *
 *===-----------------------------------------------------------------------===
 */

#if !defined(NULL) || !__building_module(_Builtin_stddef)

/* linux/stddef.h will define NULL to 0. glibc (and other) headers then define
 * __need_NULL and rely on stddef.h to redefine NULL to the correct value again.
 * Modules don't support redefining macros like that, but support that pattern
 * in the non-modules case.
 */
#undef NULL

#ifdef __cplusplus
#if !defined(__MINGW32__) && !defined(_MSC_VER)
#define NULL __null
#else
#define NULL 0
#endif
#else
#define NULL ((void*)0)
#endif

#endif
`,"__stddef_nullptr_t.h":`/*===---- __stddef_nullptr_t.h - Definition of nullptr_t -------------------===
 *
 * Part of the LLVM Project, under the Apache License v2.0 with LLVM Exceptions.
 * See https://llvm.org/LICENSE.txt for license information.
 * SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception
 *
 *===-----------------------------------------------------------------------===
 */

/*
 * When -fbuiltin-headers-in-system-modules is set this is a non-modular header
 * and needs to behave as if it was textual.
 */
#if !defined(_NULLPTR_T) ||                                                    \\
    (__has_feature(modules) && !__building_module(_Builtin_stddef))
#define _NULLPTR_T

#ifdef __cplusplus
#if defined(_MSC_EXTENSIONS) && defined(_NATIVE_NULLPTR_SUPPORTED)
namespace std {
typedef decltype(nullptr) nullptr_t;
}
using ::std::nullptr_t;
#endif
#elif defined(__STDC_VERSION__) && __STDC_VERSION__ >= 202311L
typedef typeof(nullptr) nullptr_t;
#endif

#endif
`,"__stddef_offsetof.h":`/*===---- __stddef_offsetof.h - Definition of offsetof ---------------------===
 *
 * Part of the LLVM Project, under the Apache License v2.0 with LLVM Exceptions.
 * See https://llvm.org/LICENSE.txt for license information.
 * SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception
 *
 *===-----------------------------------------------------------------------===
 */

/*
 * When -fbuiltin-headers-in-system-modules is set this is a non-modular header
 * and needs to behave as if it was textual.
 */
#if !defined(offsetof) ||                                                      \\
    (__has_feature(modules) && !__building_module(_Builtin_stddef))
#define offsetof(t, d) __builtin_offsetof(t, d)
#endif
`,"__stddef_ptrdiff_t.h":`/*===---- __stddef_ptrdiff_t.h - Definition of ptrdiff_t -------------------===
 *
 * Part of the LLVM Project, under the Apache License v2.0 with LLVM Exceptions.
 * See https://llvm.org/LICENSE.txt for license information.
 * SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception
 *
 *===-----------------------------------------------------------------------===
 */

/*
 * When -fbuiltin-headers-in-system-modules is set this is a non-modular header
 * and needs to behave as if it was textual.
 */
#if !defined(_PTRDIFF_T) ||                                                    \\
    (__has_feature(modules) && !__building_module(_Builtin_stddef))
#define _PTRDIFF_T

typedef __PTRDIFF_TYPE__ ptrdiff_t;

#endif
`,"__stddef_rsize_t.h":`/*===---- __stddef_rsize_t.h - Definition of rsize_t -----------------------===
 *
 * Part of the LLVM Project, under the Apache License v2.0 with LLVM Exceptions.
 * See https://llvm.org/LICENSE.txt for license information.
 * SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception
 *
 *===-----------------------------------------------------------------------===
 */

/*
 * When -fbuiltin-headers-in-system-modules is set this is a non-modular header
 * and needs to behave as if it was textual.
 */
#if !defined(_RSIZE_T) ||                                                      \\
    (__has_feature(modules) && !__building_module(_Builtin_stddef))
#define _RSIZE_T

typedef __SIZE_TYPE__ rsize_t;

#endif
`,"__stddef_size_t.h":`/*===---- __stddef_size_t.h - Definition of size_t -------------------------===
 *
 * Part of the LLVM Project, under the Apache License v2.0 with LLVM Exceptions.
 * See https://llvm.org/LICENSE.txt for license information.
 * SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception
 *
 *===-----------------------------------------------------------------------===
 */

/*
 * When -fbuiltin-headers-in-system-modules is set this is a non-modular header
 * and needs to behave as if it was textual.
 */
#if !defined(_SIZE_T) ||                                                       \\
    (__has_feature(modules) && !__building_module(_Builtin_stddef))
#define _SIZE_T

typedef __SIZE_TYPE__ size_t;

#endif
`,"__stddef_unreachable.h":`/*===---- __stddef_unreachable.h - Definition of unreachable ---------------===
 *
 * Part of the LLVM Project, under the Apache License v2.0 with LLVM Exceptions.
 * See https://llvm.org/LICENSE.txt for license information.
 * SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception
 *
 *===-----------------------------------------------------------------------===
 */

#ifndef __cplusplus

/*
 * When -fbuiltin-headers-in-system-modules is set this is a non-modular header
 * and needs to behave as if it was textual.
 */
#if !defined(unreachable) ||                                                   \\
    (__has_feature(modules) && !__building_module(_Builtin_stddef))
#define unreachable() __builtin_unreachable()
#endif

#endif
`,"__stddef_wchar_t.h":`/*===---- __stddef_wchar.h - Definition of wchar_t -------------------------===
 *
 * Part of the LLVM Project, under the Apache License v2.0 with LLVM Exceptions.
 * See https://llvm.org/LICENSE.txt for license information.
 * SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception
 *
 *===-----------------------------------------------------------------------===
 */

#if !defined(__cplusplus) || (defined(_MSC_VER) && !_NATIVE_WCHAR_T_DEFINED)

/*
 * When -fbuiltin-headers-in-system-modules is set this is a non-modular header
 * and needs to behave as if it was textual.
 */
#if !defined(_WCHAR_T) ||                                                      \\
    (__has_feature(modules) && !__building_module(_Builtin_stddef))
#define _WCHAR_T

#ifdef _MSC_EXTENSIONS
#define _WCHAR_T_DEFINED
#endif

typedef __WCHAR_TYPE__ wchar_t;

#endif

#endif
`,"__stddef_wint_t.h":`/*===---- __stddef_wint.h - Definition of wint_t ---------------------------===
 *
 * Part of the LLVM Project, under the Apache License v2.0 with LLVM Exceptions.
 * See https://llvm.org/LICENSE.txt for license information.
 * SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception
 *
 *===-----------------------------------------------------------------------===
 */

#ifndef _WINT_T
#define _WINT_T

typedef __WINT_TYPE__ wint_t;

#endif
`,"stdint.h":`/*===---- stdint.h - Standard header for sized integer types --------------===*\\
 *
 * Part of the LLVM Project, under the Apache License v2.0 with LLVM Exceptions.
 * See https://llvm.org/LICENSE.txt for license information.
 * SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception
 *
\\*===----------------------------------------------------------------------===*/

#ifndef __CLANG_STDINT_H
// AIX system headers need stdint.h to be re-enterable while _STD_TYPES_T
// is defined until an inclusion of it without _STD_TYPES_T occurs, in which
// case the header guard macro is defined.
#if !defined(_AIX) || !defined(_STD_TYPES_T) || !defined(__STDC_HOSTED__)
#define __CLANG_STDINT_H
#endif

#if defined(__MVS__) && __has_include_next(<stdint.h>)
#include_next <stdint.h>
#else

/* If we're hosted, fall back to the system's stdint.h, which might have
 * additional definitions.
 */
#if __STDC_HOSTED__ && __has_include_next(<stdint.h>)

// C99 7.18.3 Limits of other integer types
//
//  Footnote 219, 220: C++ implementations should define these macros only when
//  __STDC_LIMIT_MACROS is defined before <stdint.h> is included.
//
//  Footnote 222: C++ implementations should define these macros only when
//  __STDC_CONSTANT_MACROS is defined before <stdint.h> is included.
//
// C++11 [cstdint.syn]p2:
//
//  The macros defined by <cstdint> are provided unconditionally. In particular,
//  the symbols __STDC_LIMIT_MACROS and __STDC_CONSTANT_MACROS (mentioned in
//  footnotes 219, 220, and 222 in the C standard) play no role in C++.
//
// C11 removed the problematic footnotes.
//
// Work around this inconsistency by always defining those macros in C++ mode,
// so that a C library implementation which follows the C99 standard can be
// used in C++.
# ifdef __cplusplus
#  if !defined(__STDC_LIMIT_MACROS)
#   define __STDC_LIMIT_MACROS
#   define __STDC_LIMIT_MACROS_DEFINED_BY_CLANG
#  endif
#  if !defined(__STDC_CONSTANT_MACROS)
#   define __STDC_CONSTANT_MACROS
#   define __STDC_CONSTANT_MACROS_DEFINED_BY_CLANG
#  endif
# endif

# include_next <stdint.h>

# ifdef __STDC_LIMIT_MACROS_DEFINED_BY_CLANG
#  undef __STDC_LIMIT_MACROS
#  undef __STDC_LIMIT_MACROS_DEFINED_BY_CLANG
# endif
# ifdef __STDC_CONSTANT_MACROS_DEFINED_BY_CLANG
#  undef __STDC_CONSTANT_MACROS
#  undef __STDC_CONSTANT_MACROS_DEFINED_BY_CLANG
# endif

#else

/* C99 7.18.1.1 Exact-width integer types.
 * C99 7.18.1.2 Minimum-width integer types.
 * C99 7.18.1.3 Fastest minimum-width integer types.
 *
 * The standard requires that exact-width type be defined for 8-, 16-, 32-, and
 * 64-bit types if they are implemented. Other exact width types are optional.
 * This implementation defines an exact-width types for every integer width
 * that is represented in the standard integer types.
 *
 * The standard also requires minimum-width types be defined for 8-, 16-, 32-,
 * and 64-bit widths regardless of whether there are corresponding exact-width
 * types.
 *
 * To accommodate targets that are missing types that are exactly 8, 16, 32, or
 * 64 bits wide, this implementation takes an approach of cascading
 * redefinitions, redefining __int_leastN_t to successively smaller exact-width
 * types. It is therefore important that the types are defined in order of
 * descending widths.
 *
 * We currently assume that the minimum-width types and the fastest
 * minimum-width types are the same. This is allowed by the standard, but is
 * suboptimal.
 *
 * In violation of the standard, some targets do not implement a type that is
 * wide enough to represent all of the required widths (8-, 16-, 32-, 64-bit).
 * To accommodate these targets, a required minimum-width type is only
 * defined if there exists an exact-width type of equal or greater width.
 */

#ifdef __INT64_TYPE__
# ifndef __int8_t_defined /* glibc sys/types.h also defines int64_t*/
typedef __INT64_TYPE__ int64_t;
# endif /* __int8_t_defined */
typedef __UINT64_TYPE__ uint64_t;
# undef __int_least64_t
# define __int_least64_t int64_t
# undef __uint_least64_t
# define __uint_least64_t uint64_t
# undef __int_least32_t
# define __int_least32_t int64_t
# undef __uint_least32_t
# define __uint_least32_t uint64_t
# undef __int_least16_t
# define __int_least16_t int64_t
# undef __uint_least16_t
# define __uint_least16_t uint64_t
# undef __int_least8_t
# define __int_least8_t int64_t
# undef __uint_least8_t
# define __uint_least8_t uint64_t
#endif /* __INT64_TYPE__ */

#ifdef __int_least64_t
typedef __int_least64_t int_least64_t;
typedef __uint_least64_t uint_least64_t;
typedef __int_least64_t int_fast64_t;
typedef __uint_least64_t uint_fast64_t;
#endif /* __int_least64_t */

#ifdef __INT56_TYPE__
typedef __INT56_TYPE__ int56_t;
typedef __UINT56_TYPE__ uint56_t;
typedef int56_t int_least56_t;
typedef uint56_t uint_least56_t;
typedef int56_t int_fast56_t;
typedef uint56_t uint_fast56_t;
# undef __int_least32_t
# define __int_least32_t int56_t
# undef __uint_least32_t
# define __uint_least32_t uint56_t
# undef __int_least16_t
# define __int_least16_t int56_t
# undef __uint_least16_t
# define __uint_least16_t uint56_t
# undef __int_least8_t
# define __int_least8_t int56_t
# undef __uint_least8_t
# define __uint_least8_t uint56_t
#endif /* __INT56_TYPE__ */


#ifdef __INT48_TYPE__
typedef __INT48_TYPE__ int48_t;
typedef __UINT48_TYPE__ uint48_t;
typedef int48_t int_least48_t;
typedef uint48_t uint_least48_t;
typedef int48_t int_fast48_t;
typedef uint48_t uint_fast48_t;
# undef __int_least32_t
# define __int_least32_t int48_t
# undef __uint_least32_t
# define __uint_least32_t uint48_t
# undef __int_least16_t
# define __int_least16_t int48_t
# undef __uint_least16_t
# define __uint_least16_t uint48_t
# undef __int_least8_t
# define __int_least8_t int48_t
# undef __uint_least8_t
# define __uint_least8_t uint48_t
#endif /* __INT48_TYPE__ */


#ifdef __INT40_TYPE__
typedef __INT40_TYPE__ int40_t;
typedef __UINT40_TYPE__ uint40_t;
typedef int40_t int_least40_t;
typedef uint40_t uint_least40_t;
typedef int40_t int_fast40_t;
typedef uint40_t uint_fast40_t;
# undef __int_least32_t
# define __int_least32_t int40_t
# undef __uint_least32_t
# define __uint_least32_t uint40_t
# undef __int_least16_t
# define __int_least16_t int40_t
# undef __uint_least16_t
# define __uint_least16_t uint40_t
# undef __int_least8_t
# define __int_least8_t int40_t
# undef __uint_least8_t
# define __uint_least8_t uint40_t
#endif /* __INT40_TYPE__ */


#ifdef __INT32_TYPE__

# ifndef __int8_t_defined /* glibc sys/types.h also defines int32_t*/
typedef __INT32_TYPE__ int32_t;
# endif /* __int8_t_defined */

# ifndef __uint32_t_defined  /* more glibc compatibility */
# define __uint32_t_defined
typedef __UINT32_TYPE__ uint32_t;
# endif /* __uint32_t_defined */

# undef __int_least32_t
# define __int_least32_t int32_t
# undef __uint_least32_t
# define __uint_least32_t uint32_t
# undef __int_least16_t
# define __int_least16_t int32_t
# undef __uint_least16_t
# define __uint_least16_t uint32_t
# undef __int_least8_t
# define __int_least8_t int32_t
# undef __uint_least8_t
# define __uint_least8_t uint32_t
#endif /* __INT32_TYPE__ */

#ifdef __int_least32_t
typedef __int_least32_t int_least32_t;
typedef __uint_least32_t uint_least32_t;
typedef __int_least32_t int_fast32_t;
typedef __uint_least32_t uint_fast32_t;
#endif /* __int_least32_t */

#ifdef __INT24_TYPE__
typedef __INT24_TYPE__ int24_t;
typedef __UINT24_TYPE__ uint24_t;
typedef int24_t int_least24_t;
typedef uint24_t uint_least24_t;
typedef int24_t int_fast24_t;
typedef uint24_t uint_fast24_t;
# undef __int_least16_t
# define __int_least16_t int24_t
# undef __uint_least16_t
# define __uint_least16_t uint24_t
# undef __int_least8_t
# define __int_least8_t int24_t
# undef __uint_least8_t
# define __uint_least8_t uint24_t
#endif /* __INT24_TYPE__ */

#ifdef __INT16_TYPE__
#ifndef __int8_t_defined /* glibc sys/types.h also defines int16_t*/
typedef __INT16_TYPE__ int16_t;
#endif /* __int8_t_defined */
typedef __UINT16_TYPE__ uint16_t;
# undef __int_least16_t
# define __int_least16_t int16_t
# undef __uint_least16_t
# define __uint_least16_t uint16_t
# undef __int_least8_t
# define __int_least8_t int16_t
# undef __uint_least8_t
# define __uint_least8_t uint16_t
#endif /* __INT16_TYPE__ */

#ifdef __int_least16_t
typedef __int_least16_t int_least16_t;
typedef __uint_least16_t uint_least16_t;
typedef __int_least16_t int_fast16_t;
typedef __uint_least16_t uint_fast16_t;
#endif /* __int_least16_t */


#ifdef __INT8_TYPE__
#ifndef __int8_t_defined  /* glibc sys/types.h also defines int8_t*/
typedef __INT8_TYPE__ int8_t;
#endif /* __int8_t_defined */
typedef __UINT8_TYPE__ uint8_t;
# undef __int_least8_t
# define __int_least8_t int8_t
# undef __uint_least8_t
# define __uint_least8_t uint8_t
#endif /* __INT8_TYPE__ */

#ifdef __int_least8_t
typedef __int_least8_t int_least8_t;
typedef __uint_least8_t uint_least8_t;
typedef __int_least8_t int_fast8_t;
typedef __uint_least8_t uint_fast8_t;
#endif /* __int_least8_t */

/* prevent glibc sys/types.h from defining conflicting types */
#ifndef __int8_t_defined
# define __int8_t_defined
#endif /* __int8_t_defined */

/* C99 7.18.1.4 Integer types capable of holding object pointers.
 */
#define __stdint_join3(a,b,c) a ## b ## c

#ifndef _INTPTR_T
#ifndef __intptr_t_defined
typedef __INTPTR_TYPE__ intptr_t;
#define __intptr_t_defined
#define _INTPTR_T
#endif
#endif

#ifndef _UINTPTR_T
typedef __UINTPTR_TYPE__ uintptr_t;
#define _UINTPTR_T
#endif

/* C99 7.18.1.5 Greatest-width integer types.
 */
typedef __INTMAX_TYPE__  intmax_t;
typedef __UINTMAX_TYPE__ uintmax_t;

/* C99 7.18.4 Macros for minimum-width integer constants.
 *
 * The standard requires that integer constant macros be defined for all the
 * minimum-width types defined above. As 8-, 16-, 32-, and 64-bit minimum-width
 * types are required, the corresponding integer constant macros are defined
 * here. This implementation also defines minimum-width types for every other
 * integer width that the target implements, so corresponding macros are
 * defined below, too.
 *
 * Note that C++ should not check __STDC_CONSTANT_MACROS here, contrary to the
 * claims of the C standard (see C++ 18.3.1p2, [cstdint.syn]).
 */

#ifdef __int_least64_t
#define INT64_C(v) __INT64_C(v)
#define UINT64_C(v) __UINT64_C(v)
#endif /* __int_least64_t */


#ifdef __INT56_TYPE__
#define INT56_C(v) __INT56_C(v)
#define UINT56_C(v) __UINT56_C(v)
#endif /* __INT56_TYPE__ */


#ifdef __INT48_TYPE__
#define INT48_C(v) __INT48_C(v)
#define UINT48_C(v) __UINT48_C(v)
#endif /* __INT48_TYPE__ */


#ifdef __INT40_TYPE__
#define INT40_C(v) __INT40_C(v)
#define UINT40_C(v) __UINT40_C(v)
#endif /* __INT40_TYPE__ */


#ifdef __int_least32_t
#define INT32_C(v) __INT32_C(v)
#define UINT32_C(v) __UINT32_C(v)
#endif /* __int_least32_t */


#ifdef __INT24_TYPE__
#define INT24_C(v) __INT24_C(v)
#define UINT24_C(v) __UINT24_C(v)
#endif /* __INT24_TYPE__ */


#ifdef __int_least16_t
#define INT16_C(v) __INT16_C(v)
#define UINT16_C(v) __UINT16_C(v)
#endif /* __int_least16_t */


#ifdef __int_least8_t
#define INT8_C(v) __INT8_C(v)
#define UINT8_C(v) __UINT8_C(v)
#endif /* __int_least8_t */


/* C99 7.18.2.1 Limits of exact-width integer types.
 * C99 7.18.2.2 Limits of minimum-width integer types.
 * C99 7.18.2.3 Limits of fastest minimum-width integer types.
 *
 * The presence of limit macros are completely optional in C99.  This
 * implementation defines limits for all of the types (exact- and
 * minimum-width) that it defines above, using the limits of the minimum-width
 * type for any types that do not have exact-width representations.
 *
 * As in the type definitions, this section takes an approach of
 * successive-shrinking to determine which limits to use for the standard (8,
 * 16, 32, 64) bit widths when they don't have exact representations. It is
 * therefore important that the definitions be kept in order of decending
 * widths.
 *
 * Note that C++ should not check __STDC_LIMIT_MACROS here, contrary to the
 * claims of the C standard (see C++ 18.3.1p2, [cstdint.syn]).
 */

#ifdef __INT64_TYPE__
# define INT64_MAX           INT64_C( 9223372036854775807)
# define INT64_MIN         (-INT64_C( 9223372036854775807)-1)
# define UINT64_MAX         UINT64_C(18446744073709551615)

#if defined(__STDC_VERSION__) && __STDC_VERSION__ >= 202311L
# define UINT64_WIDTH         64
# define INT64_WIDTH          UINT64_WIDTH

# define __UINT_LEAST64_WIDTH UINT64_WIDTH
# undef __UINT_LEAST32_WIDTH
# define __UINT_LEAST32_WIDTH UINT64_WIDTH
# undef __UINT_LEAST16_WIDTH
# define __UINT_LEAST16_WIDTH UINT64_WIDTH
# undef __UINT_LEAST8_MAX
# define __UINT_LEAST8_MAX UINT64_MAX
#endif /* __STDC_VERSION__ */

# define __INT_LEAST64_MIN   INT64_MIN
# define __INT_LEAST64_MAX   INT64_MAX
# define __UINT_LEAST64_MAX UINT64_MAX
# undef __INT_LEAST32_MIN
# define __INT_LEAST32_MIN   INT64_MIN
# undef __INT_LEAST32_MAX
# define __INT_LEAST32_MAX   INT64_MAX
# undef __UINT_LEAST32_MAX
# define __UINT_LEAST32_MAX UINT64_MAX
# undef __INT_LEAST16_MIN
# define __INT_LEAST16_MIN   INT64_MIN
# undef __INT_LEAST16_MAX
# define __INT_LEAST16_MAX   INT64_MAX
# undef __UINT_LEAST16_MAX
# define __UINT_LEAST16_MAX UINT64_MAX
# undef __INT_LEAST8_MIN
# define __INT_LEAST8_MIN    INT64_MIN
# undef __INT_LEAST8_MAX
# define __INT_LEAST8_MAX    INT64_MAX
# undef __UINT_LEAST8_MAX
# define __UINT_LEAST8_MAX  UINT64_MAX
#endif /* __INT64_TYPE__ */

#ifdef __INT_LEAST64_MIN
# define INT_LEAST64_MIN   __INT_LEAST64_MIN
# define INT_LEAST64_MAX   __INT_LEAST64_MAX
# define UINT_LEAST64_MAX __UINT_LEAST64_MAX
# define INT_FAST64_MIN    __INT_LEAST64_MIN
# define INT_FAST64_MAX    __INT_LEAST64_MAX
# define UINT_FAST64_MAX  __UINT_LEAST64_MAX

#if defined(__STDC_VERSION__) &&  __STDC_VERSION__ >= 202311L
# define UINT_LEAST64_WIDTH __UINT_LEAST64_WIDTH
# define INT_LEAST64_WIDTH  UINT_LEAST64_WIDTH
# define UINT_FAST64_WIDTH  __UINT_LEAST64_WIDTH
# define INT_FAST64_WIDTH   UINT_FAST64_WIDTH
#endif /* __STDC_VERSION__ */
#endif /* __INT_LEAST64_MIN */


#ifdef __INT56_TYPE__
# define INT56_MAX           INT56_C(36028797018963967)
# define INT56_MIN         (-INT56_C(36028797018963967)-1)
# define UINT56_MAX         UINT56_C(72057594037927935)
# define INT_LEAST56_MIN     INT56_MIN
# define INT_LEAST56_MAX     INT56_MAX
# define UINT_LEAST56_MAX   UINT56_MAX
# define INT_FAST56_MIN      INT56_MIN
# define INT_FAST56_MAX      INT56_MAX
# define UINT_FAST56_MAX    UINT56_MAX

# undef __INT_LEAST32_MIN
# define __INT_LEAST32_MIN   INT56_MIN
# undef __INT_LEAST32_MAX
# define __INT_LEAST32_MAX   INT56_MAX
# undef __UINT_LEAST32_MAX
# define __UINT_LEAST32_MAX UINT56_MAX
# undef __INT_LEAST16_MIN
# define __INT_LEAST16_MIN   INT56_MIN
# undef __INT_LEAST16_MAX
# define __INT_LEAST16_MAX   INT56_MAX
# undef __UINT_LEAST16_MAX
# define __UINT_LEAST16_MAX UINT56_MAX
# undef __INT_LEAST8_MIN
# define __INT_LEAST8_MIN    INT56_MIN
# undef __INT_LEAST8_MAX
# define __INT_LEAST8_MAX    INT56_MAX
# undef __UINT_LEAST8_MAX
# define __UINT_LEAST8_MAX  UINT56_MAX

#if defined(__STDC_VERSION__) && __STDC_VERSION__ >= 202311L
# define UINT56_WIDTH         56
# define INT56_WIDTH          UINT56_WIDTH
# define UINT_LEAST56_WIDTH   UINT56_WIDTH
# define INT_LEAST56_WIDTH    UINT_LEAST56_WIDTH
# define UINT_FAST56_WIDTH    UINT56_WIDTH
# define INT_FAST56_WIDTH     UINT_FAST56_WIDTH
# undef __UINT_LEAST32_WIDTH
# define __UINT_LEAST32_WIDTH UINT56_WIDTH
# undef __UINT_LEAST16_WIDTH
# define __UINT_LEAST16_WIDTH UINT56_WIDTH
# undef __UINT_LEAST8_WIDTH
# define __UINT_LEAST8_WIDTH  UINT56_WIDTH
#endif /* __STDC_VERSION__ */
#endif /* __INT56_TYPE__ */


#ifdef __INT48_TYPE__
# define INT48_MAX           INT48_C(140737488355327)
# define INT48_MIN         (-INT48_C(140737488355327)-1)
# define UINT48_MAX         UINT48_C(281474976710655)
# define INT_LEAST48_MIN     INT48_MIN
# define INT_LEAST48_MAX     INT48_MAX
# define UINT_LEAST48_MAX   UINT48_MAX
# define INT_FAST48_MIN      INT48_MIN
# define INT_FAST48_MAX      INT48_MAX
# define UINT_FAST48_MAX    UINT48_MAX

# undef __INT_LEAST32_MIN
# define __INT_LEAST32_MIN   INT48_MIN
# undef __INT_LEAST32_MAX
# define __INT_LEAST32_MAX   INT48_MAX
# undef __UINT_LEAST32_MAX
# define __UINT_LEAST32_MAX UINT48_MAX
# undef __INT_LEAST16_MIN
# define __INT_LEAST16_MIN   INT48_MIN
# undef __INT_LEAST16_MAX
# define __INT_LEAST16_MAX   INT48_MAX
# undef __UINT_LEAST16_MAX
# define __UINT_LEAST16_MAX UINT48_MAX
# undef __INT_LEAST8_MIN
# define __INT_LEAST8_MIN    INT48_MIN
# undef __INT_LEAST8_MAX
# define __INT_LEAST8_MAX    INT48_MAX
# undef __UINT_LEAST8_MAX
# define __UINT_LEAST8_MAX  UINT48_MAX

#if defined(__STDC_VERSION__) && __STDC_VERSION__ >= 202311L
#define UINT48_WIDTH         48
#define INT48_WIDTH          UINT48_WIDTH
#define UINT_LEAST48_WIDTH   UINT48_WIDTH
#define INT_LEAST48_WIDTH    UINT_LEAST48_WIDTH
#define UINT_FAST48_WIDTH    UINT48_WIDTH
#define INT_FAST48_WIDTH     UINT_FAST48_WIDTH
#undef __UINT_LEAST32_WIDTH
#define __UINT_LEAST32_WIDTH UINT48_WIDTH
# undef __UINT_LEAST16_WIDTH
#define __UINT_LEAST16_WIDTH UINT48_WIDTH
# undef __UINT_LEAST8_WIDTH
#define __UINT_LEAST8_WIDTH  UINT48_WIDTH
#endif /* __STDC_VERSION__ */
#endif /* __INT48_TYPE__ */


#ifdef __INT40_TYPE__
# define INT40_MAX           INT40_C(549755813887)
# define INT40_MIN         (-INT40_C(549755813887)-1)
# define UINT40_MAX         UINT40_C(1099511627775)
# define INT_LEAST40_MIN     INT40_MIN
# define INT_LEAST40_MAX     INT40_MAX
# define UINT_LEAST40_MAX   UINT40_MAX
# define INT_FAST40_MIN      INT40_MIN
# define INT_FAST40_MAX      INT40_MAX
# define UINT_FAST40_MAX    UINT40_MAX

# undef __INT_LEAST32_MIN
# define __INT_LEAST32_MIN   INT40_MIN
# undef __INT_LEAST32_MAX
# define __INT_LEAST32_MAX   INT40_MAX
# undef __UINT_LEAST32_MAX
# define __UINT_LEAST32_MAX UINT40_MAX
# undef __INT_LEAST16_MIN
# define __INT_LEAST16_MIN   INT40_MIN
# undef __INT_LEAST16_MAX
# define __INT_LEAST16_MAX   INT40_MAX
# undef __UINT_LEAST16_MAX
# define __UINT_LEAST16_MAX UINT40_MAX
# undef __INT_LEAST8_MIN
# define __INT_LEAST8_MIN    INT40_MIN
# undef __INT_LEAST8_MAX
# define __INT_LEAST8_MAX    INT40_MAX
# undef __UINT_LEAST8_MAX
# define __UINT_LEAST8_MAX  UINT40_MAX

#if defined(__STDC_VERSION__) && __STDC_VERSION__ >= 202311L
# define UINT40_WIDTH         40
# define INT40_WIDTH          UINT40_WIDTH
# define UINT_LEAST40_WIDTH   UINT40_WIDTH
# define INT_LEAST40_WIDTH    UINT_LEAST40_WIDTH
# define UINT_FAST40_WIDTH    UINT40_WIDTH
# define INT_FAST40_WIDTH     UINT_FAST40_WIDTH
# undef __UINT_LEAST32_WIDTH
# define __UINT_LEAST32_WIDTH UINT40_WIDTH
# undef __UINT_LEAST16_WIDTH
# define __UINT_LEAST16_WIDTH UINT40_WIDTH
# undef __UINT_LEAST8_WIDTH
# define __UINT_LEAST8_WIDTH  UINT40_WIDTH
#endif /* __STDC_VERSION__ */
#endif /* __INT40_TYPE__ */


#ifdef __INT32_TYPE__
# define INT32_MAX           INT32_C(2147483647)
# define INT32_MIN         (-INT32_C(2147483647)-1)
# define UINT32_MAX         UINT32_C(4294967295)

# undef __INT_LEAST32_MIN
# define __INT_LEAST32_MIN   INT32_MIN
# undef __INT_LEAST32_MAX
# define __INT_LEAST32_MAX   INT32_MAX
# undef __UINT_LEAST32_MAX
# define __UINT_LEAST32_MAX UINT32_MAX
# undef __INT_LEAST16_MIN
# define __INT_LEAST16_MIN   INT32_MIN
# undef __INT_LEAST16_MAX
# define __INT_LEAST16_MAX   INT32_MAX
# undef __UINT_LEAST16_MAX
# define __UINT_LEAST16_MAX UINT32_MAX
# undef __INT_LEAST8_MIN
# define __INT_LEAST8_MIN    INT32_MIN
# undef __INT_LEAST8_MAX
# define __INT_LEAST8_MAX    INT32_MAX
# undef __UINT_LEAST8_MAX
# define __UINT_LEAST8_MAX  UINT32_MAX

#if defined(__STDC_VERSION__) && __STDC_VERSION__ >= 202311L
# define UINT32_WIDTH         32
# define INT32_WIDTH          UINT32_WIDTH
# undef __UINT_LEAST32_WIDTH
# define __UINT_LEAST32_WIDTH UINT32_WIDTH
# undef __UINT_LEAST16_WIDTH
# define __UINT_LEAST16_WIDTH UINT32_WIDTH
# undef __UINT_LEAST8_WIDTH
# define __UINT_LEAST8_WIDTH  UINT32_WIDTH
#endif /* __STDC_VERSION__ */
#endif /* __INT32_TYPE__ */

#ifdef __INT_LEAST32_MIN
# define INT_LEAST32_MIN   __INT_LEAST32_MIN
# define INT_LEAST32_MAX   __INT_LEAST32_MAX
# define UINT_LEAST32_MAX __UINT_LEAST32_MAX
# define INT_FAST32_MIN    __INT_LEAST32_MIN
# define INT_FAST32_MAX    __INT_LEAST32_MAX
# define UINT_FAST32_MAX  __UINT_LEAST32_MAX

#if defined(__STDC_VERSION__) && __STDC_VERSION__ >= 202311L
# define UINT_LEAST32_WIDTH __UINT_LEAST32_WIDTH
# define INT_LEAST32_WIDTH  UINT_LEAST32_WIDTH
# define UINT_FAST32_WIDTH  __UINT_LEAST32_WIDTH
# define INT_FAST32_WIDTH   UINT_FAST32_WIDTH
#endif /* __STDC_VERSION__ */
#endif /* __INT_LEAST32_MIN */


#ifdef __INT24_TYPE__
# define INT24_MAX           INT24_C(8388607)
# define INT24_MIN         (-INT24_C(8388607)-1)
# define UINT24_MAX         UINT24_C(16777215)
# define INT_LEAST24_MIN     INT24_MIN
# define INT_LEAST24_MAX     INT24_MAX
# define UINT_LEAST24_MAX   UINT24_MAX
# define INT_FAST24_MIN      INT24_MIN
# define INT_FAST24_MAX      INT24_MAX
# define UINT_FAST24_MAX    UINT24_MAX

# undef __INT_LEAST16_MIN
# define __INT_LEAST16_MIN   INT24_MIN
# undef __INT_LEAST16_MAX
# define __INT_LEAST16_MAX   INT24_MAX
# undef __UINT_LEAST16_MAX
# define __UINT_LEAST16_MAX UINT24_MAX
# undef __INT_LEAST8_MIN
# define __INT_LEAST8_MIN    INT24_MIN
# undef __INT_LEAST8_MAX
# define __INT_LEAST8_MAX    INT24_MAX
# undef __UINT_LEAST8_MAX
# define __UINT_LEAST8_MAX  UINT24_MAX

#if defined(__STDC_VERSION__) && __STDC_VERSION__ >= 202311L
# define UINT24_WIDTH         24
# define INT24_WIDTH          UINT24_WIDTH
# define UINT_LEAST24_WIDTH   UINT24_WIDTH
# define INT_LEAST24_WIDTH    UINT_LEAST24_WIDTH
# define UINT_FAST24_WIDTH    UINT24_WIDTH
# define INT_FAST24_WIDTH     UINT_FAST24_WIDTH
# undef __UINT_LEAST16_WIDTH
# define __UINT_LEAST16_WIDTH UINT24_WIDTH
# undef __UINT_LEAST8_WIDTH
# define __UINT_LEAST8_WIDTH  UINT24_WIDTH
#endif /* __STDC_VERSION__ */
#endif /* __INT24_TYPE__ */


#ifdef __INT16_TYPE__
#define INT16_MAX            INT16_C(32767)
#define INT16_MIN          (-INT16_C(32767)-1)
#define UINT16_MAX          UINT16_C(65535)

# undef __INT_LEAST16_MIN
# define __INT_LEAST16_MIN   INT16_MIN
# undef __INT_LEAST16_MAX
# define __INT_LEAST16_MAX   INT16_MAX
# undef __UINT_LEAST16_MAX
# define __UINT_LEAST16_MAX UINT16_MAX
# undef __INT_LEAST8_MIN
# define __INT_LEAST8_MIN    INT16_MIN
# undef __INT_LEAST8_MAX
# define __INT_LEAST8_MAX    INT16_MAX
# undef __UINT_LEAST8_MAX
# define __UINT_LEAST8_MAX  UINT16_MAX

#if defined(__STDC_VERSION__) && __STDC_VERSION__ >= 202311L
# define UINT16_WIDTH         16
# define INT16_WIDTH          UINT16_WIDTH
# undef __UINT_LEAST16_WIDTH
# define __UINT_LEAST16_WIDTH UINT16_WIDTH
# undef __UINT_LEAST8_WIDTH
# define __UINT_LEAST8_WIDTH  UINT16_WIDTH
#endif /* __STDC_VERSION__ */
#endif /* __INT16_TYPE__ */

#ifdef __INT_LEAST16_MIN
# define INT_LEAST16_MIN   __INT_LEAST16_MIN
# define INT_LEAST16_MAX   __INT_LEAST16_MAX
# define UINT_LEAST16_MAX __UINT_LEAST16_MAX
# define INT_FAST16_MIN    __INT_LEAST16_MIN
# define INT_FAST16_MAX    __INT_LEAST16_MAX
# define UINT_FAST16_MAX  __UINT_LEAST16_MAX

#if defined(__STDC_VERSION__) && __STDC_VERSION__ >= 202311L
# define UINT_LEAST16_WIDTH __UINT_LEAST16_WIDTH
# define INT_LEAST16_WIDTH  UINT_LEAST16_WIDTH
# define UINT_FAST16_WIDTH  __UINT_LEAST16_WIDTH
# define INT_FAST16_WIDTH   UINT_FAST16_WIDTH
#endif /* __STDC_VERSION__ */
#endif /* __INT_LEAST16_MIN */


#ifdef __INT8_TYPE__
# define INT8_MAX            INT8_C(127)
# define INT8_MIN          (-INT8_C(127)-1)
# define UINT8_MAX          UINT8_C(255)

# undef __INT_LEAST8_MIN
# define __INT_LEAST8_MIN    INT8_MIN
# undef __INT_LEAST8_MAX
# define __INT_LEAST8_MAX    INT8_MAX
# undef __UINT_LEAST8_MAX
# define __UINT_LEAST8_MAX  UINT8_MAX

#if defined(__STDC_VERSION__) && __STDC_VERSION__ >= 202311L
# define UINT8_WIDTH         8
# define INT8_WIDTH          UINT8_WIDTH
# undef __UINT_LEAST8_WIDTH
# define __UINT_LEAST8_WIDTH UINT8_WIDTH
#endif /* __STDC_VERSION__ */
#endif /* __INT8_TYPE__ */

#ifdef __INT_LEAST8_MIN
# define INT_LEAST8_MIN   __INT_LEAST8_MIN
# define INT_LEAST8_MAX   __INT_LEAST8_MAX
# define UINT_LEAST8_MAX __UINT_LEAST8_MAX
# define INT_FAST8_MIN    __INT_LEAST8_MIN
# define INT_FAST8_MAX    __INT_LEAST8_MAX
# define UINT_FAST8_MAX  __UINT_LEAST8_MAX

#if defined(__STDC_VERSION__) && __STDC_VERSION__ >= 202311L
# define UINT_LEAST8_WIDTH __UINT_LEAST8_WIDTH
# define INT_LEAST8_WIDTH  UINT_LEAST8_WIDTH
# define UINT_FAST8_WIDTH  __UINT_LEAST8_WIDTH
# define INT_FAST8_WIDTH   UINT_FAST8_WIDTH
#endif /* __STDC_VERSION__ */
#endif /* __INT_LEAST8_MIN */

/* Some utility macros */
#define  __INTN_MIN(n)  __stdint_join3( INT, n, _MIN)
#define  __INTN_MAX(n)  __stdint_join3( INT, n, _MAX)
#define __UINTN_MAX(n)  __stdint_join3(UINT, n, _MAX)
#define  __INTN_C(n, v) __stdint_join3( INT, n, _C(v))
#define __UINTN_C(n, v) __stdint_join3(UINT, n, _C(v))

/* C99 7.18.2.4 Limits of integer types capable of holding object pointers. */
/* C99 7.18.3 Limits of other integer types. */

#define  INTPTR_MIN  (-__INTPTR_MAX__-1)
#define  INTPTR_MAX    __INTPTR_MAX__
#define UINTPTR_MAX   __UINTPTR_MAX__
#define PTRDIFF_MIN (-__PTRDIFF_MAX__-1)
#define PTRDIFF_MAX   __PTRDIFF_MAX__
#define    SIZE_MAX      __SIZE_MAX__

/* C23 7.22.2.4 Width of integer types capable of holding object pointers. */
#if defined(__STDC_VERSION__) && __STDC_VERSION__ >= 202311L
/* NB: The C standard requires that these be the same value, but the compiler
   exposes separate internal width macros. */
#define INTPTR_WIDTH  __INTPTR_WIDTH__
#define UINTPTR_WIDTH __UINTPTR_WIDTH__
#endif

/* ISO9899:2011 7.20 (C11 Annex K): Define RSIZE_MAX if __STDC_WANT_LIB_EXT1__
 * is enabled. */
#if defined(__STDC_WANT_LIB_EXT1__) && __STDC_WANT_LIB_EXT1__ >= 1
#define   RSIZE_MAX            (SIZE_MAX >> 1)
#endif

/* C99 7.18.2.5 Limits of greatest-width integer types. */
#define  INTMAX_MIN (-__INTMAX_MAX__-1)
#define  INTMAX_MAX   __INTMAX_MAX__
#define UINTMAX_MAX  __UINTMAX_MAX__

/* C23 7.22.2.5 Width of greatest-width integer types. */
#if defined(__STDC_VERSION__) && __STDC_VERSION__ >= 202311L
/* NB: The C standard requires that these be the same value, but the compiler
   exposes separate internal width macros. */
#define INTMAX_WIDTH __INTMAX_WIDTH__
#define UINTMAX_WIDTH __UINTMAX_WIDTH__
#endif

/* C99 7.18.3 Limits of other integer types. */
#define SIG_ATOMIC_MIN __INTN_MIN(__SIG_ATOMIC_WIDTH__)
#define SIG_ATOMIC_MAX __INTN_MAX(__SIG_ATOMIC_WIDTH__)
#ifdef __WINT_UNSIGNED__
# define WINT_MIN       __UINTN_C(__WINT_WIDTH__, 0)
# define WINT_MAX       __UINTN_MAX(__WINT_WIDTH__)
#else
# define WINT_MIN       __INTN_MIN(__WINT_WIDTH__)
# define WINT_MAX       __INTN_MAX(__WINT_WIDTH__)
#endif

#ifndef WCHAR_MAX
# define WCHAR_MAX __WCHAR_MAX__
#endif
#ifndef WCHAR_MIN
# if __WCHAR_MAX__ == __INTN_MAX(__WCHAR_WIDTH__)
#  define WCHAR_MIN __INTN_MIN(__WCHAR_WIDTH__)
# else
#  define WCHAR_MIN __UINTN_C(__WCHAR_WIDTH__, 0)
# endif
#endif

/* 7.18.4.2 Macros for greatest-width integer constants. */
#define  INTMAX_C(v) __INTMAX_C(v)
#define UINTMAX_C(v) __UINTMAX_C(v)

/* C23 7.22.3.x Width of other integer types. */
#if defined(__STDC_VERSION__) && __STDC_VERSION__ >= 202311L
#define PTRDIFF_WIDTH    __PTRDIFF_WIDTH__
#define SIG_ATOMIC_WIDTH __SIG_ATOMIC_WIDTH__
#define SIZE_WIDTH       __SIZE_WIDTH__
#define WCHAR_WIDTH      __WCHAR_WIDTH__
#define WINT_WIDTH       __WINT_WIDTH__
#endif

#endif /* __STDC_HOSTED__ */
#endif /* __MVS__ */
#endif /* __CLANG_STDINT_H */
`,"stdnoreturn.h":`/*===---- stdnoreturn.h - Standard header for noreturn macro ---------------===
 *
 * Part of the LLVM Project, under the Apache License v2.0 with LLVM Exceptions.
 * See https://llvm.org/LICENSE.txt for license information.
 * SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception
 *
 *===-----------------------------------------------------------------------===
 */

#ifndef __STDNORETURN_H
#define __STDNORETURN_H

#if defined(__MVS__) && __has_include_next(<stdnoreturn.h>)
#include_next <stdnoreturn.h>
#else

#define noreturn _Noreturn
#define __noreturn_is_defined 1

#endif /* __MVS__ */

#if (defined(__STDC_VERSION__) && __STDC_VERSION__ > 201710L) &&               \\
    !defined(_CLANG_DISABLE_CRT_DEPRECATION_WARNINGS)
/* The noreturn macro is deprecated in C23. We do not mark it as such because
   including the header file in C23 is also deprecated and we do not want to
   issue a confusing diagnostic for code which includes <stdnoreturn.h>
   followed by code that writes [[noreturn]]. The issue with such code is not
   with the attribute, or the use of 'noreturn', but the inclusion of the
   header. */
/* FIXME: We should be issuing a deprecation warning here, but cannot yet due
 * to system headers which include this header file unconditionally.
 */
#endif

#endif /* __STDNORETURN_H */
`,"tgmath.h":`/*===---- tgmath.h - Standard header for type generic math ----------------===*\\
 *
 * Part of the LLVM Project, under the Apache License v2.0 with LLVM Exceptions.
 * See https://llvm.org/LICENSE.txt for license information.
 * SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception
 *
\\*===----------------------------------------------------------------------===*/

#ifndef __CLANG_TGMATH_H
#define __CLANG_TGMATH_H

/* C99 7.22 Type-generic math <tgmath.h>. */
#include <math.h>

/*
 * Allow additional definitions and implementation-defined values on Apple
 * platforms. This is done after #include <math.h> to avoid depcycle conflicts
 * between libcxx and darwin in C++ modules builds.
 */
#if defined(__APPLE__) && __STDC_HOSTED__ && __has_include_next(<tgmath.h>)
#  include_next <tgmath.h>
#else

/* C++ handles type genericity with overloading in math.h. */
#ifndef __cplusplus
#include <complex.h>

#define _TG_ATTRSp __attribute__((__overloadable__))
#define _TG_ATTRS __attribute__((__overloadable__, __always_inline__))

// promotion

typedef void _Argument_type_is_not_arithmetic;
static _Argument_type_is_not_arithmetic __tg_promote(...)
  __attribute__((__unavailable__,__overloadable__));
static double               _TG_ATTRSp __tg_promote(int);
static double               _TG_ATTRSp __tg_promote(unsigned int);
static double               _TG_ATTRSp __tg_promote(long);
static double               _TG_ATTRSp __tg_promote(unsigned long);
static double               _TG_ATTRSp __tg_promote(long long);
static double               _TG_ATTRSp __tg_promote(unsigned long long);
static float                _TG_ATTRSp __tg_promote(float);
static double               _TG_ATTRSp __tg_promote(double);
static long double          _TG_ATTRSp __tg_promote(long double);
static float _Complex       _TG_ATTRSp __tg_promote(float _Complex);
static double _Complex      _TG_ATTRSp __tg_promote(double _Complex);
static long double _Complex _TG_ATTRSp __tg_promote(long double _Complex);

#define __tg_promote1(__x)           (__typeof__(__tg_promote(__x)))
#define __tg_promote2(__x, __y)      (__typeof__(__tg_promote(__x) + \\
                                                 __tg_promote(__y)))
#define __tg_promote3(__x, __y, __z) (__typeof__(__tg_promote(__x) + \\
                                                 __tg_promote(__y) + \\
                                                 __tg_promote(__z)))

// acos

static float
    _TG_ATTRS
    __tg_acos(float __x) {return acosf(__x);}

static double
    _TG_ATTRS
    __tg_acos(double __x) {return acos(__x);}

static long double
    _TG_ATTRS
    __tg_acos(long double __x) {return acosl(__x);}

static float _Complex
    _TG_ATTRS
    __tg_acos(float _Complex __x) {return cacosf(__x);}

static double _Complex
    _TG_ATTRS
    __tg_acos(double _Complex __x) {return cacos(__x);}

static long double _Complex
    _TG_ATTRS
    __tg_acos(long double _Complex __x) {return cacosl(__x);}

#undef acos
#define acos(__x) __tg_acos(__tg_promote1((__x))(__x))

// asin

static float
    _TG_ATTRS
    __tg_asin(float __x) {return asinf(__x);}

static double
    _TG_ATTRS
    __tg_asin(double __x) {return asin(__x);}

static long double
    _TG_ATTRS
    __tg_asin(long double __x) {return asinl(__x);}

static float _Complex
    _TG_ATTRS
    __tg_asin(float _Complex __x) {return casinf(__x);}

static double _Complex
    _TG_ATTRS
    __tg_asin(double _Complex __x) {return casin(__x);}

static long double _Complex
    _TG_ATTRS
    __tg_asin(long double _Complex __x) {return casinl(__x);}

#undef asin
#define asin(__x) __tg_asin(__tg_promote1((__x))(__x))

// atan

static float
    _TG_ATTRS
    __tg_atan(float __x) {return atanf(__x);}

static double
    _TG_ATTRS
    __tg_atan(double __x) {return atan(__x);}

static long double
    _TG_ATTRS
    __tg_atan(long double __x) {return atanl(__x);}

static float _Complex
    _TG_ATTRS
    __tg_atan(float _Complex __x) {return catanf(__x);}

static double _Complex
    _TG_ATTRS
    __tg_atan(double _Complex __x) {return catan(__x);}

static long double _Complex
    _TG_ATTRS
    __tg_atan(long double _Complex __x) {return catanl(__x);}

#undef atan
#define atan(__x) __tg_atan(__tg_promote1((__x))(__x))

// acosh

static float
    _TG_ATTRS
    __tg_acosh(float __x) {return acoshf(__x);}

static double
    _TG_ATTRS
    __tg_acosh(double __x) {return acosh(__x);}

static long double
    _TG_ATTRS
    __tg_acosh(long double __x) {return acoshl(__x);}

static float _Complex
    _TG_ATTRS
    __tg_acosh(float _Complex __x) {return cacoshf(__x);}

static double _Complex
    _TG_ATTRS
    __tg_acosh(double _Complex __x) {return cacosh(__x);}

static long double _Complex
    _TG_ATTRS
    __tg_acosh(long double _Complex __x) {return cacoshl(__x);}

#undef acosh
#define acosh(__x) __tg_acosh(__tg_promote1((__x))(__x))

// asinh

static float
    _TG_ATTRS
    __tg_asinh(float __x) {return asinhf(__x);}

static double
    _TG_ATTRS
    __tg_asinh(double __x) {return asinh(__x);}

static long double
    _TG_ATTRS
    __tg_asinh(long double __x) {return asinhl(__x);}

static float _Complex
    _TG_ATTRS
    __tg_asinh(float _Complex __x) {return casinhf(__x);}

static double _Complex
    _TG_ATTRS
    __tg_asinh(double _Complex __x) {return casinh(__x);}

static long double _Complex
    _TG_ATTRS
    __tg_asinh(long double _Complex __x) {return casinhl(__x);}

#undef asinh
#define asinh(__x) __tg_asinh(__tg_promote1((__x))(__x))

// atanh

static float
    _TG_ATTRS
    __tg_atanh(float __x) {return atanhf(__x);}

static double
    _TG_ATTRS
    __tg_atanh(double __x) {return atanh(__x);}

static long double
    _TG_ATTRS
    __tg_atanh(long double __x) {return atanhl(__x);}

static float _Complex
    _TG_ATTRS
    __tg_atanh(float _Complex __x) {return catanhf(__x);}

static double _Complex
    _TG_ATTRS
    __tg_atanh(double _Complex __x) {return catanh(__x);}

static long double _Complex
    _TG_ATTRS
    __tg_atanh(long double _Complex __x) {return catanhl(__x);}

#undef atanh
#define atanh(__x) __tg_atanh(__tg_promote1((__x))(__x))

// cos

static float
    _TG_ATTRS
    __tg_cos(float __x) {return cosf(__x);}

static double
    _TG_ATTRS
    __tg_cos(double __x) {return cos(__x);}

static long double
    _TG_ATTRS
    __tg_cos(long double __x) {return cosl(__x);}

static float _Complex
    _TG_ATTRS
    __tg_cos(float _Complex __x) {return ccosf(__x);}

static double _Complex
    _TG_ATTRS
    __tg_cos(double _Complex __x) {return ccos(__x);}

static long double _Complex
    _TG_ATTRS
    __tg_cos(long double _Complex __x) {return ccosl(__x);}

#undef cos
#define cos(__x) __tg_cos(__tg_promote1((__x))(__x))

// sin

static float
    _TG_ATTRS
    __tg_sin(float __x) {return sinf(__x);}

static double
    _TG_ATTRS
    __tg_sin(double __x) {return sin(__x);}

static long double
    _TG_ATTRS
    __tg_sin(long double __x) {return sinl(__x);}

static float _Complex
    _TG_ATTRS
    __tg_sin(float _Complex __x) {return csinf(__x);}

static double _Complex
    _TG_ATTRS
    __tg_sin(double _Complex __x) {return csin(__x);}

static long double _Complex
    _TG_ATTRS
    __tg_sin(long double _Complex __x) {return csinl(__x);}

#undef sin
#define sin(__x) __tg_sin(__tg_promote1((__x))(__x))

// tan

static float
    _TG_ATTRS
    __tg_tan(float __x) {return tanf(__x);}

static double
    _TG_ATTRS
    __tg_tan(double __x) {return tan(__x);}

static long double
    _TG_ATTRS
    __tg_tan(long double __x) {return tanl(__x);}

static float _Complex
    _TG_ATTRS
    __tg_tan(float _Complex __x) {return ctanf(__x);}

static double _Complex
    _TG_ATTRS
    __tg_tan(double _Complex __x) {return ctan(__x);}

static long double _Complex
    _TG_ATTRS
    __tg_tan(long double _Complex __x) {return ctanl(__x);}

#undef tan
#define tan(__x) __tg_tan(__tg_promote1((__x))(__x))

// cosh

static float
    _TG_ATTRS
    __tg_cosh(float __x) {return coshf(__x);}

static double
    _TG_ATTRS
    __tg_cosh(double __x) {return cosh(__x);}

static long double
    _TG_ATTRS
    __tg_cosh(long double __x) {return coshl(__x);}

static float _Complex
    _TG_ATTRS
    __tg_cosh(float _Complex __x) {return ccoshf(__x);}

static double _Complex
    _TG_ATTRS
    __tg_cosh(double _Complex __x) {return ccosh(__x);}

static long double _Complex
    _TG_ATTRS
    __tg_cosh(long double _Complex __x) {return ccoshl(__x);}

#undef cosh
#define cosh(__x) __tg_cosh(__tg_promote1((__x))(__x))

// sinh

static float
    _TG_ATTRS
    __tg_sinh(float __x) {return sinhf(__x);}

static double
    _TG_ATTRS
    __tg_sinh(double __x) {return sinh(__x);}

static long double
    _TG_ATTRS
    __tg_sinh(long double __x) {return sinhl(__x);}

static float _Complex
    _TG_ATTRS
    __tg_sinh(float _Complex __x) {return csinhf(__x);}

static double _Complex
    _TG_ATTRS
    __tg_sinh(double _Complex __x) {return csinh(__x);}

static long double _Complex
    _TG_ATTRS
    __tg_sinh(long double _Complex __x) {return csinhl(__x);}

#undef sinh
#define sinh(__x) __tg_sinh(__tg_promote1((__x))(__x))

// tanh

static float
    _TG_ATTRS
    __tg_tanh(float __x) {return tanhf(__x);}

static double
    _TG_ATTRS
    __tg_tanh(double __x) {return tanh(__x);}

static long double
    _TG_ATTRS
    __tg_tanh(long double __x) {return tanhl(__x);}

static float _Complex
    _TG_ATTRS
    __tg_tanh(float _Complex __x) {return ctanhf(__x);}

static double _Complex
    _TG_ATTRS
    __tg_tanh(double _Complex __x) {return ctanh(__x);}

static long double _Complex
    _TG_ATTRS
    __tg_tanh(long double _Complex __x) {return ctanhl(__x);}

#undef tanh
#define tanh(__x) __tg_tanh(__tg_promote1((__x))(__x))

// exp

static float
    _TG_ATTRS
    __tg_exp(float __x) {return expf(__x);}

static double
    _TG_ATTRS
    __tg_exp(double __x) {return exp(__x);}

static long double
    _TG_ATTRS
    __tg_exp(long double __x) {return expl(__x);}

static float _Complex
    _TG_ATTRS
    __tg_exp(float _Complex __x) {return cexpf(__x);}

static double _Complex
    _TG_ATTRS
    __tg_exp(double _Complex __x) {return cexp(__x);}

static long double _Complex
    _TG_ATTRS
    __tg_exp(long double _Complex __x) {return cexpl(__x);}

#undef exp
#define exp(__x) __tg_exp(__tg_promote1((__x))(__x))

// log

static float
    _TG_ATTRS
    __tg_log(float __x) {return logf(__x);}

static double
    _TG_ATTRS
    __tg_log(double __x) {return log(__x);}

static long double
    _TG_ATTRS
    __tg_log(long double __x) {return logl(__x);}

static float _Complex
    _TG_ATTRS
    __tg_log(float _Complex __x) {return clogf(__x);}

static double _Complex
    _TG_ATTRS
    __tg_log(double _Complex __x) {return clog(__x);}

static long double _Complex
    _TG_ATTRS
    __tg_log(long double _Complex __x) {return clogl(__x);}

#undef log
#define log(__x) __tg_log(__tg_promote1((__x))(__x))

// pow

static float
    _TG_ATTRS
    __tg_pow(float __x, float __y) {return powf(__x, __y);}

static double
    _TG_ATTRS
    __tg_pow(double __x, double __y) {return pow(__x, __y);}

static long double
    _TG_ATTRS
    __tg_pow(long double __x, long double __y) {return powl(__x, __y);}

static float _Complex
    _TG_ATTRS
    __tg_pow(float _Complex __x, float _Complex __y) {return cpowf(__x, __y);}

static double _Complex
    _TG_ATTRS
    __tg_pow(double _Complex __x, double _Complex __y) {return cpow(__x, __y);}

static long double _Complex
    _TG_ATTRS
    __tg_pow(long double _Complex __x, long double _Complex __y)
    {return cpowl(__x, __y);}

#undef pow
#define pow(__x, __y) __tg_pow(__tg_promote2((__x), (__y))(__x), \\
                               __tg_promote2((__x), (__y))(__y))

// sqrt

static float
    _TG_ATTRS
    __tg_sqrt(float __x) {return sqrtf(__x);}

static double
    _TG_ATTRS
    __tg_sqrt(double __x) {return sqrt(__x);}

static long double
    _TG_ATTRS
    __tg_sqrt(long double __x) {return sqrtl(__x);}

static float _Complex
    _TG_ATTRS
    __tg_sqrt(float _Complex __x) {return csqrtf(__x);}

static double _Complex
    _TG_ATTRS
    __tg_sqrt(double _Complex __x) {return csqrt(__x);}

static long double _Complex
    _TG_ATTRS
    __tg_sqrt(long double _Complex __x) {return csqrtl(__x);}

#undef sqrt
#define sqrt(__x) __tg_sqrt(__tg_promote1((__x))(__x))

// fabs

static float
    _TG_ATTRS
    __tg_fabs(float __x) {return fabsf(__x);}

static double
    _TG_ATTRS
    __tg_fabs(double __x) {return fabs(__x);}

static long double
    _TG_ATTRS
    __tg_fabs(long double __x) {return fabsl(__x);}

static float
    _TG_ATTRS
    __tg_fabs(float _Complex __x) {return cabsf(__x);}

static double
    _TG_ATTRS
    __tg_fabs(double _Complex __x) {return cabs(__x);}

static long double
    _TG_ATTRS
    __tg_fabs(long double _Complex __x) {return cabsl(__x);}

#undef fabs
#define fabs(__x) __tg_fabs(__tg_promote1((__x))(__x))

// atan2

static float
    _TG_ATTRS
    __tg_atan2(float __x, float __y) {return atan2f(__x, __y);}

static double
    _TG_ATTRS
    __tg_atan2(double __x, double __y) {return atan2(__x, __y);}

static long double
    _TG_ATTRS
    __tg_atan2(long double __x, long double __y) {return atan2l(__x, __y);}

#undef atan2
#define atan2(__x, __y) __tg_atan2(__tg_promote2((__x), (__y))(__x), \\
                                   __tg_promote2((__x), (__y))(__y))

// cbrt

static float
    _TG_ATTRS
    __tg_cbrt(float __x) {return cbrtf(__x);}

static double
    _TG_ATTRS
    __tg_cbrt(double __x) {return cbrt(__x);}

static long double
    _TG_ATTRS
    __tg_cbrt(long double __x) {return cbrtl(__x);}

#undef cbrt
#define cbrt(__x) __tg_cbrt(__tg_promote1((__x))(__x))

// ceil

static float
    _TG_ATTRS
    __tg_ceil(float __x) {return ceilf(__x);}

static double
    _TG_ATTRS
    __tg_ceil(double __x) {return ceil(__x);}

static long double
    _TG_ATTRS
    __tg_ceil(long double __x) {return ceill(__x);}

#undef ceil
#define ceil(__x) __tg_ceil(__tg_promote1((__x))(__x))

// copysign

static float
    _TG_ATTRS
    __tg_copysign(float __x, float __y) {return copysignf(__x, __y);}

static double
    _TG_ATTRS
    __tg_copysign(double __x, double __y) {return copysign(__x, __y);}

static long double
    _TG_ATTRS
    __tg_copysign(long double __x, long double __y) {return copysignl(__x, __y);}

#undef copysign
#define copysign(__x, __y) __tg_copysign(__tg_promote2((__x), (__y))(__x), \\
                                         __tg_promote2((__x), (__y))(__y))

// erf

static float
    _TG_ATTRS
    __tg_erf(float __x) {return erff(__x);}

static double
    _TG_ATTRS
    __tg_erf(double __x) {return erf(__x);}

static long double
    _TG_ATTRS
    __tg_erf(long double __x) {return erfl(__x);}

#undef erf
#define erf(__x) __tg_erf(__tg_promote1((__x))(__x))

// erfc

static float
    _TG_ATTRS
    __tg_erfc(float __x) {return erfcf(__x);}

static double
    _TG_ATTRS
    __tg_erfc(double __x) {return erfc(__x);}

static long double
    _TG_ATTRS
    __tg_erfc(long double __x) {return erfcl(__x);}

#undef erfc
#define erfc(__x) __tg_erfc(__tg_promote1((__x))(__x))

// exp2

static float
    _TG_ATTRS
    __tg_exp2(float __x) {return exp2f(__x);}

static double
    _TG_ATTRS
    __tg_exp2(double __x) {return exp2(__x);}

static long double
    _TG_ATTRS
    __tg_exp2(long double __x) {return exp2l(__x);}

#undef exp2
#define exp2(__x) __tg_exp2(__tg_promote1((__x))(__x))

// expm1

static float
    _TG_ATTRS
    __tg_expm1(float __x) {return expm1f(__x);}

static double
    _TG_ATTRS
    __tg_expm1(double __x) {return expm1(__x);}

static long double
    _TG_ATTRS
    __tg_expm1(long double __x) {return expm1l(__x);}

#undef expm1
#define expm1(__x) __tg_expm1(__tg_promote1((__x))(__x))

// fdim

static float
    _TG_ATTRS
    __tg_fdim(float __x, float __y) {return fdimf(__x, __y);}

static double
    _TG_ATTRS
    __tg_fdim(double __x, double __y) {return fdim(__x, __y);}

static long double
    _TG_ATTRS
    __tg_fdim(long double __x, long double __y) {return fdiml(__x, __y);}

#undef fdim
#define fdim(__x, __y) __tg_fdim(__tg_promote2((__x), (__y))(__x), \\
                                 __tg_promote2((__x), (__y))(__y))

// floor

static float
    _TG_ATTRS
    __tg_floor(float __x) {return floorf(__x);}

static double
    _TG_ATTRS
    __tg_floor(double __x) {return floor(__x);}

static long double
    _TG_ATTRS
    __tg_floor(long double __x) {return floorl(__x);}

#undef floor
#define floor(__x) __tg_floor(__tg_promote1((__x))(__x))

// fma

static float
    _TG_ATTRS
    __tg_fma(float __x, float __y, float __z)
    {return fmaf(__x, __y, __z);}

static double
    _TG_ATTRS
    __tg_fma(double __x, double __y, double __z)
    {return fma(__x, __y, __z);}

static long double
    _TG_ATTRS
    __tg_fma(long double __x,long double __y, long double __z)
    {return fmal(__x, __y, __z);}

#undef fma
#define fma(__x, __y, __z)                                \\
        __tg_fma(__tg_promote3((__x), (__y), (__z))(__x), \\
                 __tg_promote3((__x), (__y), (__z))(__y), \\
                 __tg_promote3((__x), (__y), (__z))(__z))

// fmax

static float
    _TG_ATTRS
    __tg_fmax(float __x, float __y) {return fmaxf(__x, __y);}

static double
    _TG_ATTRS
    __tg_fmax(double __x, double __y) {return fmax(__x, __y);}

static long double
    _TG_ATTRS
    __tg_fmax(long double __x, long double __y) {return fmaxl(__x, __y);}

#undef fmax
#define fmax(__x, __y) __tg_fmax(__tg_promote2((__x), (__y))(__x), \\
                                 __tg_promote2((__x), (__y))(__y))

// fmin

static float
    _TG_ATTRS
    __tg_fmin(float __x, float __y) {return fminf(__x, __y);}

static double
    _TG_ATTRS
    __tg_fmin(double __x, double __y) {return fmin(__x, __y);}

static long double
    _TG_ATTRS
    __tg_fmin(long double __x, long double __y) {return fminl(__x, __y);}

#undef fmin
#define fmin(__x, __y) __tg_fmin(__tg_promote2((__x), (__y))(__x), \\
                                 __tg_promote2((__x), (__y))(__y))

// fmod

static float
    _TG_ATTRS
    __tg_fmod(float __x, float __y) {return fmodf(__x, __y);}

static double
    _TG_ATTRS
    __tg_fmod(double __x, double __y) {return fmod(__x, __y);}

static long double
    _TG_ATTRS
    __tg_fmod(long double __x, long double __y) {return fmodl(__x, __y);}

#undef fmod
#define fmod(__x, __y) __tg_fmod(__tg_promote2((__x), (__y))(__x), \\
                                 __tg_promote2((__x), (__y))(__y))

// frexp

static float
    _TG_ATTRS
    __tg_frexp(float __x, int* __y) {return frexpf(__x, __y);}

static double
    _TG_ATTRS
    __tg_frexp(double __x, int* __y) {return frexp(__x, __y);}

static long double
    _TG_ATTRS
    __tg_frexp(long double __x, int* __y) {return frexpl(__x, __y);}

#undef frexp
#define frexp(__x, __y) __tg_frexp(__tg_promote1((__x))(__x), __y)

// hypot

static float
    _TG_ATTRS
    __tg_hypot(float __x, float __y) {return hypotf(__x, __y);}

static double
    _TG_ATTRS
    __tg_hypot(double __x, double __y) {return hypot(__x, __y);}

static long double
    _TG_ATTRS
    __tg_hypot(long double __x, long double __y) {return hypotl(__x, __y);}

#undef hypot
#define hypot(__x, __y) __tg_hypot(__tg_promote2((__x), (__y))(__x), \\
                                   __tg_promote2((__x), (__y))(__y))

// ilogb

static int
    _TG_ATTRS
    __tg_ilogb(float __x) {return ilogbf(__x);}

static int
    _TG_ATTRS
    __tg_ilogb(double __x) {return ilogb(__x);}

static int
    _TG_ATTRS
    __tg_ilogb(long double __x) {return ilogbl(__x);}

#undef ilogb
#define ilogb(__x) __tg_ilogb(__tg_promote1((__x))(__x))

// ldexp

static float
    _TG_ATTRS
    __tg_ldexp(float __x, int __y) {return ldexpf(__x, __y);}

static double
    _TG_ATTRS
    __tg_ldexp(double __x, int __y) {return ldexp(__x, __y);}

static long double
    _TG_ATTRS
    __tg_ldexp(long double __x, int __y) {return ldexpl(__x, __y);}

#undef ldexp
#define ldexp(__x, __y) __tg_ldexp(__tg_promote1((__x))(__x), __y)

// lgamma

static float
    _TG_ATTRS
    __tg_lgamma(float __x) {return lgammaf(__x);}

static double
    _TG_ATTRS
    __tg_lgamma(double __x) {return lgamma(__x);}

static long double
    _TG_ATTRS
    __tg_lgamma(long double __x) {return lgammal(__x);}

#undef lgamma
#define lgamma(__x) __tg_lgamma(__tg_promote1((__x))(__x))

// llrint

static long long
    _TG_ATTRS
    __tg_llrint(float __x) {return llrintf(__x);}

static long long
    _TG_ATTRS
    __tg_llrint(double __x) {return llrint(__x);}

static long long
    _TG_ATTRS
    __tg_llrint(long double __x) {return llrintl(__x);}

#undef llrint
#define llrint(__x) __tg_llrint(__tg_promote1((__x))(__x))

// llround

static long long
    _TG_ATTRS
    __tg_llround(float __x) {return llroundf(__x);}

static long long
    _TG_ATTRS
    __tg_llround(double __x) {return llround(__x);}

static long long
    _TG_ATTRS
    __tg_llround(long double __x) {return llroundl(__x);}

#undef llround
#define llround(__x) __tg_llround(__tg_promote1((__x))(__x))

// log10

static float
    _TG_ATTRS
    __tg_log10(float __x) {return log10f(__x);}

static double
    _TG_ATTRS
    __tg_log10(double __x) {return log10(__x);}

static long double
    _TG_ATTRS
    __tg_log10(long double __x) {return log10l(__x);}

#undef log10
#define log10(__x) __tg_log10(__tg_promote1((__x))(__x))

// log1p

static float
    _TG_ATTRS
    __tg_log1p(float __x) {return log1pf(__x);}

static double
    _TG_ATTRS
    __tg_log1p(double __x) {return log1p(__x);}

static long double
    _TG_ATTRS
    __tg_log1p(long double __x) {return log1pl(__x);}

#undef log1p
#define log1p(__x) __tg_log1p(__tg_promote1((__x))(__x))

// log2

static float
    _TG_ATTRS
    __tg_log2(float __x) {return log2f(__x);}

static double
    _TG_ATTRS
    __tg_log2(double __x) {return log2(__x);}

static long double
    _TG_ATTRS
    __tg_log2(long double __x) {return log2l(__x);}

#undef log2
#define log2(__x) __tg_log2(__tg_promote1((__x))(__x))

// logb

static float
    _TG_ATTRS
    __tg_logb(float __x) {return logbf(__x);}

static double
    _TG_ATTRS
    __tg_logb(double __x) {return logb(__x);}

static long double
    _TG_ATTRS
    __tg_logb(long double __x) {return logbl(__x);}

#undef logb
#define logb(__x) __tg_logb(__tg_promote1((__x))(__x))

// lrint

static long
    _TG_ATTRS
    __tg_lrint(float __x) {return lrintf(__x);}

static long
    _TG_ATTRS
    __tg_lrint(double __x) {return lrint(__x);}

static long
    _TG_ATTRS
    __tg_lrint(long double __x) {return lrintl(__x);}

#undef lrint
#define lrint(__x) __tg_lrint(__tg_promote1((__x))(__x))

// lround

static long
    _TG_ATTRS
    __tg_lround(float __x) {return lroundf(__x);}

static long
    _TG_ATTRS
    __tg_lround(double __x) {return lround(__x);}

static long
    _TG_ATTRS
    __tg_lround(long double __x) {return lroundl(__x);}

#undef lround
#define lround(__x) __tg_lround(__tg_promote1((__x))(__x))

// nearbyint

static float
    _TG_ATTRS
    __tg_nearbyint(float __x) {return nearbyintf(__x);}

static double
    _TG_ATTRS
    __tg_nearbyint(double __x) {return nearbyint(__x);}

static long double
    _TG_ATTRS
    __tg_nearbyint(long double __x) {return nearbyintl(__x);}

#undef nearbyint
#define nearbyint(__x) __tg_nearbyint(__tg_promote1((__x))(__x))

// nextafter

static float
    _TG_ATTRS
    __tg_nextafter(float __x, float __y) {return nextafterf(__x, __y);}

static double
    _TG_ATTRS
    __tg_nextafter(double __x, double __y) {return nextafter(__x, __y);}

static long double
    _TG_ATTRS
    __tg_nextafter(long double __x, long double __y) {return nextafterl(__x, __y);}

#undef nextafter
#define nextafter(__x, __y) __tg_nextafter(__tg_promote2((__x), (__y))(__x), \\
                                           __tg_promote2((__x), (__y))(__y))

// nexttoward

static float
    _TG_ATTRS
    __tg_nexttoward(float __x, long double __y) {return nexttowardf(__x, __y);}

static double
    _TG_ATTRS
    __tg_nexttoward(double __x, long double __y) {return nexttoward(__x, __y);}

static long double
    _TG_ATTRS
    __tg_nexttoward(long double __x, long double __y) {return nexttowardl(__x, __y);}

#undef nexttoward
#define nexttoward(__x, __y) __tg_nexttoward(__tg_promote1((__x))(__x), (__y))

// remainder

static float
    _TG_ATTRS
    __tg_remainder(float __x, float __y) {return remainderf(__x, __y);}

static double
    _TG_ATTRS
    __tg_remainder(double __x, double __y) {return remainder(__x, __y);}

static long double
    _TG_ATTRS
    __tg_remainder(long double __x, long double __y) {return remainderl(__x, __y);}

#undef remainder
#define remainder(__x, __y) __tg_remainder(__tg_promote2((__x), (__y))(__x), \\
                                           __tg_promote2((__x), (__y))(__y))

// remquo

static float
    _TG_ATTRS
    __tg_remquo(float __x, float __y, int* __z)
    {return remquof(__x, __y, __z);}

static double
    _TG_ATTRS
    __tg_remquo(double __x, double __y, int* __z)
    {return remquo(__x, __y, __z);}

static long double
    _TG_ATTRS
    __tg_remquo(long double __x,long double __y, int* __z)
    {return remquol(__x, __y, __z);}

#undef remquo
#define remquo(__x, __y, __z)                         \\
        __tg_remquo(__tg_promote2((__x), (__y))(__x), \\
                    __tg_promote2((__x), (__y))(__y), \\
                    (__z))

// rint

static float
    _TG_ATTRS
    __tg_rint(float __x) {return rintf(__x);}

static double
    _TG_ATTRS
    __tg_rint(double __x) {return rint(__x);}

static long double
    _TG_ATTRS
    __tg_rint(long double __x) {return rintl(__x);}

#undef rint
#define rint(__x) __tg_rint(__tg_promote1((__x))(__x))

// round

static float
    _TG_ATTRS
    __tg_round(float __x) {return roundf(__x);}

static double
    _TG_ATTRS
    __tg_round(double __x) {return round(__x);}

static long double
    _TG_ATTRS
    __tg_round(long double __x) {return roundl(__x);}

#undef round
#define round(__x) __tg_round(__tg_promote1((__x))(__x))

// scalbn

static float
    _TG_ATTRS
    __tg_scalbn(float __x, int __y) {return scalbnf(__x, __y);}

static double
    _TG_ATTRS
    __tg_scalbn(double __x, int __y) {return scalbn(__x, __y);}

static long double
    _TG_ATTRS
    __tg_scalbn(long double __x, int __y) {return scalbnl(__x, __y);}

#undef scalbn
#define scalbn(__x, __y) __tg_scalbn(__tg_promote1((__x))(__x), __y)

// scalbln

static float
    _TG_ATTRS
    __tg_scalbln(float __x, long __y) {return scalblnf(__x, __y);}

static double
    _TG_ATTRS
    __tg_scalbln(double __x, long __y) {return scalbln(__x, __y);}

static long double
    _TG_ATTRS
    __tg_scalbln(long double __x, long __y) {return scalblnl(__x, __y);}

#undef scalbln
#define scalbln(__x, __y) __tg_scalbln(__tg_promote1((__x))(__x), __y)

// tgamma

static float
    _TG_ATTRS
    __tg_tgamma(float __x) {return tgammaf(__x);}

static double
    _TG_ATTRS
    __tg_tgamma(double __x) {return tgamma(__x);}

static long double
    _TG_ATTRS
    __tg_tgamma(long double __x) {return tgammal(__x);}

#undef tgamma
#define tgamma(__x) __tg_tgamma(__tg_promote1((__x))(__x))

// trunc

static float
    _TG_ATTRS
    __tg_trunc(float __x) {return truncf(__x);}

static double
    _TG_ATTRS
    __tg_trunc(double __x) {return trunc(__x);}

static long double
    _TG_ATTRS
    __tg_trunc(long double __x) {return truncl(__x);}

#undef trunc
#define trunc(__x) __tg_trunc(__tg_promote1((__x))(__x))

// carg

static float
    _TG_ATTRS
    __tg_carg(float __x) {return atan2f(0.F, __x);}

static double
    _TG_ATTRS
    __tg_carg(double __x) {return atan2(0., __x);}

static long double
    _TG_ATTRS
    __tg_carg(long double __x) {return atan2l(0.L, __x);}

static float
    _TG_ATTRS
    __tg_carg(float _Complex __x) {return cargf(__x);}

static double
    _TG_ATTRS
    __tg_carg(double _Complex __x) {return carg(__x);}

static long double
    _TG_ATTRS
    __tg_carg(long double _Complex __x) {return cargl(__x);}

#undef carg
#define carg(__x) __tg_carg(__tg_promote1((__x))(__x))

// cimag

static float
    _TG_ATTRS
    __tg_cimag(float __x) {return 0;}

static double
    _TG_ATTRS
    __tg_cimag(double __x) {return 0;}

static long double
    _TG_ATTRS
    __tg_cimag(long double __x) {return 0;}

static float
    _TG_ATTRS
    __tg_cimag(float _Complex __x) {return cimagf(__x);}

static double
    _TG_ATTRS
    __tg_cimag(double _Complex __x) {return cimag(__x);}

static long double
    _TG_ATTRS
    __tg_cimag(long double _Complex __x) {return cimagl(__x);}

#undef cimag
#define cimag(__x) __tg_cimag(__tg_promote1((__x))(__x))

// conj

static float _Complex
    _TG_ATTRS
    __tg_conj(float __x) {return __x;}

static double _Complex
    _TG_ATTRS
    __tg_conj(double __x) {return __x;}

static long double _Complex
    _TG_ATTRS
    __tg_conj(long double __x) {return __x;}

static float _Complex
    _TG_ATTRS
    __tg_conj(float _Complex __x) {return conjf(__x);}

static double _Complex
    _TG_ATTRS
    __tg_conj(double _Complex __x) {return conj(__x);}

static long double _Complex
    _TG_ATTRS
    __tg_conj(long double _Complex __x) {return conjl(__x);}

#undef conj
#define conj(__x) __tg_conj(__tg_promote1((__x))(__x))

// cproj

static float _Complex
    _TG_ATTRS
    __tg_cproj(float __x) {return cprojf(__x);}

static double _Complex
    _TG_ATTRS
    __tg_cproj(double __x) {return cproj(__x);}

static long double _Complex
    _TG_ATTRS
    __tg_cproj(long double __x) {return cprojl(__x);}

static float _Complex
    _TG_ATTRS
    __tg_cproj(float _Complex __x) {return cprojf(__x);}

static double _Complex
    _TG_ATTRS
    __tg_cproj(double _Complex __x) {return cproj(__x);}

static long double _Complex
    _TG_ATTRS
    __tg_cproj(long double _Complex __x) {return cprojl(__x);}

#undef cproj
#define cproj(__x) __tg_cproj(__tg_promote1((__x))(__x))

// creal

static float
    _TG_ATTRS
    __tg_creal(float __x) {return __x;}

static double
    _TG_ATTRS
    __tg_creal(double __x) {return __x;}

static long double
    _TG_ATTRS
    __tg_creal(long double __x) {return __x;}

static float
    _TG_ATTRS
    __tg_creal(float _Complex __x) {return crealf(__x);}

static double
    _TG_ATTRS
    __tg_creal(double _Complex __x) {return creal(__x);}

static long double
    _TG_ATTRS
    __tg_creal(long double _Complex __x) {return creall(__x);}

#undef creal
#define creal(__x) __tg_creal(__tg_promote1((__x))(__x))

#undef _TG_ATTRSp
#undef _TG_ATTRS

#endif /* __cplusplus */
#endif /* __has_include_next */
#endif /* __CLANG_TGMATH_H */
`,"unwind.h":`/*===---- unwind.h - Stack unwinding ----------------------------------------===
 *
 * Part of the LLVM Project, under the Apache License v2.0 with LLVM Exceptions.
 * See https://llvm.org/LICENSE.txt for license information.
 * SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception
 *
 *===-----------------------------------------------------------------------===
 */

/* See "Data Definitions for libgcc_s" in the Linux Standard Base.*/

#ifndef __CLANG_UNWIND_H
#define __CLANG_UNWIND_H

#if defined(__APPLE__) && __has_include_next(<unwind.h>)
/* Darwin (from 11.x on) provide an unwind.h. If that's available,
 * use it. libunwind wraps some of its definitions in #ifdef _GNU_SOURCE,
 * so define that around the include.*/
# ifndef _GNU_SOURCE
#  define _SHOULD_UNDEFINE_GNU_SOURCE
#  define _GNU_SOURCE
# endif
// libunwind's unwind.h reflects the current visibility.  However, Mozilla
// builds with -fvisibility=hidden and relies on gcc's unwind.h to reset the
// visibility to default and export its contents.  gcc also allows users to
// override its override by #defining HIDE_EXPORTS (but note, this only obeys
// the user's -fvisibility setting; it doesn't hide any exports on its own).  We
// imitate gcc's header here:
# ifdef HIDE_EXPORTS
#  include_next <unwind.h>
# else
#  pragma GCC visibility push(default)
#  include_next <unwind.h>
#  pragma GCC visibility pop
# endif
# ifdef _SHOULD_UNDEFINE_GNU_SOURCE
#  undef _GNU_SOURCE
#  undef _SHOULD_UNDEFINE_GNU_SOURCE
# endif
#else

#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

/* It is a bit strange for a header to play with the visibility of the
   symbols it declares, but this matches gcc's behavior and some programs
   depend on it */
#ifndef HIDE_EXPORTS
#pragma GCC visibility push(default)
#endif

typedef uintptr_t _Unwind_Word __attribute__((__mode__(__unwind_word__)));
typedef intptr_t _Unwind_Sword __attribute__((__mode__(__unwind_word__)));
typedef uintptr_t _Unwind_Ptr;
typedef uintptr_t _Unwind_Internal_Ptr;
typedef uint64_t _Unwind_Exception_Class;

typedef intptr_t _sleb128_t;
typedef uintptr_t _uleb128_t;

struct _Unwind_Context;
#if defined(__arm__) && !(defined(__USING_SJLJ_EXCEPTIONS__) || \\
                          defined(__ARM_DWARF_EH__) || defined(__SEH__))
struct _Unwind_Control_Block;
typedef struct _Unwind_Control_Block _Unwind_Control_Block;
#define _Unwind_Exception _Unwind_Control_Block /* Alias */
#else
struct _Unwind_Exception;
typedef struct _Unwind_Exception _Unwind_Exception;
#endif
typedef enum {
  _URC_NO_REASON = 0,
#if defined(__arm__) && !defined(__USING_SJLJ_EXCEPTIONS__) && \\
    !defined(__ARM_DWARF_EH__) && !defined(__SEH__)
  _URC_OK = 0, /* used by ARM EHABI */
#endif
  _URC_FOREIGN_EXCEPTION_CAUGHT = 1,

  _URC_FATAL_PHASE2_ERROR = 2,
  _URC_FATAL_PHASE1_ERROR = 3,
  _URC_NORMAL_STOP = 4,

  _URC_END_OF_STACK = 5,
  _URC_HANDLER_FOUND = 6,
  _URC_INSTALL_CONTEXT = 7,
  _URC_CONTINUE_UNWIND = 8,
#if defined(__arm__) && !defined(__USING_SJLJ_EXCEPTIONS__) && \\
    !defined(__ARM_DWARF_EH__) && !defined(__SEH__)
  _URC_FAILURE = 9 /* used by ARM EHABI */
#endif
} _Unwind_Reason_Code;

typedef enum {
  _UA_SEARCH_PHASE = 1,
  _UA_CLEANUP_PHASE = 2,

  _UA_HANDLER_FRAME = 4,
  _UA_FORCE_UNWIND = 8,
  _UA_END_OF_STACK = 16 /* gcc extension to C++ ABI */
} _Unwind_Action;

typedef void (*_Unwind_Exception_Cleanup_Fn)(_Unwind_Reason_Code,
                                             _Unwind_Exception *);

#if defined(__arm__) && !(defined(__USING_SJLJ_EXCEPTIONS__) || \\
                          defined(__ARM_DWARF_EH__) || defined(__SEH__))
typedef struct _Unwind_Control_Block _Unwind_Control_Block;
typedef uint32_t _Unwind_EHT_Header;

struct _Unwind_Control_Block {
  uint64_t exception_class;
  void (*exception_cleanup)(_Unwind_Reason_Code, _Unwind_Control_Block *);
  /* unwinder cache (private fields for the unwinder's use) */
  struct {
    uint32_t reserved1; /* forced unwind stop function, 0 if not forced */
    uint32_t reserved2; /* personality routine */
    uint32_t reserved3; /* callsite */
    uint32_t reserved4; /* forced unwind stop argument */
    uint32_t reserved5;
  } unwinder_cache;
  /* propagation barrier cache (valid after phase 1) */
  struct {
    uint32_t sp;
    uint32_t bitpattern[5];
  } barrier_cache;
  /* cleanup cache (preserved over cleanup) */
  struct {
    uint32_t bitpattern[4];
  } cleanup_cache;
  /* personality cache (for personality's benefit) */
  struct {
    uint32_t fnstart;         /* function start address */
    _Unwind_EHT_Header *ehtp; /* pointer to EHT entry header word */
    uint32_t additional;      /* additional data */
    uint32_t reserved1;
  } pr_cache;
  long long int : 0; /* force alignment of next item to 8-byte boundary */
} __attribute__((__aligned__(8)));
#else
struct _Unwind_Exception {
  _Unwind_Exception_Class exception_class;
  _Unwind_Exception_Cleanup_Fn exception_cleanup;
#if !defined (__USING_SJLJ_EXCEPTIONS__) && defined (__SEH__)
  _Unwind_Word private_[6];
#else
  _Unwind_Word private_1;
  _Unwind_Word private_2;
#endif
  /* The Itanium ABI requires that _Unwind_Exception objects are "double-word
   * aligned".  GCC has interpreted this to mean "use the maximum useful
   * alignment for the target"; so do we. */
} __attribute__((__aligned__));
#endif

typedef _Unwind_Reason_Code (*_Unwind_Stop_Fn)(int, _Unwind_Action,
                                               _Unwind_Exception_Class,
                                               _Unwind_Exception *,
                                               struct _Unwind_Context *,
                                               void *);

typedef _Unwind_Reason_Code (*_Unwind_Personality_Fn)(int, _Unwind_Action,
                                                      _Unwind_Exception_Class,
                                                      _Unwind_Exception *,
                                                      struct _Unwind_Context *);
typedef _Unwind_Personality_Fn __personality_routine;

typedef _Unwind_Reason_Code (*_Unwind_Trace_Fn)(struct _Unwind_Context *,
                                                void *);

#if defined(__arm__) && !(defined(__USING_SJLJ_EXCEPTIONS__) ||                \\
                          defined(__ARM_DWARF_EH__) || defined(__SEH__))
typedef enum {
  _UVRSC_CORE = 0,        /* integer register */
  _UVRSC_VFP = 1,         /* vfp */
  _UVRSC_WMMXD = 3,       /* Intel WMMX data register */
  _UVRSC_WMMXC = 4,       /* Intel WMMX control register */
  _UVRSC_PSEUDO = 5       /* Special purpose pseudo register */
} _Unwind_VRS_RegClass;

typedef enum {
  _UVRSD_UINT32 = 0,
  _UVRSD_VFPX = 1,
  _UVRSD_UINT64 = 3,
  _UVRSD_FLOAT = 4,
  _UVRSD_DOUBLE = 5
} _Unwind_VRS_DataRepresentation;

typedef enum {
  _UVRSR_OK = 0,
  _UVRSR_NOT_IMPLEMENTED = 1,
  _UVRSR_FAILED = 2
} _Unwind_VRS_Result;

typedef uint32_t _Unwind_State;
#define _US_VIRTUAL_UNWIND_FRAME  ((_Unwind_State)0)
#define _US_UNWIND_FRAME_STARTING ((_Unwind_State)1)
#define _US_UNWIND_FRAME_RESUME   ((_Unwind_State)2)
#define _US_ACTION_MASK           ((_Unwind_State)3)
#define _US_FORCE_UNWIND          ((_Unwind_State)8)

_Unwind_VRS_Result _Unwind_VRS_Get(struct _Unwind_Context *__context,
  _Unwind_VRS_RegClass __regclass,
  uint32_t __regno,
  _Unwind_VRS_DataRepresentation __representation,
  void *__valuep);

_Unwind_VRS_Result _Unwind_VRS_Set(struct _Unwind_Context *__context,
  _Unwind_VRS_RegClass __regclass,
  uint32_t __regno,
  _Unwind_VRS_DataRepresentation __representation,
  void *__valuep);

static __inline__
_Unwind_Word _Unwind_GetGR(struct _Unwind_Context *__context, int __index) {
  _Unwind_Word __value;
  _Unwind_VRS_Get(__context, _UVRSC_CORE, __index, _UVRSD_UINT32, &__value);
  return __value;
}

static __inline__
void _Unwind_SetGR(struct _Unwind_Context *__context, int __index,
                   _Unwind_Word __value) {
  _Unwind_VRS_Set(__context, _UVRSC_CORE, __index, _UVRSD_UINT32, &__value);
}

static __inline__
_Unwind_Word _Unwind_GetIP(struct _Unwind_Context *__context) {
  _Unwind_Word __ip = _Unwind_GetGR(__context, 15);
  return __ip & ~(_Unwind_Word)(0x1); /* Remove thumb mode bit. */
}

static __inline__
void _Unwind_SetIP(struct _Unwind_Context *__context, _Unwind_Word __value) {
  _Unwind_Word __thumb_mode_bit = _Unwind_GetGR(__context, 15) & 0x1;
  _Unwind_SetGR(__context, 15, __value | __thumb_mode_bit);
}
#else
_Unwind_Word _Unwind_GetGR(struct _Unwind_Context *, int);
void _Unwind_SetGR(struct _Unwind_Context *, int, _Unwind_Word);

_Unwind_Word _Unwind_GetIP(struct _Unwind_Context *);
void _Unwind_SetIP(struct _Unwind_Context *, _Unwind_Word);
#endif


_Unwind_Word _Unwind_GetIPInfo(struct _Unwind_Context *, int *);

_Unwind_Word _Unwind_GetCFA(struct _Unwind_Context *);

_Unwind_Word _Unwind_GetBSP(struct _Unwind_Context *);

void *_Unwind_GetLanguageSpecificData(struct _Unwind_Context *);

_Unwind_Ptr _Unwind_GetRegionStart(struct _Unwind_Context *);

/* DWARF EH functions; currently not available on Darwin/ARM */
#if !defined(__APPLE__) || !defined(__arm__)
_Unwind_Reason_Code _Unwind_RaiseException(_Unwind_Exception *);
_Unwind_Reason_Code _Unwind_ForcedUnwind(_Unwind_Exception *, _Unwind_Stop_Fn,
                                         void *);
void _Unwind_DeleteException(_Unwind_Exception *);
void _Unwind_Resume(_Unwind_Exception *);
_Unwind_Reason_Code _Unwind_Resume_or_Rethrow(_Unwind_Exception *);

#endif

_Unwind_Reason_Code _Unwind_Backtrace(_Unwind_Trace_Fn, void *);

/* setjmp(3)/longjmp(3) stuff */
typedef struct SjLj_Function_Context *_Unwind_FunctionContext_t;

void _Unwind_SjLj_Register(_Unwind_FunctionContext_t);
void _Unwind_SjLj_Unregister(_Unwind_FunctionContext_t);
_Unwind_Reason_Code _Unwind_SjLj_RaiseException(_Unwind_Exception *);
_Unwind_Reason_Code _Unwind_SjLj_ForcedUnwind(_Unwind_Exception *,
                                              _Unwind_Stop_Fn, void *);
void _Unwind_SjLj_Resume(_Unwind_Exception *);
_Unwind_Reason_Code _Unwind_SjLj_Resume_or_Rethrow(_Unwind_Exception *);

void *_Unwind_FindEnclosingFunction(void *);

#ifdef __APPLE__

_Unwind_Ptr _Unwind_GetDataRelBase(struct _Unwind_Context *)
    __attribute__((__unavailable__));
_Unwind_Ptr _Unwind_GetTextRelBase(struct _Unwind_Context *)
    __attribute__((__unavailable__));

/* Darwin-specific functions */
void __register_frame(const void *);
void __deregister_frame(const void *);

struct dwarf_eh_bases {
  uintptr_t tbase;
  uintptr_t dbase;
  uintptr_t func;
};
void *_Unwind_Find_FDE(const void *, struct dwarf_eh_bases *);

void __register_frame_info_bases(const void *, void *, void *, void *)
  __attribute__((__unavailable__));
void __register_frame_info(const void *, void *) __attribute__((__unavailable__));
void __register_frame_info_table_bases(const void *, void*, void *, void *)
  __attribute__((__unavailable__));
void __register_frame_info_table(const void *, void *)
  __attribute__((__unavailable__));
void __register_frame_table(const void *) __attribute__((__unavailable__));
void __deregister_frame_info(const void *) __attribute__((__unavailable__));
void __deregister_frame_info_bases(const void *)__attribute__((__unavailable__));

#else

_Unwind_Ptr _Unwind_GetDataRelBase(struct _Unwind_Context *);
_Unwind_Ptr _Unwind_GetTextRelBase(struct _Unwind_Context *);

#endif


#ifndef HIDE_EXPORTS
#pragma GCC visibility pop
#endif

#ifdef __cplusplus
}
#endif

#endif

#endif /* __CLANG_UNWIND_H */
`,"varargs.h":`/*===---- varargs.h - Variable argument handling -------------------------------------===
*
* Part of the LLVM Project, under the Apache License v2.0 with LLVM Exceptions.
* See https://llvm.org/LICENSE.txt for license information.
* SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception
*
*===-----------------------------------------------------------------------===
*/
#ifndef __VARARGS_H
#define __VARARGS_H
#if defined(__MVS__) && __has_include_next(<varargs.h>)
#include_next <varargs.h>
#else
#error "Please use <stdarg.h> instead of <varargs.h>"
#endif /* __MVS__ */
#endif
`}),W=Object.freeze({name:`clang`,version:`22.1.8`,revision:`ca7933e47d3a3451d81e72ac174dcb5aa28b59d1`});function ve(e,t,n){if(t?.name!==W.name||t.version!==W.version||t.revision!==W.revision||n!==`/lib/clang/22`)return!1;let r=new TextDecoder(`utf-8`,{fatal:!0}),i=[];for(let[a,o]of Object.entries(_e)){let s=`${n}/include/${a}`;try{let n=e.readFile(s);if(n!==null){if(r.decode(n)!==o)throw Error(`Clang ${t.version} resource header differs from its pinned source: ${a}`)}else i.push([s,o])}catch(e){throw Error(`Unable to inspect Clang ${t.version} resource header ${a}: ${e instanceof Error?e.message:String(e)}`,{cause:e})}}if(i.length)try{e.mkdirTree(`${n}/include`)}catch(e){throw Error(`Unable to prepare Clang ${t.version} resource header directory: ${e instanceof Error?e.message:String(e)}`,{cause:e})}let a=new TextEncoder;for(let[n,r]of i)try{e.writeFile(n,a.encode(r))}catch(e){throw Error(`Unable to install Clang ${t.version} resource header ${n.slice(n.lastIndexOf(`/`)+1)}: ${e instanceof Error?e.message:String(e)}`,{cause:e})}return!0}const ye=[`-fobjc-runtime=gnustep-2.0`,`-fblocks`],be=[`-DOBJC2RUNTIME=1`];function xe(e){return(e||``).trim().toUpperCase().replaceAll(/\s+/g,``)}function Se(e){switch(xe(e)){case`98`:case`CPP98`:case`C++98`:case`GNU++98`:case`GNUC++98`:return`-std=gnu++98`;case`03`:case`CPP03`:case`C++03`:case`GNU++03`:case`GNUC++03`:return`-std=gnu++03`;case`11`:case`CPP11`:case`C++11`:case`GNU++11`:case`GNUC++11`:return`-std=gnu++11`;case`14`:case`CPP14`:case`C++14`:case`GNU++14`:case`GNUC++14`:return`-std=gnu++14`;case`17`:case`CPP17`:case`C++17`:case`GNU++17`:case`GNUC++17`:return`-std=gnu++17`;case`20`:case`CPP20`:case`C++20`:case`GNU++20`:case`GNUC++20`:return`-std=gnu++20`;case`23`:case`CPP23`:case`C++23`:case`GNU++23`:case`GNUC++23`:return`-std=gnu++23`;case`26`:case`CPP26`:case`C++26`:case`GNU++26`:case`GNUC++26`:return`-std=gnu++26`;default:return`-std=gnu++20`}}function Ce(e){switch(xe(e)){case`89`:case`90`:case`C89`:case`C90`:case`GNU89`:case`GNU90`:case`GNUC89`:case`GNUC90`:return`-std=gnu89`;case`99`:case`C99`:case`GNU99`:case`GNUC99`:return`-std=gnu99`;case`11`:case`C11`:case`GNU11`:case`GNUC11`:return`-std=gnu11`;case`17`:case`18`:case`C17`:case`C18`:case`GNU17`:case`GNU18`:case`GNUC17`:case`GNUC18`:return`-std=gnu17`;case`23`:case`2X`:case`C23`:case`C2X`:case`GNU23`:case`GNU2X`:case`GNUC23`:case`GNUC2X`:return`-std=gnu23`;case`2Y`:case`C2Y`:case`GNU2Y`:case`GNUC2Y`:return`-std=gnu2y`;default:return`-std=gnu11`}}function G(e,t){return e===`C`?{languageArg:`c`,standardArg:Ce(t.cVersion)}:e===`OBJC`?{languageArg:`objective-c`,standardArg:Ce(t.cVersion)}:{languageArg:`c++`,standardArg:Se(t.cppVersion)}}function we(e,t=``,n){return[...[`CPP`,`OBJCXX`].includes(e)?[`${t}/include/c++/v1`,`${t}/include/wasm32-wasi/c++/v1`]:[],...n?[`${n.replace(/\/+$/,``)}/include`]:[],`${t}/include/wasm32-wasi`,`${t}/include`]}const K=`/workspace`,q=`${K}/main.cpp`;`${q}`;const Te=e=>e.endsWith(`/`)?e.slice(0,-1):e,Ee=(e=`CPP`,t={})=>{let n=e===`OBJCXX`?{...G(`CPP`,t),languageArg:`objective-c++`}:G(e,t),r=e===`CPP`||e===`OBJCXX`,i=t.sourceLanguage===`CPP`||t.sourceLanguage===`OBJCXX`,a=r?/^-std=(?:(?:c|gnu)\d|iso9899:)/:/^-std=(?:c|gnu)\+\+/,o=t.sourceLanguage&&r!==i?(t.compileArgs??[]).filter(e=>!a.test(e)):t.compileArgs??[],s=o.includes(`-nostdinc`),c=s||o.includes(`-nostdlibinc`)||o.some(e=>e===`--sysroot`||e.startsWith(`--sysroot=`)||e.startsWith(`-isysroot`)),l=s||o.includes(`-nobuiltininc`),u=l?void 0:t.resourceDir,d=c?u?[`${u.replace(/\/+$/,``)}/include`]:[]:we(o.includes(`-nostdinc++`)?`C`:e,`/usr`,u);return[n.standardArg,`-x`,n.languageArg,`--target=wasm32-wasip1`,...t.simd===!1?[]:he(`/usr`,!l),...t.resourceDir?[`-resource-dir`,t.resourceDir]:[],...d.map(e=>`-isystem${e}`),...e===`OBJC`||e===`OBJCXX`?[...ye.flatMap(e=>e.startsWith(`-fobjc-runtime=`)?[`-Xclang`,e]:[e]),...be,`-I/objc`,`-I/objc/objc`]:[],...o]},De=(e={})=>{let t={C:[`c`],CPP:[`cc`,`cpp`,`cxx`,`hh`,`hpp`,`hxx`],OBJC:[`m`],OBJCXX:[`mm`]};return t[e.sourceLanguage??`CPP`].push(`h`),[`C`,`CPP`,`OBJC`,`OBJCXX`].map(n=>JSON.stringify({If:{PathMatch:`.*\\.(${t[n].join(`|`)})`},CompileFlags:{Add:Ee(n,e)}})).join(`
---
`)};var J=class{chunks=[];chunkIndex=0;offset=0;readable=!1;waiters=[];get hasBytes(){return this.chunkIndex<this.chunks.length}push(e){if(e.byteLength){this.chunks.push(e);for(let e of this.waiters.splice(0))e()}}read(){if(!this.readable)return null;let e=this.chunks[this.chunkIndex];if(!e)return null;let t=e[this.offset++];return this.offset===e.length&&(this.readable=!1,this.offset=0,this.chunkIndex++,this.chunkIndex===this.chunks.length?(this.chunks=[],this.chunkIndex=0):this.chunkIndex>=64&&(this.chunks=this.chunks.slice(this.chunkIndex),this.chunkIndex=0)),t}async ready(){this.hasBytes||await new Promise(e=>this.waiters.push(e)),this.readable=!0}};const Y=new TextEncoder,Oe=`${K}/`;function ke(e){let t=j(e.startsWith(Oe)?e.slice(Oe.length):e),n=Y.encode(t).byteLength;if(n>O.maxPathBytes)throw new D(`path-size-limit`,`Clangd workspace path ${t} is ${n} bytes; limit is ${O.maxPathBytes}`,{path:t,limit:O.maxPathBytes,actual:n});return`${Oe}${t}`}var X=class{maxFiles;paths=/* @__PURE__ */ new Set([q]);constructor(e=O.maxFiles){if(this.maxFiles=e,!Number.isSafeInteger(e)||e<1)throw new D(`invalid-limit`,`Clangd workspace file limit must be a positive safe integer`)}register(e){let t=ke(e);if(this.paths.has(t))return{path:t,added:!1};let n=this.paths.size+1;if(n>this.maxFiles)throw new D(`file-count-limit`,`Clangd workspace contains ${n} files; limit is ${this.maxFiles}`,{limit:this.maxFiles,actual:n});return this.paths.add(t),{path:t,added:!0}}unregister(e){e!==q&&this.paths.delete(e)}};function Ae(e){if(!e||typeof e!=`object`||Array.isArray(e))throw Error(`Invalid clangd header asset metadata`);let t=e;if(!t||t.schemaVersion!==1||typeof t.version!=`string`||!t.version||typeof t.targetTriple!=`string`||!/^wasm32-[a-z0-9]+(?:-[a-z0-9]+)*$/.test(t.targetTriple)||typeof t.resourceDir!=`string`||!/^\/lib\/clang\/[a-zA-Z0-9_.-]+$/.test(t.resourceDir)||!t.files||typeof t.files!=`object`||Array.isArray(t.files))throw Error(`Invalid clangd header asset metadata`);let n=t.files,r=[`/usr/include/`,`${t.resourceDir}/include/`];for(let[e,t]of Object.entries(n))if(!r.some(t=>e.startsWith(t))||e.slice(1).split(`/`).some(e=>!e||e===`.`||e===`..`)||/[\\\x00-\x1f]/u.test(e)||typeof t!=`string`)throw Error(`Invalid clangd header path or contents`);for(let e of[`/usr/include/${t.targetTriple}/stdio.h`,`/usr/include/c++/v1/vector`,`${t.resourceDir}/include/stddef.h`])if(!Object.hasOwn(n,e)||typeof n[e]!=`string`)throw Error(`Required clangd asset header is missing: ${e}`);return{schemaVersion:1,version:t.version,targetTriple:t.targetTriple,resourceDir:t.resourceDir,files:n}}function je(e,t){let n=Ae(t);for(let[t,r]of Object.entries(n.files))e.mkdirTree(t.slice(0,t.lastIndexOf(`/`))),e.writeFile(t,r);return n.resourceDir}const Me=new TextEncoder,Ne=new TextDecoder,Z=new le,Pe=new J;let Fe=!1,Ie=``;const Le=e=>{let t=e;return!t||typeof t!=`object`?typeof e:typeof t.method==`string`?t.method:t.id===void 0?`unknown`:`response:${String(t.id)}`},Re=e=>{let t=e;return!!t&&typeof t==`object`&&t.jsonrpc===`2.0`},Q=(...e)=>{Fe&&console.debug(`[wasm-idle:clangd-worker]`,...e)},ze=()=>Pe.read(),Be=()=>Pe.ready();let Ve=null,$=null;const He=new X,Ue=e=>{let t=Z.insert(e);if(!t||!Ve)return;let n=JSON.parse(t);Q(`stdout`,Le(n)),Ve.write(n)},We=e=>{if(Fe){if(e===10||e===13){Ie&&Q(`stderr`,Ie),Ie=``;return}Ie+=String.fromCharCode(e)}},Ge=()=>{Ve?.end(),self.reportError?.(`clangd aborted`)},Ke=e=>{let t=ke(e);if(!$)return;let n=He.register(t),r=n.path.lastIndexOf(`/`),i=r>0?n.path.slice(0,r):K;try{$.FS.mkdirTree(i),$.FS.writeFile(n.path,``)}catch(e){throw n.added&&He.unregister(n.path),e}};self.addEventListener(`message`,async e=>{if(e.data?.type===`sync-file`){try{if(typeof e.data.name!=`string`)throw TypeError(`clangd sync-file name must be a string`);Ke(e.data.name)}catch(e){self.postMessage({type:`error`,message:`Failed to sync clangd workspace file: ${e instanceof Error?e.message:String(e)}`})}return}if(e.data?.type===`init`){Fe=!!e.data.debug;try{if(typeof e.data.baseUrl!=`string`||!e.data.baseUrl.trim())throw Error(`clangd init requires an explicit baseUrl`);let t=Te(e.data.baseUrl.trim())+`/`;if(Q(`init`,t),!e.data.assets)throw Error(`clangd init requires preloaded runtime assets`);let n=new Uint8Array(e.data.assets.clangdJs);self.postMessage({type:`progress`,stage:`module-loading`,value:1,max:3});let r=Ne.decode(n),i=URL.createObjectURL(new Blob([r],{type:`text/javascript;charset=utf-8`})),a=e.data.assets.clangdModule,o;if(!a){if(!e.data.assets.clangdWasmGz)throw Error(`clangd init requires Wasm bytes or a verified Module`);let t=new Uint8Array(e.data.assets.clangdWasmGz);self.postMessage({type:`progress`,stage:`decompression`,value:2,max:3}),o=await U(t,`clangd.wasm.gz`)}o&&e.data.assets.clangdWasmIntegrity&&await E({asset:`clangd.wasm.gz`,bytes:o,expected:e.data.assets.clangdWasmIntegrity,stage:`uncompressed`,mimeType:`application/wasm`,runtimeId:`clangd`}),self.postMessage({type:`progress`,stage:`wasm-initialization`,value:3,max:3});let s;if(o){let e=new Blob([Uint8Array.from(o).buffer],{type:`application/wasm`});s=URL.createObjectURL(e)}else if(!(a instanceof WebAssembly.Module)||!Number.isSafeInteger(e.data.assets.clangdWasmBytes)||e.data.assets.clangdWasmBytes<=0||e.data.assets.clangdWasmBytes>134217728||!/^[a-f0-9]{64}$/.test(e.data.assets.clangdWasmSha256||``))throw Error(`Invalid prepared clangd Module metadata`);let{default:c}=await import(
/* @vite-ignore */
i);$=await c({thisProgram:`/usr/bin/clangd`,mainScriptUrlOrBlob:i,locateFile:(e,t)=>e.endsWith(`.wasm`)&&s?s:`${t}${e}`,...a?{instantiateWasm:(e,t)=>{let n=new WebAssembly.Instance(a,e);return t(n,a),n.exports}}:{},stdinReady:Be,stdin:ze,stdout:Ue,stderr:We,onExit:Ge,onAbort:Ge}),$.FS.mkdirTree(K),ce($.FS,`/usr`);let l=e.data.assets.clangdWasmSha256||e.data.assets.clangdWasmIntegrity?.uncompressedSha256||Array.from(new Uint8Array(await crypto.subtle.digest(`SHA-256`,Uint8Array.from(o))),e=>e.toString(16).padStart(2,`0`)).join(``),u=[`0d71e7a7f8e6dd369cb2a0b22cc4016d649f370e5b905adb6092536deb0ee019`,`f2bef5c4b4aa8691f0b996286231c5778a17119c41537ae4108c7ff2795f7fc3`,`f712eb98cba42f560121a09b655567a5fbc900e6568a29a9c6949d81a17fec5c`].includes(l),d=e.data.assets.clangdHeaders?je($.FS,e.data.assets.clangdHeaders):u?`/lib/clang/22`:void 0;d&&!e.data.assets.clangdHeaders&&ve({readFile:e=>$.FS.analyzePath(e).exists?$.FS.readFile(e):null,mkdirTree:e=>$.FS.mkdirTree(e),writeFile:(e,t)=>$.FS.writeFile(e,t)},W,d);let f=u&&d===`/lib/clang/22`;f&&ge($.FS,`/usr`),Ke(q),$.FS.writeFile(`${K}/.clangd`,De({...e.data.compileProfile,resourceDir:d,simd:f}));for(let[t,n]of Object.entries(e.data.assets.objectiveCHeaders||{})){if(!t||t.startsWith(`/`)||t.split(`/`).some(e=>!e||e===`..`||e===`.`)||/[\\\x00-\x1f]/u.test(t)||typeof n!=`string`)throw Error(`Invalid Objective-C header path or contents`);let e=`/objc/${t}`;$.FS.mkdirTree(e.slice(0,e.lastIndexOf(`/`))),$.FS.writeFile(e,n)}Q(`callMain start`);let p=$.callMain([]);Q(`callMain returned`,p),Ve=new S(self),new re(self).listen(e=>{if(!Re(e)){Q(`ignored control message`,Le(e));return}Q(`stdin message`,Le(e));let t=JSON.stringify(e).replace(/[\u007F-\uFFFF]/g,e=>`\\u`+e.codePointAt(0)?.toString(16).padStart(4,`0`)),n=Me.encode(t).byteLength;Pe.push(Me.encode(`Content-Length: ${n}\r\n\r\n${t}`)),Q(`stdin queued bytes`,n)}),self.postMessage({type:`ready`,value:o?.byteLength??e.data.assets.clangdWasmBytes})}catch(e){self.postMessage({type:`error`,message:e instanceof Error?e.message:String(e)})}}});