""" logging API ('producers' and 'consumers' connected via keywords) """

